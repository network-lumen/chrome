const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/vendor-cosmjs-CHW-r_ld.js","assets/vendor-Ds0KLgep.js"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { r as m, j as e, u as lt, S as ss, Q as rs, C as ns, V as tt, a as st, R as je, b as Qe, X as Fe, c as as, d as _t, e as os, A as is, f as ls, E as rt, g as nt, I as at, h as ct, i as Mt, k as ot, l as Ae, T as cs, m as Ye, U as ds, n as Rt, o as Xe, p as ms, q as us, s as xs, t as hs, v as ft, P as ps, w as fs, x as $t, B as gs, y as gt, z as le, N as me, D as bs, H as ys, __tla as __tla_0 } from "./assets/vendor-react-B5kArZaE.js";
import { k as ce, l as ie, m as M, n as Be, s as Te, o as vs, p as Dt, q as js, r as He, u as Ve, v as qt, w as qe } from "./assets/vendor-cosmjs-CHW-r_ld.js";
import { p as te } from "./assets/vendor-lumen-BPhhsvED.js";
import { R as J } from "./assets/vendor-Ds0KLgep.js";
import { R as $e, N as Y, V, a as bt } from "./assets/network-Bu5WsoSQ.js";
Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  var _a;
  (function() {
    const s = document.createElement("link").relList;
    if (s && s.supports && s.supports("modulepreload")) return;
    for (const n of document.querySelectorAll('link[rel="modulepreload"]')) a(n);
    new MutationObserver((n) => {
      for (const l of n) if (l.type === "childList") for (const i of l.addedNodes) i.tagName === "LINK" && i.rel === "modulepreload" && a(i);
    }).observe(document, {
      childList: true,
      subtree: true
    });
    function r(n) {
      const l = {};
      return n.integrity && (l.integrity = n.integrity), n.referrerPolicy && (l.referrerPolicy = n.referrerPolicy), n.crossOrigin === "use-credentials" ? l.credentials = "include" : n.crossOrigin === "anonymous" ? l.credentials = "omit" : l.credentials = "same-origin", l;
    }
    function a(n) {
      if (n.ep) return;
      n.ep = true;
      const l = r(n);
      fetch(n.href, l);
    }
  })();
  class De {
    static async createWallet() {
      const s = await ce.DirectSecp256k1HdWallet.generate(24, {
        prefix: "lmn"
      }), r = await s.getAccounts(), a = await te.createKeyPair("dilithium3"), n = J.from(a.publicKey), l = J.from(a.privateKey);
      if (l.length !== 4e3) throw new Error("Invalid PQC Private Key Length");
      if (n.length !== 1952) throw new Error("Invalid PQC Public Key Length");
      const i = {
        scheme: "dilithium3",
        publicKey: n.toString("hex"),
        privateKey: l.toString("hex"),
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      return {
        mnemonic: s.mnemonic,
        address: r[0].address,
        pqcKey: i
      };
    }
    static async importWallet(s, r) {
      let a, n, l;
      if (typeof s == "string" && s.split(" ").length >= 12) a = s, n = r, l = (await (await ce.DirectSecp256k1HdWallet.fromMnemonic(a, {
        prefix: "lmn"
      })).getAccounts())[0].address;
      else {
        let c;
        if (typeof s == "string") try {
          c = JSON.parse(s);
        } catch {
          throw new Error("Invalid Wallet JSON string");
        }
        else c = s;
        if (!c.mnemonic || !c.address) throw new Error("Invalid Wallet Backup: Missing mnemonic or address");
        a = c.mnemonic, l = c.address, n = c;
      }
      if (!n) throw new Error("Missing PQC Key Data for import");
      const d = this.normalizePqcInput(n);
      return {
        type: "lumen/dual-signer",
        version: 1,
        mnemonic: a,
        address: l,
        pqcKey: d
      };
    }
    static normalizePqcInput(s) {
      const r = s["validator-pqc"] || s.pqc || s.pqcKey || s;
      if (!r) throw new Error("Could not find PQC data in file");
      const a = r.private_key || r.privateKey || r.encryptedPrivateKey, n = r.public_key || r.publicKey;
      if (!a) throw new Error("Missing Private Key (checked private_key/privateKey)");
      const l = (c) => {
        if (!c) return "";
        const u = c.trim();
        return /^[0-9a-fA-F]+$/.test(u) ? u : J.from(u, "base64").toString("hex");
      }, i = l(a);
      let d = l(n);
      if ((!d || d.length === 0) && i.length === 8e3 && (d = i.substring(0, 3904)), i.length !== 8e3) throw new Error(`Invalid Private Key Length: ${i.length} (Expected 8000 hex chars)`);
      if (d.length !== 3904) throw new Error(`Invalid Public Key Length: ${d.length} (Expected 3904 hex chars)`);
      return {
        scheme: "dilithium3",
        privateKey: i,
        publicKey: d,
        createdAt: r.created_at || r.createdAt || (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    static async recoverFromMnemonic(s) {
      const a = await (await ce.DirectSecp256k1HdWallet.fromMnemonic(s, {
        prefix: "lmn"
      })).getAccounts(), n = await te.createKeyPair("dilithium3"), l = J.from(n.publicKey), i = J.from(n.privateKey), d = {
        scheme: "dilithium3",
        publicKey: l.toString("hex"),
        privateKey: i.toString("hex"),
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      return {
        type: "lumen/dual-signer",
        version: 1,
        mnemonic: s,
        address: a[0].address,
        pqcKey: d
      };
    }
    static async deriveAddress(s) {
      return this.deriveAddressWithPrefix(s, "lmn");
    }
    static async deriveAddressWithPrefix(s, r) {
      return (await (await ce.DirectSecp256k1HdWallet.fromMnemonic(s, {
        prefix: r
      })).getAccounts())[0].address;
    }
  }
  const ws = ({ onConfirm: t }) => {
    const [s, r] = m.useState(""), [a, n] = m.useState(""), [l, i] = m.useState(""), [d, c] = m.useState(false), [u, x] = m.useState(false), b = ((o) => o.length === 0 ? {
      strength: 0,
      label: "",
      color: ""
    } : o.length < 6 ? {
      strength: 1,
      label: "Too Short",
      color: "bg-red-500"
    } : o.length < 8 ? {
      strength: 2,
      label: "Weak",
      color: "bg-orange-500"
    } : o.length < 12 ? {
      strength: 3,
      label: "Good",
      color: "bg-yellow-500"
    } : {
      strength: 4,
      label: "Strong",
      color: "bg-green-500"
    })(s), h = () => {
      if (s.length < 6) {
        i("Password must be at least 6 characters.");
        return;
      }
      if (s !== a) {
        i("Passwords do not match.");
        return;
      }
      t(s);
    };
    return e.jsxs("div", {
      className: "flex flex-col h-full justify-between p-8 animate-fade-in",
      children: [
        e.jsxs("div", {
          className: "flex-1 flex flex-col justify-center",
          children: [
            e.jsxs("div", {
              className: "text-center mb-8",
              children: [
                e.jsxs("div", {
                  className: "relative w-16 h-16 mx-auto mb-4",
                  children: [
                    e.jsx("div", {
                      className: "absolute inset-0 bg-primary/20 rounded-full blur-xl"
                    }),
                    e.jsx("div", {
                      className: "relative w-full h-full bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center",
                      children: e.jsx("svg", {
                        className: "w-8 h-8 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                        })
                      })
                    })
                  ]
                }),
                e.jsx("h2", {
                  className: "text-2xl font-bold text-foreground mb-2 tracking-tight",
                  children: "Secure Your Wallet"
                }),
                e.jsx("p", {
                  className: "text-[var(--text-muted)] text-sm leading-relaxed max-w-sm mx-auto",
                  children: "Create a strong password to encrypt your wallet. This password is stored locally and cannot be recovered."
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-5",
              children: [
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-semibold text-[var(--text-muted)] ml-1 uppercase tracking-wide",
                      children: "New Password"
                    }),
                    e.jsxs("div", {
                      className: "relative",
                      children: [
                        e.jsx("input", {
                          type: d ? "text" : "password",
                          value: s,
                          onChange: (o) => {
                            r(o.target.value), i("");
                          },
                          onKeyDown: (o) => o.key === "Enter" && a && h(),
                          className: "w-full bg-surface border-2 border-border rounded-xl p-4 pr-12 text-foreground focus:border-primary outline-none transition-all placeholder:text-[var(--text-dim)]",
                          placeholder: "Enter password",
                          autoFocus: true
                        }),
                        e.jsx("button", {
                          type: "button",
                          onClick: () => c(!d),
                          className: "absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-foreground transition-colors",
                          children: d ? e.jsx("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: e.jsx("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: 2,
                              d: "M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                            })
                          }) : e.jsxs("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: [
                              e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                              }),
                              e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                              })
                            ]
                          })
                        })
                      ]
                    }),
                    s && e.jsxs("div", {
                      className: "space-y-1.5 mt-2",
                      children: [
                        e.jsx("div", {
                          className: "flex gap-1",
                          children: [
                            1,
                            2,
                            3,
                            4
                          ].map((o) => e.jsx("div", {
                            className: `h-1 flex-1 rounded-full transition-all ${o <= b.strength ? b.color : "bg-border"}`
                          }, o))
                        }),
                        b.label && e.jsxs("p", {
                          className: "text-xs text-[var(--text-muted)] ml-1",
                          children: [
                            "Password strength: ",
                            e.jsx("span", {
                              className: "font-semibold",
                              children: b.label
                            })
                          ]
                        })
                      ]
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-semibold text-[var(--text-muted)] ml-1 uppercase tracking-wide",
                      children: "Confirm Password"
                    }),
                    e.jsxs("div", {
                      className: "relative",
                      children: [
                        e.jsx("input", {
                          type: u ? "text" : "password",
                          value: a,
                          onChange: (o) => {
                            n(o.target.value), i("");
                          },
                          onKeyDown: (o) => o.key === "Enter" && s && h(),
                          className: "w-full bg-surface border-2 border-border rounded-xl p-4 pr-12 text-foreground focus:border-primary outline-none transition-all placeholder:text-[var(--text-dim)]",
                          placeholder: "Confirm password"
                        }),
                        e.jsx("button", {
                          type: "button",
                          onClick: () => x(!u),
                          className: "absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-foreground transition-colors",
                          children: u ? e.jsx("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: e.jsx("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: 2,
                              d: "M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                            })
                          }) : e.jsxs("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: [
                              e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                              }),
                              e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                              })
                            ]
                          })
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            l && e.jsxs("div", {
              className: "mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-2",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5 text-red-500 shrink-0 mt-0.5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  })
                }),
                e.jsx("p", {
                  className: "text-red-400 text-sm",
                  children: l
                })
              ]
            }),
            e.jsx("div", {
              className: "mt-6 p-4 bg-surface/50 border border-border rounded-xl",
              children: e.jsxs("div", {
                className: "flex items-start gap-3",
                children: [
                  e.jsx("svg", {
                    className: "w-5 h-5 text-primary shrink-0 mt-0.5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    })
                  }),
                  e.jsxs("div", {
                    className: "text-xs text-[var(--text-muted)] leading-relaxed",
                    children: [
                      e.jsx("p", {
                        className: "font-semibold text-foreground mb-1",
                        children: "Important Security Notice"
                      }),
                      e.jsxs("ul", {
                        className: "space-y-1 list-disc list-inside",
                        children: [
                          e.jsx("li", {
                            children: "This password encrypts your wallet locally"
                          }),
                          e.jsx("li", {
                            children: "We cannot recover or reset your password"
                          }),
                          e.jsx("li", {
                            children: "Use a strong, unique password"
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            })
          ]
        }),
        e.jsx("button", {
          onClick: h,
          disabled: !s || !a || s.length < 6,
          className: "w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-hover hover:to-primary disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100",
          children: "Secure Wallet"
        })
      ]
    });
  }, Ns = ({ onCreateNew: t, onImportExisting: s, onBack: r }) => e.jsx("div", {
    className: "flex flex-col items-center justify-start w-full min-h-screen animate-fade-in bg-gradient-to-b from-background via-background to-surface overflow-y-auto",
    children: e.jsxs("div", {
      className: "w-full max-w-lg mx-auto flex flex-col items-center py-16 px-8 my-auto",
      children: [
        e.jsxs("div", {
          className: "text-center mb-12 w-full",
          children: [
            e.jsxs("div", {
              className: "relative w-28 h-28 mx-auto mb-8 group",
              children: [
                e.jsx("div", {
                  className: "absolute inset-0 bg-gradient-to-r from-primary via-lumen to-primary-light rounded-full blur-3xl opacity-40 group-hover:opacity-60 transition-all duration-700 animate-pulse-slow"
                }),
                e.jsx("img", {
                  src: "/icons/logo.png",
                  alt: "Lumen Wallet",
                  className: "w-full h-full object-contain relative z-10 transform group-hover:scale-105 transition-transform duration-500"
                })
              ]
            }),
            e.jsx("h1", {
              className: "text-4xl font-bold text-foreground mb-4 font-display tracking-tight text-center",
              children: "Welcome to Lumen"
            }),
            e.jsx("p", {
              className: "text-[var(--text-muted)] text-base leading-relaxed max-w-sm mx-auto text-center px-4",
              children: "The most secure and user-friendly wallet for the Lumen blockchain"
            })
          ]
        }),
        e.jsxs("div", {
          className: "grid grid-cols-2 gap-3 mb-10 w-full px-2",
          children: [
            e.jsxs("div", {
              className: "flex flex-col items-center gap-2 p-4 bg-surface/30 border border-border/50 rounded-2xl hover:border-primary/40 transition-all group text-center",
              children: [
                e.jsx("div", {
                  className: "w-10 h-10 bg-gradient-to-br from-primary to-primary-light rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform shadow-lg shadow-primary/10 mb-1",
                  children: e.jsx("svg", {
                    className: "w-5 h-5 text-white",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    })
                  })
                }),
                e.jsx("h3", {
                  className: "font-semibold text-foreground text-sm",
                  children: "Quantum Safe"
                }),
                e.jsx("p", {
                  className: "text-[10px] text-[var(--text-muted)] leading-tight",
                  children: "Post-quantum cryptography"
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex flex-col items-center gap-2 p-4 bg-surface/30 border border-border/50 rounded-2xl hover:border-primary/40 transition-all group text-center",
              children: [
                e.jsx("div", {
                  className: "w-10 h-10 bg-gradient-to-br from-lumen to-primary rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform shadow-lg shadow-primary/10 mb-1",
                  children: e.jsx("svg", {
                    className: "w-5 h-5 text-white",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M13 10V3L4 14h7v7l9-11h-7z"
                    })
                  })
                }),
                e.jsx("h3", {
                  className: "font-semibold text-foreground text-sm",
                  children: "Fast & Secure"
                }),
                e.jsx("p", {
                  className: "text-[10px] text-[var(--text-muted)] leading-tight",
                  children: "Enterprise-grade security"
                })
              ]
            }),
            e.jsxs("div", {
              className: "col-span-2 flex items-center gap-4 p-4 bg-surface/30 border border-border/50 rounded-2xl hover:border-primary/40 transition-all group",
              children: [
                e.jsx("div", {
                  className: "w-10 h-10 bg-gradient-to-br from-primary-light to-lumen rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform shadow-lg shadow-primary/10",
                  children: e.jsx("svg", {
                    className: "w-5 h-5 text-white",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    })
                  })
                }),
                e.jsxs("div", {
                  className: "text-left",
                  children: [
                    e.jsx("h3", {
                      className: "font-semibold text-foreground text-sm",
                      children: "Non-Custodial"
                    }),
                    e.jsx("p", {
                      className: "text-[10px] text-[var(--text-muted)] leading-tight",
                      children: "Your keys, your crypto. Full control over your assets."
                    })
                  ]
                })
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "space-y-4 w-full",
          children: [
            e.jsxs("button", {
              onClick: t,
              className: "w-full bg-primary hover:bg-primary-hover text-white font-bold py-4 rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98] shadow-[0_0_20px_rgba(99,102,241,0.3)] hover:shadow-[0_0_30px_rgba(99,102,241,0.5)] text-base group overflow-hidden relative",
              children: [
                e.jsxs("span", {
                  className: "relative z-10 flex items-center justify-center gap-2",
                  children: [
                    "Create New Wallet",
                    e.jsx("svg", {
                      className: "w-5 h-5 group-hover:translate-x-1 transition-transform",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M13 7l5 5m0 0l-5 5m5-5H6"
                      })
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer"
                })
              ]
            }),
            e.jsx("button", {
              onClick: s,
              className: "w-full bg-surface/50 hover:bg-surfaceHighlight border-2 border-border/60 hover:border-primary/40 text-primary font-bold py-4 rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98] text-base",
              children: "Import Existing Wallet"
            }),
            r && e.jsxs("button", {
              onClick: r,
              className: "w-full py-2 text-sm font-semibold text-[var(--text-muted)] hover:text-primary transition-colors flex items-center justify-center gap-2 group/back",
              children: [
                e.jsx("svg", {
                  className: "w-4 h-4 group-hover/back:-translate-x-1 transition-transform",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M10 19l-7-7m0 0l7-7m-7 7h18"
                  })
                }),
                "Back to Dashboard"
              ]
            }),
            e.jsxs("p", {
              className: "text-[10px] text-[var(--text-muted)] text-center leading-relaxed px-4 pt-4",
              children: [
                "By continuing, you agree to our",
                " ",
                e.jsx("a", {
                  href: "#",
                  className: "text-primary hover:underline font-medium",
                  children: "Terms"
                }),
                " ",
                "and",
                " ",
                e.jsx("a", {
                  href: "#",
                  className: "text-primary hover:underline font-medium",
                  children: "Privacy Policy"
                })
              ]
            })
          ]
        })
      ]
    })
  }), ks = ({ onSelectMnemonic: t, onSelectImport: s, onBack: r }) => e.jsxs("div", {
    className: "flex flex-col h-full justify-between p-8 animate-fade-in",
    children: [
      e.jsxs("div", {
        className: "flex-1 flex flex-col justify-center",
        children: [
          e.jsxs("div", {
            className: "text-center mb-10",
            children: [
              e.jsxs("div", {
                className: "relative w-16 h-16 mx-auto mb-6",
                children: [
                  e.jsx("div", {
                    className: "absolute inset-0 bg-primary/20 rounded-full blur-xl"
                  }),
                  e.jsx("div", {
                    className: "relative w-full h-full bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center",
                    children: e.jsx("svg", {
                      className: "w-8 h-8 text-white",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M12 4v16m8-8H4"
                      })
                    })
                  })
                ]
              }),
              e.jsx("h2", {
                className: "text-2xl font-bold text-foreground mb-2 tracking-tight",
                children: "Create New Wallet"
              }),
              e.jsx("p", {
                className: "text-[var(--text-muted)] text-sm leading-relaxed max-w-sm mx-auto",
                children: "Choose how you'd like to create your wallet"
              })
            ]
          }),
          e.jsxs("div", {
            className: "space-y-4 max-w-md mx-auto w-full",
            children: [
              e.jsx("button", {
                onClick: t,
                className: "w-full p-6 bg-surface border-2 border-border hover:border-primary rounded-xl transition-all text-left group hover:scale-[1.02] active:scale-[0.98] transform",
                children: e.jsxs("div", {
                  className: "flex items-start gap-4",
                  children: [
                    e.jsx("div", {
                      className: "w-12 h-12 bg-gradient-to-br from-primary to-primary-light rounded-lg flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform",
                      children: e.jsx("svg", {
                        className: "w-6 h-6 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        })
                      })
                    }),
                    e.jsxs("div", {
                      className: "flex-1",
                      children: [
                        e.jsx("h3", {
                          className: "font-bold text-foreground mb-1 text-lg",
                          children: "Create with Mnemonic"
                        }),
                        e.jsx("p", {
                          className: "text-sm text-[var(--text-muted)] leading-relaxed mb-2",
                          children: "Generate a new 24-word recovery phrase"
                        }),
                        e.jsxs("div", {
                          className: "flex items-center gap-2 text-xs text-primary font-medium",
                          children: [
                            e.jsx("span", {
                              children: "Recommended for new users"
                            }),
                            e.jsx("svg", {
                              className: "w-4 h-4",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M9 5l7 7-7 7"
                              })
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              }),
              e.jsx("button", {
                onClick: s,
                className: "w-full p-6 bg-surface border-2 border-border hover:border-primary rounded-xl transition-all text-left group hover:scale-[1.02] active:scale-[0.98] transform",
                children: e.jsxs("div", {
                  className: "flex items-start gap-4",
                  children: [
                    e.jsx("div", {
                      className: "w-12 h-12 bg-gradient-to-br from-lumen to-primary-light rounded-lg flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform",
                      children: e.jsx("svg", {
                        className: "w-6 h-6 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        })
                      })
                    }),
                    e.jsxs("div", {
                      className: "flex-1",
                      children: [
                        e.jsx("h3", {
                          className: "font-bold text-foreground mb-1 text-lg",
                          children: "Import Existing Wallet"
                        }),
                        e.jsx("p", {
                          className: "text-sm text-[var(--text-muted)] leading-relaxed mb-2",
                          children: "Restore from recovery phrase or private key"
                        }),
                        e.jsxs("div", {
                          className: "flex items-center gap-2 text-xs text-[var(--text-muted)] font-medium",
                          children: [
                            e.jsx("span", {
                              children: "For existing wallet users"
                            }),
                            e.jsx("svg", {
                              className: "w-4 h-4",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M9 5l7 7-7 7"
                              })
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              })
            ]
          }),
          e.jsx("div", {
            className: "mt-8 p-4 bg-surface/50 border border-border rounded-xl max-w-md mx-auto w-full",
            children: e.jsxs("div", {
              className: "flex items-start gap-3",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5 text-primary shrink-0 mt-0.5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  })
                }),
                e.jsxs("div", {
                  className: "text-xs text-[var(--text-muted)] leading-relaxed",
                  children: [
                    e.jsx("p", {
                      className: "font-semibold text-foreground mb-1",
                      children: "Security Notice"
                    }),
                    e.jsx("p", {
                      children: "Your recovery phrase is the only way to restore your wallet. Keep it safe and never share it with anyone."
                    })
                  ]
                })
              ]
            })
          })
        ]
      }),
      e.jsxs("button", {
        onClick: r,
        className: "w-full text-[var(--text-muted)] hover:text-foreground font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2",
        children: [
          e.jsx("svg", {
            className: "w-5 h-5",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "currentColor",
            children: e.jsx("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: 2,
              d: "M15 19l-7-7 7-7"
            })
          }),
          "Back"
        ]
      })
    ]
  }), Cs = ({ mnemonic: t, pqcKey: s, address: r, onConfirm: a, onBack: n }) => {
    const [l, i] = m.useState(false), [d, c] = m.useState(false), u = t.split(" "), x = () => {
      navigator.clipboard.writeText(t), i(true), setTimeout(() => i(false), 2e3);
    }, v = () => {
      const b = JSON.stringify({
        pqcKey: s
      }, null, 2), h = new Blob([
        b
      ], {
        type: "application/json"
      }), o = URL.createObjectURL(h), y = document.createElement("a");
      y.href = o, y.download = `lumen_pqc_${r.substring(0, 8)}.json`, document.body.appendChild(y), y.click(), document.body.removeChild(y), URL.revokeObjectURL(o);
    };
    return e.jsxs("div", {
      className: "flex flex-col h-full justify-between p-8 animate-fade-in overflow-y-auto",
      children: [
        e.jsxs("div", {
          className: "flex-1",
          children: [
            e.jsxs("div", {
              className: "text-center mb-6",
              children: [
                e.jsxs("div", {
                  className: "relative w-16 h-16 mx-auto mb-4",
                  children: [
                    e.jsx("div", {
                      className: "absolute inset-0 bg-primary/20 rounded-full blur-xl"
                    }),
                    e.jsx("div", {
                      className: "relative w-full h-full bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center",
                      children: e.jsx("svg", {
                        className: "w-8 h-8 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        })
                      })
                    })
                  ]
                }),
                e.jsx("h2", {
                  className: "text-2xl font-bold text-foreground mb-2 tracking-tight",
                  children: "Secret Recovery Phrase"
                }),
                e.jsx("p", {
                  className: "text-[var(--text-muted)] text-sm leading-relaxed max-w-sm mx-auto",
                  children: "Write down these 24 words in order and store them safely"
                })
              ]
            }),
            e.jsx("div", {
              className: "mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-xl",
              children: e.jsxs("div", {
                className: "flex items-start gap-3",
                children: [
                  e.jsx("svg", {
                    className: "w-5 h-5 text-red-500 shrink-0 mt-0.5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    })
                  }),
                  e.jsxs("div", {
                    className: "text-xs text-red-400 leading-relaxed",
                    children: [
                      e.jsx("p", {
                        className: "font-semibold mb-1",
                        children: "Never share your recovery phrase!"
                      }),
                      e.jsxs("ul", {
                        className: "space-y-1 list-disc list-inside",
                        children: [
                          e.jsx("li", {
                            children: "Anyone with this phrase can access your funds"
                          }),
                          e.jsx("li", {
                            children: "Store both mnemonic and PQC keys offline securely"
                          }),
                          e.jsx("li", {
                            children: "PQC keys cannot be recovered from mnemonic alone"
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            }),
            e.jsxs("div", {
              className: "mb-6 p-6 bg-surface border-2 border-border rounded-xl",
              children: [
                e.jsx("div", {
                  className: "grid grid-cols-2 gap-3",
                  children: u.map((b, h) => e.jsxs("div", {
                    className: "flex items-center gap-3 p-3 bg-background rounded-lg border border-border",
                    children: [
                      e.jsxs("span", {
                        className: "text-xs font-bold text-[var(--text-muted)] w-6",
                        children: [
                          h + 1,
                          "."
                        ]
                      }),
                      e.jsx("span", {
                        className: "font-mono text-sm text-foreground font-semibold",
                        children: b
                      })
                    ]
                  }, h))
                }),
                e.jsx("button", {
                  onClick: x,
                  className: "w-full mt-4 py-3 bg-background hover:bg-surfaceHighlight border border-border rounded-lg transition-all flex items-center justify-center gap-2 text-sm font-semibold text-foreground",
                  children: l ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("svg", {
                        className: "w-5 h-5 text-green-500",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M5 13l4 4L19 7"
                        })
                      }),
                      "Copied!"
                    ]
                  }) : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("svg", {
                        className: "w-5 h-5",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                        })
                      }),
                      "Copy Mnemonic"
                    ]
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "mb-6 space-y-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between ml-1",
                  children: [
                    e.jsx("label", {
                      className: "text-[10px] uppercase font-bold text-[var(--text-muted)] tracking-wider",
                      children: "PQC Key Data (JSON)"
                    }),
                    e.jsx("span", {
                      className: "text-[10px] text-primary font-bold",
                      children: "Recommended Backup"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "p-4 bg-surface border border-border rounded-xl space-y-4",
                  children: [
                    e.jsx("div", {
                      className: "bg-black/20 border border-border rounded-lg p-3 text-[8px] font-mono break-all leading-tight max-h-24 overflow-y-auto whitespace-pre-wrap",
                      children: JSON.stringify({
                        pqcKey: s
                      }, null, 2)
                    }),
                    e.jsxs("button", {
                      onClick: v,
                      className: "w-full py-3 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded-lg transition-all flex items-center justify-center gap-2 text-xs font-bold text-primary",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                          })
                        }),
                        "Download PQC Backup JSON"
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsxs("label", {
              className: "flex items-start gap-3 p-4 bg-surface/50 border border-border rounded-xl cursor-pointer hover:border-primary/50 transition-all",
              children: [
                e.jsx("input", {
                  type: "checkbox",
                  checked: d,
                  onChange: (b) => c(b.target.checked),
                  className: "mt-1 w-5 h-5 rounded border-2 border-border bg-background checked:bg-primary checked:border-primary focus:ring-2 focus:ring-primary/50 cursor-pointer"
                }),
                e.jsxs("div", {
                  className: "text-sm text-[var(--text-muted)] leading-relaxed",
                  children: [
                    e.jsx("p", {
                      className: "font-semibold text-foreground mb-1",
                      children: "I have saved my mnemonic and PQC key data"
                    }),
                    e.jsx("p", {
                      className: "text-xs",
                      children: "I understand that I need both to fully restore my wallet functions (PQC features) in the future."
                    })
                  ]
                })
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "space-y-3 mt-6",
          children: [
            e.jsx("button", {
              onClick: a,
              disabled: !d,
              className: "w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-hover hover:to-primary disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100",
              children: "Continue"
            }),
            e.jsxs("button", {
              onClick: n,
              className: "w-full text-[var(--text-muted)] hover:text-foreground font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M15 19l-7-7 7-7"
                  })
                }),
                "Back"
              ]
            })
          ]
        })
      ]
    });
  }, Ss = ({ mnemonic: t, onVerified: s, onBack: r }) => {
    const a = t.split(" "), [n, l] = m.useState({}), [i, d] = m.useState([]), [c, u] = m.useState(""), [x] = m.useState(() => {
      const o = [];
      for (; o.length < 3; ) {
        const y = Math.floor(Math.random() * a.length);
        o.includes(y) || o.push(y);
      }
      return o.sort((y, g) => y - g);
    });
    m.useEffect(() => {
      const o = x.map((P) => a[P]), g = a.filter((P, k) => !x.includes(k)).sort(() => Math.random() - 0.5).slice(0, 6), S = [
        ...o,
        ...g
      ].sort(() => Math.random() - 0.5);
      d(S);
    }, []);
    const v = (o, y) => {
      l((g) => ({
        ...g,
        [o]: y
      })), u("");
    }, b = () => {
      let o = true;
      for (const y of x) if (n[y] !== a[y]) {
        o = false;
        break;
      }
      o ? s() : u("The selected words do not match. Please try again.");
    }, h = x.every((o) => n[o]);
    return e.jsxs("div", {
      className: "flex flex-col h-full justify-between p-8 animate-fade-in overflow-y-auto",
      children: [
        e.jsxs("div", {
          className: "flex-1",
          children: [
            e.jsxs("div", {
              className: "text-center mb-6",
              children: [
                e.jsxs("div", {
                  className: "relative w-16 h-16 mx-auto mb-4",
                  children: [
                    e.jsx("div", {
                      className: "absolute inset-0 bg-primary/20 rounded-full blur-xl"
                    }),
                    e.jsx("div", {
                      className: "relative w-full h-full bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center",
                      children: e.jsx("svg", {
                        className: "w-8 h-8 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                        })
                      })
                    })
                  ]
                }),
                e.jsx("h2", {
                  className: "text-2xl font-bold text-foreground mb-2 tracking-tight",
                  children: "Verify Recovery Phrase"
                }),
                e.jsx("p", {
                  className: "text-[var(--text-muted)] text-sm leading-relaxed max-w-sm mx-auto",
                  children: "Select the correct words to verify you saved your recovery phrase"
                })
              ]
            }),
            e.jsx("div", {
              className: "space-y-4 mb-6",
              children: x.map((o) => e.jsxs("div", {
                className: "space-y-2",
                children: [
                  e.jsxs("label", {
                    className: "text-xs font-semibold text-[var(--text-muted)] ml-1 uppercase tracking-wide",
                    children: [
                      "Word #",
                      o + 1
                    ]
                  }),
                  e.jsx("div", {
                    className: "grid grid-cols-3 gap-2",
                    children: i.map((y, g) => e.jsx("button", {
                      onClick: () => v(o, y),
                      className: `p-3 rounded-lg border-2 transition-all font-mono text-sm font-semibold ${n[o] === y ? "bg-primary border-primary text-white" : "bg-surface border-border text-foreground hover:border-primary/50"}`,
                      children: y
                    }, `${o}-${g}`))
                  })
                ]
              }, o))
            }),
            c && e.jsxs("div", {
              className: "mb-6 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-2 animate-fade-in",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5 text-red-500 shrink-0 mt-0.5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  })
                }),
                e.jsx("p", {
                  className: "text-red-400 text-sm",
                  children: c
                })
              ]
            }),
            e.jsx("div", {
              className: "p-4 bg-surface/50 border border-border rounded-xl",
              children: e.jsxs("div", {
                className: "flex items-start gap-3",
                children: [
                  e.jsx("svg", {
                    className: "w-5 h-5 text-primary shrink-0 mt-0.5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    })
                  }),
                  e.jsxs("div", {
                    className: "text-xs text-[var(--text-muted)] leading-relaxed",
                    children: [
                      e.jsx("p", {
                        className: "font-semibold text-foreground mb-1",
                        children: "Why verify?"
                      }),
                      e.jsx("p", {
                        children: "This ensures you've correctly saved your recovery phrase. Without it, you won't be able to restore your wallet if you lose access."
                      })
                    ]
                  })
                ]
              })
            })
          ]
        }),
        e.jsxs("div", {
          className: "space-y-3 mt-6",
          children: [
            e.jsx("button", {
              onClick: b,
              disabled: !h,
              className: "w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-hover hover:to-primary disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100",
              children: "Verify & Continue"
            }),
            e.jsxs("button", {
              onClick: r,
              className: "w-full text-[var(--text-muted)] hover:text-foreground font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M15 19l-7-7 7-7"
                  })
                }),
                "Back"
              ]
            })
          ]
        })
      ]
    });
  }, Ls = ({ onImport: t, onGenerateFreshPqc: s, onBack: r, isLoading: a, error: n }) => {
    const [l, i] = m.useState(""), [d, c] = m.useState(null), [u, x] = m.useState("existing"), [v, b] = m.useState("file"), [h, o] = m.useState(""), [y, g] = m.useState(""), [S, P] = m.useState(null), k = (j) => {
      try {
        const w = j.replace(/\u00A0/g, " ").trim(), A = JSON.parse(w);
        return A.pqcKey && A.pqcKey.scheme ? A.pqcKey : A.pqc && A.pqc.scheme ? A.pqc : A;
      } catch (w) {
        throw new Error(w.message);
      }
    }, C = (j) => {
      var _a2;
      const w = (_a2 = j.target.files) == null ? void 0 : _a2[0];
      if (w) {
        const A = new FileReader();
        A.onload = (T) => {
          var _a3;
          try {
            const B = k((_a3 = T.target) == null ? void 0 : _a3.result);
            c(B), g(""), P(null);
          } catch (B) {
            g("Invalid PQC JSON: " + B.message), c(null);
          }
        }, A.readAsText(w);
      }
    }, N = (j) => {
      const w = j.target.value;
      if (o(w), P(null), !w.trim()) {
        c(null);
        return;
      }
      try {
        const A = k(w);
        c(A), g("");
      } catch (A) {
        c(null), P(A.message);
      }
    }, f = () => {
      const j = l.trim().split(/\s+/);
      if (j.length !== 12 && j.length !== 24) {
        g("Recovery phrase must be 12 or 24 words");
        return;
      }
      if (u === "fresh") {
        s(l.trim());
        return;
      }
      if (!d) {
        g('Upload your PQC JSON or choose "Generate fresh post-quantum-resistant keys".');
        return;
      }
      t(l.trim(), d);
    }, L = l.trim().split(/\s+/).filter((j) => j).length;
    return e.jsxs("div", {
      className: "flex flex-col h-full justify-between p-8 animate-fade-in overflow-y-auto",
      children: [
        e.jsxs("div", {
          className: "flex-1",
          children: [
            e.jsxs("div", {
              className: "text-center mb-6",
              children: [
                e.jsxs("div", {
                  className: "relative w-16 h-16 mx-auto mb-4",
                  children: [
                    e.jsx("div", {
                      className: "absolute inset-0 bg-primary/20 rounded-full blur-xl"
                    }),
                    e.jsx("div", {
                      className: "relative w-full h-full bg-gradient-to-br from-lumen to-primary-light rounded-full flex items-center justify-center",
                      children: e.jsx("svg", {
                        className: "w-8 h-8 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        })
                      })
                    })
                  ]
                }),
                e.jsx("h2", {
                  className: "text-2xl font-bold text-foreground mb-2 tracking-tight",
                  children: "Import Wallet"
                }),
                e.jsx("p", {
                  className: "text-[var(--text-muted)] text-sm leading-relaxed max-w-sm mx-auto",
                  children: "Import your wallet with your recovery phrase and post-quantum security"
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-2 mb-4",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-semibold text-[var(--text-muted)] ml-1 uppercase tracking-wide",
                      children: "1. Mnemonic Phrase"
                    }),
                    e.jsxs("span", {
                      className: `text-xs font-semibold ${L === 12 || L === 24 ? "text-green-500" : "text-[var(--text-muted)]"}`,
                      children: [
                        L,
                        " words"
                      ]
                    })
                  ]
                }),
                e.jsx("textarea", {
                  value: l,
                  onChange: (j) => {
                    i(j.target.value), g("");
                  },
                  placeholder: "Enter your 12 or 24-word recovery phrase",
                  className: "w-full bg-surface border-2 border-border rounded-xl p-4 text-foreground text-sm focus:border-primary outline-none transition-all placeholder:text-[var(--text-dim)] font-mono resize-none",
                  rows: 4,
                  autoFocus: true
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-2 mb-4",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-semibold text-[var(--text-muted)] ml-1 uppercase tracking-wide",
                      children: "2. Post-Quantum Security"
                    }),
                    e.jsx("span", {
                      className: "text-[10px] font-semibold uppercase tracking-wide text-[var(--text-dim)]",
                      children: u === "existing" ? "Import existing keys" : "Generate new keys"
                    })
                  ]
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => {
                    x("existing"), g(""), P(null);
                  },
                  className: `w-full rounded-xl border p-4 text-left transition-all ${u === "existing" ? "border-primary bg-primary/5 shadow-[0_0_0_1px_rgba(99,102,241,0.25)]" : "border-border bg-surface hover:border-[var(--text-dim)]"}`,
                  children: e.jsxs("div", {
                    className: "flex items-start gap-3",
                    children: [
                      e.jsx("div", {
                        className: `mt-0.5 flex h-5 w-5 items-center justify-center rounded-full border ${u === "existing" ? "border-primary bg-primary text-white" : "border-border text-transparent"}`,
                        children: e.jsx("svg", {
                          className: "w-3 h-3",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 3,
                            d: "M5 13l4 4L19 7"
                          })
                        })
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx("p", {
                            className: "text-sm font-semibold text-foreground",
                            children: "Upload existing post-quantum key JSON"
                          }),
                          e.jsx("p", {
                            className: "mt-1 text-xs text-[var(--text-muted)]",
                            children: "Use this if your wallet already has PQC keys and you exported a `lumen-pqc-key.json` file."
                          })
                        ]
                      })
                    ]
                  })
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-3 px-1",
                  children: [
                    e.jsx("div", {
                      className: "h-px flex-1 bg-border"
                    }),
                    e.jsx("span", {
                      className: "text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--text-dim)]",
                      children: "or"
                    }),
                    e.jsx("div", {
                      className: "h-px flex-1 bg-border"
                    })
                  ]
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => {
                    x("fresh"), g(""), P(null);
                  },
                  className: `w-full rounded-xl border p-4 text-left transition-all ${u === "fresh" ? "border-primary bg-primary/5 shadow-[0_0_0_1px_rgba(99,102,241,0.25)]" : "border-border bg-surface hover:border-[var(--text-dim)]"}`,
                  children: e.jsxs("div", {
                    className: "flex items-start gap-3",
                    children: [
                      e.jsx("div", {
                        className: `mt-0.5 flex h-5 w-5 items-center justify-center rounded-full border ${u === "fresh" ? "border-primary bg-primary text-white" : "border-border text-transparent"}`,
                        children: e.jsx("svg", {
                          className: "w-3 h-3",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 3,
                            d: "M5 13l4 4L19 7"
                          })
                        })
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx("p", {
                            className: "text-sm font-semibold text-foreground",
                            children: "Generate fresh post-quantum-resistant keys"
                          }),
                          e.jsx("p", {
                            className: "mt-1 text-xs text-[var(--text-muted)]",
                            children: "Best for legacy wallets from Keplr and similar apps that do not already export PQC keys."
                          })
                        ]
                      })
                    ]
                  })
                }),
                u === "existing" ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsxs("div", {
                      className: "flex bg-surfaceHighlight rounded-lg p-0.5 border border-border w-fit",
                      children: [
                        e.jsx("button", {
                          type: "button",
                          onClick: () => {
                            b("file"), c(null), o(""), P(null), g("");
                          },
                          className: `px-2 py-0.5 text-[10px] rounded-md transition-all ${v === "file" ? "bg-primary text-white shadow" : "text-[var(--text-muted)] hover:text-foreground"}`,
                          children: "File"
                        }),
                        e.jsx("button", {
                          type: "button",
                          onClick: () => {
                            b("code"), c(null), P(null), g("");
                          },
                          className: `px-2 py-0.5 text-[10px] rounded-md transition-all ${v === "code" ? "bg-primary text-white shadow" : "text-[var(--text-muted)] hover:text-foreground"}`,
                          children: "Paste"
                        })
                      ]
                    }),
                    v === "file" ? e.jsxs("div", {
                      className: `relative border border-dashed rounded-xl p-4 transition-colors ${d ? "border-green-500/50 bg-green-500/5" : "border-border hover:border-[var(--text-dim)] bg-surface"}`,
                      children: [
                        e.jsx("input", {
                          type: "file",
                          accept: ".json",
                          onChange: C,
                          className: "absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        }),
                        e.jsx("div", {
                          className: "flex flex-col items-center justify-center text-center gap-2",
                          children: d ? e.jsxs(e.Fragment, {
                            children: [
                              e.jsx("div", {
                                className: "w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center text-green-500",
                                children: e.jsx("svg", {
                                  className: "w-4 h-4",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  children: e.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M5 13l4 4L19 7"
                                  })
                                })
                              }),
                              e.jsx("span", {
                                className: "text-xs text-green-500 font-medium",
                                children: "Valid Dilithium3 Key"
                              })
                            ]
                          }) : e.jsxs(e.Fragment, {
                            children: [
                              e.jsx("svg", {
                                className: "w-6 h-6 text-[var(--text-muted)]",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                stroke: "currentColor",
                                children: e.jsx("path", {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
                                })
                              }),
                              e.jsxs("span", {
                                className: "text-xs text-[var(--text-muted)]",
                                children: [
                                  "Upload ",
                                  e.jsx("span", {
                                    className: "text-foreground font-medium",
                                    children: "lumen-pqc-key.json"
                                  })
                                ]
                              })
                            ]
                          })
                        })
                      ]
                    }) : e.jsxs("div", {
                      className: "relative",
                      children: [
                        e.jsx("textarea", {
                          value: h,
                          onChange: N,
                          placeholder: 'Paste JSON content here: {"scheme":"dilithium3", ...}',
                          className: `w-full bg-surface border-2 rounded-xl p-4 text-foreground text-xs font-mono focus:border-primary outline-none transition-all placeholder:text-[var(--text-dim)] resize-none ${d ? "border-green-500/50" : h && !d ? "border-red-500/50" : "border-border"}`,
                          rows: 6
                        }),
                        d && e.jsx("div", {
                          className: "absolute bottom-2 right-2 text-[10px] text-green-500 font-bold bg-green-500/10 px-2 py-1 rounded",
                          children: "Valid JSON"
                        }),
                        h && !d && e.jsx("div", {
                          className: "absolute bottom-2 right-2 text-[10px] text-red-500 font-bold bg-red-500/10 px-2 py-1 rounded",
                          children: S || "Invalid Format"
                        })
                      ]
                    })
                  ]
                }) : e.jsx("div", {
                  className: "rounded-xl border border-primary/20 bg-primary/5 p-4",
                  children: e.jsxs("div", {
                    className: "flex items-start gap-3",
                    children: [
                      e.jsx("div", {
                        className: "w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center text-primary shrink-0",
                        children: e.jsx("svg", {
                          className: "w-4 h-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M12 8c-3.314 0-6 2.239-6 5 0 1.835 1.186 3.439 2.95 4.307L12 21l3.05-3.693C16.814 16.439 18 14.835 18 13c0-2.761-2.686-5-6-5z"
                          })
                        })
                      }),
                      e.jsxs("div", {
                        className: "text-xs text-[var(--text-muted)] leading-relaxed",
                        children: [
                          e.jsx("p", {
                            className: "font-semibold text-foreground mb-1",
                            children: "Fresh post-quantum-resistant keys will be generated locally during import."
                          }),
                          e.jsx("p", {
                            children: "This is the simplest path for non-post-quantum-resistant wallets from Keplr and similar apps."
                          }),
                          e.jsxs("p", {
                            className: "mt-2 text-primary/90",
                            children: [
                              "After import, open wallet settings and tap ",
                              e.jsx("span", {
                                className: "font-semibold text-foreground",
                                children: "Link PQC Account"
                              }),
                              " to register these keys on-chain."
                            ]
                          })
                        ]
                      })
                    ]
                  })
                })
              ]
            }),
            (y || n) && e.jsxs("div", {
              className: "mb-6 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-2 animate-fade-in",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5 text-red-500 shrink-0 mt-0.5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  })
                }),
                e.jsx("p", {
                  className: "text-red-400 text-sm",
                  children: y || n
                })
              ]
            }),
            e.jsx("div", {
              className: "p-4 bg-surface/50 border border-border rounded-xl",
              children: e.jsxs("div", {
                className: "flex items-start gap-3",
                children: [
                  e.jsx("svg", {
                    className: "w-5 h-5 text-primary shrink-0 mt-0.5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    })
                  }),
                  e.jsxs("div", {
                    className: "text-xs text-[var(--text-muted)] leading-relaxed",
                    children: [
                      e.jsx("p", {
                        className: "font-semibold text-foreground mb-1",
                        children: "Import Requirements"
                      }),
                      e.jsxs("ul", {
                        className: "space-y-1 list-disc list-inside",
                        children: [
                          e.jsx("li", {
                            children: "Mnemonic must be 12 or 24 words"
                          }),
                          e.jsx("li", {
                            children: u === "existing" ? "Existing PQC key must be Dilithium3 format" : "Fresh Dilithium3 PQC keys will be generated locally for you"
                          }),
                          e.jsx("li", {
                            children: u === "existing" ? "Use this path if you already exported a PQC JSON file" : "Use this path for legacy wallets that do not already include PQC keys"
                          }),
                          e.jsx("li", {
                            children: u === "existing" ? "Imported wallets keep their current PQC identity" : "Fresh keys must be linked on-chain after import before sending transactions"
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            })
          ]
        }),
        e.jsxs("div", {
          className: "space-y-3 mt-6",
          children: [
            e.jsx("button", {
              onClick: f,
              disabled: !l.trim() || u === "existing" && !d || a,
              className: "w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-hover hover:to-primary disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100",
              children: a ? u === "fresh" ? "Generating PQC Keys..." : "Importing..." : u === "fresh" ? "Import Wallet & Generate PQC Keys" : "Import Wallet"
            }),
            e.jsxs("button", {
              onClick: r,
              className: "w-full text-[var(--text-muted)] hover:text-foreground font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2",
              children: [
                e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M15 19l-7-7 7-7"
                  })
                }),
                "Back"
              ]
            })
          ]
        })
      ]
    });
  }, Ps = ({ onReceive: t, onHistory: s }) => {
    const r = lt(), a = [
      {
        label: "Send",
        icon: e.jsx(ss, {
          size: 20
        }),
        onClick: () => r("/send"),
        active: true
      },
      {
        label: "Receive",
        icon: e.jsx(rs, {
          size: 20
        }),
        onClick: t,
        active: true
      },
      {
        label: "Stake",
        icon: e.jsx(ns, {
          size: 20
        }),
        onClick: () => r("/stake"),
        active: true
      },
      {
        label: "Vote",
        icon: e.jsx(tt, {
          size: 20
        }),
        onClick: () => r("/governance"),
        active: true
      },
      {
        label: "History",
        icon: e.jsx(st, {
          size: 20
        }),
        onClick: s,
        active: true
      }
    ];
    return e.jsx("div", {
      className: "grid grid-cols-5 gap-3 px-4 py-3",
      children: a.map((n, l) => e.jsxs("div", {
        className: `flex flex-col items-center gap-2 group cursor-pointer transition-all duration-300 ${n.active ? "hover:-translate-y-1" : "opacity-40 grayscale cursor-not-allowed"}`,
        onClick: n.active ? n.onClick : void 0,
        children: [
          e.jsxs("div", {
            className: "w-[52px] h-[52px] rounded-2xl flex items-center justify-center transition-all duration-500 glass-squircle relative group-hover:shadow-[0_8px_20px_-6px_rgba(0,0,0,0.5)]",
            children: [
              e.jsx("div", {
                className: "absolute inset-0 rounded-2xl bg-gradient-to-tr from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
              }),
              e.jsx("div", {
                className: `transition-all duration-500 group-hover:scale-110 group-active:scale-90 ${n.active ? "text-foreground" : "text-foreground/20"}`,
                children: n.icon
              })
            ]
          }),
          e.jsx("span", {
            className: `text-[9px] font-black uppercase tracking-[0.1em] transition-colors duration-300 ${n.active ? "text-foreground/40 group-hover:text-primary" : "text-foreground/20"}`,
            children: n.label
          })
        ]
      }, l))
    });
  }, As = ({ address: t, onClose: s, title: r = "Receive Assets", helperText: a = "Only send Lumen (LMN) assets to this address." }) => {
    const [n, l] = je.useState(false), i = () => {
      navigator.clipboard.writeText(t), l(true), setTimeout(() => l(false), 2e3);
    }, d = e.jsx("div", {
      className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in",
      onClick: s,
      style: {
        margin: 0,
        left: 0,
        right: 0,
        top: 0,
        bottom: 0
      },
      children: e.jsxs("div", {
        className: "bg-surface border border-border rounded-2xl w-full max-w-sm p-6 relative shadow-2xl animate-slide-up",
        onClick: (c) => c.stopPropagation(),
        children: [
          e.jsx("button", {
            onClick: s,
            className: "absolute top-4 right-4 text-[var(--text-muted)] hover:text-foreground transition-colors",
            children: e.jsx(Fe, {
              className: "w-5 h-5"
            })
          }),
          e.jsxs("div", {
            className: "text-center space-y-6",
            children: [
              e.jsx("h3", {
                className: "text-lg font-bold text-foreground",
                children: r
              }),
              e.jsx("div", {
                className: "bg-white p-4 rounded-xl inline-block mx-auto",
                children: e.jsx(as, {
                  value: t,
                  size: 180,
                  viewBox: "0 0 256 256",
                  style: {
                    height: "auto",
                    maxWidth: "100%",
                    width: "100%"
                  }
                })
              }),
              e.jsxs("div", {
                className: "space-y-2",
                children: [
                  e.jsx("p", {
                    className: "text-xs text-[var(--text-muted)] font-medium uppercase tracking-wide",
                    children: "Wallet Address"
                  }),
                  e.jsxs("div", {
                    onClick: i,
                    className: "bg-surfaceHighlight border border-border p-3 rounded-xl flex items-center justify-between gap-3 cursor-pointer hover:border-primary/50 transition-all group",
                    children: [
                      e.jsx("code", {
                        className: "text-xs text-foreground font-mono truncate",
                        children: t
                      }),
                      e.jsx("div", {
                        className: "text-[var(--text-muted)] group-hover:text-primary transition-colors",
                        children: n ? e.jsx(_t, {
                          className: "w-4 h-4 text-green-500"
                        }) : e.jsx(os, {
                          className: "w-4 h-4"
                        })
                      })
                    ]
                  })
                ]
              }),
              e.jsx("p", {
                className: "text-[10px] text-[var(--text-dim)]",
                children: a
              })
            ]
          })
        ]
      })
    });
    return Qe.createPortal(d, document.body);
  }, yt = "lumen", Wt = 4e3, Is = (t) => Array.from(new Set($e.map((s) => s.address.replace(/\/$/, "")))), Es = async (t, s, r) => {
    const a = await fetch(`${t}${s}`, {
      ...r,
      signal: AbortSignal.timeout(Wt)
    });
    if (!a.ok) throw new Error(`HTTP ${a.status}`);
    return a.json();
  }, Ge = async (t, s, r) => {
    let a;
    for (const n of Is()) try {
      return {
        data: await Es(n, t, r),
        endpoint: n
      };
    } catch (l) {
      a = l;
    }
    throw a instanceof Error ? a : new Error("All REST providers failed");
  }, ze = (t) => {
    if (!t) return new Uint8Array(0);
    if (typeof t == "string") {
      const s = t.trim();
      if (s.length === 0) return new Uint8Array(0);
      if (/^[0-9a-fA-F]+$/.test(s)) try {
        const r = J.from(s, "hex");
        if (r.length > 0) return new Uint8Array(r);
      } catch {
      }
      try {
        const r = J.from(s, "base64");
        if (r.length > 0) return new Uint8Array(r);
        const a = atob(s);
        return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
      } catch {
        try {
          const a = atob(s);
          return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
        } catch {
          return new Uint8Array(0);
        }
      }
    }
    return new Uint8Array(t);
  };
  async function Bs(t) {
    var _a2, _b, _c;
    try {
      const { data: s } = await Ge("/lumen/pqc/v1/params", t);
      return {
        minBalance: ((_b = (_a2 = s.params) == null ? void 0 : _a2.min_balance_for_link) == null ? void 0 : _b.amount) || "1000",
        powDifficultyBits: ((_c = s.params) == null ? void 0 : _c.pow_difficulty_bits) || 21
      };
    } catch (s) {
      return console.error("[LINK] Failed to fetch requirements:", s), {
        minBalance: "1000",
        powDifficultyBits: 21
      };
    }
  }
  async function Ts(t, s, r) {
    var _a2;
    try {
      const { data: a } = await Ge(`/cosmos/bank/v1beta1/balances/${t}`, r), n = (_a2 = a.balances) == null ? void 0 : _a2.find((d) => d.denom === "ulmn"), l = parseInt((n == null ? void 0 : n.amount) || "0"), i = parseInt(s);
      return l >= i;
    } catch (a) {
      return console.error("[LINK] Balance check failed:", a), false;
    }
  }
  async function _s(t, s, r) {
    const a = ze(t);
    if (a.length === 0) throw new Error("Invalid PQC public key: decoded to 0 bytes");
    try {
      const n = te.computePowNonce(a, s, {
        onProgress: r
      });
      return J.from(n).toString("hex");
    } catch (n) {
      throw console.error("[LINK] PoW computation failed:", n), new Error(`Failed to compute PoW nonce: ${n.message}`);
    }
  }
  async function Ms(t, s, r) {
    var _a2, _b, _c, _d, _e2;
    try {
      const a = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
        prefix: "lmn"
      }), n = await a.getAccounts(), { data: l, endpoint: i } = await Ge(`/cosmos/auth/v1beta1/accounts/${t.address}`, r), d = l.account, c = BigInt(d.sequence || "0"), u = BigInt(d.account_number || "0"), x = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
      if (!x) return {
        success: false,
        error: "PQC public key data not found in wallet"
      };
      const v = "/lumen.pqc.v1.MsgLinkAccountPQC", b = new TextEncoder().encode(t.address), h = new TextEncoder().encode("dilithium3"), o = ze(x.publicKey), y = ze(s);
      if (o.length === 0) return {
        success: false,
        error: "PQC public key decoding failed (0 bytes)"
      };
      const g = b.length, S = h.length, P = o.length, k = y.length, C = (se) => {
        const ae = [];
        for (; se > 127; ) ae.push(se & 127 | 128), se >>>= 7;
        return ae.push(se & 127), ae;
      }, N = [];
      N.push(10), N.push(...C(g)), N.push(...Array.from(b)), N.push(18), N.push(...C(S)), N.push(...Array.from(h)), N.push(26), N.push(...C(P)), N.push(...Array.from(o)), N.push(34), N.push(...C(k)), N.push(...Array.from(y));
      const f = new Uint8Array(N), L = ie.Any.fromPartial({
        typeUrl: v,
        value: f
      }), j = M.TxBody.fromPartial({
        messages: [
          L
        ],
        memo: "Link PQC Account"
      }), w = M.TxBody.encode(j).finish(), A = ie.Any.fromPartial({
        typeUrl: "/cosmos.crypto.secp256k1.PubKey",
        value: Be.PubKey.encode({
          key: n[0].pubkey
        }).finish()
      }), T = M.AuthInfo.fromPartial({
        signerInfos: [
          {
            publicKey: A,
            modeInfo: {
              single: {
                mode: Te.SignMode.SIGN_MODE_DIRECT
              }
            },
            sequence: c
          }
        ],
        fee: M.Fee.fromPartial({
          amount: [],
          gasLimit: BigInt(2e5)
        })
      }), B = M.AuthInfo.encode(T).finish(), E = x.privateKey || x.private_key || x.encryptedPrivateKey, _ = ze(E);
      if (_.length === 0) return {
        success: false,
        error: "PQC private key decoding failed (0 bytes)"
      };
      const R = {
        bodyBytes: w,
        authInfoBytes: B,
        signatures: []
      }, K = te.computeSignBytes(yt, Number(u), R), Q = await te.signDilithium(K, _), re = {
        addr: t.address,
        scheme: "dilithium3",
        signature: new Uint8Array(Q),
        pubKey: o
      }, X = te.withPqcExtension(w, [
        re
      ]), ne = M.SignDoc.fromPartial({
        bodyBytes: X,
        authInfoBytes: B,
        chainId: yt,
        accountNumber: u
      }), { signature: $ } = await a.signDirect(t.address, ne), W = M.TxRaw.fromPartial({
        bodyBytes: X,
        authInfoBytes: B,
        signatures: [
          J.from($.signature, "base64")
        ]
      }), q = M.TxRaw.encode(W).finish(), Z = J.from(q).toString("base64"), G = await (await fetch(`${i}/cosmos/tx/v1beta1/txs`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(Wt),
        body: JSON.stringify({
          tx_bytes: Z,
          mode: "BROADCAST_MODE_SYNC"
        })
      })).json();
      if (!G.tx_response || G.tx_response.code !== 0) {
        const se = ((_e2 = G.tx_response) == null ? void 0 : _e2.raw_log) || "Transaction rejected";
        return console.error("[LINK] Broadcast failed:", se), {
          success: false,
          error: se
        };
      }
      return {
        success: true,
        txHash: G.tx_response.txhash
      };
    } catch (a) {
      return console.error("[LINK] Link transaction error:", a), {
        success: false,
        error: a.message || "Unknown error"
      };
    }
  }
  async function Rs(t, s) {
    var _a2;
    try {
      const { data: r } = await Ge(`/lumen/pqc/v1/accounts/${t}`, s);
      return ((_a2 = r.account) == null ? void 0 : _a2.pqc_public_key) ? {
        isLinked: true,
        pqcPublicKey: r.account.pqc_public_key
      } : {
        isLinked: false
      };
    } catch {
      return {
        isLinked: false
      };
    }
  }
  const $s = (t) => {
    var _a2, _b, _c, _d;
    if (!t) return null;
    if (((_a2 = t.pqcKey) == null ? void 0 : _a2.privateKey) || ((_b = t.pqcKey) == null ? void 0 : _b.private_key)) return t.pqcKey;
    if (((_c = t.pqc) == null ? void 0 : _c.privateKey) || ((_d = t.pqc) == null ? void 0 : _d.private_key)) return t.pqc;
    for (const s of Object.keys(t)) {
      const r = t[s];
      if (r && typeof r == "object" && r.scheme === "dilithium3" && (r.privateKey || r.private_key)) return r;
    }
    return t.pqcKey || t.pqc || null;
  }, Ut = ({ wallet: t, onWalletUpdate: s, isModal: r, onClose: a }) => {
    const [n, l] = m.useState(!r && (!t || t.linked || t.linkTxHash) ? "hidden" : "checking"), [i, d] = m.useState(""), [c, u] = m.useState(0), [x, v] = m.useState({
      minBalance: "1000",
      powBits: 21
    }), [b, h] = m.useState(false), [o, y] = m.useState(""), [g, S] = m.useState(null), [P, k] = m.useState("idle"), [C, N] = m.useState("");
    m.useEffect(() => {
      l(!r && (!t || t.linked || t.linkTxHash) ? "hidden" : "checking"), d(""), y("");
    }, [
      t == null ? void 0 : t.address,
      t == null ? void 0 : t.linked,
      t == null ? void 0 : t.linkTxHash,
      r
    ]), m.useEffect(() => {
      if (t == null ? void 0 : t.linked) {
        l(r ? "success" : "hidden");
        return;
      }
      const j = new AbortController();
      async function w() {
        if (n !== "checking" && n !== "hidden") return;
        if (!t) {
          j.signal.aborted || l(r ? "error" : "hidden");
          return;
        }
        let A;
        try {
          if (A = await Bs(), j.signal.aborted) return;
          v({
            minBalance: A.minBalance,
            powBits: A.powDifficultyBits
          });
        } catch {
          if (j.signal.aborted) return;
        }
        const T = await Ts(t.address, (A == null ? void 0 : A.minBalance) || "1000");
        if (j.signal.aborted) return;
        if (!T) {
          r ? (d(`Insufficient balance. Linking requires ${parseInt((A == null ? void 0 : A.minBalance) || "1000") / 1e6} LMN.`), l("error")) : l("hidden");
          return;
        }
        const B = await Rs(t.address);
        if (!j.signal.aborted) {
          if (B.isLinked) {
            if (s) try {
              s({
                ...t,
                linked: true,
                linkedAt: (/* @__PURE__ */ new Date()).toISOString(),
                ...B.pqcPublicKey ? {
                  pqcKey: {
                    ...t.pqcKey,
                    publicKey: B.pqcPublicKey
                  }
                } : {}
              });
            } catch (E) {
              console.error("[LinkPQCBanner] Failed to persist linked status:", E);
            }
            l(r ? "success" : "hidden");
            return;
          }
          l("ready");
        }
      }
      return w(), () => j.abort();
    }, [
      t,
      s
    ]);
    const f = async () => {
      if (t) try {
        d(""), S(null), k("idle"), h(true), l("computing"), setTimeout(async () => {
          var _a2, _b, _c, _d;
          try {
            h(false);
            const j = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
            if (!j || !j.publicKey && !j.public_key) throw new Error("PQC public key not found in wallet. Please re-import.");
            const w = j.publicKey || j.public_key, A = await _s(w, x.powBits, (E) => {
              const _ = Math.min(95, E / 1e5 * 100);
              u(_);
            });
            u(100), l("broadcasting");
            const T = await Ms(t, A);
            if (!T.success) throw new Error(T.error || "Link transaction failed");
            const B = T.txHash || "";
            S(B), s && s({
              ...t,
              linked: true,
              linkedAt: (/* @__PURE__ */ new Date()).toISOString(),
              linkTxHash: B
            }), l("success"), k("verifying");
            try {
              const E = "https://rest.cosmos.directory/lumen";
              await new Promise((R) => setTimeout(R, 2e3));
              const _ = await fetch(`${E}/cosmos/tx/v1beta1/txs/${B}`);
              if (_.ok) {
                const K = (await _.json()).tx_response;
                (K == null ? void 0 : K.raw_log) && N(K.raw_log), (K == null ? void 0 : K.code) !== void 0 && K.code !== 0 ? k("failed") : k("verified");
              } else k("failed");
            } catch (E) {
              console.error("Verification fetch failed", E), k("failed");
            }
          } catch {
          }
        }, 100);
      } catch {
      }
    }, L = () => {
      if (!t) return;
      const j = $s(t), w = (j == null ? void 0 : j.privateKey) || (j == null ? void 0 : j.private_key) || (j == null ? void 0 : j.encryptedPrivateKey), A = (j == null ? void 0 : j.publicKey) || (j == null ? void 0 : j.public_key);
      if (!j || !w || !A) {
        y("PQC backup data not found in this wallet.");
        return;
      }
      const T = JSON.stringify({
        pqcKey: j
      }, null, 2), B = new Blob([
        T
      ], {
        type: "application/json"
      }), E = URL.createObjectURL(B), _ = document.createElement("a");
      _.href = E, _.download = `lumen_pqc_${t.address.substring(0, 8)}.json`, document.body.appendChild(_), _.click(), document.body.removeChild(_), URL.revokeObjectURL(E), y("PQC backup downloaded.");
    };
    return n === "hidden" ? null : e.jsxs("div", {
      className: "mb-4 p-4 rounded-lg border-2 border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20",
      children: [
        n === "checking" && e.jsxs("div", {
          className: "flex flex-col items-center justify-center py-4 text-center space-y-3",
          children: [
            e.jsx("div", {
              className: "w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"
            }),
            e.jsx("p", {
              className: "text-sm text-[var(--text-muted)]",
              children: "Verifying account status..."
            })
          ]
        }),
        n === "ready" && e.jsxs("div", {
          className: "flex items-start justify-between",
          children: [
            e.jsxs("div", {
              className: "flex-1",
              children: [
                e.jsx("h3", {
                  className: "font-bold text-yellow-900 dark:text-yellow-100 mb-1",
                  children: "\u{1F517} Link Your PQC Account"
                }),
                e.jsx("p", {
                  className: "text-sm text-yellow-800 dark:text-yellow-200 mb-3",
                  children: "To enable dual-signed transactions, you need to register your PQC public key on-chain. This is a one-time setup that requires computing a proof-of-work (may take 10-30 seconds)."
                })
              ]
            }),
            e.jsx("button", {
              onClick: f,
              disabled: b || n !== "ready",
              className: "ml-4 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 disabled:bg-yellow-800 disabled:opacity-50 text-white rounded-lg font-medium transition-colors flex items-center justify-center min-w-[100px]",
              children: b ? e.jsx("span", {
                className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"
              }) : "Link Now"
            })
          ]
        }),
        n === "computing" && e.jsxs("div", {
          children: [
            e.jsx("h3", {
              className: "font-bold text-yellow-900 dark:text-yellow-100 mb-2",
              children: "\u2699\uFE0F Computing Proof-of-Work..."
            }),
            e.jsx("p", {
              className: "text-sm text-yellow-800 dark:text-yellow-200 mb-2",
              children: "Please wait while we compute the required nonce. This may take a moment."
            }),
            e.jsx("div", {
              className: "w-full bg-yellow-200 dark:bg-yellow-800 rounded-full h-2",
              children: e.jsx("div", {
                className: "bg-yellow-600 h-2 rounded-full transition-all duration-300",
                style: {
                  width: `${c}%`
                }
              })
            }),
            e.jsxs("p", {
              className: "text-xs text-yellow-700 dark:text-yellow-300 mt-1",
              children: [
                "Progress: ",
                Math.round(c),
                "%"
              ]
            })
          ]
        }),
        n === "broadcasting" && e.jsxs("div", {
          children: [
            e.jsx("h3", {
              className: "font-bold text-yellow-900 dark:text-yellow-100 mb-2",
              children: "\u{1F4E1} Broadcasting Transaction..."
            }),
            e.jsx("p", {
              className: "text-sm text-yellow-800 dark:text-yellow-200",
              children: "Linking your PQC account on-chain. Please wait..."
            })
          ]
        }),
        n === "success" && e.jsxs("div", {
          children: [
            e.jsx("h3", {
              className: "font-bold text-green-900 dark:text-green-100 mb-1 flex items-center gap-2",
              children: "\u2705 PQC Account Linked!"
            }),
            e.jsx("p", {
              className: "text-sm text-green-800 dark:text-green-200 mb-3",
              children: "Your PQC key is now registered."
            }),
            g && e.jsxs("div", {
              className: "mb-3 rounded-lg border border-green-200 bg-white text-green-950 dark:border-green-800 dark:bg-slate-950/60 dark:text-green-100",
              children: [
                e.jsx("div", {
                  className: "border-b border-green-200/80 px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-green-700 dark:border-green-800/80 dark:text-green-300",
                  children: "Transaction Hash"
                }),
                e.jsx("div", {
                  className: "px-3 py-2 text-xs font-mono break-all",
                  children: g
                })
              ]
            }),
            e.jsxs("div", {
              className: "mb-3 rounded-lg border border-green-200 bg-green-50/80 p-3 dark:border-green-800 dark:bg-green-950/20",
              children: [
                e.jsx("p", {
                  className: "text-xs font-semibold text-green-900 dark:text-green-100",
                  children: "Export your post-quantum backup now"
                }),
                e.jsx("p", {
                  className: "mt-1 text-[11px] leading-relaxed text-green-800 dark:text-green-200",
                  children: "This downloads your PQC signer data in the same JSON format used by wallet import. Keep it with your mnemonic to restore dual-signer access later."
                }),
                e.jsx("button", {
                  onClick: L,
                  className: "mt-3 w-full rounded-lg border border-green-300 bg-white px-3 py-2 text-xs font-bold text-green-800 transition-colors hover:bg-green-100 dark:border-green-700 dark:bg-slate-950/50 dark:text-green-100 dark:hover:bg-green-900/30",
                  children: "Download PQC Backup JSON"
                }),
                o && e.jsx("p", {
                  className: "mt-2 text-[10px] font-semibold text-green-700 dark:text-green-300",
                  children: o
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex flex-col gap-2",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2 text-xs font-medium",
                  children: [
                    P === "verifying" && e.jsxs("span", {
                      className: "flex items-center gap-1 text-yellow-600 dark:text-yellow-400",
                      children: [
                        e.jsx("span", {
                          className: "w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin"
                        }),
                        "Verifying on chain..."
                      ]
                    }),
                    P === "verified" && e.jsxs("span", {
                      className: "flex items-center gap-1 text-green-700 dark:text-green-400",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M5 13l4 4L19 7"
                          })
                        }),
                        "Confirmed Indexed"
                      ]
                    }),
                    P === "failed" && e.jsxs("span", {
                      className: "flex items-center gap-1 text-orange-600 dark:text-orange-400",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                          })
                        }),
                        "Transaction Status: ",
                        C ? "Failed/Warning" : "Pending Indexing"
                      ]
                    })
                  ]
                }),
                C && e.jsxs("div", {
                  className: `p-2 rounded text-[10px] font-mono border ${P === "failed" ? "bg-orange-100 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800 text-orange-800 dark:text-orange-200" : "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300"}`,
                  children: [
                    e.jsx("span", {
                      className: "font-bold opacity-70 block mb-0.5",
                      children: "Log:"
                    }),
                    C
                  ]
                })
              ]
            }),
            e.jsx("button", {
              onClick: () => {
                if (r && a) {
                  a();
                  return;
                }
                l("hidden");
              },
              className: "mt-3 w-full py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-xs font-bold transition-colors",
              children: "Done"
            })
          ]
        }),
        n === "error" && e.jsxs("div", {
          children: [
            e.jsx("h3", {
              className: "font-bold text-red-900 dark:text-red-100 mb-1",
              children: "\u274C Linking Failed"
            }),
            e.jsx("p", {
              className: "text-sm text-red-800 dark:text-red-200 mb-3",
              children: i
            }),
            e.jsx("button", {
              onClick: f,
              disabled: b || n !== "error",
              className: "px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-red-800 disabled:opacity-50 text-white rounded-lg font-medium transition-colors text-sm flex items-center justify-center min-w-[80px]",
              children: b ? e.jsx("span", {
                className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"
              }) : "Retry"
            })
          ]
        })
      ]
    });
  }, Ds = "modulepreload", qs = function(t) {
    return "/" + t;
  }, vt = {}, ve = function(s, r, a) {
    let n = Promise.resolve();
    if (r && r.length > 0) {
      let c = function(u) {
        return Promise.all(u.map((x) => Promise.resolve(x).then((v) => ({
          status: "fulfilled",
          value: v
        }), (v) => ({
          status: "rejected",
          reason: v
        }))));
      };
      document.getElementsByTagName("link");
      const i = document.querySelector("meta[property=csp-nonce]"), d = (i == null ? void 0 : i.nonce) || (i == null ? void 0 : i.getAttribute("nonce"));
      n = c(r.map((u) => {
        if (u = qs(u), u in vt) return;
        vt[u] = true;
        const x = u.endsWith(".css"), v = x ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${u}"]${v}`)) return;
        const b = document.createElement("link");
        if (b.rel = x ? "stylesheet" : Ds, x || (b.as = "script"), b.crossOrigin = "", b.href = u, d && b.setAttribute("nonce", d), document.head.appendChild(b), x) return new Promise((h, o) => {
          b.addEventListener("load", h), b.addEventListener("error", () => o(new Error(`Unable to preload CSS for ${u}`)));
        });
      }));
    }
    function l(i) {
      const d = new Event("vite:preloadError", {
        cancelable: true
      });
      if (d.payload = i, window.dispatchEvent(d), !d.defaultPrevented) throw i;
    }
    return n.then((i) => {
      for (const d of i || []) d.status === "rejected" && l(d.reason);
      return s().catch(l);
    });
  }, jt = "lumen_history_v1", Ke = 100, _e = "https://rpc.cosmos.directory/lumen", wt = "https://rest.cosmos.directory/lumen";
  class ge {
    static getHistory(s) {
      return this.loadStore()[s] || [];
    }
    static saveTransaction(s, r) {
      const a = this.loadStore(), n = a[s] || [];
      n.some((l) => l.hash === r.hash) || (n.unshift(r), n.sort((l, i) => new Date(i.timestamp).getTime() - new Date(l.timestamp).getTime()), n.length > Ke && (n.length = Ke), a[s] = n, this.saveStore(a));
    }
    static saveHistory(s, r) {
      const a = this.loadStore(), l = [
        ...a[s] || []
      ];
      r.forEach((i) => {
        l.some((d) => d.hash === i.hash) || l.push(i);
      }), l.sort((i, d) => new Date(d.timestamp).getTime() - new Date(i.timestamp).getTime()), l.length > Ke && (l.length = Ke), a[s] = l, this.saveStore(a);
    }
    static async syncGap(s) {
      var _a2;
      try {
        const r = `transfer.recipient='${s}'`, a = `${_e}/tx_search?query="${r}"&prove=true&per_page=50&page=1&order_by="desc"`, n = await fetch(a);
        if (!n.ok) return;
        const i = ((_a2 = (await n.json()).result) == null ? void 0 : _a2.txs) || [];
        if (i.length === 0) return;
        const { fromBase64: d, toHex: c } = await ve(async () => {
          const { fromBase64: b, toHex: h } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((o) => o.a);
          return {
            fromBase64: b,
            toHex: h
          };
        }, __vite__mapDeps([0,1])), { sha256: u } = await ve(async () => {
          const { sha256: b } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((h) => h.b);
          return {
            sha256: b
          };
        }, __vite__mapDeps([0,1]));
        await Promise.all(i.map(async (b) => {
          var _a3, _b, _c;
          try {
            const h = b.height, o = b.tx_result, y = b.tx;
            let g = b.hash;
            if (!g && y) {
              const f = u(d(y));
              g = c(f).toUpperCase();
            }
            let S = (/* @__PURE__ */ new Date()).toISOString();
            try {
              const L = await (await fetch(`${_e}/block?height=${h}`)).json();
              ((_c = (_b = (_a3 = L.result) == null ? void 0 : _a3.block) == null ? void 0 : _b.header) == null ? void 0 : _c.time) && (S = L.result.block.header.time);
            } catch {
            }
            const k = (o.events || []).find((f) => f.type === "transfer");
            let C = "0", N = "Unknown";
            if (k) {
              const f = (w) => {
                const A = k.attributes.find((B) => B.key === w || B.key === btoa(w));
                if (!A) return null;
                let T = A.value;
                if (w === "amount" && !T.includes("ulmn")) try {
                  T = atob(T);
                } catch {
                }
                if (w === "sender" && !T.startsWith("lmn")) try {
                  T = atob(T);
                } catch {
                }
                return T;
              }, L = f("amount");
              L && L.includes("ulmn") && (C = (parseInt(L.replace("ulmn", "")) / 1e6).toFixed(6));
              const j = f("sender");
              j && (N = j);
            }
            this.saveTransaction(s, {
              hash: g,
              height: h,
              timestamp: S,
              type: "receive",
              amount: C,
              denom: "LMN",
              counterparty: N,
              status: "success"
            });
          } catch (h) {
            console.error("GapSync Parse Error", h);
          }
        }));
        const x = Math.max(...i.map((b) => parseInt(b.height))), v = this.getLastScannedHeight(s);
        x > v && this.saveLastScannedHeight(s, x);
      } catch (r) {
        console.error("[GapSync] Failed", r);
      }
    }
    static async onBalanceIncrease(s) {
      await this.syncBlocks(s, 100, true);
    }
    static async syncBlocks(s, r = 20, a = false) {
      try {
        let n = 0;
        try {
          const h = await fetch(`${wt}/cosmos/base/tendermint/v1beta1/blocks/latest`);
          if (h.ok) {
            const o = await h.json();
            n = parseInt(o.block.header.height);
          }
        } catch {
        }
        if (n === 0) try {
          const h = await fetch(`${_e}/status`);
          if (h.ok) {
            const o = await h.json();
            n = parseInt(o.result.sync_info.latest_block_height);
          }
        } catch {
          return;
        }
        let l = this.getLastScannedHeight(s);
        if ((a || l === 0 || n - l > 1e3) && (l = n - r), !a && l >= n) return;
        const i = Math.min(l + r, n), d = [];
        for (let h = l + 1; h <= i; h++) d.push(h);
        const { fromBase64: c, toHex: u } = await ve(async () => {
          const { fromBase64: h, toHex: o } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((y) => y.a);
          return {
            fromBase64: h,
            toHex: o
          };
        }, __vite__mapDeps([0,1])), { sha256: x } = await ve(async () => {
          const { sha256: h } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((o) => o.b);
          return {
            sha256: h
          };
        }, __vite__mapDeps([0,1])), { decodeTxRaw: v } = await ve(async () => {
          const { decodeTxRaw: h } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((o) => o.i);
          return {
            decodeTxRaw: h
          };
        }, __vite__mapDeps([0,1])), { MsgSend: b } = await ve(async () => {
          const { MsgSend: h } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((o) => o.t);
          return {
            MsgSend: h
          };
        }, __vite__mapDeps([0,1]));
        await Promise.all(d.map(async (h) => {
          var _a2, _b, _c, _d, _e2, _f;
          let o = false;
          try {
            const y = await fetch(`${_e}/block_results?height=${h}`);
            if (y.ok) {
              const g = await y.json();
              if (g.result) {
                o = true;
                const P = await (await fetch(`${_e}/block?height=${h}`)).json(), k = ((_c = (_b = (_a2 = P.result) == null ? void 0 : _a2.block) == null ? void 0 : _b.header) == null ? void 0 : _c.time) || (/* @__PURE__ */ new Date()).toISOString(), C = ((_f = (_e2 = (_d = P.result) == null ? void 0 : _d.block) == null ? void 0 : _e2.data) == null ? void 0 : _f.txs) || [], N = (f, L, j, w) => {
                  var _a3;
                  const A = f.find((T) => T.type === "transfer");
                  if (A) {
                    let B = (_a3 = A.attributes.find((E) => E.key === "recipient" || E.key === "cmVjaXBpZW50")) == null ? void 0 : _a3.value;
                    if (B && !B.startsWith("lmn")) try {
                      B = atob(B);
                    } catch {
                    }
                    B === s && this.saveFoundTx(s, h.toString(), k, L, f, j, w);
                  }
                };
                N(g.result.finalize_block_events || [], "sys"), (g.result.txs_results || []).forEach((f, L) => {
                  N(f.events || [], "tx", C[L], L);
                });
              }
            }
          } catch {
          }
          if (!o) try {
            const y = await fetch(`${wt}/cosmos/base/tendermint/v1beta1/blocks/${h}`);
            if (y.ok) {
              const g = await y.json(), S = g.block || g.sdk_block;
              S && S.data && S.data.txs && S.data.txs.forEach((P) => {
                try {
                  v(c(P)).body.messages.forEach((C) => {
                    if (C.typeUrl === "/cosmos.bank.v1beta1.MsgSend") {
                      const N = b.decode(C.value), f = N.amount[0], L = f ? (parseFloat(f.amount) / 1e6).toFixed(6) : "0", j = u(x(c(P))).toUpperCase();
                      N.toAddress === s && this.saveTransaction(s, {
                        hash: j,
                        height: h.toString(),
                        timestamp: S.header.time,
                        type: "receive",
                        amount: L,
                        denom: "LMN",
                        counterparty: N.fromAddress,
                        status: "success"
                      }), N.fromAddress === s && this.saveTransaction(s, {
                        hash: j,
                        height: h.toString(),
                        timestamp: S.header.time,
                        type: "send",
                        amount: L,
                        denom: "LMN",
                        counterparty: N.toAddress,
                        status: "success"
                      });
                    } else if (C.typeUrl === "/cosmos.staking.v1beta1.MsgDelegate") {
                      const N = u(x(c(P))).toUpperCase();
                      this.saveTransaction(s, {
                        hash: N,
                        height: h.toString(),
                        timestamp: S.header.time,
                        type: "stake",
                        amount: "Checking...",
                        denom: "LMN",
                        counterparty: "Lumen Staking",
                        status: "success"
                      });
                    }
                  });
                } catch {
                }
              });
            }
          } catch {
          }
        })), a || this.saveLastScannedHeight(s, i);
      } catch (n) {
        console.error("[HybridScanner] Fatal error", n);
      }
    }
    static getLastScannedHeight(s) {
      const r = `lumen_last_height_${s}`, a = localStorage.getItem(r);
      return a ? parseInt(a) : 0;
    }
    static saveLastScannedHeight(s, r) {
      localStorage.setItem(`lumen_last_height_${s}`, r.toString());
    }
    static loadStore() {
      try {
        const s = localStorage.getItem(jt);
        return s ? JSON.parse(s) : {};
      } catch {
        return {};
      }
    }
    static saveStore(s) {
      localStorage.setItem(jt, JSON.stringify(s));
    }
    static async saveFoundTx(s, r, a, n, l, i, d) {
      var _a2, _b;
      let c = "";
      if (n === "tx" && i) try {
        const { fromBase64: o, toHex: y } = await ve(async () => {
          const { fromBase64: P, toHex: k } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((C) => C.a);
          return {
            fromBase64: P,
            toHex: k
          };
        }, __vite__mapDeps([0,1])), { sha256: g } = await ve(async () => {
          const { sha256: P } = await import("./assets/vendor-cosmjs-CHW-r_ld.js").then((k) => k.b);
          return {
            sha256: P
          };
        }, __vite__mapDeps([0,1])), S = g(o(i));
        c = y(S).toUpperCase();
      } catch {
      }
      c || (c = `detected-${r}-${d ?? n}-${Date.now().toString().slice(-4)}`);
      let u = "0";
      const x = l.find((o) => o.type === "transfer"), v = (_a2 = x == null ? void 0 : x.attributes) == null ? void 0 : _a2.find((o) => o.key === "amount" || o.key === "YW1vdW50");
      if (v) {
        let o = v.value;
        if (!o.includes("ulmn")) try {
          o = atob(o);
        } catch {
        }
        o.includes("ulmn") && (u = (parseInt(o.replace("ulmn", "")) / 1e6).toFixed(6));
      }
      const b = (_b = x == null ? void 0 : x.attributes) == null ? void 0 : _b.find((o) => o.key === "sender" || o.key === "c2VuZGVy");
      let h = "Unknown";
      if (b) {
        let o = b.value;
        if (!o.startsWith("lmn")) try {
          o = atob(o);
        } catch {
        }
        h = o;
      }
      this.saveTransaction(s, {
        hash: c,
        height: r,
        timestamp: a,
        type: "receive",
        amount: u,
        denom: "LMN",
        counterparty: h,
        status: "success"
      });
    }
  }
  const Ws = ({ address: t, onClose: s }) => {
    const [r, a] = m.useState(() => ge.getHistory(t)), [n, l] = m.useState("all");
    m.useEffect(() => {
      a(ge.getHistory(t));
      const c = setInterval(() => {
        a(ge.getHistory(t));
      }, 2e3);
      return () => clearInterval(c);
    }, [
      t
    ]);
    const i = r.filter((c) => n === "all" || (n === "sent" ? c.type === "send" : c.type === "receive")).sort((c, u) => new Date(u.timestamp).getTime() - new Date(c.timestamp).getTime()), d = e.jsx("div", {
      className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in",
      onClick: s,
      style: {
        margin: 0,
        left: 0,
        right: 0,
        top: 0,
        bottom: 0
      },
      children: e.jsxs("div", {
        className: "w-full max-w-md h-[85vh] bg-surface border border-border rounded-xl flex flex-col relative overflow-hidden",
        onClick: (c) => c.stopPropagation(),
        children: [
          e.jsxs("div", {
            className: "px-4 py-3 border-b border-border flex items-center justify-between bg-surface z-10 shrink-0",
            children: [
              e.jsxs("h2", {
                className: "text-base font-semibold text-foreground flex items-center gap-2",
                children: [
                  e.jsx(st, {
                    className: "w-4 h-4 text-primary"
                  }),
                  "Transaction History"
                ]
              }),
              e.jsx("button", {
                onClick: s,
                className: "p-1.5 hover:bg-surfaceHighlight rounded-lg transition-colors text-[var(--text-muted)] hover:text-foreground",
                children: e.jsx(Fe, {
                  className: "w-4 h-4"
                })
              })
            ]
          }),
          e.jsx("div", {
            className: "p-2 flex gap-1 bg-background/50 shrink-0",
            children: [
              "all",
              "sent",
              "received"
            ].map((c) => e.jsx("button", {
              onClick: () => l(c),
              className: `flex-1 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors ${n === c ? "bg-primary text-white" : "text-[var(--text-muted)] hover:bg-surfaceHighlight hover:text-foreground"}`,
              children: c
            }, c))
          }),
          e.jsx("div", {
            className: "flex-1 overflow-y-auto p-3 space-y-2",
            children: i.length === 0 ? e.jsxs("div", {
              className: "flex flex-col items-center justify-center h-full text-[var(--text-muted)] gap-2",
              children: [
                e.jsx("div", {
                  className: "w-14 h-14 bg-surfaceHighlight rounded-full flex items-center justify-center",
                  children: e.jsx(st, {
                    className: "w-7 h-7 opacity-30"
                  })
                }),
                e.jsx("p", {
                  className: "text-xs font-medium",
                  children: "No transactions found"
                }),
                e.jsx("p", {
                  className: "text-[10px] text-[var(--text-dim)]",
                  children: "Your transaction history will appear here"
                })
              ]
            }) : i.map((c) => e.jsxs("div", {
              className: "group bg-background hover:bg-surfaceHighlight border border-border rounded-lg p-3 transition-colors cursor-default",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between mb-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        e.jsx("div", {
                          className: `w-8 h-8 rounded-full flex items-center justify-center ${c.status === "failed" ? "bg-red-500/10 text-red-500" : c.type === "send" ? "bg-orange-500/10 text-orange-500" : "bg-green-500/10 text-green-500"}`,
                          children: c.status === "failed" ? e.jsx(Fe, {
                            className: "w-4 h-4"
                          }) : c.type === "send" ? e.jsx(is, {
                            className: "w-4 h-4"
                          }) : e.jsx(ls, {
                            className: "w-4 h-4"
                          })
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsx("p", {
                              className: "text-xs font-semibold text-foreground capitalize",
                              children: c.type === "send" ? "Sent" : "Received"
                            }),
                            e.jsx("p", {
                              className: "text-[10px] text-[var(--text-muted)]",
                              children: new Date(c.timestamp).toLocaleString("en-US", {
                                month: "numeric",
                                day: "numeric",
                                year: "numeric",
                                hour: "numeric",
                                minute: "2-digit",
                                hour12: true
                              })
                            })
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "text-right",
                      children: [
                        e.jsxs("p", {
                          className: `text-sm font-semibold font-mono ${c.type === "send" ? "text-foreground" : "text-green-500"}`,
                          children: [
                            c.type === "send" ? "-" : "+",
                            c.amount,
                            " ",
                            c.denom
                          ]
                        }),
                        e.jsx("p", {
                          className: `text-[9px] font-semibold uppercase ${c.status === "success" ? "text-green-500" : c.status === "failed" ? "text-red-500" : "text-yellow-500"}`,
                          children: c.status
                        })
                      ]
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex items-center justify-between pt-2 border-t border-border/50",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-1.5 text-[10px] text-[var(--text-muted)]",
                      children: [
                        e.jsx("span", {
                          className: "font-medium",
                          children: c.type === "send" ? "To:" : "From:"
                        }),
                        e.jsxs("span", {
                          className: "font-mono bg-surfaceHighlight px-1.5 py-0.5 rounded",
                          children: [
                            c.counterparty.slice(0, 10),
                            "...",
                            c.counterparty.slice(-6)
                          ]
                        })
                      ]
                    }),
                    c.hash.startsWith("detected-") || c.hash.startsWith("sys-") ? e.jsxs("a", {
                      href: `https://winscan.winsnip.xyz/lumen-mainnet/blocks/${c.height}`,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "text-[10px] flex items-center gap-0.5 text-primary hover:text-primary-hover transition-colors font-medium",
                      children: [
                        "View",
                        e.jsx(rt, {
                          className: "w-3 h-3"
                        })
                      ]
                    }) : c.hash.startsWith("offline-") ? e.jsx("span", {
                      className: "text-[10px] flex items-center gap-0.5 text-[var(--text-dim)] cursor-help",
                      title: "Transaction not found in recent blocks",
                      children: e.jsx("span", {
                        children: "Unindexed"
                      })
                    }) : e.jsxs("a", {
                      href: `https://winscan.winsnip.xyz/lumen-mainnet/transactions/${c.hash}`,
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className: "text-[10px] flex items-center gap-0.5 text-primary hover:text-primary-hover transition-colors font-medium",
                      children: [
                        "View",
                        e.jsx(rt, {
                          className: "w-3 h-3"
                        })
                      ]
                    })
                  ]
                })
              ]
            }, c.hash))
          })
        ]
      })
    });
    return Qe.createPortal(d, document.body);
  }, Us = {
    "beezee-1": {
      label: "BeeZee",
      addressPrefix: "bze",
      restEndpoint: "https://rest.getbze.com",
      rpcEndpoint: "https://rpc.getbze.com",
      nativeDenom: "ubze",
      feeDenom: "ubze",
      minGasPrice: 0.01,
      iconText: "BZE",
      chainRegistryName: "beezee"
    },
    "bzetestnet-3": {
      label: "BeeZee Testnet",
      addressPrefix: "bze",
      restEndpoint: "https://testnet.getbze.com",
      rpcEndpoint: "https://testnet-rpc.getbze.com",
      nativeDenom: "ubze",
      feeDenom: "ubze",
      minGasPrice: 0.01,
      iconText: "BZE",
      chainRegistryName: "beezee"
    }
  }, Nt = "ulmn", Hs = "ibc/693DDB2D9B4260D67C8136C22D837F37488E0FBD81857D8E9C6022332EA26E33", Ks = [
    {
      sourcePort: "transfer",
      sourceChannel: "channel-0",
      counterpartyPort: "transfer",
      counterpartyChannel: "channel-10",
      chainId: "beezee-1",
      label: "BeeZee (Route 10)",
      expectedDestinationDenom: Hs,
      expectedDestinationTracePath: "transfer/channel-10",
      expectedDestinationSymbol: "LMN",
      expectedDestinationDisplayName: "LMN via IBC"
    }
  ];
  function Os(t) {
    return Array.from(t).map((s) => s.toString(16).padStart(2, "0")).join("").toUpperCase();
  }
  async function zs(t, s) {
    const r = `${String(t || "").trim()}/${String(s).trim()}`.replace(/^\/+/, ""), a = new TextEncoder().encode(r), n = await globalThis.crypto.subtle.digest("SHA-256", a);
    return `ibc/${Os(new Uint8Array(n))}`;
  }
  function Fs(t) {
    const s = String(t).trim().toLowerCase();
    return s ? s === "ulmn" ? "LMN" : s === "ubze" ? "BZE" : s.startsWith("u") && s.length > 1 ? s.slice(1).toUpperCase() : s.toUpperCase() : "";
  }
  function Vs(t) {
    return Ks.find((s) => s.sourcePort === t.portId && s.sourceChannel === t.channelId && (!s.counterpartyChannel || s.counterpartyChannel === t.counterpartyChannelId)) || null;
  }
  function Ht(t, s) {
    return `${String(t || "").replace(/\/+$/, "")}${s}`;
  }
  async function Kt(t, s) {
    const r = new AbortController(), a = globalThis.setTimeout(() => r.abort(), s);
    let n;
    try {
      n = await fetch(t, {
        signal: r.signal
      });
    } finally {
      globalThis.clearTimeout(a);
    }
    if (!n.ok) throw new Error(`HTTP ${n.status} while fetching ${t}`);
    return n.json();
  }
  function it(t) {
    const r = String(t || "").trim().toLowerCase().match(/^([a-z0-9]{1,24})1[ac-hj-np-z02-9]{6,}$/);
    return r ? r[1] : "";
  }
  function Qs(t) {
    return !!it(t);
  }
  function Ot(t) {
    const s = String(t || "").trim();
    return s && Us[s] || null;
  }
  function Gs(t) {
    const s = String(t || "").trim().toLowerCase();
    if (!s) return [];
    const r = /* @__PURE__ */ new Set(), a = s.replace(/(?:[_-]?testnet.*$)|(?:[_-]?mainnet.*$)|(?:[_-]?devnet.*$)|(?:[_-]?localnet.*$)|(?:[_-]?stage.*$)|(?:[_-]?alpha.*$)|(?:[_-]?beta.*$)/, "").replace(/[_-]?\d+$/, "").replace(/[_-]+$/, ""), n = a.split(/[_-]/)[0] || a;
    for (const l of [
      a,
      n
    ]) {
      const i = l.replace(/[^a-z0-9]/g, "");
      i && r.add(i);
    }
    return (s.includes("bzetestnet") || s.includes("beezee")) && r.add("bze"), Array.from(r);
  }
  async function zt(t = false) {
    var _a2;
    const s = Array.from(new Set($e.filter((i) => i.provider !== "CosmosDirectory" && i.provider !== "Winnode").map((i) => i.address)));
    if (!s.length) throw new Error("No REST endpoints configured for IBC route discovery.");
    let r;
    try {
      r = await Promise.any(s.map(async (i) => {
        const d = await Kt(Ht(i, "/ibc/core/channel/v1/channels?pagination.limit=200"), t ? 12e3 : 7e3);
        return {
          restEndpoint: i,
          payload: Array.isArray(d == null ? void 0 : d.channels) ? d.channels : []
        };
      }));
    } catch (i) {
      const d = (_a2 = i == null ? void 0 : i.errors) == null ? void 0 : _a2[0], c = d instanceof Error ? d.message : String(d || (i == null ? void 0 : i.message) || i || "");
      throw new Error(c ? `Failed to load IBC routes: ${c}` : "Failed to load IBC routes.");
    }
    const a = r.restEndpoint, l = r.payload.map((i) => {
      var _a3, _b;
      const d = (i == null ? void 0 : i.counterparty) || {};
      return {
        channelId: String((i == null ? void 0 : i.channel_id) ?? (i == null ? void 0 : i.channelId) ?? "").trim(),
        portId: String((i == null ? void 0 : i.port_id) ?? (i == null ? void 0 : i.portId) ?? "transfer").trim() || "transfer",
        counterpartyChannelId: String((d == null ? void 0 : d.channel_id) ?? (d == null ? void 0 : d.channelId) ?? "").trim(),
        counterpartyPortId: String((d == null ? void 0 : d.port_id) ?? (d == null ? void 0 : d.portId) ?? "").trim(),
        connectionId: String(((_a3 = i == null ? void 0 : i.connection_hops) == null ? void 0 : _a3[0]) ?? ((_b = i == null ? void 0 : i.connectionHops) == null ? void 0 : _b[0]) ?? "").trim(),
        state: String((i == null ? void 0 : i.state) || "").trim().toUpperCase()
      };
    }).filter((i) => !i.channelId || i.state && i.state !== "STATE_OPEN" && i.state !== "OPEN" ? false : i.portId === "transfer");
    return {
      restEndpoint: a,
      channels: l
    };
  }
  function Js(t) {
    const s = Vs(t), r = s ? Ot(s.chainId) : null;
    return {
      ...t,
      chainId: (s == null ? void 0 : s.chainId) || "",
      label: (s == null ? void 0 : s.label) || (t.counterpartyChannelId ? `Route ${t.counterpartyChannelId.replace(/^channel-/, "")}` : t.channelId),
      prefixHints: (r == null ? void 0 : r.addressPrefix) ? [
        r.addressPrefix
      ] : [],
      addressPrefix: (r == null ? void 0 : r.addressPrefix) || "",
      knownMeta: r,
      expectedDestinationDenom: (s == null ? void 0 : s.expectedDestinationDenom) || "",
      expectedDestinationTracePath: (s == null ? void 0 : s.expectedDestinationTracePath) || "",
      expectedDestinationSymbol: (s == null ? void 0 : s.expectedDestinationSymbol) || "",
      expectedDestinationDisplayName: (s == null ? void 0 : s.expectedDestinationDisplayName) || ""
    };
  }
  async function Ys(t, s = false) {
    var _a2, _b, _c, _d, _e2, _f;
    if (t.knownMeta && t.chainId) return t;
    const { restEndpoint: r } = await zt(s);
    let a = "";
    try {
      const v = await Kt(Ht(r, `/ibc/core/channel/v1/channels/${encodeURIComponent(t.channelId)}/ports/${encodeURIComponent(t.portId)}/client_state`), 3500);
      a = String(((_b = (_a2 = v == null ? void 0 : v.identified_client_state) == null ? void 0 : _a2.client_state) == null ? void 0 : _b.chain_id) || ((_d = (_c = v == null ? void 0 : v.identified_client_state) == null ? void 0 : _c.client_state) == null ? void 0 : _d.chainId) || ((_e2 = v == null ? void 0 : v.client_state) == null ? void 0 : _e2.chain_id) || ((_f = v == null ? void 0 : v.client_state) == null ? void 0 : _f.chainId) || "").trim();
    } catch {
      a = "";
    }
    const n = Ot(a), l = Array.from(/* @__PURE__ */ new Set([
      ...(n == null ? void 0 : n.addressPrefix) ? [
        n.addressPrefix
      ] : [],
      ...Gs(a)
    ])), i = n ? n.label : a || (t.counterpartyChannelId ? `${t.channelId} -> ${t.counterpartyChannelId}` : t.channelId);
    let d = "", c = "", u = "", x = "";
    return t.counterpartyChannelId && (d = `${t.counterpartyPortId || "transfer"}/${t.counterpartyChannelId}`, c = await zs(d, Nt), u = Fs(Nt), x = u ? `${u} via IBC` : "IBC Asset"), {
      ...t,
      chainId: a,
      label: i,
      prefixHints: l,
      addressPrefix: (n == null ? void 0 : n.addressPrefix) || l[0] || "",
      knownMeta: n,
      expectedDestinationDenom: c,
      expectedDestinationTracePath: d,
      expectedDestinationSymbol: u,
      expectedDestinationDisplayName: x
    };
  }
  async function Ft(t = false) {
    const { channels: s } = await zt(t);
    return s.map((r) => Js(r)).sort((r, a) => r.label.localeCompare(a.label));
  }
  const Me = /* @__PURE__ */ new Map(), Re = /* @__PURE__ */ new Map();
  function dt(t) {
    return String(t || "").replace(/\/+$/, "");
  }
  function We(t, s) {
    return `${dt(t)}${s}`;
  }
  function Xs(t) {
    return Array.from(t).map((s) => s.toString(16).padStart(2, "0")).join("").toUpperCase();
  }
  async function Zs(t, s) {
    const r = `${String(t || "").trim()}/${String(s).trim()}`.replace(/^\/+/, ""), a = new TextEncoder().encode(r), n = await globalThis.crypto.subtle.digest("SHA-256", a);
    return `ibc/${Xs(new Uint8Array(n))}`;
  }
  function er(t) {
    const r = String(t || "").trim().toLowerCase().match(/^([a-z0-9]{1,24})1[ac-hj-np-z02-9]{6,}$/);
    return r ? r[1] : "";
  }
  function tr(t) {
    const s = String(t || "").trim();
    return s.length <= 16 ? s : `${s.slice(0, 10)}...${s.slice(-6)}`;
  }
  function sr(t) {
    const s = Number(t);
    return Number.isFinite(s) && (s / 1e6).toFixed(6).replace(/\.?0+$/, "") || "0";
  }
  function rr(t) {
    const s = String(t || "").trim().toLowerCase();
    return s ? s === "ulmn" ? "LMN" : s === "ubze" ? "BZE" : s === "uusdc" ? "USDC" : s.startsWith("u") && s.length > 1 ? s.slice(1).toUpperCase() : s.startsWith("factory/") ? (s.split("/").pop() || s).toUpperCase() : s.startsWith("ibc/") ? "IBC" : s.toUpperCase() : "";
  }
  function nr(t, s, r) {
    const a = String(t || "").trim().toLowerCase();
    return (r == null ? void 0 : r.baseDenom) ? `${s} via IBC` : a === "ulmn" ? "Lumen" : a === "ubze" ? "BeeZee" : a === "uusdc" ? "USDC" : a.startsWith("ibc/") ? `${s} (IBC)` : s || t;
  }
  async function Se(t, s) {
    const r = new AbortController(), a = globalThis.setTimeout(() => r.abort(), s);
    let n;
    try {
      n = await fetch(t, {
        signal: r.signal
      });
    } finally {
      globalThis.clearTimeout(a);
    }
    if (!n.ok) throw new Error(`HTTP ${n.status} while fetching ${t}`);
    return n.json();
  }
  async function ar(t) {
    const s = Y.getInstance().getQuickRestEndpoint(), r = await Se(`${s}/cosmos/bank/v1beta1/balances/${encodeURIComponent(t)}`, 12e3);
    return (Array.isArray(r == null ? void 0 : r.balances) ? r.balances : []).map((n) => ({
      denom: String((n == null ? void 0 : n.denom) || "").trim(),
      amount: String((n == null ? void 0 : n.amount) || "0").trim() || "0"
    }));
  }
  async function or(t, s) {
    const r = await Se(We(t, `/cosmos/bank/v1beta1/balances/${encodeURIComponent(s)}`), 12e3);
    return (Array.isArray(r == null ? void 0 : r.balances) ? r.balances : []).map((n) => ({
      denom: String((n == null ? void 0 : n.denom) || "").trim(),
      amount: String((n == null ? void 0 : n.amount) || "0").trim() || "0"
    }));
  }
  async function ir(t, s, r) {
    var _a2;
    const a = String(r || "").trim();
    if (!a) return null;
    try {
      const l = ((_a2 = await Se(We(t, `/cosmos/bank/v1beta1/balances/${encodeURIComponent(s)}/by_denom?denom=${encodeURIComponent(a)}`), 12e3)) == null ? void 0 : _a2.balance) || null;
      return l ? {
        denom: String((l == null ? void 0 : l.denom) || a).trim() || a,
        amount: String((l == null ? void 0 : l.amount) || "0").trim() || "0"
      } : null;
    } catch {
      return null;
    }
  }
  async function lr(t, s, r) {
    const a = String(s).trim().toLowerCase(), n = String(r).trim().toLowerCase();
    if (!a || !n) return [];
    const l = `${dt(t)}|${a}|${n}`;
    if (Re.has(l)) return Re.get(l) || [];
    try {
      const i = await Se(We(t, "/ibc/core/channel/v1/channels?pagination.limit=200"), 12e3), d = (Array.isArray(i == null ? void 0 : i.channels) ? i.channels : []).map((x) => ({
        channelId: String((x == null ? void 0 : x.channel_id) || "").trim(),
        portId: String((x == null ? void 0 : x.port_id) || "transfer").trim() || "transfer",
        state: String((x == null ? void 0 : x.state) || "").trim().toUpperCase()
      })).filter((x) => x.channelId && x.portId === "transfer"), c = await Promise.all(d.map(async (x) => {
        var _a2, _b, _c, _d, _e2, _f;
        try {
          const v = await Se(We(t, `/ibc/core/channel/v1/channels/${encodeURIComponent(x.channelId)}/ports/${encodeURIComponent(x.portId)}/client_state`), 6e3), b = String(((_b = (_a2 = v == null ? void 0 : v.identified_client_state) == null ? void 0 : _a2.client_state) == null ? void 0 : _b.chain_id) || ((_d = (_c = v == null ? void 0 : v.identified_client_state) == null ? void 0 : _c.client_state) == null ? void 0 : _d.chainId) || ((_e2 = v == null ? void 0 : v.client_state) == null ? void 0 : _e2.chain_id) || ((_f = v == null ? void 0 : v.client_state) == null ? void 0 : _f.chainId) || "").trim().toLowerCase();
          return !b || b !== a && !b.startsWith(`${a}-`) ? "" : Zs(`${x.portId}/${x.channelId}`, r);
        } catch {
          return "";
        }
      })), u = Array.from(new Set(c.filter(Boolean)));
      return Re.set(l, u), u;
    } catch {
      return Re.set(l, []), [];
    }
  }
  async function cr(t, s, { isLocal: r = false } = {}) {
    const a = String(s || "").trim();
    if (!a || !a.toUpperCase().startsWith("IBC/")) return null;
    const n = a.slice(4), l = `${r ? "__local__" : dt(t)}|${n}`;
    if (Me.has(l)) return Me.get(l) || null;
    try {
      const i = r ? await Se(`${Y.getInstance().getQuickRestEndpoint()}/ibc/apps/transfer/v1/denom_traces/${encodeURIComponent(n)}`, 1e4) : await Se(We(t, `/ibc/apps/transfer/v1/denom_traces/${encodeURIComponent(n)}`), 1e4), d = (i == null ? void 0 : i.denom_trace) || (i == null ? void 0 : i.denomTrace) || null, c = d ? {
        baseDenom: String((d == null ? void 0 : d.base_denom) || (d == null ? void 0 : d.baseDenom) || "").trim(),
        path: String((d == null ? void 0 : d.path) || "").trim()
      } : null;
      return Me.set(l, c), c;
    } catch {
      return Me.set(l, null), null;
    }
  }
  function dr(t) {
    return t.knownMeta || null;
  }
  async function Ze(t) {
    var _a2, _b;
    const s = String(((_a2 = t.coin) == null ? void 0 : _a2.denom) || "").trim(), r = String(((_b = t.coin) == null ? void 0 : _b.amount) || "0").trim() || "0", a = s ? await cr(t.restEndpoint, s, {
      isLocal: t.isLocal
    }) : null, n = (a == null ? void 0 : a.baseDenom) || s, l = rr(n), i = nr(s, l, a), d = er(t.ownerAddress), c = BigInt(r) > 0n, u = t.transferTargets.length > 0 && BigInt(r) > 0n;
    return {
      id: `${t.chainId}:${s || "unknown"}`,
      chainId: t.chainId,
      chainLabel: t.chainLabel,
      ownerAddress: t.ownerAddress,
      addressPrefix: d,
      denom: s,
      microAmount: r,
      displayAmount: sr(r),
      displayName: i,
      displaySymbol: l,
      traceLabel: (a == null ? void 0 : a.path) ? `Trace: ${a.path}` : "",
      routeLabel: t.routeLabel,
      sendEnabled: c,
      transferEnabled: u,
      transferTargets: t.transferTargets,
      restEndpoint: t.restEndpoint,
      rpcEndpoint: t.rpcEndpoint,
      feeDenom: t.feeDenom,
      minGasPrice: t.minGasPrice,
      isLocal: t.isLocal,
      error: String(t.error || "")
    };
  }
  async function mr(t) {
    Me.clear(), Re.clear();
    const s = "lumen", r = "Lumen", a = Y.getInstance().getQuickRestEndpoint(), n = await Ft(true), l = Array.from(n.reduce((o, y) => {
      const g = y.chainId || y.channelId;
      if (o.has(g)) return o;
      const S = dr(y);
      return (S == null ? void 0 : S.addressPrefix) && o.set(g, {
        channel: y,
        meta: S
      }), o;
    }, /* @__PURE__ */ new Map())).map(([, o]) => o), i = await Promise.all(l.map(async (o) => ({
      ...o,
      ownerAddress: await De.deriveAddressWithPrefix(t.mnemonic, o.meta.addressPrefix)
    }))), d = i.map((o) => ({
      key: `${o.channel.chainId}:${o.channel.channelId}`,
      chainId: o.channel.chainId,
      chainLabel: o.channel.label || o.meta.label,
      addressPrefix: o.meta.addressPrefix,
      defaultRecipient: o.ownerAddress,
      sourceChannel: o.channel.channelId,
      sourcePort: o.channel.portId,
      routeLabel: `${o.meta.label} (${o.channel.channelId.replace(/^channel-/, "Route ")})`
    })), c = await ar(t.address), u = c.length ? c : [
      {
        denom: "ulmn",
        amount: "0"
      }
    ], x = await Promise.all(u.map((o) => Ze({
      chainId: s,
      chainLabel: r,
      ownerAddress: t.address,
      coin: o,
      transferTargets: d,
      routeLabel: d.length ? `Available to: ${d.map((y) => y.chainLabel).join(", ")}` : "No linked chain available.",
      restEndpoint: a,
      rpcEndpoint: "",
      feeDenom: "ulmn",
      minGasPrice: 0,
      isLocal: true
    }))), v = [], b = await Promise.all(i.map(async (o) => {
      const y = o.channel.chainId || o.channel.channelId, g = o.channel.counterpartyChannelId ? [
        {
          key: `${s}:${o.channel.counterpartyChannelId}`,
          chainId: s,
          chainLabel: r,
          addressPrefix: "lmn",
          defaultRecipient: t.address,
          sourceChannel: o.channel.counterpartyChannelId,
          sourcePort: o.channel.counterpartyPortId || "transfer",
          routeLabel: `Lumen (${(o.channel.counterpartyChannelId || "").replace(/^channel-/, "Route ")})`
        }
      ] : [], S = {
        denom: o.meta.nativeDenom,
        amount: "0"
      }, P = await lr(o.meta.restEndpoint, s, "ulmn"), k = Array.from(new Set([
        String(o.channel.expectedDestinationDenom || "").trim(),
        ...P
      ].filter(Boolean)));
      try {
        const C = await or(o.meta.restEndpoint, o.ownerAddress), N = await Promise.all(k.filter((j) => !C.some((w) => w.denom === j)).map((j) => ir(o.meta.restEndpoint, o.ownerAddress, j))), f = [
          ...C,
          ...N.filter((j) => !!j)
        ], L = f.length ? f : [
          S
        ];
        return Promise.all(L.map((j) => Ze({
          chainId: y,
          chainLabel: o.meta.label,
          ownerAddress: o.ownerAddress,
          coin: j,
          transferTargets: g,
          routeLabel: g.length ? `Return path: ${g[0].routeLabel}` : "No return path configured.",
          restEndpoint: o.meta.restEndpoint,
          rpcEndpoint: o.meta.rpcEndpoint,
          feeDenom: o.meta.feeDenom,
          minGasPrice: o.meta.minGasPrice,
          isLocal: false
        })));
      } catch (C) {
        return v.push(`${o.meta.label}: ${String((C == null ? void 0 : C.message) || C || "Failed to load balances")}`), [
          await Ze({
            chainId: y,
            chainLabel: o.meta.label,
            ownerAddress: o.ownerAddress,
            coin: S,
            transferTargets: g,
            routeLabel: g.length ? `Return path: ${g[0].routeLabel}` : "No return path configured.",
            restEndpoint: o.meta.restEndpoint,
            rpcEndpoint: o.meta.rpcEndpoint,
            feeDenom: o.meta.feeDenom,
            minGasPrice: o.meta.minGasPrice,
            isLocal: false,
            error: String((C == null ? void 0 : C.message) || C || "Failed to load balances")
          })
        ];
      }
    }));
    return {
      rows: [
        ...x,
        ...b.flat()
      ].sort((o, y) => o.chainId !== y.chainId ? o.isLocal ? -1 : y.isLocal ? 1 : o.chainLabel.localeCompare(y.chainLabel) : o.transferEnabled !== y.transferEnabled ? o.transferEnabled ? -1 : 1 : o.displayName.localeCompare(y.displayName)),
      errors: v
    };
  }
  function ur(t) {
    return `${tr(t.ownerAddress)}${t.addressPrefix ? ` \xB7 ${t.addressPrefix.toUpperCase()}` : ""}`;
  }
  function xr(t) {
    const s = String(t.denom || "").trim().toLowerCase();
    return !(!s || s.startsWith("ibc/") || s === "ulmn" || s === "ubze" || s === "uusdc");
  }
  const et = ({ onWalletReady: t, activeKeys: s, isAdding: r, onCancel: a, showLinkModal: n, onCloseLinkModal: l }) => {
    const i = lt(), [d, c] = m.useState(r ? "create-method" : "welcome"), [u, x] = je.useState(false), v = je.useRef("0"), [b, h] = m.useState(null), [o, y] = m.useState(null), [g, S] = m.useState(false), [P, k] = m.useState("0.00"), [C, N] = m.useState(() => localStorage.getItem("hideBalance") === "true"), f = (p) => {
      p.stopPropagation();
      const I = !C;
      N(I), localStorage.setItem("hideBalance", String(I));
    }, [L, j] = m.useState(false), [w, A] = m.useState(null), [T, B] = m.useState(false), [E, _] = m.useState(false), [R, K] = m.useState(null), [Q, re] = m.useState([]), [X, ne] = m.useState(false), [$, W] = m.useState(null), q = je.useRef(0);
    je.useEffect(() => {
      if (!s) return;
      const p = async () => {
        var _a2;
        try {
          const z = Y.getInstance().getQuickRestEndpoint(), O = await fetch(`${z}/cosmos/bank/v1beta1/balances/${s.address}`);
          if (!O.ok) throw new Error("Failed to fetch balance");
          if (O.ok) {
            const xe = ((_a2 = (await O.json()).balances.find((de) => de.denom === "ulmn")) == null ? void 0 : _a2.amount) || "0", Ne = (parseFloat(xe) / 1e6).toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 6
            });
            k(Ne);
            const oe = parseFloat(v.current);
            parseFloat(xe) > oe && oe > 0 && ge.onBalanceIncrease(s.address), v.current = xe;
          }
        } catch {
        }
      };
      p();
      const I = setInterval(p, 1e4);
      return () => clearInterval(I);
    }, [
      s
    ]), je.useEffect(() => {
      if (!(s == null ? void 0 : s.address)) return;
      ge.syncGap(s.address), ge.syncBlocks(s.address);
    }, [
      s
    ]);
    const Z = je.useCallback(async (p = true) => {
      if (!s) return;
      const I = ++q.current;
      try {
        p && ne(true);
        const z = await mr(s);
        if (I !== q.current) return;
        re(z.rows), W(z.errors.length ? z.errors.join(" \xB7 ") : null);
      } catch (z) {
        if (I !== q.current) return;
        re([]), W((z == null ? void 0 : z.message) || "Failed to load assets.");
      } finally {
        I === q.current && ne(false);
      }
    }, [
      s
    ]);
    je.useEffect(() => {
      if (!s) return;
      Z(true);
      const p = setInterval(() => {
        Z(false);
      }, 15e3);
      return () => clearInterval(p);
    }, [
      s,
      Z
    ]);
    const F = async () => {
      if (o) try {
        x(true);
        const p = await V.getWallets();
        if (p.some((z) => z.address === o.address)) {
          alert("Wallet already exists!"), x(false);
          return;
        }
        const I = [
          ...p,
          o
        ];
        await V.saveWallets(I), t();
      } catch (p) {
        console.error(p);
        const I = p.message === "Session expired." ? "Wallet is locked. Please unlock your wallet in the extension popup first before adding a new one." : "Failed to add wallet: " + p.message;
        h(I), x(false);
      }
    }, G = async (p) => {
      if (o) try {
        if (x(true), await V.hasWallet()) {
          h("A wallet already exists on this device. Please unlock it and use 'Add Wallet' instead of creating a new vault."), x(false);
          return;
        }
        await V.lock([
          o
        ], p), t();
      } catch (I) {
        console.error(I), h("Failed to encrypt wallet.");
      } finally {
        x(false);
      }
    }, U = async (p) => {
      try {
        const I = await V.getWallets(), z = I.findIndex((O) => O.address === p.address);
        if (z === -1) return;
        I[z] = {
          ...I[z],
          ...p
        }, await V.saveWallets(I), t();
      } catch (I) {
        console.error("Failed to update wallet in vault:", I);
      }
    }, se = async () => {
      try {
        x(true), h(null);
        const p = await De.createWallet();
        y(p), c("mnemonic-display");
      } catch (p) {
        h(p.message || "Generation failed");
      } finally {
        x(false);
      }
    }, ae = async (p) => {
      try {
        if (S(true), h(null), r) try {
          await V.getWallets();
        } catch {
          h("Session expired or vault locked. Please unlock and try again.");
          return;
        }
        const I = await p();
        if (y(I), r) {
          const z = await V.getWallets();
          if (z.some((ue) => ue.address === I.address)) {
            h("Wallet already exists in your vault.");
            return;
          }
          const O = [
            ...z,
            I
          ];
          await V.saveWallets(O), t();
          return;
        }
        c("set-password");
      } catch (I) {
        h(I.message || "Import failed");
      } finally {
        S(false);
      }
    };
    return s ? e.jsxs("div", {
      className: "h-full overflow-y-auto space-y-6 animate-slide-up relative pb-24",
      children: [
        n && e.jsx("div", {
          className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in",
          children: e.jsxs("div", {
            className: "w-full max-w-sm bg-surface border border-border rounded-xl relative",
            children: [
              e.jsx("button", {
                onClick: l,
                className: "absolute top-2 right-2 p-1 text-[var(--text-muted)] hover:text-foreground rounded-full hover:bg-white/5 transition-colors z-10",
                children: e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M6 18L18 6M6 6l12 12"
                  })
                })
              }),
              e.jsx("div", {
                className: "p-4 pt-8",
                children: e.jsx(Ut, {
                  wallet: s,
                  onWalletUpdate: U,
                  isModal: true
                })
              })
            ]
          })
        }),
        e.jsx("div", {
          className: "relative mt-2 px-1",
          children: e.jsxs("div", {
            className: "premium-card rounded-3xl p-6 transition-all duration-700 group/balance",
            children: [
              e.jsx("div", {
                className: "absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-lumen/5 opacity-50 group-hover/balance:opacity-100 transition-opacity duration-700"
              }),
              e.jsxs("div", {
                className: "relative z-10",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center justify-between mb-8",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                          e.jsx("div", {
                            className: "w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(99,102,241,0.8)]"
                          }),
                          e.jsx("span", {
                            className: "text-[10px] font-bold text-foreground/40 tracking-[0.2em] uppercase",
                            children: "Total Balance"
                          }),
                          e.jsx("button", {
                            onClick: f,
                            className: "p-1.5 text-foreground/20 hover:text-foreground transition-all rounded-lg hover:bg-foreground/5",
                            children: C ? e.jsxs("svg", {
                              className: "w-3.5 h-3.5",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: [
                                e.jsx("path", {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                                }),
                                e.jsx("path", {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                })
                              ]
                            }) : e.jsx("svg", {
                              className: "w-3.5 h-3.5",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                              })
                            })
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-1.5 bg-green-500/10 px-2.5 py-1 rounded-full border border-green-500/20 backdrop-blur-md",
                        children: [
                          e.jsx("div", {
                            className: "w-1 h-1 rounded-full bg-green-500 shadow-[0_0_5px_rgba(34,197,94,1)] animate-pulse"
                          }),
                          e.jsx("span", {
                            className: "text-[9px] font-black text-green-500 uppercase tracking-widest",
                            children: "Secured"
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "mb-8",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-baseline gap-2.5 mb-1.5",
                        children: [
                          e.jsx("span", {
                            className: "text-5xl font-black text-foreground tracking-tight leading-none",
                            children: C ? "\u2022\u2022\u2022\u2022\u2022\u2022" : P.split(".")[0]
                          }),
                          !C && e.jsxs("span", {
                            className: "text-3xl font-bold text-foreground/40 tabular-nums",
                            children: [
                              ".",
                              P.split(".")[1] || "00"
                            ]
                          }),
                          e.jsx("span", {
                            className: "text-base font-black text-primary/50 tracking-tighter ml-1",
                            children: "LMN"
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx("div", {
                            className: "h-[1px] w-8 bg-foreground/10"
                          }),
                          e.jsx("span", {
                            className: "text-[11px] font-bold text-foreground/30 font-mono tracking-tight",
                            children: "\u2248 $0.00 USD"
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "relative group/address",
                    children: [
                      e.jsx("div", {
                        className: "absolute inset-0 bg-foreground/5 rounded-xl blur-xl opacity-0 group-hover/address:opacity-100 transition-opacity"
                      }),
                      e.jsxs("div", {
                        className: "relative bg-foreground/5 rounded-xl p-3.5 flex items-center justify-between hover:bg-foreground/10 transition-colors",
                        children: [
                          e.jsxs("div", {
                            className: "flex-1 min-w-0 pr-4",
                            children: [
                              e.jsx("div", {
                                className: "text-[8px] font-black text-foreground/30 mb-1 uppercase tracking-[0.2em]",
                                children: "Address"
                              }),
                              e.jsxs("div", {
                                className: "font-mono text-[10px] text-foreground/60 leading-relaxed tracking-tight break-all",
                                children: [
                                  s.address.substring(0, 24),
                                  e.jsx("wbr", {}),
                                  s.address.substring(24)
                                ]
                              })
                            ]
                          }),
                          e.jsx("button", {
                            onClick: () => {
                              navigator.clipboard.writeText(s.address), _(true), setTimeout(() => _(false), 2e3);
                            },
                            className: `p-2.5 rounded-lg transition-all active:scale-90 border border-border/50 ${E ? "bg-green-500 text-white shadow-lg shadow-green-500/20 border-green-500" : "bg-surface text-foreground/40 hover:text-primary hover:shadow-lg"}`,
                            children: E ? e.jsx("svg", {
                              className: "w-3.5 h-3.5",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 3,
                                d: "M5 13l4 4L19 7"
                              })
                            }) : e.jsx("svg", {
                              className: "w-3.5 h-3.5",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                              })
                            })
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            ]
          })
        }),
        e.jsx(Ps, {
          onReceive: () => {
            A(null), j(true);
          },
          onHistory: () => B(true)
        }),
        e.jsxs("section", {
          className: "px-4 pb-2 space-y-3",
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx("h3", {
                      className: "text-sm font-bold text-foreground",
                      children: "Assets Across Chains"
                    }),
                    e.jsx("p", {
                      className: "text-[11px] text-[var(--text-muted)]",
                      children: "See what you hold on Lumen and linked IBC chains."
                    })
                  ]
                }),
                e.jsx("button", {
                  onClick: () => {
                    Z(true);
                  },
                  className: "text-[10px] font-bold text-primary hover:text-primary-hover transition-colors",
                  children: X ? "Refreshing..." : "Refresh"
                })
              ]
            }),
            $ && e.jsx("div", {
              className: "rounded-2xl border border-amber-500/20 bg-amber-500/10 p-3",
              children: e.jsx("p", {
                className: "text-[11px] text-amber-300 leading-relaxed",
                children: $
              })
            }),
            e.jsx("div", {
              className: "space-y-3",
              children: Q.filter((p) => !(p.isLocal && p.denom === "ulmn")).map((p) => e.jsxs("div", {
                className: "rounded-2xl border border-border bg-surface p-4 space-y-3",
                children: [
                  e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs("div", {
                        children: [
                          e.jsxs("div", {
                            className: "flex items-center gap-2",
                            children: [
                              e.jsx("p", {
                                className: "text-sm font-semibold text-foreground",
                                children: p.displayName
                              }),
                              p.chainLabel.trim().toLowerCase() !== p.displayName.trim().toLowerCase() && e.jsx("span", {
                                className: "rounded-full border border-border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-primary",
                                children: p.chainLabel
                              })
                            ]
                          }),
                          e.jsxs("div", {
                            className: "mt-1 flex items-center justify-between gap-3",
                            children: [
                              e.jsx("p", {
                                className: "text-[11px] text-[var(--text-muted)]",
                                children: ur(p)
                              }),
                              e.jsx("button", {
                                onClick: () => {
                                  navigator.clipboard.writeText(p.ownerAddress), K(p.id), setTimeout(() => {
                                    K((I) => I === p.id ? null : I);
                                  }, 2e3);
                                },
                                className: `shrink-0 p-2 rounded-lg transition-all active:scale-90 border border-border/50 ${R === p.id ? "bg-green-500 text-white shadow-lg shadow-green-500/20 border-green-500" : "bg-surface text-foreground/40 hover:text-primary hover:shadow-lg"}`,
                                "aria-label": "Copy address",
                                title: "Copy address",
                                children: R === p.id ? e.jsx("svg", {
                                  className: "w-3.5 h-3.5",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  children: e.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 3,
                                    d: "M5 13l4 4L19 7"
                                  })
                                }) : e.jsx("svg", {
                                  className: "w-3.5 h-3.5",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  children: e.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                                  })
                                })
                              })
                            ]
                          })
                        ]
                      }),
                      xr(p) && e.jsx("p", {
                        className: "text-[11px] break-all text-[var(--text-muted)]",
                        children: p.denom
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "rounded-2xl border border-border/60 bg-background/60 px-4 py-3",
                    children: [
                      e.jsx("p", {
                        className: "text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--text-muted)]",
                        children: "Balance"
                      }),
                      e.jsxs("div", {
                        className: "mt-1 flex items-end gap-2",
                        children: [
                          e.jsx("p", {
                            className: "text-2xl font-black text-foreground leading-none",
                            children: p.displayAmount
                          }),
                          e.jsx("p", {
                            className: "text-sm font-bold text-primary/80",
                            children: p.displaySymbol
                          })
                        ]
                      })
                    ]
                  }),
                  !!p.error && e.jsx("div", {
                    className: "space-y-1",
                    children: e.jsx("p", {
                      className: "text-[11px] text-amber-300",
                      children: p.error
                    })
                  }),
                  e.jsxs("div", {
                    className: "grid grid-cols-2 gap-2",
                    children: [
                      e.jsx("button", {
                        onClick: () => {
                          A(p), j(true);
                        },
                        className: "rounded-xl border border-border bg-background px-3 py-2 text-xs font-bold text-foreground transition-colors hover:bg-surfaceHighlight",
                        children: "Receive"
                      }),
                      e.jsx("button", {
                        onClick: () => i("/send", {
                          state: {
                            assetContext: p,
                            initialMode: "same-chain"
                          }
                        }),
                        disabled: !p.sendEnabled,
                        className: "rounded-xl border border-border bg-background px-3 py-2 text-xs font-bold text-foreground transition-colors hover:bg-surfaceHighlight disabled:cursor-not-allowed disabled:opacity-40",
                        children: "Send"
                      })
                    ]
                  })
                ]
              }, p.id))
            })
          ]
        }),
        L && e.jsx(As, {
          address: (w == null ? void 0 : w.ownerAddress) || s.address,
          title: w ? `Receive On ${w.chainLabel}` : "Receive Assets",
          helperText: w ? `Only send ${w.chainLabel} assets to this address.` : "Only send Lumen (LMN) assets to this address.",
          onClose: () => {
            j(false), A(null);
          }
        }),
        T && e.jsx(Ws, {
          address: s.address,
          onClose: () => B(false)
        })
      ]
    }) : d === "welcome" ? e.jsx(Ns, {
      onCreateNew: () => c("create-method"),
      onImportExisting: () => c("import"),
      onBack: a
    }) : d === "create-method" ? e.jsx(ks, {
      onSelectMnemonic: se,
      onSelectImport: () => c("import"),
      onBack: () => c("welcome")
    }) : d === "mnemonic-display" && o ? e.jsx(Cs, {
      mnemonic: o.mnemonic,
      pqcKey: o.pqcKey,
      address: o.address,
      onConfirm: () => c("mnemonic-verify"),
      onBack: () => c("create-method")
    }) : d === "mnemonic-verify" && o ? e.jsx(Ss, {
      mnemonic: o.mnemonic,
      onVerified: () => {
        r ? F() : c("set-password");
      },
      onBack: () => c("mnemonic-display")
    }) : d === "import" ? e.jsx(Ls, {
      onImport: (p, I) => ae(() => De.importWallet(p, I)),
      onGenerateFreshPqc: (p) => ae(() => De.recoverFromMnemonic(p)),
      onBack: () => c(r ? "create-method" : "welcome"),
      isLoading: g,
      error: b
    }) : d === "set-password" ? e.jsx(ws, {
      onConfirm: G
    }) : null;
  }, hr = ({ onUnlock: t, error: s }) => {
    const [r, a] = m.useState(""), [n, l] = m.useState(false);
    return e.jsxs("div", {
      className: "flex flex-col h-full justify-between p-8 animate-fade-in bg-gradient-to-b from-background via-background to-surface",
      children: [
        e.jsxs("div", {
          className: "flex-1 flex flex-col justify-center",
          children: [
            e.jsxs("div", {
              className: "text-center mb-10 relative z-10",
              children: [
                e.jsxs("div", {
                  className: "relative w-24 h-24 mx-auto mb-6 group",
                  children: [
                    e.jsx("div", {
                      className: "absolute inset-0 bg-gradient-to-r from-primary via-lumen to-primary-light rounded-full blur-3xl opacity-40 group-hover:opacity-60 transition-all duration-700 animate-pulse-slow"
                    }),
                    e.jsx("img", {
                      src: "/icons/logo.png",
                      alt: "Lumen Wallet",
                      className: "w-full h-full object-contain relative z-10 transform group-hover:scale-105 transition-transform duration-500"
                    })
                  ]
                }),
                e.jsx("h2", {
                  className: "text-3xl font-bold text-foreground mb-2 font-display tracking-tight",
                  children: "Welcome Back"
                }),
                e.jsx("p", {
                  className: "text-[var(--text-muted)] text-sm font-medium",
                  children: "Enter your password to unlock"
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-semibold text-[var(--text-muted)] ml-1 uppercase tracking-wide",
                      children: "Password"
                    }),
                    e.jsxs("div", {
                      className: "relative",
                      children: [
                        e.jsx("input", {
                          type: n ? "text" : "password",
                          value: r,
                          onChange: (i) => a(i.target.value),
                          onKeyDown: (i) => i.key === "Enter" && r && t(r),
                          className: "w-full bg-surface border-2 border-border rounded-xl p-4 pr-12 text-foreground focus:border-primary outline-none transition-all placeholder:text-[var(--text-dim)]",
                          placeholder: "Enter your password",
                          autoFocus: true
                        }),
                        e.jsx("button", {
                          type: "button",
                          onClick: () => l(!n),
                          className: "absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-foreground transition-colors",
                          children: n ? e.jsx("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: e.jsx("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: 2,
                              d: "M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                            })
                          }) : e.jsxs("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: [
                              e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                              }),
                              e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                              })
                            ]
                          })
                        })
                      ]
                    })
                  ]
                }),
                s && e.jsxs("div", {
                  className: "p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-2 animate-fade-in",
                  children: [
                    e.jsx("svg", {
                      className: "w-5 h-5 text-red-500 shrink-0 mt-0.5",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      })
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx("p", {
                          className: "text-red-400 text-sm font-medium",
                          children: s
                        }),
                        e.jsx("p", {
                          className: "text-red-400/70 text-xs mt-1",
                          children: "Please try again or reset your wallet"
                        })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "space-y-3",
          children: [
            e.jsx("button", {
              onClick: () => t(r),
              disabled: !r,
              className: "w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-hover hover:to-primary disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100",
              children: "Unlock Wallet"
            }),
            e.jsx("button", {
              className: "w-full text-[var(--text-muted)] hover:text-foreground text-sm font-medium py-2 transition-colors",
              children: "Forgot Password?"
            })
          ]
        })
      ]
    });
  }, pr = ({ wallets: t, activeWalletIndex: s, activeWalletName: r, onSwitch: a, onAdd: n, onLock: l, onSettings: i, onRename: d, onBackup: c, onLinkPqc: u, onDelete: x }) => {
    var _a2;
    const [v, b] = m.useState(false), [h, o] = m.useState(null), [y, g] = m.useState(""), S = (k, C, N) => {
      k.stopPropagation(), o(C), g(N);
    }, P = (k, C) => {
      k.preventDefault(), d(C, y.trim() || `Wallet ${C + 1}`), o(null);
    };
    return e.jsxs("div", {
      className: "relative",
      children: [
        e.jsxs("div", {
          onClick: () => b(!v),
          className: "flex items-center gap-2 p-2 rounded-lg hover:bg-surfaceHighlight transition-all group cursor-pointer",
          title: "Wallet Settings",
          children: [
            e.jsxs("div", {
              className: "flex flex-col items-end mr-1 min-w-0",
              children: [
                e.jsx("span", {
                  className: "text-xs font-bold text-foreground tracking-wide truncate max-w-[120px]",
                  children: r
                }),
                e.jsx("span", {
                  className: "text-[9px] text-green-400 font-medium tracking-wider",
                  children: "Connected"
                })
              ]
            }),
            e.jsx("div", {
              className: "w-8 h-8 rounded-full bg-surface border border-border flex items-center justify-center group-hover:border-primary/50 transition-colors",
              children: e.jsxs("svg", {
                className: "w-5 h-5 text-[var(--text-muted)] group-hover:text-primary transition-colors",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: [
                  e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                  }),
                  e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  })
                ]
              })
            })
          ]
        }),
        v && e.jsxs(e.Fragment, {
          children: [
            e.jsx("div", {
              className: "fixed inset-0 z-[99998]",
              onClick: () => {
                b(false), o(null);
              }
            }),
            e.jsxs("div", {
              className: "absolute right-0 top-full mt-2 w-64 bg-surface border border-border rounded-xl z-[99999] animate-fade-in overflow-hidden",
              children: [
                e.jsxs("div", {
                  className: "p-3 border-b border-border flex items-center justify-between",
                  children: [
                    e.jsx("span", {
                      className: "text-[10px] font-bold text-[var(--text-dim)] uppercase tracking-widest",
                      children: "Wallets"
                    }),
                    e.jsxs("span", {
                      className: "text-[10px] text-primary bg-primary/10 px-1.5 py-0.5 rounded font-mono",
                      children: [
                        t.length,
                        " Active"
                      ]
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "max-h-64 overflow-y-auto",
                  children: t.map((k, C) => {
                    var _a3, _b;
                    return e.jsx("div", {
                      className: "relative group/item",
                      children: h === C ? e.jsx("form", {
                        onSubmit: (N) => P(N, C),
                        className: "p-2 bg-surfaceHighlight",
                        children: e.jsx("input", {
                          autoFocus: true,
                          value: y,
                          onChange: (N) => g(N.target.value),
                          onBlur: (N) => P(N, C),
                          className: "w-full bg-background border border-primary rounded px-2 py-1 text-xs text-foreground outline-none"
                        })
                      }) : e.jsxs("div", {
                        onClick: () => {
                          a(C), b(false);
                        },
                        className: `w-full text-left px-3 py-3 hover:bg-surfaceHighlight flex items-center gap-3 group transition-colors border-l-2 cursor-pointer ${C === s ? "border-green-500 bg-green-500/5" : "border-transparent hover:border-primary"}`,
                        children: [
                          e.jsx("div", {
                            className: "w-5 h-5 flex items-center justify-center shrink-0",
                            children: C === s ? e.jsx("svg", {
                              className: "w-4 h-4 text-green-500",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M5 13l4 4L19 7"
                              })
                            }) : e.jsx("div", {
                              className: "w-1.5 h-1.5 rounded-full bg-surface border border-border group-hover:bg-primary/50 transition-colors"
                            })
                          }),
                          e.jsxs("div", {
                            className: "flex flex-col overflow-hidden flex-1",
                            children: [
                              e.jsx("div", {
                                className: "flex items-center gap-2",
                                children: e.jsx("span", {
                                  className: `text-xs font-bold truncate ${C === s ? "text-primary" : "text-foreground"}`,
                                  children: ((_a3 = k.pqcKey) == null ? void 0 : _a3.name) || ((_b = k.pqc) == null ? void 0 : _b.name) || "Wallet " + (C + 1)
                                })
                              }),
                              e.jsxs("span", {
                                className: "text-[10px] text-[var(--text-muted)] font-mono",
                                children: [
                                  k.address.slice(0, 10),
                                  "...",
                                  k.address.slice(-6)
                                ]
                              })
                            ]
                          }),
                          e.jsxs("div", {
                            className: "flex opacity-0 group-hover:opacity-100 transition-opacity",
                            children: [
                              e.jsx("button", {
                                onClick: (N) => {
                                  var _a4, _b2;
                                  return S(N, C, ((_a4 = k.pqcKey) == null ? void 0 : _a4.name) || ((_b2 = k.pqc) == null ? void 0 : _b2.name) || "Wallet " + (C + 1));
                                },
                                className: "p-1.5 hover:bg-surface rounded text-[var(--text-muted)] hover:text-primary transition-all",
                                title: "Rename",
                                children: e.jsx("svg", {
                                  className: "w-3.5 h-3.5",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  children: e.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                                  })
                                })
                              }),
                              x && e.jsx("button", {
                                onClick: (N) => {
                                  var _a4, _b2;
                                  N.stopPropagation(), confirm(`Are you sure you want to delete ${((_a4 = k.pqcKey) == null ? void 0 : _a4.name) || ((_b2 = k.pqc) == null ? void 0 : _b2.name) || "this wallet"}? This action cannot be undone.`) && x(k.address);
                                },
                                className: "p-1.5 hover:bg-red-500/10 rounded text-[var(--text-muted)] hover:text-red-500 transition-all ml-1",
                                title: "Delete Wallet",
                                children: e.jsx("svg", {
                                  className: "w-3.5 h-3.5",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  children: e.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                  })
                                })
                              })
                            ]
                          })
                        ]
                      })
                    }, k.address);
                  })
                }),
                e.jsxs("div", {
                  className: "p-1 border-t border-border bg-surface/50 space-y-1",
                  children: [
                    e.jsxs("button", {
                      onClick: () => {
                        n(), b(false);
                      },
                      className: "w-full flex items-center gap-3 px-3 py-2 text-xs text-foreground font-medium hover:bg-surfaceHighlight hover:text-primary rounded-lg transition-colors group",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4 text-[var(--text-muted)] group-hover:text-primary transition-colors",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M12 4v16m8-8H4"
                          })
                        }),
                        "Add / Import Wallet"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => {
                        c(s), b(false);
                      },
                      className: "w-full flex items-center gap-3 px-3 py-2 text-xs text-foreground font-medium hover:bg-surfaceHighlight hover:text-primary rounded-lg transition-colors group",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4 text-[var(--text-muted)] group-hover:text-primary transition-colors",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                          })
                        }),
                        "Secure Wallet (Backup)"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => {
                        i(), b(false);
                      },
                      className: "w-full flex items-center gap-3 px-3 py-2 text-xs text-foreground font-medium hover:bg-surfaceHighlight hover:text-primary rounded-lg transition-colors group",
                      children: [
                        e.jsxs("svg", {
                          className: "w-4 h-4 text-[var(--text-muted)] group-hover:text-primary transition-colors",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: [
                            e.jsx("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: 2,
                              d: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-1.065-2.572c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                            }),
                            e.jsx("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: 2,
                              d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                            })
                          ]
                        }),
                        "Settings"
                      ]
                    }),
                    ((_a2 = t[s]) == null ? void 0 : _a2.linked) ? e.jsxs("button", {
                      disabled: true,
                      className: "w-full flex items-center gap-3 px-3 py-2 text-xs text-green-600 dark:text-green-500 font-medium bg-green-500/10 rounded-lg cursor-default transition-colors opacity-80",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4 text-green-600 dark:text-green-500",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                          })
                        }),
                        "PQC Security Active"
                      ]
                    }) : e.jsxs("button", {
                      onClick: () => {
                        u == null ? void 0 : u(), b(false);
                      },
                      className: "w-full flex items-center gap-3 px-3 py-2 text-xs text-yellow-600 dark:text-yellow-500 font-medium hover:bg-yellow-500/10 rounded-lg transition-colors group",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4 text-yellow-600 dark:text-yellow-500",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                          })
                        }),
                        "Link PQC Account"
                      ]
                    }),
                    e.jsx("div", {
                      className: "h-px bg-white/5 my-1"
                    }),
                    e.jsxs("button", {
                      onClick: () => {
                        l(), b(false);
                      },
                      className: "w-full flex items-center gap-3 px-3 py-2 text-xs text-red-400 font-medium hover:bg-red-500/10 rounded-lg transition-colors",
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                          })
                        }),
                        "Lock Wallet"
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  }, fr = ({ onBack: t }) => {
    var _a2, _b;
    const [s, r] = m.useState("minute"), [a, n] = m.useState(5), [l, i] = m.useState(false), [d, c] = m.useState([]), [u, x] = m.useState(true), [v, b] = m.useState(null), [h, o] = m.useState(""), [y, g] = m.useState("");
    m.useEffect(() => {
      (async () => {
        const L = await V.getLockSettings();
        r(L.type), n(L.value);
        const j = Y.getInstance();
        x(j.isAutoMode()), b(j.getSelectedProvider() === "Auto" ? null : j.getSelectedProvider()), o(await j.getRestEndpoint()), g(await j.getRpcEndpoint());
        try {
          const A = (await chrome.storage.local.get([
            "connectedOrigins"
          ])).connectedOrigins || [];
          c(A);
        } catch {
        }
      })();
    }, []);
    const S = async () => {
      const f = !u;
      x(f);
      const L = Y.getInstance();
      f ? (L.setAuto(true), b(null)) : v && L.setManualProvider(v), o(await L.getRestEndpoint(true)), g(await L.getRpcEndpoint());
    }, P = async () => {
      var _a3, _b2;
      Y.getInstance().setAuto(true), x(true), b(null);
      try {
        await chrome.storage.local.remove([
          "rpc_settings"
        ]);
      } catch {
      }
      o(((_a3 = $e[0]) == null ? void 0 : _a3.address) || ""), g(((_b2 = bt[0]) == null ? void 0 : _b2.address) || "");
    }, k = async () => {
      await V.setLockTimeout(s, a);
      const f = Y.getInstance();
      u ? f.setAuto(true) : v && f.setManualProvider(v), await f.saveSettings(), o(await f.getRestEndpoint(true)), g(await f.getRpcEndpoint()), i(true), setTimeout(() => i(false), 2e3);
    }, C = async (f) => {
      try {
        const w = ((await chrome.storage.local.get([
          "connectedOrigins"
        ])).connectedOrigins || []).filter((A) => A !== f);
        await chrome.storage.local.set({
          connectedOrigins: w
        }), c(w);
      } catch (L) {
        console.error("Error disconnecting dApp:", L);
      }
    }, N = (f) => {
      try {
        return new URL(f).hostname;
      } catch {
        return f;
      }
    };
    return e.jsxs("div", {
      className: "flex flex-col h-full min-h-0 animate-fade-in relative",
      children: [
        e.jsxs("header", {
          className: "flex items-center gap-4 p-4 border-b border-border",
          children: [
            e.jsx("button", {
              onClick: t,
              className: "p-2 -ml-2 text-[var(--text-muted)] hover:text-foreground transition-colors rounded-lg hover:bg-surfaceHighlight",
              children: e.jsx("svg", {
                className: "w-5 h-5",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: e.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M10 19l-7-7m0 0l7-7m-7 7h18"
                })
              })
            }),
            e.jsx("h2", {
              className: "text-lg font-bold text-foreground",
              children: "Settings"
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex-1 overflow-y-auto p-6 pb-24 space-y-8",
          children: [
            e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2 text-primary",
                  children: [
                    e.jsx("svg", {
                      className: "w-5 h-5",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                      })
                    }),
                    e.jsx("h3", {
                      className: "font-bold text-sm uppercase tracking-wider",
                      children: "Auto-Lock Timer"
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "text-xs text-[var(--text-muted)] leading-relaxed",
                  children: "Your wallet will automatically lock after being idle for this duration."
                }),
                e.jsxs("div", {
                  className: "bg-surface rounded-xl p-4 border border-border space-y-4",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-4",
                      children: [
                        e.jsx("input", {
                          type: "number",
                          min: "1",
                          value: a,
                          onChange: (f) => n(Math.max(1, parseInt(f.target.value) || 1)),
                          className: "w-20 bg-surfaceHighlight border border-border rounded-lg p-2 text-center text-foreground font-mono focus:border-primary outline-none transition-colors"
                        }),
                        e.jsxs("div", {
                          className: "flex bg-surfaceHighlight rounded-lg p-1 border border-border transition-colors",
                          children: [
                            e.jsx("button", {
                              onClick: () => r("minute"),
                              className: `px-3 py-1.5 rounded text-xs font-medium transition-all ${s === "minute" ? "bg-primary text-white shadow" : "text-[var(--text-muted)] hover:text-foreground"}`,
                              children: "Minutes"
                            }),
                            e.jsx("button", {
                              onClick: () => r("hour"),
                              className: `px-3 py-1.5 rounded text-xs font-medium transition-all ${s === "hour" ? "bg-primary text-white shadow" : "text-[var(--text-muted)] hover:text-foreground"}`,
                              children: "Hours"
                            }),
                            e.jsx("button", {
                              onClick: () => r("day"),
                              className: `px-3 py-1.5 rounded text-xs font-medium transition-all ${s === "day" ? "bg-primary text-white shadow" : "text-[var(--text-muted)] hover:text-foreground"}`,
                              children: "Days"
                            })
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "text-[10px] text-[var(--text-dim)] font-mono",
                      children: [
                        "Auto-lock after: ",
                        e.jsxs("span", {
                          className: "text-foreground",
                          children: [
                            a,
                            " ",
                            s,
                            "(s)"
                          ]
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2 text-primary",
                  children: [
                    e.jsx("svg", {
                      className: "w-5 h-5",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                      })
                    }),
                    e.jsx("h3", {
                      className: "font-bold text-sm uppercase tracking-wider",
                      children: "Connected Applications"
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "text-xs text-[var(--text-muted)] leading-relaxed",
                  children: "Manage applications that have permission to view your account address."
                }),
                e.jsx("div", {
                  className: "bg-surface rounded-xl border border-border overflow-hidden",
                  children: d.length === 0 ? e.jsx("div", {
                    className: "p-4 text-center text-xs text-[var(--text-dim)]",
                    children: "No applications connected"
                  }) : e.jsx("div", {
                    className: "divide-y divide-border",
                    children: d.map((f) => e.jsxs("div", {
                      className: "flex items-center justify-between p-3",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-3 overflow-hidden",
                          children: [
                            e.jsx("div", {
                              className: "w-8 h-8 rounded-full bg-surfaceHighlight flex items-center justify-center shrink-0",
                              children: e.jsx("span", {
                                className: "text-xs font-bold text-primary",
                                children: N(f).charAt(0).toUpperCase()
                              })
                            }),
                            e.jsxs("div", {
                              className: "truncate",
                              children: [
                                e.jsx("div", {
                                  className: "text-sm font-medium text-foreground truncate",
                                  children: N(f)
                                }),
                                e.jsx("div", {
                                  className: "text-[10px] text-[var(--text-muted)] truncate",
                                  children: f
                                })
                              ]
                            })
                          ]
                        }),
                        e.jsx("button", {
                          onClick: () => C(f),
                          className: "p-2 text-gray-500 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors ml-2",
                          title: "Disconnect",
                          children: e.jsx("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: e.jsx("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: 2,
                              d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                            })
                          })
                        })
                      ]
                    }, f))
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2 text-primary",
                  children: [
                    e.jsx("svg", {
                      className: "w-5 h-5",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                      })
                    }),
                    e.jsx("h3", {
                      className: "font-bold text-sm uppercase tracking-wider",
                      children: "Network Settings"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "bg-surface rounded-xl p-4 border border-border space-y-4",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center justify-between",
                      children: [
                        e.jsx("span", {
                          className: "text-xs font-medium text-foreground",
                          children: "Automatic RPC Selection"
                        }),
                        e.jsx("button", {
                          onClick: S,
                          className: `relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${u ? "bg-primary" : "bg-surfaceHighlight"}`,
                          children: e.jsx("span", {
                            className: `inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${u ? "translate-x-5" : "translate-x-1"}`
                          })
                        })
                      ]
                    }),
                    !u && e.jsxs("div", {
                      className: "space-y-2 animate-fade-in shadow-sm",
                      children: [
                        e.jsx("label", {
                          className: "text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tight",
                          children: "Select Provider"
                        }),
                        e.jsxs("select", {
                          value: v || "",
                          onChange: (f) => b(f.target.value),
                          className: "w-full bg-surfaceHighlight border border-border rounded-lg p-2 text-xs text-foreground outline-none focus:border-primary transition-colors cursor-pointer",
                          children: [
                            e.jsx("option", {
                              value: "",
                              disabled: true,
                              children: "Choose a provider"
                            }),
                            $e.map((f) => e.jsx("option", {
                              value: f.provider,
                              children: f.provider
                            }, f.provider))
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "pt-2 border-t border-border/50",
                      children: [
                        e.jsx("div", {
                          className: "text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tight mb-1",
                          children: "Active RPC Endpoint"
                        }),
                        e.jsx("div", {
                          className: "text-[10px] font-mono text-primary truncate bg-primary/5 p-2 rounded-lg border border-primary/10",
                          children: y || ((_a2 = bt[0]) == null ? void 0 : _a2.address) || "Resolving..."
                        }),
                        e.jsx("div", {
                          className: "mt-2 text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tight mb-1",
                          children: "Active REST Endpoint"
                        }),
                        e.jsx("div", {
                          className: "text-[10px] font-mono text-primary truncate bg-primary/5 p-2 rounded-lg border border-primary/10",
                          children: h || ((_b = $e[0]) == null ? void 0 : _b.address) || "Resolving..."
                        }),
                        e.jsx("button", {
                          onClick: P,
                          className: "mt-3 w-full text-[11px] font-semibold text-primary border border-primary/20 rounded-lg py-2 hover:bg-primary/10 transition-colors",
                          children: "Reset to Cosmos Directory"
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsx("div", {
              className: "pt-4",
              children: e.jsx("button", {
                onClick: k,
                disabled: l,
                className: `w-full py-3 rounded-xl font-bold text-sm transition-all ${l ? "bg-green-500 text-white" : "bg-primary hover:bg-primary-hover text-white"}`,
                children: l ? "Saved!" : "Save Settings"
              })
            })
          ]
        })
      ]
    });
  }, gr = ({ wallet: t, onClose: s }) => {
    const [r, a] = m.useState(false), [n, l] = m.useState(""), [i, d] = m.useState(false), [c, u] = m.useState(null), [x, v] = m.useState(false), [b, h] = m.useState(false), [o, y] = m.useState(null), g = async (f) => {
      f.preventDefault();
      try {
        d(true), u(null), await V.unlock(n), a(true);
      } catch {
        u("Incorrect password");
      } finally {
        d(false);
      }
    }, P = (() => {
      if (t.pqcKey && t.pqcKey.privateKey) return t.pqcKey;
      if (t.pqc && t.pqc.privateKey) return t.pqc;
      for (const f of Object.keys(t)) {
        const L = t[f];
        if (L && typeof L == "object" && L.scheme === "dilithium3" && L.privateKey) return L;
      }
      return t.pqcKey || t.pqc;
    })(), k = (f, L) => {
      navigator.clipboard.writeText(f), y(L), setTimeout(() => y(null), 2e3);
    }, C = () => {
      const f = JSON.stringify({
        pqcKey: P
      }, null, 2), L = new Blob([
        f
      ], {
        type: "application/json"
      }), j = URL.createObjectURL(L), w = document.createElement("a");
      w.href = j, w.download = `lumen_pqc_${t.address.substring(0, 8)}.json`, document.body.appendChild(w), w.click(), document.body.removeChild(w), URL.revokeObjectURL(j);
    }, N = e.jsx("div", {
      className: "fixed inset-0 z-[99999] bg-background/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in text-left",
      onClick: s,
      style: {
        margin: 0,
        left: 0,
        right: 0,
        top: 0,
        bottom: 0
      },
      children: r ? e.jsxs("div", {
        className: "bg-surface border border-border rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-slide-up flex flex-col max-h-[90vh]",
        onClick: (f) => f.stopPropagation(),
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between mb-6",
            children: [
              e.jsx("h3", {
                className: "text-xl font-bold text-foreground",
                children: "Secure Backup"
              }),
              e.jsx("button", {
                onClick: s,
                className: "p-2 hover:bg-surfaceHighlight rounded-full transition-colors",
                children: e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M6 18L18 6M6 6l18 18"
                  })
                })
              })
            ]
          }),
          e.jsxs("div", {
            className: "space-y-6 overflow-y-auto flex-1 pr-2",
            children: [
              e.jsxs("section", {
                className: "space-y-2",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center justify-between",
                    children: [
                      e.jsx("label", {
                        className: "text-[10px] uppercase font-bold text-[var(--text-muted)] tracking-wider",
                        children: "Mnemonic Phrase"
                      }),
                      e.jsx("button", {
                        onClick: () => v(!x),
                        className: "text-[10px] text-primary hover:underline font-bold",
                        children: x ? "Hide" : "Reveal"
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "relative group",
                    children: [
                      e.jsx("div", {
                        className: `bg-black/20 border border-border rounded-xl p-4 text-xs font-mono leading-relaxed transition-all ${x ? "" : "blur-sm select-none"}`,
                        children: t.mnemonic
                      }),
                      x && e.jsx("button", {
                        onClick: () => k(t.mnemonic, "Mnemonic"),
                        className: "absolute top-2 right-2 p-1.5 bg-surface rounded-lg border border-border opacity-0 group-hover:opacity-100 transition-opacity",
                        children: e.jsx("svg", {
                          className: "w-3 h-3",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2"
                          })
                        })
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("section", {
                className: "space-y-2",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center justify-between",
                    children: [
                      e.jsx("label", {
                        className: "text-[10px] uppercase font-bold text-[var(--text-muted)] tracking-wider",
                        children: "PQC Key Data (JSON)"
                      }),
                      e.jsx("button", {
                        onClick: () => h(!b),
                        className: "text-[10px] text-primary hover:underline font-bold",
                        children: b ? "Hide" : "Reveal"
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "relative group",
                    children: [
                      e.jsx("div", {
                        className: `bg-black/20 border border-border rounded-xl p-3 text-[9px] font-mono break-all leading-tight max-h-32 overflow-y-auto whitespace-pre-wrap transition-all ${b ? "" : "blur-sm select-none"}`,
                        children: JSON.stringify({
                          pqcKey: P
                        }, null, 2)
                      }),
                      b && e.jsx("button", {
                        onClick: () => k(JSON.stringify({
                          pqcKey: P
                        }, null, 2), "PQC Data"),
                        className: "absolute top-2 right-2 p-1.5 bg-surface rounded-lg border border-border opacity-0 group-hover:opacity-100 transition-opacity",
                        children: e.jsx("svg", {
                          className: "w-3 h-3",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2"
                          })
                        })
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex gap-3 items-start",
                children: [
                  e.jsx("svg", {
                    className: "w-5 h-5 text-amber-500 shrink-0",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    })
                  }),
                  e.jsx("p", {
                    className: "text-[10px] text-amber-500 leading-normal",
                    children: "NEVER share these keys with anyone. Anyone with your mnemonic or private key can steal your funds."
                  })
                ]
              })
            ]
          }),
          e.jsxs("div", {
            className: "pt-6 space-y-3",
            children: [
              e.jsxs("button", {
                onClick: C,
                className: "w-full bg-primary hover:bg-primary-hover text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-primary/20 flex items-center justify-center gap-2 text-sm",
                children: [
                  e.jsx("svg", {
                    className: "w-4 h-4",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                    })
                  }),
                  "Download JSON Backup"
                ]
              }),
              o && e.jsxs("p", {
                className: "text-center text-[10px] font-bold text-primary animate-bounce",
                children: [
                  "Copied ",
                  o,
                  "!"
                ]
              })
            ]
          })
        ]
      }) : e.jsxs("div", {
        className: "bg-surface border border-border rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-slide-up",
        onClick: (f) => f.stopPropagation(),
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between mb-6",
            children: [
              e.jsx("h3", {
                className: "text-xl font-bold text-foreground",
                children: "Unlock Backup"
              }),
              e.jsx("button", {
                onClick: s,
                className: "p-2 hover:bg-surfaceHighlight rounded-full transition-colors",
                children: e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M6 18L18 6M6 6l18 18"
                  })
                })
              })
            ]
          }),
          e.jsxs("form", {
            onSubmit: g,
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "space-y-2",
                children: [
                  e.jsx("label", {
                    className: "text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider",
                    children: "Enter Password"
                  }),
                  e.jsx("input", {
                    type: "password",
                    autoFocus: true,
                    value: n,
                    onChange: (f) => {
                      l(f.target.value), u(null);
                    },
                    className: "w-full bg-background border border-border rounded-xl px-4 py-3 text-foreground outline-none focus:border-primary transition-colors",
                    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
                  })
                ]
              }),
              c && e.jsx("div", {
                className: "p-3 bg-red-500/10 border border-red-500/20 rounded-xl",
                children: e.jsx("p", {
                  className: "text-red-500 text-xs font-medium text-center",
                  children: c
                })
              }),
              e.jsx("button", {
                type: "submit",
                disabled: !n || i,
                className: "w-full bg-primary hover:bg-primary-hover disabled:opacity-50 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-primary/20 flex items-center justify-center gap-2",
                children: i ? e.jsx("span", {
                  className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"
                }) : "Confirm Password"
              })
            ]
          })
        ]
      })
    });
    return Qe.createPortal(N, document.body);
  }, Vt = ({ message: t, type: s = "success", onClose: r, duration: a = 3e3 }) => {
    m.useEffect(() => {
      const i = setTimeout(() => {
        r();
      }, a);
      return () => clearTimeout(i);
    }, [
      a,
      r
    ]);
    const n = () => {
      switch (s) {
        case "success":
          return e.jsx(Mt, {
            className: "w-5 h-5 text-green-500"
          });
        case "error":
          return e.jsx(nt, {
            className: "w-5 h-5 text-red-500"
          });
        case "warning":
          return e.jsx(ct, {
            className: "w-5 h-5 text-yellow-500"
          });
        case "info":
          return e.jsx(at, {
            className: "w-5 h-5 text-blue-500"
          });
      }
    }, l = () => {
      switch (s) {
        case "success":
          return "bg-green-500/10 border-green-500/30";
        case "error":
          return "bg-red-500/10 border-red-500/30";
        case "warning":
          return "bg-yellow-500/10 border-yellow-500/30";
        case "info":
          return "bg-blue-500/10 border-blue-500/30";
      }
    };
    return e.jsx("div", {
      className: "fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-fade-in",
      children: e.jsxs("div", {
        className: `flex items-center gap-3 px-4 py-3 rounded-xl border ${l()} backdrop-blur-md shadow-lg min-w-[280px]`,
        children: [
          n(),
          e.jsx("p", {
            className: "text-sm font-medium text-foreground flex-1",
            children: t
          }),
          e.jsx("button", {
            onClick: r,
            className: "text-[var(--text-muted)] hover:text-foreground transition-colors",
            children: e.jsx(nt, {
              className: "w-4 h-4"
            })
          })
        ]
      })
    });
  }, Ie = "lumen", mt = BigInt(3e5), Ee = (t) => {
    if (!t) return new Uint8Array(0);
    if (typeof t == "string") {
      const s = t.trim();
      if (s.length === 0) return new Uint8Array(0);
      if (/^[0-9a-fA-F]+$/.test(s)) try {
        const r = J.from(s, "hex");
        if (r.length > 0) return new Uint8Array(r);
      } catch {
      }
      try {
        const r = J.from(s, "base64");
        if (r.length > 0) return new Uint8Array(r);
        const a = atob(s);
        return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
      } catch {
        try {
          const a = atob(s);
          return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
        } catch {
          return new Uint8Array(0);
        }
      }
    }
    return new Uint8Array(t);
  };
  async function ut(t) {
    const s = await Y.getInstance().getRestEndpoint(), r = await fetch(`${s}/cosmos/auth/v1beta1/accounts/${t}`);
    if (!r.ok) throw new Error(`Account fetch failed: ${r.status} ${r.statusText}`);
    const a = await r.json(), n = a.account || a;
    return {
      accountNumber: BigInt(n.account_number || 0),
      sequence: BigInt(n.sequence || 0)
    };
  }
  async function br(t) {
    try {
      const s = await Y.getInstance().getRestEndpoint(), r = await fetch(`${s}/cosmos/staking/v1beta1/delegations/${t}`);
      if (!r.ok) {
        if (r.status === 404) return [];
        throw new Error(`Failed to fetch delegations: ${r.status}`);
      }
      return (await r.json()).delegation_responses || [];
    } catch (s) {
      return console.error("Error fetching delegations:", s), [];
    }
  }
  async function yr(t) {
    try {
      const s = await Y.getInstance().getRestEndpoint(), r = await fetch(`${s}/cosmos/staking/v1beta1/delegators/${t}/unbonding_delegations`);
      if (!r.ok) {
        if (r.status === 404) return [];
        throw new Error(`Failed to fetch unbonding delegations: ${r.status}`);
      }
      return (await r.json()).unbonding_responses || [];
    } catch (s) {
      return console.error("Error fetching unbonding delegations:", s), [];
    }
  }
  async function vr(t) {
    try {
      const s = await Y.getInstance().getRestEndpoint(), r = await fetch(`${s}/cosmos/distribution/v1beta1/delegators/${t}/rewards`);
      if (!r.ok) {
        if (r.status === 404) return {
          total: [],
          rewards: []
        };
        throw new Error(`Failed to fetch rewards: ${r.status}`);
      }
      const a = await r.json();
      return {
        total: a.total || [],
        rewards: a.rewards || []
      };
    } catch (s) {
      return console.error("Error fetching rewards:", s), {
        total: [],
        rewards: []
      };
    }
  }
  async function jr() {
    try {
      const t = await Y.getInstance().getRestEndpoint(), s = await fetch(`${t}/cosmos/staking/v1beta1/validators?status=BOND_STATUS_BONDED`);
      if (!s.ok) throw new Error(`Failed to fetch validators: ${s.status}`);
      return (await s.json()).validators || [];
    } catch (t) {
      return console.error("Error fetching validators:", t), [];
    }
  }
  async function kt(t) {
    try {
      const s = await Y.getInstance().getRestEndpoint(), r = await fetch(`${s}/cosmos/staking/v1beta1/validators/${t}`);
      if (!r.ok) throw new Error(`Failed to fetch validator: ${r.status}`);
      return (await r.json()).validator;
    } catch (s) {
      return console.error("Error fetching validator:", s), null;
    }
  }
  async function wr(t, s, r) {
    var _a2, _b, _c, _d;
    const a = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
      prefix: "lmn"
    }), [n] = await a.getAccounts();
    if (n.address !== t.address) throw new Error("Address mismatch");
    await Y.getInstance().sync();
    const { accountNumber: l, sequence: i } = await ut(t.address), d = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
    if (!d) throw new Error("Missing PQC key data. Please re-import your wallet.");
    const c = d.privateKey || d.private_key || d.encryptedPrivateKey, u = d.publicKey || d.public_key;
    if (!c || !u) throw new Error("PQC keys missing sub-properties. Please re-import your wallet.");
    const x = Ee(c), v = Ee(u);
    if (v.length !== 1952) throw new Error(`Invalid PQC Public Key. Expected 1952 bytes, got ${v.length}.`);
    if (x.length !== 4e3) throw new Error(`Invalid PQC Private Key. Expected 4000 bytes, got ${x.length}.`);
    const b = Dt.MsgDelegate.encode({
      delegatorAddress: t.address,
      validatorAddress: s,
      amount: {
        denom: "ulmn",
        amount: r
      }
    }).finish(), h = ie.Any.fromPartial({
      typeUrl: "/cosmos.staking.v1beta1.MsgDelegate",
      value: b
    }), o = M.TxBody.fromPartial({
      messages: [
        h
      ],
      memo: `Stake ${r} ulmn`
    }), y = M.TxBody.encode(o).finish(), g = ie.Any.fromPartial({
      typeUrl: "/cosmos.crypto.secp256k1.PubKey",
      value: Be.PubKey.encode({
        key: n.pubkey
      }).finish()
    }), S = M.AuthInfo.fromPartial({
      signerInfos: [
        {
          publicKey: g,
          modeInfo: {
            single: {
              mode: Te.SignMode.SIGN_MODE_DIRECT
            }
          },
          sequence: i
        }
      ],
      fee: M.Fee.fromPartial({
        amount: [],
        gasLimit: mt
      })
    }), P = M.AuthInfo.encode(S).finish(), k = {
      bodyBytes: y,
      authInfoBytes: P,
      signatures: []
    }, C = te.computeSignBytes(Ie, Number(l), k), N = await te.signDilithium(C, x), f = {
      addr: t.address,
      scheme: "dilithium3",
      signature: new Uint8Array(N),
      pubKey: v
    };
    let L = te.withPqcExtension(y, [
      f
    ]);
    const j = M.SignDoc.fromPartial({
      bodyBytes: L,
      authInfoBytes: P,
      chainId: Ie,
      accountNumber: l
    }), { signature: w } = await a.signDirect(t.address, j), A = M.TxRaw.fromPartial({
      bodyBytes: L,
      authInfoBytes: P,
      signatures: [
        J.from(w.signature, "base64")
      ]
    }), T = M.TxRaw.encode(A).finish();
    return await xt(T);
  }
  async function Nr(t, s, r) {
    var _a2, _b, _c, _d;
    const a = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
      prefix: "lmn"
    }), [n] = await a.getAccounts();
    if (n.address !== t.address) throw new Error("Address mismatch");
    await Y.getInstance().sync();
    const { accountNumber: l, sequence: i } = await ut(t.address), d = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
    if (!d) throw new Error("Missing PQC key data. Please re-import your wallet.");
    const c = d.privateKey || d.private_key || d.encryptedPrivateKey, u = d.publicKey || d.public_key;
    if (!c || !u) throw new Error("PQC keys missing sub-properties. Please re-import your wallet.");
    const x = Ee(c), v = Ee(u);
    if (v.length !== 1952) throw new Error(`Invalid PQC Public Key. Expected 1952 bytes, got ${v.length}.`);
    if (x.length !== 4e3) throw new Error(`Invalid PQC Private Key. Expected 4000 bytes, got ${x.length}.`);
    const b = Dt.MsgUndelegate.encode({
      delegatorAddress: t.address,
      validatorAddress: s,
      amount: {
        denom: "ulmn",
        amount: r
      }
    }).finish(), h = ie.Any.fromPartial({
      typeUrl: "/cosmos.staking.v1beta1.MsgUndelegate",
      value: b
    }), o = M.TxBody.fromPartial({
      messages: [
        h
      ],
      memo: `Unstake ${r} ulmn`
    }), y = M.TxBody.encode(o).finish(), g = ie.Any.fromPartial({
      typeUrl: "/cosmos.crypto.secp256k1.PubKey",
      value: Be.PubKey.encode({
        key: n.pubkey
      }).finish()
    }), S = M.AuthInfo.fromPartial({
      signerInfos: [
        {
          publicKey: g,
          modeInfo: {
            single: {
              mode: Te.SignMode.SIGN_MODE_DIRECT
            }
          },
          sequence: i
        }
      ],
      fee: M.Fee.fromPartial({
        amount: [],
        gasLimit: mt
      })
    }), P = M.AuthInfo.encode(S).finish(), k = {
      bodyBytes: y,
      authInfoBytes: P,
      signatures: []
    }, C = te.computeSignBytes(Ie, Number(l), k), N = await te.signDilithium(C, x), f = {
      addr: t.address,
      scheme: "dilithium3",
      signature: new Uint8Array(N),
      pubKey: v
    };
    let L = te.withPqcExtension(y, [
      f
    ]);
    const j = M.SignDoc.fromPartial({
      bodyBytes: L,
      authInfoBytes: P,
      chainId: Ie,
      accountNumber: l
    }), { signature: w } = await a.signDirect(t.address, j), A = M.TxRaw.fromPartial({
      bodyBytes: L,
      authInfoBytes: P,
      signatures: [
        J.from(w.signature, "base64")
      ]
    }), T = M.TxRaw.encode(A).finish();
    return await xt(T);
  }
  async function kr(t, s) {
    var _a2, _b, _c, _d;
    const r = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
      prefix: "lmn"
    }), [a] = await r.getAccounts();
    if (a.address !== t.address) throw new Error("Address mismatch");
    await Y.getInstance().sync();
    const { accountNumber: n, sequence: l } = await ut(t.address), i = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
    if (!i) throw new Error("Missing PQC key data. Please re-import your wallet.");
    const d = i.privateKey || i.private_key || i.encryptedPrivateKey, c = i.publicKey || i.public_key;
    if (!d || !c) throw new Error("PQC keys missing sub-properties. Please re-import your wallet.");
    const u = Ee(d), x = Ee(c);
    if (x.length !== 1952) throw new Error(`Invalid PQC Public Key. Expected 1952 bytes, got ${x.length}.`);
    if (u.length !== 4e3) throw new Error(`Invalid PQC Private Key. Expected 4000 bytes, got ${u.length}.`);
    const v = vs.MsgWithdrawDelegatorReward.encode({
      delegatorAddress: t.address,
      validatorAddress: s
    }).finish(), b = ie.Any.fromPartial({
      typeUrl: "/cosmos.distribution.v1beta1.MsgWithdrawDelegatorReward",
      value: v
    }), h = M.TxBody.fromPartial({
      messages: [
        b
      ],
      memo: "Claim staking rewards"
    }), o = M.TxBody.encode(h).finish(), y = ie.Any.fromPartial({
      typeUrl: "/cosmos.crypto.secp256k1.PubKey",
      value: Be.PubKey.encode({
        key: a.pubkey
      }).finish()
    }), g = M.AuthInfo.fromPartial({
      signerInfos: [
        {
          publicKey: y,
          modeInfo: {
            single: {
              mode: Te.SignMode.SIGN_MODE_DIRECT
            }
          },
          sequence: l
        }
      ],
      fee: M.Fee.fromPartial({
        amount: [],
        gasLimit: mt
      })
    }), S = M.AuthInfo.encode(g).finish(), P = {
      bodyBytes: o,
      authInfoBytes: S,
      signatures: []
    }, k = te.computeSignBytes(Ie, Number(n), P), C = await te.signDilithium(k, u), N = {
      addr: t.address,
      scheme: "dilithium3",
      signature: new Uint8Array(C),
      pubKey: x
    };
    let f = te.withPqcExtension(o, [
      N
    ]);
    const L = M.SignDoc.fromPartial({
      bodyBytes: f,
      authInfoBytes: S,
      chainId: Ie,
      accountNumber: n
    }), { signature: j } = await r.signDirect(t.address, L), w = M.TxRaw.fromPartial({
      bodyBytes: f,
      authInfoBytes: S,
      signatures: [
        J.from(j.signature, "base64")
      ]
    }), A = M.TxRaw.encode(w).finish();
    return await xt(A);
  }
  async function xt(t) {
    var _a2, _b;
    const r = {
      tx_bytes: J.from(t).toString("base64"),
      mode: "BROADCAST_MODE_SYNC"
    }, a = await Y.getInstance().getRestEndpoint(), n = await fetch(`${a}/cosmos/tx/v1beta1/txs`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(r)
    }), l = await n.json();
    if (!n.ok || ((_a2 = l.tx_response) == null ? void 0 : _a2.code) !== 0) throw console.error("[TX] Broadcast Failed:", l), new Error(((_b = l.tx_response) == null ? void 0 : _b.raw_log) || JSON.stringify(l));
    return l.tx_response.txhash;
  }
  const Cr = ({ walletKeys: t, onBack: s }) => {
    const [r, a] = m.useState("stake"), [n, l] = m.useState([]), [i, d] = m.useState([]), [c, u] = m.useState(null), [x, v] = m.useState(""), [b, h] = m.useState(false), [o, y] = m.useState(false), [g, S] = m.useState(false), [P, k] = m.useState(""), [C, N] = m.useState("success"), [f, L] = m.useState("0"), [j, w] = m.useState("0"), [A, T] = m.useState("dashboard"), [B, E] = m.useState("0"), [_, R] = m.useState(""), [K, Q] = m.useState([]), [re, X] = m.useState(false), [ne, $] = m.useState(null), W = i.length > 0, q = async () => {
      var _a2, _b, _c, _d, _e2;
      if (t == null ? void 0 : t.address) {
        y(true);
        try {
          const p = await br(t.address), I = await vr(t.address);
          let z = BigInt(0);
          const O = [];
          for (const oe of p) {
            const he = oe.delegation.validator_address, de = oe.balance.amount;
            z += BigInt(de);
            const ke = await kt(he), Le = ((_c = (_b = (_a2 = I.rewards.find((Ce) => Ce.validator_address === he)) == null ? void 0 : _a2.reward) == null ? void 0 : _b.find((Ce) => Ce.denom === "ulmn")) == null ? void 0 : _c.amount) || "0";
            if (ke) {
              const Ce = parseFloat(ke.commission.commission_rates.rate) * 100;
              O.push({
                validator: {
                  address: he,
                  moniker: ke.description.moniker,
                  commission: `${Ce.toFixed(1)}%`,
                  votingPower: (Number(ke.tokens) / 1e6).toFixed(0),
                  status: ke.status === "BOND_STATUS_BONDED" ? "active" : "inactive",
                  apr: "12.5%"
                },
                amount: (Number(de) / 1e6).toFixed(2),
                rewards: (parseFloat(Le) / 1e6).toFixed(6),
                validatorAddress: he
              });
            }
          }
          d(O), L((Number(z) / 1e6).toFixed(2));
          const ue = ((_d = I.total.find((oe) => oe.denom === "ulmn")) == null ? void 0 : _d.amount) || "0";
          w((parseFloat(ue) / 1e6).toFixed(6));
          const xe = await yr(t.address), Ne = [];
          for (const oe of xe) {
            const he = await kt(oe.validator_address);
            for (const de of oe.entries) Ne.push({
              validatorMoniker: ((_e2 = he == null ? void 0 : he.description) == null ? void 0 : _e2.moniker) || "Unknown",
              amount: (Number(de.balance) / 1e6).toFixed(2),
              completionTime: de.completion_time
            });
          }
          Q(Ne);
        } catch (p) {
          console.error("Error fetching staking data:", p), k("Failed to fetch staking data"), N("error"), S(true);
        } finally {
          y(false);
        }
      }
    }, Z = async () => {
      var _a2;
      try {
        const I = (await jr()).map((O) => {
          const ue = parseFloat(O.commission.commission_rates.rate) * 100;
          return {
            address: O.operator_address,
            moniker: O.description.moniker,
            commission: `${ue.toFixed(1)}%`,
            votingPower: (Number(O.tokens) / 1e6).toFixed(0),
            status: O.status === "BOND_STATUS_BONDED" ? "active" : "inactive",
            apr: "12.5%"
          };
        });
        l(I);
        const z = await fetch(`https://rest.cosmos.directory/lumen/cosmos/bank/v1beta1/balances/${t.address}`);
        if (z.ok) {
          const ue = ((_a2 = (await z.json()).balances.find((xe) => xe.denom === "ulmn")) == null ? void 0 : _a2.amount) || "0";
          E(ue);
        }
      } catch (p) {
        console.error("Error fetching validators:", p);
      }
    };
    m.useEffect(() => {
      q(), Z();
    }, [
      t == null ? void 0 : t.address
    ]);
    const F = async () => {
      if (!(!c || !x || !t)) {
        h(true);
        try {
          const p = (parseFloat(x) * 1e6).toString();
          if (BigInt(p) > BigInt(B)) throw new Error("Insufficient balance");
          const I = await wr(t, c.address, p);
          ge.saveTransaction(t.address, {
            hash: I,
            height: "...",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            type: "stake",
            amount: x,
            denom: "LMN",
            counterparty: c.moniker,
            status: "success"
          }), k("Staked successfully!"), N("success"), S(true), v(""), u(null), T("dashboard"), await q();
        } catch (p) {
          console.error("Staking error:", p), k(p.message || "Failed to stake"), N("error"), S(true);
        } finally {
          h(false);
        }
      }
    }, G = async (p) => {
      $(p), X(true);
    }, U = async () => {
      if (!(!t || !ne)) {
        h(true), X(false);
        try {
          const p = (parseFloat(ne.amount) * 1e6).toString(), I = await Nr(t, ne.validatorAddress, p);
          k(`Unstaked successfully! Asset is now unbonding. TX: ${I.slice(0, 8)}...`), N("success"), S(true), await q();
        } catch (p) {
          console.error("Unstaking error:", p), k(p.message || "Failed to unstake"), N("error"), S(true);
        } finally {
          h(false), $(null);
        }
      }
    }, se = async (p) => {
      if (t) {
        h(true);
        try {
          const I = await kr(t, p);
          ge.saveTransaction(t.address, {
            hash: I,
            height: "...",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            type: "claim",
            amount: "Checking...",
            denom: "LMN",
            counterparty: "Rewards",
            status: "success"
          }), k("Rewards claimed!"), N("success"), S(true), await q();
        } catch (I) {
          console.error("Claim rewards error:", I), k(I.message || "Failed to claim rewards");
        } finally {
          h(false);
        }
      }
    }, ae = n.filter((p) => p.moniker.toLowerCase().includes(_.toLowerCase()) || p.address.toLowerCase().includes(_.toLowerCase())).sort((p, I) => Number(I.votingPower) - Number(p.votingPower));
    return e.jsxs("div", {
      className: "flex flex-col h-full min-h-0 bg-background relative",
      children: [
        e.jsx("style", {
          children: `
                input::-webkit-outer-spin-button,
                input::-webkit-inner-spin-button {
                    -webkit-appearance: none;
                    margin: 0;
                }
                input[type=number] {
                    -moz-appearance: textfield;
                }
                @keyframes progress-slow {
                    0% { transform: translateX(-100%); }
                    100% { transform: translateX(300%); }
                }
                .animate-progress-slow {
                    animation: progress-slow 3s infinite linear;
                }
            `
        }),
        e.jsxs("div", {
          className: "flex items-center justify-between px-4 py-1.5 premium-header backdrop-blur-xl shrink-0 z-20",
          children: [
            e.jsx("button", {
              onClick: () => {
                A === "dashboard" ? s() : A === "detail" ? T("dashboard") : A === "confirm" && T("detail");
              },
              className: "p-1.5 hover:bg-surfaceHighlight rounded-lg transition-all duration-300 hover:scale-110 active:scale-95",
              children: e.jsx(ot, {
                className: "w-4 h-4 text-foreground"
              })
            }),
            e.jsx("h1", {
              className: "text-base font-bold text-foreground tracking-tight",
              children: A === "dashboard" ? "Staking" : A === "detail" ? "Manage Stake" : "Confirm Staking"
            }),
            e.jsx("button", {
              onClick: q,
              disabled: o,
              className: "p-1.5 hover:bg-surfaceHighlight rounded-lg transition-all duration-300 hover:scale-110 active:scale-95 disabled:scale-100",
              children: e.jsx(Ae, {
                className: `w-4 h-4 text-foreground transition-transform ${o ? "animate-spin" : ""}`
              })
            })
          ]
        }),
        A === "dashboard" && e.jsxs("div", {
          className: "flex flex-col h-full min-h-0 overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-300",
          children: [
            e.jsxs("div", {
              className: "grid grid-cols-3 gap-1.5 p-3 pb-2",
              children: [
                e.jsxs("div", {
                  className: "bg-surface border border-border rounded-lg p-2 hover:bg-surfaceHighlight transition-colors min-w-0",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-1 mb-1",
                      children: [
                        e.jsx(cs, {
                          className: "w-3 h-3 text-primary"
                        }),
                        e.jsx("span", {
                          className: "text-[8px] text-[var(--text-dim)] uppercase font-bold tracking-wider",
                          children: "APR"
                        })
                      ]
                    }),
                    e.jsx("p", {
                      className: "text-sm font-bold text-foreground truncate",
                      children: "12.5%"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "bg-surface border border-border rounded-lg p-2 hover:bg-surfaceHighlight transition-colors min-w-0",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-1 mb-1",
                      children: [
                        e.jsx(Ye, {
                          className: "w-3 h-3 text-lumen"
                        }),
                        e.jsx("span", {
                          className: "text-[8px] text-[var(--text-dim)] uppercase font-bold tracking-wider",
                          children: "Staked"
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex items-baseline gap-0.5 min-w-0 overflow-hidden",
                      children: [
                        e.jsx("p", {
                          className: `font-bold text-foreground truncate ${f.length > 8 ? "text-xs" : "text-sm"}`,
                          children: f
                        }),
                        e.jsx("span", {
                          className: "text-[7px] font-bold text-[var(--text-dim)] shrink-0",
                          children: "LMN"
                        })
                      ]
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "bg-surface border border-border rounded-lg p-2 hover:bg-surfaceHighlight transition-colors min-w-0",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-1 mb-1",
                      children: [
                        e.jsx(ds, {
                          className: "w-3 h-3 text-green-500"
                        }),
                        e.jsx("span", {
                          className: "text-[8px] text-[var(--text-dim)] uppercase font-bold tracking-wider",
                          children: "Rewards"
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex items-baseline gap-0.5 min-w-0 overflow-hidden",
                      children: [
                        e.jsx("p", {
                          className: `font-bold text-foreground truncate ${j.length > 8 ? "text-xs" : "text-sm"}`,
                          children: j
                        }),
                        e.jsx("span", {
                          className: "text-[7px] font-bold text-[var(--text-dim)] shrink-0",
                          children: "LMN"
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsx("div", {
              className: "flex gap-2 px-4 mb-3",
              children: [
                "stake",
                "unstake",
                "rewards"
              ].map((p) => e.jsx("button", {
                onClick: () => a(p),
                className: `flex-1 py-2 px-3 rounded-lg font-bold text-[10px] uppercase tracking-wider transition-all duration-300 ${r === p ? "bg-primary text-white shadow-lg shadow-primary/20 scale-[1.02]" : "bg-surface text-[var(--text-dim)] hover:bg-surfaceHighlight"}`,
                children: p
              }, p))
            }),
            e.jsxs("div", {
              className: "flex-1 overflow-y-auto px-3 pb-24 scrollbar-hide",
              children: [
                r === "stake" && e.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    W && e.jsxs("div", {
                      children: [
                        e.jsx("h3", {
                          className: "text-[10px] font-black uppercase tracking-[0.15em] text-[var(--text-dim)] mb-2 px-1",
                          children: "Your Active Stakes"
                        }),
                        e.jsx("div", {
                          className: "space-y-2",
                          children: i.map((p, I) => e.jsx("div", {
                            className: "bg-surface border border-border rounded-xl p-4 group hover:border-primary/50 transition-all duration-300",
                            children: e.jsxs("div", {
                              className: "flex items-center justify-between mb-3",
                              children: [
                                e.jsxs("div", {
                                  className: "flex items-center gap-3",
                                  children: [
                                    e.jsx("div", {
                                      className: "w-9 h-9 bg-primary/10 rounded-xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500",
                                      children: e.jsx(Ye, {
                                        size: 18
                                      })
                                    }),
                                    e.jsxs("div", {
                                      children: [
                                        e.jsx("p", {
                                          className: "font-bold text-sm text-foreground",
                                          children: p.validator.moniker
                                        }),
                                        e.jsxs("p", {
                                          className: "text-[9px] text-[var(--text-muted)] font-mono",
                                          children: [
                                            p.validator.address.slice(0, 16),
                                            "..."
                                          ]
                                        })
                                      ]
                                    })
                                  ]
                                }),
                                e.jsxs("div", {
                                  className: "text-right",
                                  children: [
                                    e.jsxs("p", {
                                      className: "text-sm font-black text-foreground",
                                      children: [
                                        p.amount,
                                        " LMN"
                                      ]
                                    }),
                                    e.jsxs("p", {
                                      className: "text-[9px] text-green-500 font-bold",
                                      children: [
                                        "+",
                                        p.rewards,
                                        " LMN"
                                      ]
                                    })
                                  ]
                                })
                              ]
                            })
                          }, I))
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center justify-between mb-2 px-1",
                          children: [
                            e.jsx("h3", {
                              className: "text-[10px] font-black uppercase tracking-[0.15em] text-[var(--text-dim)]",
                              children: "Select Validator"
                            }),
                            e.jsxs("span", {
                              className: "text-[9px] font-bold text-primary",
                              children: [
                                ae.length,
                                " active"
                              ]
                            })
                          ]
                        }),
                        e.jsxs("div", {
                          className: "relative mb-3 group",
                          children: [
                            e.jsx(Rt, {
                              className: "absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[var(--text-dim)] group-focus-within:text-primary transition-colors"
                            }),
                            e.jsx("input", {
                              type: "text",
                              placeholder: "Search moniker or address...",
                              value: _,
                              onChange: (p) => R(p.target.value),
                              className: "w-full bg-surface border border-border rounded-xl py-2 px-9 text-[11px] focus:border-primary focus:bg-surfaceHighlight outline-none transition-all shadow-inner"
                            })
                          ]
                        }),
                        e.jsxs("div", {
                          className: "space-y-1.5",
                          children: [
                            ae.map((p) => e.jsxs("button", {
                              onClick: () => {
                                u(p), T("detail");
                              },
                              className: "w-full bg-surface border border-border rounded-xl p-2.5 flex items-center justify-between group hover:border-primary/50 transition-all duration-300 hover:scale-[1.01]",
                              children: [
                                e.jsxs("div", {
                                  className: "flex items-center gap-2.5",
                                  children: [
                                    e.jsx("div", {
                                      className: "w-8 h-8 bg-surfaceHighlight border border-border rounded-lg flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-all duration-500",
                                      children: e.jsx(Xe, {
                                        size: 16,
                                        className: "opacity-50 group-hover:opacity-100"
                                      })
                                    }),
                                    e.jsxs("div", {
                                      className: "text-left",
                                      children: [
                                        e.jsx("p", {
                                          className: "font-bold text-[13px] text-foreground tracking-tight",
                                          children: p.moniker
                                        }),
                                        e.jsxs("div", {
                                          className: "flex items-center gap-1.5 opacity-60",
                                          children: [
                                            e.jsxs("span", {
                                              className: "text-[9px] font-bold text-foreground/50",
                                              children: [
                                                p.commission,
                                                " fee"
                                              ]
                                            }),
                                            e.jsx("span", {
                                              className: "text-[9px] font-bold text-foreground/20",
                                              children: "\u2022"
                                            }),
                                            e.jsxs("span", {
                                              className: "text-[9px] font-bold text-primary/80",
                                              children: [
                                                Number(p.votingPower).toLocaleString(),
                                                " LMN staked"
                                              ]
                                            }),
                                            e.jsx("span", {
                                              className: "text-[9px] font-bold text-foreground/20",
                                              children: "\u2022"
                                            }),
                                            e.jsxs("span", {
                                              className: "text-[9px] font-bold text-green-500",
                                              children: [
                                                p.apr,
                                                " APR"
                                              ]
                                            })
                                          ]
                                        })
                                      ]
                                    })
                                  ]
                                }),
                                e.jsx(ms, {
                                  className: "w-4 h-4 text-border group-hover:text-primary group-hover:translate-x-1 transition-all"
                                })
                              ]
                            }, p.address)),
                            ae.length === 0 && e.jsxs("div", {
                              className: "text-center py-8 text-[var(--text-dim)] text-xs font-semibold",
                              children: [
                                'No validators found matching "',
                                _,
                                '"'
                              ]
                            })
                          ]
                        })
                      ]
                    })
                  ]
                }),
                r === "unstake" && e.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    K.length > 0 && e.jsxs("div", {
                      className: "space-y-2",
                      children: [
                        e.jsx("h3", {
                          className: "text-[10px] font-black uppercase tracking-[0.15em] text-lumen mb-2 px-1",
                          children: "Unbonding Assets"
                        }),
                        K.map((p, I) => e.jsxs("div", {
                          className: "bg-lumen/5 border border-lumen/20 rounded-xl p-3 relative overflow-hidden",
                          children: [
                            e.jsxs("div", {
                              className: "flex justify-between items-start mb-2 relative z-10",
                              children: [
                                e.jsxs("div", {
                                  children: [
                                    e.jsx("p", {
                                      className: "font-bold text-xs text-foreground tracking-tight",
                                      children: p.validatorMoniker
                                    }),
                                    e.jsxs("p", {
                                      className: "text-[9px] text-[var(--text-dim)] font-medium",
                                      children: [
                                        "Completes: ",
                                        new Date(p.completionTime).toLocaleDateString()
                                      ]
                                    })
                                  ]
                                }),
                                e.jsxs("div", {
                                  className: "text-right",
                                  children: [
                                    e.jsxs("p", {
                                      className: "text-sm font-black text-foreground",
                                      children: [
                                        p.amount,
                                        " LMN"
                                      ]
                                    }),
                                    e.jsx("p", {
                                      className: "text-[9px] text-lumen font-bold animate-pulse",
                                      children: "Unbonding..."
                                    })
                                  ]
                                })
                              ]
                            }),
                            e.jsx("div", {
                              className: "w-full h-1 bg-border/30 rounded-full overflow-hidden",
                              children: e.jsx("div", {
                                className: "w-1/3 h-full bg-lumen animate-progress-slow"
                              })
                            })
                          ]
                        }, I))
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx("h3", {
                          className: "text-[10px] font-black uppercase tracking-[0.15em] text-[var(--text-dim)] mb-2 px-1",
                          children: "Staked Assets"
                        }),
                        o ? e.jsx("div", {
                          className: "text-center py-10 opacity-50",
                          children: e.jsx(Ae, {
                            className: "w-8 h-8 mx-auto mb-2 animate-spin text-primary"
                          })
                        }) : W ? e.jsx("div", {
                          className: "space-y-2",
                          children: i.map((p, I) => e.jsxs("div", {
                            className: "bg-surface border border-border rounded-xl p-4 group",
                            children: [
                              e.jsx("div", {
                                className: "flex items-center justify-between mb-4",
                                children: e.jsxs("div", {
                                  className: "flex items-center gap-3",
                                  children: [
                                    e.jsx("div", {
                                      className: "w-9 h-9 bg-red-500/10 text-red-500 rounded-xl flex items-center justify-center",
                                      children: e.jsx(Ye, {
                                        size: 18
                                      })
                                    }),
                                    e.jsxs("div", {
                                      children: [
                                        e.jsx("p", {
                                          className: "font-bold text-sm",
                                          children: p.validator.moniker
                                        }),
                                        e.jsxs("p", {
                                          className: "text-[9px] text-[var(--text-muted)]",
                                          children: [
                                            "Staked: ",
                                            p.amount,
                                            " LMN"
                                          ]
                                        })
                                      ]
                                    })
                                  ]
                                })
                              }),
                              e.jsx("button", {
                                onClick: () => G(p),
                                disabled: b,
                                className: "w-full py-2.5 rounded-lg bg-red-500/10 text-red-500 text-xs font-bold hover:bg-red-500 hover:text-white transition-all disabled:opacity-50",
                                children: b ? "Processing..." : "Unstake Assets"
                              })
                            ]
                          }, I))
                        }) : e.jsx("div", {
                          className: "text-center py-12 text-[var(--text-dim)] text-xs font-semibold",
                          children: "No active stakes found."
                        })
                      ]
                    })
                  ]
                }),
                r === "rewards" && e.jsx("div", {
                  className: "space-y-2",
                  children: o ? e.jsx("div", {
                    className: "text-center py-10 opacity-50",
                    children: e.jsx(Ae, {
                      className: "w-8 h-8 mx-auto mb-2 animate-spin text-primary"
                    })
                  }) : W ? i.map((p, I) => e.jsxs("div", {
                    className: "bg-surface border border-border rounded-xl p-4 group",
                    children: [
                      e.jsx("div", {
                        className: "flex items-center justify-between mb-4",
                        children: e.jsxs("div", {
                          className: "flex items-center gap-3",
                          children: [
                            e.jsx("div", {
                              className: "w-9 h-9 bg-green-500/10 text-green-500 rounded-xl flex items-center justify-center",
                              children: e.jsx(us, {
                                size: 18
                              })
                            }),
                            e.jsxs("div", {
                              children: [
                                e.jsx("p", {
                                  className: "font-bold text-sm",
                                  children: p.validator.moniker
                                }),
                                e.jsxs("p", {
                                  className: "text-[10px] text-green-500 font-bold",
                                  children: [
                                    "+",
                                    p.rewards,
                                    " LMN Accumulated"
                                  ]
                                })
                              ]
                            })
                          ]
                        })
                      }),
                      e.jsx("button", {
                        onClick: () => se(p.validatorAddress),
                        disabled: b || parseFloat(p.rewards) === 0,
                        className: "w-full py-2.5 rounded-lg bg-green-500 text-white text-xs font-bold hover:bg-green-600 transition-all disabled:opacity-30",
                        children: b ? "Claiming..." : "Claim Available Rewards"
                      })
                    ]
                  }, I)) : e.jsx("div", {
                    className: "text-center py-12 text-[var(--text-dim)] text-xs font-semibold",
                    children: "No rewards to claim."
                  })
                })
              ]
            })
          ]
        }),
        A === "detail" && c && e.jsxs("div", {
          className: "flex flex-col h-full min-h-0 bg-surface/30 px-4 pt-3 animate-in slide-in-from-right-4 duration-300",
          children: [
            e.jsxs("div", {
              className: "flex-1 space-y-4 overflow-y-auto scrollbar-hide",
              children: [
                e.jsxs("div", {
                  className: "bg-surface border border-border rounded-2xl p-4 shadow-2xl relative overflow-hidden group",
                  children: [
                    e.jsx("div", {
                      className: "absolute -top-4 -right-2 p-2 opacity-5",
                      children: e.jsx(xs, {
                        size: 100
                      })
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-3 mb-3 shrink-0",
                      children: [
                        e.jsx("div", {
                          className: "w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center shadow-lg shadow-primary/20 shrink-0",
                          children: e.jsx(Xe, {
                            size: 20
                          })
                        }),
                        e.jsxs("div", {
                          className: "min-w-0",
                          children: [
                            e.jsx("h4", {
                              className: "text-sm font-black text-foreground truncate",
                              children: c.moniker
                            }),
                            e.jsx("p", {
                              className: "text-[8px] text-[var(--text-muted)] font-mono tracking-tight truncate",
                              children: c.address
                            })
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "grid grid-cols-2 gap-4",
                      children: [
                        e.jsxs("div", {
                          className: "space-y-0.5",
                          children: [
                            e.jsx("span", {
                              className: "text-[8px] font-black uppercase text-[var(--text-dim)] tracking-widest",
                              children: "APR Reward"
                            }),
                            e.jsx("p", {
                              className: "text-sm font-black text-green-500",
                              children: c.apr
                            })
                          ]
                        }),
                        e.jsxs("div", {
                          className: "space-y-0.5",
                          children: [
                            e.jsx("span", {
                              className: "text-[8px] font-black uppercase text-[var(--text-dim)] tracking-widest",
                              children: "Commission"
                            }),
                            e.jsx("p", {
                              className: "text-sm font-black text-foreground",
                              children: c.commission
                            })
                          ]
                        })
                      ]
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center justify-between px-1",
                      children: [
                        e.jsx("label", {
                          className: "text-[9px] font-black uppercase tracking-[0.2em] text-[var(--text-dim)]",
                          children: "Enter Amount"
                        }),
                        e.jsxs("div", {
                          className: "text-[9px] font-bold text-primary",
                          children: [
                            "Max: ",
                            (Number(B) / 1e6).toFixed(2),
                            " LMN"
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "relative group",
                      children: [
                        e.jsx("input", {
                          type: "number",
                          value: x,
                          onChange: (p) => v(p.target.value),
                          placeholder: "0.00",
                          className: "w-full bg-surface border-2 border-border rounded-xl p-3 text-lg font-black focus:border-primary outline-none transition-all pr-16 shadow-inner"
                        }),
                        e.jsx("div", {
                          className: "absolute right-4 top-1/2 -translate-y-1/2",
                          children: e.jsx("button", {
                            onClick: () => v((Number(B) / 1e6).toString()),
                            className: "text-[9px] font-black text-primary uppercase hover:bg-primary/10 px-1.5 py-1 rounded transition-colors",
                            children: "MAX"
                          })
                        })
                      ]
                    }),
                    x && parseFloat(x) <= 0 && e.jsxs("div", {
                      className: "flex items-center gap-1.5 px-1 text-red-500",
                      children: [
                        e.jsx(ct, {
                          size: 10
                        }),
                        e.jsx("span", {
                          className: "text-[9px] font-bold",
                          children: "Amount must be greater than 0"
                        })
                      ]
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "bg-primary/5 border border-primary/10 rounded-xl p-3 flex gap-2",
                  children: [
                    e.jsx(at, {
                      size: 14,
                      className: "text-primary shrink-0 mt-0.5"
                    }),
                    e.jsx("p", {
                      className: "text-[9px] text-foreground/60 leading-relaxed font-medium",
                      children: "Tokens bonded to validator. Unbonding takes 21 days on Cosmos networks."
                    })
                  ]
                })
              ]
            }),
            e.jsx("div", {
              className: "pb-24 pt-4 shrink-0",
              children: e.jsx("button", {
                onClick: () => T("confirm"),
                disabled: !x || parseFloat(x) <= 0,
                className: "w-full py-3.5 bg-primary text-white rounded-2xl font-black shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:scale-100",
                children: "Review Transaction"
              })
            })
          ]
        }),
        A === "confirm" && c && e.jsx("div", {
          className: "fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md animate-in fade-in duration-300 p-4",
          children: e.jsxs("div", {
            className: "w-full max-w-sm bg-background border border-border rounded-[32px] p-6 space-y-6 animate-in zoom-in-95 duration-300 shadow-2xl",
            children: [
              e.jsxs("div", {
                className: "text-center space-y-1",
                children: [
                  e.jsx("h3", {
                    className: "text-lg font-black",
                    children: "Confirm Staking"
                  }),
                  e.jsx("p", {
                    className: "text-xs text-[var(--text-muted)] font-semibold",
                    children: "Review your transaction details"
                  })
                ]
              }),
              e.jsxs("div", {
                className: "space-y-4",
                children: [
                  e.jsxs("div", {
                    className: "bg-surface border border-border rounded-2xl p-5 space-y-4",
                    children: [
                      e.jsxs("div", {
                        className: "flex justify-between items-center text-xs",
                        children: [
                          e.jsx("span", {
                            className: "text-[var(--text-dim)] font-bold",
                            children: "Action"
                          }),
                          e.jsx("span", {
                            className: "font-black text-primary uppercase tracking-wider",
                            children: "Stake Assets"
                          })
                        ]
                      }),
                      e.jsx("div", {
                        className: "h-[1px] bg-border/50"
                      }),
                      e.jsxs("div", {
                        className: "flex justify-between items-center text-xs",
                        children: [
                          e.jsx("span", {
                            className: "text-[var(--text-dim)] font-bold",
                            children: "Validator"
                          }),
                          e.jsx("span", {
                            className: "font-black",
                            children: c.moniker
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex justify-between items-center text-xs",
                        children: [
                          e.jsx("span", {
                            className: "text-[var(--text-dim)] font-bold",
                            children: "Commission"
                          }),
                          e.jsx("span", {
                            className: "font-black",
                            children: c.commission
                          })
                        ]
                      }),
                      e.jsx("div", {
                        className: "h-[1px] bg-border/50"
                      }),
                      e.jsxs("div", {
                        className: "flex justify-between items-center",
                        children: [
                          e.jsx("span", {
                            className: "text-[var(--text-dim)] text-xs font-bold",
                            children: "Total Amount"
                          }),
                          e.jsxs("div", {
                            className: "text-right",
                            children: [
                              e.jsxs("p", {
                                className: "text-xl font-black text-foreground",
                                children: [
                                  x,
                                  " LMN"
                                ]
                              }),
                              e.jsx("p", {
                                className: "text-[9px] text-[var(--text-muted)] font-bold",
                                children: "\u2248 $0 USD"
                              })
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "flex items-center gap-2 px-2 text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-[0.1em]",
                    children: [
                      e.jsx(Xe, {
                        size: 12,
                        className: "text-green-500"
                      }),
                      "Secured by Post-Quantum Dilithium3"
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex gap-3 pt-2",
                children: [
                  e.jsx("button", {
                    onClick: () => T("detail"),
                    className: "flex-1 py-4 bg-surfaceHighlight text-foreground rounded-2xl font-black text-sm hover:bg-border transition-colors",
                    children: "Back"
                  }),
                  e.jsxs("button", {
                    onClick: F,
                    disabled: b,
                    className: "flex-[2] py-4 bg-primary text-white rounded-2xl font-black text-sm shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2",
                    children: [
                      b && e.jsx(Ae, {
                        size: 16,
                        className: "animate-spin"
                      }),
                      b ? "Broadcasting..." : "Confirm & Stake"
                    ]
                  })
                ]
              })
            ]
          })
        }),
        re && ne && e.jsx("div", {
          className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-300",
          children: e.jsxs("div", {
            className: "w-full max-w-sm bg-background border border-border rounded-[32px] p-8 space-y-6 shadow-2xl animate-in zoom-in-95 duration-300",
            children: [
              e.jsx("div", {
                className: "w-16 h-16 bg-red-500/10 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-4",
                children: e.jsx(at, {
                  size: 32
                })
              }),
              e.jsxs("div", {
                className: "text-center space-y-2",
                children: [
                  e.jsx("h3", {
                    className: "text-xl font-black text-foreground",
                    children: "Confirm Unstake"
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-[var(--text-muted)] font-medium leading-relaxed px-2",
                    children: [
                      "Unstaking will start a ",
                      e.jsx("span", {
                        className: "text-red-500 font-bold",
                        children: "21-day unbonding period"
                      }),
                      ". During this time, you will not earn rewards and cannot move your tokens."
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "bg-surface border border-border rounded-xl p-4 space-y-3",
                children: [
                  e.jsxs("div", {
                    className: "flex justify-between text-[10px] font-bold uppercase tracking-wider",
                    children: [
                      e.jsx("span", {
                        className: "text-[var(--text-dim)]",
                        children: "Amount"
                      }),
                      e.jsxs("span", {
                        className: "text-foreground",
                        children: [
                          ne.amount,
                          " LMN"
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "flex justify-between text-[10px] font-bold uppercase tracking-wider",
                    children: [
                      e.jsx("span", {
                        className: "text-[var(--text-dim)]",
                        children: "Validator"
                      }),
                      e.jsx("span", {
                        className: "text-foreground",
                        children: ne.validator.moniker
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "grid grid-cols-2 gap-3",
                children: [
                  e.jsx("button", {
                    onClick: () => X(false),
                    className: "py-4 bg-surfaceHighlight text-foreground rounded-2xl font-black text-sm hover:bg-border transition-all",
                    children: "Cancel"
                  }),
                  e.jsx("button", {
                    onClick: U,
                    className: "py-4 bg-red-500 text-white rounded-2xl font-black text-sm shadow-xl shadow-red-500/20 hover:bg-red-600 transition-all",
                    children: "Unstake"
                  })
                ]
              })
            ]
          })
        }),
        e.jsx("div", {
          className: "fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-full max-w-xs px-4",
          children: g && e.jsx(Vt, {
            message: P,
            type: C,
            onClose: () => S(false)
          })
        })
      ]
    });
  }, Ct = "lumen", Sr = BigInt(2e5), St = (t) => {
    if (!t) return new Uint8Array(0);
    if (typeof t == "string") {
      const s = t.trim();
      if (s.length === 0) return new Uint8Array(0);
      if (/^[0-9a-fA-F]+$/.test(s)) try {
        const r = J.from(s, "hex");
        if (r.length > 0) return new Uint8Array(r);
      } catch {
      }
      try {
        const r = J.from(s, "base64");
        if (r.length > 0) return new Uint8Array(r);
        const a = atob(s);
        return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
      } catch {
        try {
          const a = atob(s);
          return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
        } catch {
          return new Uint8Array(0);
        }
      }
    }
    return new Uint8Array(t);
  };
  async function Lr(t, s) {
    const a = await fetch(`${s}/cosmos/auth/v1beta1/accounts/${t}`);
    if (!a.ok) throw new Error(`Account fetch failed: ${a.status} ${a.statusText}`);
    const n = await a.json(), l = n.account || n;
    return {
      accountNumber: BigInt(l.account_number || 0),
      sequence: BigInt(l.sequence || 0)
    };
  }
  function Pr(t) {
    switch (t) {
      case "yes":
        return He.VoteOption.VOTE_OPTION_YES;
      case "no":
        return He.VoteOption.VOTE_OPTION_NO;
      case "abstain":
        return He.VoteOption.VOTE_OPTION_ABSTAIN;
      case "veto":
        return He.VoteOption.VOTE_OPTION_NO_WITH_VETO;
    }
  }
  async function Ar(t, s, r, a) {
    var _a2, _b, _c, _d;
    const n = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
      prefix: "lmn"
    }), [l] = await n.getAccounts();
    if (l.address !== t.address) throw new Error(`Mnemonic derived address ${l.address} does not match wallet address ${t.address}`);
    await Y.getInstance().sync();
    const { accountNumber: i, sequence: d } = await Lr(t.address, a), c = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
    if (!c) throw new Error("Wallet is missing PQC key data. Please re-import your wallet.");
    const u = c.privateKey || c.private_key || c.encryptedPrivateKey, x = c.publicKey || c.public_key;
    if (!u || !x) throw new Error("PQC keys missing sub-properties. Please re-import your wallet.");
    const v = St(u), b = St(x);
    if (b.length !== 1952) throw new Error(`Invalid PQC Public Key. Expected 1952 bytes, got ${b.length}. Please re-import your wallet.`);
    if (v.length !== 4e3) throw new Error(`Invalid PQC Private Key Length: ${v.length} (Expected 4000)`);
    const h = js.MsgVote.encode({
      proposalId: BigInt(s),
      voter: t.address,
      option: Pr(r)
    }).finish(), o = ie.Any.fromPartial({
      typeUrl: "/cosmos.gov.v1beta1.MsgVote",
      value: h
    }), y = M.TxBody.fromPartial({
      messages: [
        o
      ],
      memo: `Vote ${r} on proposal #${s}`
    }), g = M.TxBody.encode(y).finish(), S = ie.Any.fromPartial({
      typeUrl: "/cosmos.crypto.secp256k1.PubKey",
      value: Be.PubKey.encode({
        key: l.pubkey
      }).finish()
    }), P = M.AuthInfo.fromPartial({
      signerInfos: [
        {
          publicKey: S,
          modeInfo: {
            single: {
              mode: Te.SignMode.SIGN_MODE_DIRECT
            }
          },
          sequence: d
        }
      ],
      fee: M.Fee.fromPartial({
        amount: [],
        gasLimit: Sr
      })
    }), k = M.AuthInfo.encode(P).finish(), C = {
      bodyBytes: g,
      authInfoBytes: k,
      signatures: []
    }, N = te.computeSignBytes(Ct, Number(i), C), f = await te.signDilithium(N, v), L = {
      addr: t.address,
      scheme: "dilithium3",
      signature: new Uint8Array(f),
      pubKey: b
    };
    let j = te.withPqcExtension(g, [
      L
    ]);
    const w = M.SignDoc.fromPartial({
      bodyBytes: j,
      authInfoBytes: k,
      chainId: Ct,
      accountNumber: i
    }), { signature: A } = await n.signDirect(t.address, w), T = M.TxRaw.fromPartial({
      bodyBytes: j,
      authInfoBytes: k,
      signatures: [
        J.from(A.signature, "base64")
      ]
    }), B = M.TxRaw.encode(T).finish();
    return await Ir(B, a);
  }
  async function Ir(t, s) {
    var _a2, _b;
    const r = s, n = {
      tx_bytes: J.from(t).toString("base64"),
      mode: "BROADCAST_MODE_SYNC"
    }, l = await fetch(`${r}/cosmos/tx/v1beta1/txs`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(n)
    }), i = await l.json();
    if (!l.ok || ((_a2 = i.tx_response) == null ? void 0 : _a2.code) !== 0) throw console.error("[TX] Broadcast Failed:", i), new Error(((_b = i.tx_response) == null ? void 0 : _b.raw_log) || JSON.stringify(i));
    return i.tx_response.txhash;
  }
  const Lt = "https://rest.cosmos.directory/lumen", Er = ({ walletKeys: t, onBack: s }) => {
    const [r, a] = m.useState([]), [n, l] = m.useState(null), [i, d] = m.useState(null), [c, u] = m.useState(false), [x, v] = m.useState(false), [b, h] = m.useState(false), [o, y] = m.useState(""), [g, S] = m.useState("success"), P = async () => {
      var _a2;
      v(true);
      try {
        const f = await fetch(`${Lt}/cosmos/gov/v1/proposals?proposal_status=2`);
        if (!f.ok) throw new Error("Failed to fetch proposals");
        const j = ((_a2 = (await f.json()).proposals) == null ? void 0 : _a2.map((w) => {
          var _a3, _b, _c, _d, _e2, _f, _g, _h, _i, _j;
          const A = ((_a3 = w.final_tally_result) == null ? void 0 : _a3.yes_count) || ((_b = w.final_tally_result) == null ? void 0 : _b.yes) || "0", T = ((_c = w.final_tally_result) == null ? void 0 : _c.no_count) || ((_d = w.final_tally_result) == null ? void 0 : _d.no) || "0", B = ((_e2 = w.final_tally_result) == null ? void 0 : _e2.abstain_count) || ((_f = w.final_tally_result) == null ? void 0 : _f.abstain) || "0", E = ((_g = w.final_tally_result) == null ? void 0 : _g.no_with_veto_count) || ((_h = w.final_tally_result) == null ? void 0 : _h.no_with_veto) || "0", _ = BigInt(A) + BigInt(T) + BigInt(B) + BigInt(E), R = (re) => _ === BigInt(0) ? "0%" : `${(Number(BigInt(re) * BigInt(1e4) / _) / 100).toFixed(1)}%`, K = (re) => {
            const X = Number(re) / 1e6;
            return X >= 1e6 ? `${(X / 1e6).toFixed(2)}M` : X >= 1e3 ? `${(X / 1e3).toFixed(2)}K` : X.toFixed(2);
          };
          let Q = "pending";
          return w.status === "PROPOSAL_STATUS_VOTING_PERIOD" ? Q = "voting" : w.status === "PROPOSAL_STATUS_PASSED" ? Q = "passed" : w.status === "PROPOSAL_STATUS_REJECTED" && (Q = "rejected"), {
            id: w.id || w.proposal_id,
            title: w.title || ((_i = w.content) == null ? void 0 : _i.title) || "Untitled Proposal",
            description: w.summary || ((_j = w.content) == null ? void 0 : _j.description) || w.description || "No description available",
            status: Q,
            votingEnd: w.voting_end_time ? new Date(w.voting_end_time).toLocaleDateString() : "N/A",
            yesVotes: R(A),
            noVotes: R(T),
            abstainVotes: R(B),
            vetoVotes: R(E),
            yesVotesRaw: K(A),
            noVotesRaw: K(T),
            abstainVotesRaw: K(B),
            vetoVotesRaw: K(E)
          };
        })) || [];
        a(j);
      } catch (f) {
        console.error("Error fetching proposals:", f), y("Failed to fetch proposals from network"), S("error"), h(true);
      } finally {
        v(false);
      }
    };
    m.useEffect(() => {
      P();
    }, []);
    const k = async () => {
      if (!(!n || !i || !t)) {
        u(true);
        try {
          const f = await Ar(t, n.id, i, Lt);
          y(`Vote submitted! TX: ${f.slice(0, 8)}...`), S("success"), h(true), await P(), l(null), d(null);
        } catch (f) {
          console.error("Voting error:", f), y(f.message || "Failed to submit vote"), S("error"), h(true);
        } finally {
          u(false);
        }
      }
    }, C = (f) => {
      switch (f) {
        case "voting":
          return "text-primary";
        case "passed":
          return "text-green-500";
        case "rejected":
          return "text-red-500";
        case "pending":
          return "text-yellow-500";
      }
    }, N = (f) => {
      switch (f) {
        case "voting":
          return "bg-primary/10 border-primary/30";
        case "passed":
          return "bg-green-500/10 border-green-500/30";
        case "rejected":
          return "bg-red-500/10 border-red-500/30";
        case "pending":
          return "bg-yellow-500/10 border-yellow-500/30";
      }
    };
    return n ? e.jsxs("div", {
      className: "flex flex-col h-full min-h-0 bg-background",
      children: [
        e.jsxs("div", {
          className: "flex items-center justify-between px-4 py-3 border-b border-border bg-surface",
          children: [
            e.jsx("button", {
              onClick: () => l(null),
              className: "p-1.5 hover:bg-surfaceHighlight rounded-lg transition-colors",
              children: e.jsx(ot, {
                className: "w-5 h-5 text-foreground"
              })
            }),
            e.jsxs("h1", {
              className: "text-base font-semibold text-foreground",
              children: [
                "Proposal #",
                n.id
              ]
            }),
            e.jsx("div", {
              className: "w-8"
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex-1 overflow-y-auto p-3 pb-24 space-y-3",
          children: [
            e.jsxs("div", {
              className: "bg-surface border border-border rounded-lg p-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between mb-2",
                  children: [
                    e.jsx("h2", {
                      className: "text-base font-semibold text-foreground",
                      children: n.title
                    }),
                    e.jsx("span", {
                      className: `px-2 py-0.5 rounded-full text-[9px] font-semibold uppercase ${N(n.status)} ${C(n.status)}`,
                      children: n.status
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "text-xs text-[var(--text-muted)] leading-relaxed mb-3",
                  children: n.description
                }),
                e.jsxs("div", {
                  className: "text-[10px] text-[var(--text-dim)]",
                  children: [
                    "Voting ends: ",
                    n.votingEnd
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "bg-surface border border-border rounded-lg p-3",
              children: [
                e.jsx("h3", {
                  className: "text-xs font-semibold text-foreground mb-2",
                  children: "Current Results"
                }),
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsxs("div", {
                          className: "flex justify-between text-[10px] mb-1",
                          children: [
                            e.jsx("span", {
                              className: "text-green-500 font-semibold",
                              children: "Yes"
                            }),
                            e.jsxs("div", {
                              className: "flex items-center gap-1.5",
                              children: [
                                e.jsxs("span", {
                                  className: "text-foreground font-bold",
                                  children: [
                                    n.yesVotesRaw,
                                    " LMN"
                                  ]
                                }),
                                e.jsxs("span", {
                                  className: "text-[var(--text-muted)]",
                                  children: [
                                    "(",
                                    n.yesVotes,
                                    ")"
                                  ]
                                })
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "h-1.5 bg-background rounded-full overflow-hidden",
                          children: e.jsx("div", {
                            className: "h-full bg-green-500",
                            style: {
                              width: n.yesVotes
                            }
                          })
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsxs("div", {
                          className: "flex justify-between text-[10px] mb-1",
                          children: [
                            e.jsx("span", {
                              className: "text-red-500 font-semibold",
                              children: "No"
                            }),
                            e.jsxs("div", {
                              className: "flex items-center gap-1.5",
                              children: [
                                e.jsxs("span", {
                                  className: "text-foreground font-bold",
                                  children: [
                                    n.noVotesRaw,
                                    " LMN"
                                  ]
                                }),
                                e.jsxs("span", {
                                  className: "text-[var(--text-muted)]",
                                  children: [
                                    "(",
                                    n.noVotes,
                                    ")"
                                  ]
                                })
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "h-1.5 bg-background rounded-full overflow-hidden",
                          children: e.jsx("div", {
                            className: "h-full bg-red-500",
                            style: {
                              width: n.noVotes
                            }
                          })
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsxs("div", {
                          className: "flex justify-between text-[10px] mb-1",
                          children: [
                            e.jsx("span", {
                              className: "text-yellow-500 font-semibold",
                              children: "Abstain"
                            }),
                            e.jsxs("div", {
                              className: "flex items-center gap-1.5",
                              children: [
                                e.jsxs("span", {
                                  className: "text-foreground font-bold",
                                  children: [
                                    n.abstainVotesRaw,
                                    " LMN"
                                  ]
                                }),
                                e.jsxs("span", {
                                  className: "text-[var(--text-muted)]",
                                  children: [
                                    "(",
                                    n.abstainVotes,
                                    ")"
                                  ]
                                })
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "h-1.5 bg-background rounded-full overflow-hidden",
                          children: e.jsx("div", {
                            className: "h-full bg-yellow-500",
                            style: {
                              width: n.abstainVotes
                            }
                          })
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsxs("div", {
                          className: "flex justify-between text-[10px] mb-1",
                          children: [
                            e.jsx("span", {
                              className: "text-orange-500 font-semibold",
                              children: "Veto"
                            }),
                            e.jsxs("div", {
                              className: "flex items-center gap-1.5",
                              children: [
                                e.jsxs("span", {
                                  className: "text-foreground font-bold",
                                  children: [
                                    n.vetoVotesRaw,
                                    " LMN"
                                  ]
                                }),
                                e.jsxs("span", {
                                  className: "text-[var(--text-muted)]",
                                  children: [
                                    "(",
                                    n.vetoVotes,
                                    ")"
                                  ]
                                })
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "h-1.5 bg-background rounded-full overflow-hidden",
                          children: e.jsx("div", {
                            className: "h-full bg-orange-500",
                            style: {
                              width: n.vetoVotes
                            }
                          })
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            n.status === "voting" && e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsx("h3", {
                  className: "text-xs font-semibold text-foreground",
                  children: "Cast Your Vote"
                }),
                e.jsxs("div", {
                  className: "grid grid-cols-2 gap-2",
                  children: [
                    e.jsxs("button", {
                      onClick: () => d("yes"),
                      className: `p-3 rounded-lg border transition-colors ${i === "yes" ? "border-green-500 bg-green-500/10" : "border-border bg-surface hover:border-green-500/50"}`,
                      children: [
                        e.jsx(Mt, {
                          className: `w-5 h-5 mx-auto mb-1 ${i === "yes" ? "text-green-500" : "text-[var(--text-muted)]"}`
                        }),
                        e.jsx("p", {
                          className: "text-xs font-semibold text-foreground",
                          children: "Yes"
                        })
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => d("no"),
                      className: `p-3 rounded-lg border transition-colors ${i === "no" ? "border-red-500 bg-red-500/10" : "border-border bg-surface hover:border-red-500/50"}`,
                      children: [
                        e.jsx(nt, {
                          className: `w-5 h-5 mx-auto mb-1 ${i === "no" ? "text-red-500" : "text-[var(--text-muted)]"}`
                        }),
                        e.jsx("p", {
                          className: "text-xs font-semibold text-foreground",
                          children: "No"
                        })
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => d("abstain"),
                      className: `p-3 rounded-lg border transition-colors ${i === "abstain" ? "border-yellow-500 bg-yellow-500/10" : "border-border bg-surface hover:border-yellow-500/50"}`,
                      children: [
                        e.jsx(hs, {
                          className: `w-5 h-5 mx-auto mb-1 ${i === "abstain" ? "text-yellow-500" : "text-[var(--text-muted)]"}`
                        }),
                        e.jsx("p", {
                          className: "text-xs font-semibold text-foreground",
                          children: "Abstain"
                        })
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => d("veto"),
                      className: `p-3 rounded-lg border transition-colors ${i === "veto" ? "border-orange-500 bg-orange-500/10" : "border-border bg-surface hover:border-orange-500/50"}`,
                      children: [
                        e.jsx(ct, {
                          className: `w-5 h-5 mx-auto mb-1 ${i === "veto" ? "text-orange-500" : "text-[var(--text-muted)]"}`
                        }),
                        e.jsx("p", {
                          className: "text-xs font-semibold text-foreground",
                          children: "Veto"
                        })
                      ]
                    })
                  ]
                }),
                e.jsx("button", {
                  onClick: k,
                  disabled: !i || c,
                  className: "w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-hover hover:to-primary disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all duration-300 hover:scale-105 active:scale-95",
                  children: c ? "Submitting Vote..." : "Submit Vote"
                })
              ]
            })
          ]
        })
      ]
    }) : e.jsxs("div", {
      className: "flex flex-col h-full min-h-0 bg-background",
      children: [
        e.jsxs("div", {
          className: "flex items-center justify-between px-4 py-4 border-b border-border bg-surface/80 backdrop-blur-xl",
          children: [
            e.jsx("button", {
              onClick: s,
              className: "p-2 hover:bg-surfaceHighlight rounded-xl transition-all duration-300 hover:scale-110 active:scale-95",
              children: e.jsx(ot, {
                className: "w-5 h-5 text-foreground"
              })
            }),
            e.jsx("h1", {
              className: "text-lg font-bold text-foreground",
              children: "Governance"
            }),
            e.jsx("button", {
              onClick: P,
              disabled: x,
              className: "p-2 hover:bg-surfaceHighlight rounded-xl transition-all duration-300 hover:scale-110 active:scale-95 disabled:scale-100",
              children: e.jsx(Ae, {
                className: `w-5 h-5 text-foreground transition-transform ${x ? "animate-spin" : ""}`
              })
            })
          ]
        }),
        e.jsx("div", {
          className: "flex-1 overflow-y-auto p-3 pb-24 space-y-2",
          children: x ? e.jsxs("div", {
            className: "text-center py-10",
            children: [
              e.jsx(Ae, {
                className: "w-10 h-10 text-primary mx-auto mb-2 animate-spin"
              }),
              e.jsx("p", {
                className: "text-sm text-[var(--text-muted)]",
                children: "Loading proposals..."
              })
            ]
          }) : r.filter((f) => f.status === "voting").length === 0 ? e.jsxs("div", {
            className: "text-center py-10",
            children: [
              e.jsx(tt, {
                className: "w-10 h-10 text-[var(--text-muted)] mx-auto mb-2 opacity-50"
              }),
              e.jsx("p", {
                className: "text-sm text-[var(--text-muted)]",
                children: "No active proposals"
              }),
              e.jsx("p", {
                className: "text-[10px] text-[var(--text-dim)] mt-1",
                children: "Check back later for new proposals"
              })
            ]
          }) : r.filter((f) => f.status === "voting").map((f) => e.jsxs("button", {
            onClick: () => l(f),
            className: "w-full bg-surface border border-border rounded-2xl p-4 hover:border-primary/50 transition-all duration-300 hover:scale-[1.02] text-left",
            children: [
              e.jsxs("div", {
                className: "flex items-start justify-between mb-2",
                children: [
                  e.jsxs("div", {
                    className: "flex-1",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-1.5 mb-1",
                        children: [
                          e.jsx(tt, {
                            className: "w-3.5 h-3.5 text-primary"
                          }),
                          e.jsxs("span", {
                            className: "text-[10px] font-medium text-[var(--text-muted)]",
                            children: [
                              "Proposal #",
                              f.id
                            ]
                          })
                        ]
                      }),
                      e.jsx("h3", {
                        className: "font-semibold text-sm text-foreground mb-1",
                        children: f.title
                      }),
                      e.jsx("p", {
                        className: "text-[10px] text-[var(--text-muted)] line-clamp-2",
                        children: f.description
                      })
                    ]
                  }),
                  e.jsx("span", {
                    className: `px-2 py-0.5 rounded-full text-[9px] font-semibold uppercase ${N(f.status)} ${C(f.status)} ml-2 shrink-0`,
                    children: f.status
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex items-center justify-between text-[10px] mt-2",
                children: [
                  e.jsxs("span", {
                    className: "text-[var(--text-dim)]",
                    children: [
                      "Ends: ",
                      f.votingEnd
                    ]
                  }),
                  e.jsxs("div", {
                    className: "flex gap-2",
                    children: [
                      e.jsxs("span", {
                        className: "text-green-500 font-semibold",
                        children: [
                          "Yes ",
                          f.yesVotesRaw
                        ]
                      }),
                      e.jsxs("span", {
                        className: "text-red-500 font-semibold",
                        children: [
                          "No ",
                          f.noVotesRaw
                        ]
                      })
                    ]
                  })
                ]
              })
            ]
          }, f.id))
        }),
        b && e.jsx(Vt, {
          message: o,
          type: g,
          onClose: () => h(false)
        })
      ]
    });
  }, Pt = (t) => {
    if (window.innerWidth < 600 && chrome.tabs) {
      const r = chrome.runtime.getURL(`index.html#${t}`);
      chrome.tabs.create({
        url: r
      }), window.close();
    } else window.location.hash = "#" + t;
  }, At = "lumen", Br = BigInt(2e5), Tr = BigInt(35e4), _r = 25e4, Mr = 35e4, It = (t) => {
    if (!t) return new Uint8Array(0);
    if (typeof t == "string") {
      const s = t.trim();
      if (s.length === 0) return new Uint8Array(0);
      if (/^[0-9a-fA-F]+$/.test(s)) try {
        const r = J.from(s, "hex");
        if (r.length > 0) return new Uint8Array(r);
      } catch {
      }
      try {
        const r = J.from(s, "base64");
        if (r.length > 0) return new Uint8Array(r);
        const a = atob(s);
        return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
      } catch {
        try {
          const a = atob(s);
          return new Uint8Array(a.split("").map((n) => n.charCodeAt(0)));
        } catch {
          return new Uint8Array(0);
        }
      }
    }
    return new Uint8Array(t);
  };
  async function Rr(t, s) {
    const r = s || await Y.getInstance().getRestEndpoint(), a = await fetch(`${r}/cosmos/auth/v1beta1/accounts/${t}`);
    if (!a.ok) throw new Error(`Account fetch failed: ${a.status} ${a.statusText}`);
    const n = await a.json(), l = n.account || n;
    return {
      accountNumber: BigInt(l.account_number || 0),
      sequence: BigInt(l.sequence || 0)
    };
  }
  async function Qt({ walletData: t, messages: s, memo: r, apiEndpoint: a, gasLimit: n, feeAmount: l = [] }) {
    var _a2, _b, _c, _d;
    const i = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
      prefix: "lmn"
    }), [d] = await i.getAccounts();
    if (d.address !== t.address) throw new Error(`Mnemonic derived address ${d.address} does not match wallet address ${t.address}`);
    const c = a || await Y.getInstance().getRestEndpoint(), { accountNumber: u, sequence: x } = await Rr(t.address, c), v = ((_a2 = t.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b = t.pqcKey) == null ? void 0 : _b.public_key) ? t.pqcKey : ((_c = t.pqc) == null ? void 0 : _c.publicKey) || ((_d = t.pqc) == null ? void 0 : _d.public_key) ? t.pqc : t.pqcKey || t.pqc;
    if (!v) throw new Error("Wallet is missing PQC key data. Please re-import your wallet.");
    const b = v.privateKey || v.private_key || v.encryptedPrivateKey, h = v.publicKey || v.public_key;
    if (!b || !h) throw new Error("PQC keys missing sub-properties. Please re-import your wallet.");
    const o = It(b), y = It(h);
    if (y.length !== 1952) throw new Error(`Invalid PQC Public Key. Expected 1952 bytes, got ${y.length}. Please re-import your wallet.`);
    if (o.length !== 4e3) throw new Error(`Invalid PQC Private Key Length: ${o.length} (Expected 4000)`);
    const g = M.TxBody.fromPartial({
      messages: s,
      memo: r
    }), S = M.TxBody.encode(g).finish(), P = ie.Any.fromPartial({
      typeUrl: "/cosmos.crypto.secp256k1.PubKey",
      value: Be.PubKey.encode({
        key: d.pubkey
      }).finish()
    }), k = M.AuthInfo.fromPartial({
      signerInfos: [
        {
          publicKey: P,
          modeInfo: {
            single: {
              mode: Te.SignMode.SIGN_MODE_DIRECT
            }
          },
          sequence: x
        }
      ],
      fee: M.Fee.fromPartial({
        amount: l,
        gasLimit: n
      })
    }), C = M.AuthInfo.encode(k).finish(), N = {
      bodyBytes: S,
      authInfoBytes: C,
      signatures: []
    }, f = te.computeSignBytes(At, Number(u), N), L = await te.signDilithium(f, o), j = {
      addr: t.address,
      scheme: "dilithium3",
      signature: new Uint8Array(L),
      pubKey: y
    };
    let w = te.withPqcExtension(S, [
      j
    ]);
    const A = M.TxBody.decode(w), T = "/lumen.pqc.v1.PQCSignatures";
    A.nonCriticalExtensionOptions.findIndex((Q) => Q.typeUrl === T);
    const B = M.TxBody.decode(w);
    if (!(B.nonCriticalExtensionOptions.some((Q) => Q.typeUrl === T) || B.extensionOptions.some((Q) => Q.typeUrl === T))) throw new Error("Failed to attach PQC Extension");
    const _ = M.SignDoc.fromPartial({
      bodyBytes: w,
      authInfoBytes: C,
      chainId: At,
      accountNumber: u
    }), { signature: R } = await i.signDirect(t.address, _), K = M.TxRaw.fromPartial({
      bodyBytes: w,
      authInfoBytes: C,
      signatures: [
        J.from(R.signature, "base64")
      ]
    });
    return {
      txBytes: M.TxRaw.encode(K).finish(),
      endpoint: c
    };
  }
  async function $r(t, s, r, a, n, l = "ulmn") {
    const i = qt.MsgSend.encode({
      fromAddress: t.address,
      toAddress: s,
      amount: [
        {
          denom: l,
          amount: r
        }
      ]
    }).finish(), d = ie.Any.fromPartial({
      typeUrl: "/cosmos.bank.v1beta1.MsgSend",
      value: i
    });
    return Qt({
      walletData: t,
      messages: [
        d
      ],
      memo: a,
      apiEndpoint: n,
      gasLimit: Br
    });
  }
  async function Dr(t, s, r, a, n, l = "transfer", i = 600, d, c = "ulmn") {
    const u = BigInt(Date.now() + i * 1e3) * 1000000n, x = Ve.MsgTransfer.encode(Ve.MsgTransfer.fromPartial({
      sourcePort: l,
      sourceChannel: n,
      token: {
        denom: c,
        amount: r
      },
      sender: t.address,
      receiver: s,
      timeoutTimestamp: u,
      memo: a
    })).finish(), v = ie.Any.fromPartial({
      typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
      value: x
    });
    return Qt({
      walletData: t,
      messages: [
        v
      ],
      memo: a,
      apiEndpoint: d,
      gasLimit: Tr,
      feeAmount: [
        {
          denom: "ulmn",
          amount: "1000"
        }
      ]
    });
  }
  async function qr(t, s) {
    var _a2, _b;
    const r = s || await Y.getInstance().getRestEndpoint(), n = {
      tx_bytes: J.from(t).toString("base64"),
      mode: "BROADCAST_MODE_SYNC"
    }, l = await fetch(`${r}/cosmos/tx/v1beta1/txs`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(n)
    }), i = await l.json();
    if (!l.ok || ((_a2 = i.tx_response) == null ? void 0 : _a2.code) !== 0) throw console.error("[TX] Broadcast Failed:", i), new Error(((_b = i.tx_response) == null ? void 0 : _b.raw_log) || JSON.stringify(i));
    return i.tx_response.txhash;
  }
  function Wr() {
    return new ce.Registry([
      ...qe.defaultRegistryTypes,
      [
        "/ibc.applications.transfer.v1.MsgTransfer",
        Ve.MsgTransfer
      ]
    ]);
  }
  async function Ur(t) {
    const s = await ce.DirectSecp256k1HdWallet.fromMnemonic(t.mnemonic, {
      prefix: t.prefix
    }), [r] = await s.getAccounts();
    if (r.address !== t.fromAddress) throw new Error(`Mnemonic derived address ${r.address} does not match source address ${t.fromAddress}`);
    const a = qe.GasPrice.fromString(`${t.minGasPrice}${t.feeDenom}`);
    return {
      client: await qe.SigningStargateClient.connectWithSigner(t.rpcEndpoint, s, {
        registry: Wr(),
        gasPrice: a
      }),
      wallet: s
    };
  }
  async function Gt(t) {
    const { client: s } = await Ur(t);
    try {
      const r = qe.calculateFee(t.gasLimit, qe.GasPrice.fromString(`${t.minGasPrice}${t.feeDenom}`)), a = await s.signAndBroadcast(t.fromAddress, t.messages, r, t.memo || "");
      if (a.code !== 0) {
        const n = (a == null ? void 0 : a.codespace) || "sdk";
        throw new Error(`Broadcasting transaction failed with code ${a.code} (codespace: ${n}). Log: ${a.rawLog || "Unknown error"}`);
      }
      return a.transactionHash;
    } finally {
      s.disconnect();
    }
  }
  async function Hr(t) {
    return Gt({
      mnemonic: t.mnemonic,
      prefix: t.prefix,
      fromAddress: t.fromAddress,
      rpcEndpoint: t.rpcEndpoint,
      feeDenom: t.feeDenom,
      minGasPrice: t.minGasPrice,
      gasLimit: _r,
      memo: t.memo,
      messages: [
        {
          typeUrl: "/cosmos.bank.v1beta1.MsgSend",
          value: qt.MsgSend.fromPartial({
            fromAddress: t.fromAddress,
            toAddress: t.toAddress,
            amount: [
              {
                denom: t.denom,
                amount: t.amount
              }
            ]
          })
        }
      ]
    });
  }
  async function Kr(t) {
    const s = BigInt(Date.now() + (t.timeoutSeconds ?? 600) * 1e3) * 1000000n;
    return Gt({
      mnemonic: t.mnemonic,
      prefix: t.prefix,
      fromAddress: t.fromAddress,
      rpcEndpoint: t.rpcEndpoint,
      feeDenom: t.feeDenom,
      minGasPrice: t.minGasPrice,
      gasLimit: Mr,
      memo: t.memo,
      messages: [
        {
          typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
          value: Ve.MsgTransfer.fromPartial({
            sourcePort: t.sourcePort || "transfer",
            sourceChannel: t.sourceChannel,
            token: {
              denom: t.denom,
              amount: t.amount
            },
            sender: t.fromAddress,
            receiver: t.toAddress,
            timeoutTimestamp: s,
            memo: t.memo || ""
          })
        }
      ]
    });
  }
  const Or = () => {
    const [t, s] = m.useState({
      isLoading: false,
      error: null,
      successHash: null
    }), r = async (i) => {
      s({
        isLoading: true,
        error: null,
        successHash: null
      });
      try {
        const d = Y.getInstance();
        await d.sync();
        const c = await d.getRestEndpoint();
        await new Promise((b) => setTimeout(b, 100));
        const { txBytes: u, endpoint: x } = await i(c), v = await qr(u, x);
        return s({
          isLoading: false,
          error: null,
          successHash: v
        }), v;
      } catch (d) {
        throw console.error(d), s({
          isLoading: false,
          error: d.message || "Transaction failed.",
          successHash: null
        }), d;
      }
    };
    return {
      ...t,
      sendTransaction: async (i, d, c, u = "", x = {}) => {
        const v = parseFloat(c);
        if (isNaN(v) || v <= 0) throw new Error("Invalid amount.");
        if (!d.includes("1")) throw new Error("Invalid recipient address.");
        const b = Math.round(v * 1e6).toString(), h = x.denom || "ulmn";
        if (x.useStandardTx) {
          if (!x.fromAddress || !x.addressPrefix || !x.rpcEndpoint || !x.feeDenom) throw new Error("Missing source chain configuration.");
          s({
            isLoading: true,
            error: null,
            successHash: null
          });
          try {
            const o = await Hr({
              mnemonic: i.mnemonic,
              prefix: x.addressPrefix,
              fromAddress: x.fromAddress,
              toAddress: d,
              amount: b,
              denom: h,
              memo: u,
              rpcEndpoint: x.rpcEndpoint,
              feeDenom: x.feeDenom,
              minGasPrice: x.minGasPrice ?? 0.01
            });
            return s({
              isLoading: false,
              error: null,
              successHash: o
            }), o;
          } catch (o) {
            throw console.error(o), s({
              isLoading: false,
              error: o.message || "Transaction failed.",
              successHash: null
            }), o;
          }
        }
        return r((o) => $r(i, d, b, u, o, h));
      },
      ibcTransfer: async (i, d, c, u) => {
        const x = parseFloat(c);
        if (isNaN(x) || x <= 0) throw new Error("Invalid amount.");
        if (!u.sourceChannel) throw new Error("Missing IBC route.");
        const v = Math.round(x * 1e6).toString(), b = u.denom || "ulmn";
        if (u.useStandardTx) {
          if (!u.fromAddress || !u.addressPrefix || !u.rpcEndpoint || !u.feeDenom) throw new Error("Missing source chain configuration.");
          s({
            isLoading: true,
            error: null,
            successHash: null
          });
          try {
            const h = await Kr({
              mnemonic: i.mnemonic,
              prefix: u.addressPrefix,
              fromAddress: u.fromAddress,
              toAddress: d,
              amount: v,
              denom: b,
              memo: u.memo || "",
              rpcEndpoint: u.rpcEndpoint,
              feeDenom: u.feeDenom,
              minGasPrice: u.minGasPrice ?? 0.01,
              sourceChannel: u.sourceChannel,
              sourcePort: u.sourcePort || "transfer",
              timeoutSeconds: u.timeoutSeconds ?? 600
            });
            return s({
              isLoading: false,
              error: null,
              successHash: h
            }), h;
          } catch (h) {
            throw console.error(h), s({
              isLoading: false,
              error: h.message || "Transaction failed.",
              successHash: null
            }), h;
          }
        }
        return r((h) => Dr(i, d, v, u.memo || "", u.sourceChannel, u.sourcePort || "transfer", u.timeoutSeconds ?? 600, h, b));
      },
      resetState: () => {
        s({
          isLoading: false,
          error: null,
          successHash: null
        });
      }
    };
  }, Et = "lumen_contacts";
  function zr() {
    const [t, s] = m.useState([]);
    m.useEffect(() => {
      const i = localStorage.getItem(Et);
      if (i) try {
        s(JSON.parse(i));
      } catch (d) {
        console.error("Failed to parse contacts", d);
      }
    }, []);
    const r = (i) => {
      s(i), localStorage.setItem(Et, JSON.stringify(i));
    };
    return {
      contacts: t,
      addContact: (i, d) => {
        const c = {
          id: Date.now().toString(),
          name: i,
          address: d
        };
        r([
          ...t,
          c
        ]);
      },
      removeContact: (i) => {
        r(t.filter((d) => d.id !== i));
      },
      editContact: (i, d, c) => {
        r(t.map((u) => u.id === i ? {
          ...u,
          name: d,
          address: c
        } : u));
      }
    };
  }
  const Fr = ({ onClose: t, onSelect: s }) => {
    const { contacts: r, addContact: a, removeContact: n } = zr(), [l, i] = m.useState("list"), [d, c] = m.useState(""), [u, x] = m.useState(""), [v, b] = m.useState(""), h = (g) => {
      g.preventDefault(), u && v && (a(u, v), x(""), b(""), i("list"));
    }, o = r.filter((g) => g.name.toLowerCase().includes(d.toLowerCase()) || g.address.toLowerCase().includes(d.toLowerCase())), y = e.jsx("div", {
      className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in",
      onClick: t,
      style: {
        margin: 0,
        left: 0,
        right: 0,
        top: 0,
        bottom: 0
      },
      children: e.jsxs("div", {
        className: "w-full max-w-sm h-[500px] bg-surface border border-border rounded-xl shadow-2xl flex flex-col relative overflow-hidden",
        onClick: (g) => g.stopPropagation(),
        children: [
          e.jsxs("div", {
            className: "p-4 border-b border-border flex items-center justify-between bg-surface/80 backdrop-blur",
            children: [
              e.jsxs("h2", {
                className: "text-lg font-bold text-foreground flex items-center gap-2",
                children: [
                  e.jsx(ft, {
                    className: "w-5 h-5 text-primary"
                  }),
                  "Contacts"
                ]
              }),
              e.jsx("button", {
                onClick: t,
                className: "p-1 hover:bg-surfaceHighlight rounded-full transition-colors text-[var(--text-muted)] hover:text-foreground",
                children: e.jsx(Fe, {
                  className: "w-5 h-5"
                })
              })
            ]
          }),
          l === "list" ? e.jsxs(e.Fragment, {
            children: [
              e.jsxs("div", {
                className: "p-3 border-b border-border bg-surfaceHighlight/20 flex gap-2",
                children: [
                  e.jsxs("div", {
                    className: "relative flex-1",
                    children: [
                      e.jsx(Rt, {
                        className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-dim)]"
                      }),
                      e.jsx("input", {
                        value: d,
                        onChange: (g) => c(g.target.value),
                        placeholder: "Search name or address...",
                        className: "w-full bg-surface border border-border rounded-lg pl-9 pr-3 py-2 text-xs text-foreground focus:border-primary outline-none"
                      })
                    ]
                  }),
                  e.jsx("button", {
                    onClick: () => i("add"),
                    className: "p-2 bg-primary hover:bg-primary-hover text-white rounded-lg transition-colors",
                    children: e.jsx(ps, {
                      className: "w-4 h-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-2 space-y-2",
                children: o.length === 0 ? e.jsxs("div", {
                  className: "flex flex-col items-center justify-center h-full text-[var(--text-muted)] gap-2 min-h-[200px]",
                  children: [
                    e.jsx("div", {
                      className: "w-12 h-12 bg-surfaceHighlight rounded-full flex items-center justify-center",
                      children: e.jsx(ft, {
                        className: "w-6 h-6 opacity-30"
                      })
                    }),
                    e.jsx("p", {
                      className: "text-sm",
                      children: "No contacts found"
                    }),
                    e.jsx("button", {
                      onClick: () => i("add"),
                      className: "text-xs text-primary font-bold hover:underline",
                      children: "Add New Contact"
                    })
                  ]
                }) : o.map((g) => e.jsxs("div", {
                  onClick: () => s == null ? void 0 : s(g.address),
                  className: `group bg-surface hover:bg-surfaceHighlight border border-border rounded-xl p-3 flex items-center justify-between transition-all ${s ? "cursor-pointer hover:border-primary/50" : ""}`,
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-3 overflow-hidden",
                      children: [
                        e.jsx("div", {
                          className: "w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0",
                          children: e.jsx("span", {
                            className: "font-bold text-xs",
                            children: g.name.substring(0, 2).toUpperCase()
                          })
                        }),
                        e.jsxs("div", {
                          className: "overflow-hidden",
                          children: [
                            e.jsx("p", {
                              className: "text-sm font-bold text-foreground truncate",
                              children: g.name
                            }),
                            e.jsx("p", {
                              className: "text-[10px] text-[var(--text-muted)] font-mono truncate w-32 md:w-48",
                              children: g.address
                            })
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        s && e.jsx("div", {
                          className: "w-6 h-6 rounded-full border border-border flex items-center justify-center group-hover:border-primary group-hover:bg-primary/10 transition-colors",
                          children: e.jsx(_t, {
                            className: "w-3 h-3 text-transparent group-hover:text-primary"
                          })
                        }),
                        !s && e.jsx("button", {
                          onClick: (S) => {
                            S.stopPropagation(), n(g.id);
                          },
                          className: "p-1.5 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100",
                          children: e.jsx(fs, {
                            className: "w-4 h-4"
                          })
                        })
                      ]
                    })
                  ]
                }, g.id))
              })
            ]
          }) : e.jsxs("form", {
            onSubmit: h,
            className: "p-4 space-y-4",
            children: [
              e.jsxs("div", {
                className: "space-y-2",
                children: [
                  e.jsx("label", {
                    className: "text-xs font-medium text-[var(--text-muted)]",
                    children: "Name"
                  }),
                  e.jsx("input", {
                    value: u,
                    onChange: (g) => x(g.target.value),
                    placeholder: "Alice",
                    className: "w-full bg-surface border border-border rounded-xl p-3 text-foreground text-sm focus:border-primary outline-none",
                    required: true
                  })
                ]
              }),
              e.jsxs("div", {
                className: "space-y-2",
                children: [
                  e.jsx("label", {
                    className: "text-xs font-medium text-[var(--text-muted)]",
                    children: "Address"
                  }),
                  e.jsx("input", {
                    value: v,
                    onChange: (g) => b(g.target.value),
                    placeholder: "lmn1...",
                    className: "w-full bg-surface border border-border rounded-xl p-3 text-foreground font-mono text-xs focus:border-primary outline-none",
                    required: true
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex gap-2 pt-2",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: () => i("list"),
                    className: "flex-1 py-2.5 rounded-xl font-bold text-foreground bg-surfaceHighlight hover:bg-border transition-colors text-xs",
                    children: "Cancel"
                  }),
                  e.jsx("button", {
                    type: "submit",
                    className: "flex-1 py-2.5 rounded-xl font-bold text-white bg-primary hover:bg-primary-hover transition-colors text-xs",
                    children: "Save Contact"
                  })
                ]
              })
            ]
          })
        ]
      })
    });
    return Qe.createPortal(y, document.body);
  };
  function Bt(t) {
    return {
      key: `${t.portId}:${t.channelId}`,
      chainId: t.chainId || t.channelId,
      chainLabel: t.label || "Other chain",
      addressPrefix: t.addressPrefix || t.prefixHints[0] || "",
      defaultRecipient: "",
      sourceChannel: t.channelId,
      sourcePort: t.portId,
      routeLabel: `${t.portId}/${t.channelId}`,
      expectedDestinationDenom: t.expectedDestinationDenom || "",
      expectedDestinationTracePath: t.expectedDestinationTracePath || "",
      expectedDestinationDisplayName: t.expectedDestinationDisplayName || ""
    };
  }
  function Vr(t) {
    return {
      key: t.key,
      chainId: t.chainId,
      chainLabel: t.chainLabel,
      addressPrefix: t.addressPrefix,
      defaultRecipient: t.defaultRecipient,
      sourceChannel: t.sourceChannel,
      sourcePort: t.sourcePort,
      routeLabel: t.routeLabel,
      expectedDestinationDenom: "",
      expectedDestinationTracePath: "",
      expectedDestinationDisplayName: ""
    };
  }
  function Oe(t) {
    return !Number.isFinite(t) || t <= 0 ? "0" : t.toFixed(6).replace(/\.?0+$/, "") || "0";
  }
  function Qr(t, s) {
    return String(t).startsWith("lumen") ? `https://winscan.winsnip.xyz/lumen-mainnet/transactions/${s}` : "";
  }
  async function Gr(t, s, r) {
    const a = String(t || "").replace(/\/+$/, ""), n = await fetch(`${a}/cosmos/bank/v1beta1/balances/${encodeURIComponent(s)}`);
    if (!n.ok) throw new Error("Failed to fetch balance");
    const l = await n.json(), d = (Array.isArray(l == null ? void 0 : l.balances) ? l.balances : []).find((c) => String((c == null ? void 0 : c.denom) || "").trim() === r);
    return parseFloat(String((d == null ? void 0 : d.amount) || "0")) / 1e6;
  }
  const Jr = ({ activeKeys: t, onBack: s }) => {
    const a = $t().state || null, n = (a == null ? void 0 : a.assetContext) || null, l = a == null ? void 0 : a.initialMode, { sendTransaction: i, ibcTransfer: d, isLoading: c, error: u, successHash: x, resetState: v } = Or(), [b, h] = m.useState(() => l === "ibc" && ((n == null ? void 0 : n.transferEnabled) ?? true) ? "ibc" : "same-chain"), [o, y] = m.useState(""), [g, S] = m.useState(""), [P, k] = m.useState(""), [C, N] = m.useState(false), [f, L] = m.useState(false), [j, w] = m.useState([]), [A, T] = m.useState(false), [B, E] = m.useState(null), [_, R] = m.useState(""), [K, Q] = m.useState(""), [re, X] = m.useState(""), [ne, $] = m.useState(0), [W, q] = m.useState(false), [Z, F] = m.useState(null), G = m.useRef(null), U = b === "ibc", se = (n == null ? void 0 : n.chainId) || "lumen", ae = (n == null ? void 0 : n.chainLabel) || "Lumen", p = (n == null ? void 0 : n.ownerAddress) || t.address, I = (n == null ? void 0 : n.addressPrefix) || it(p) || "lmn", z = (n == null ? void 0 : n.denom) || "ulmn", O = (n == null ? void 0 : n.displaySymbol) || "LMN", ue = (n == null ? void 0 : n.displayName) || "Lumen", xe = (n == null ? void 0 : n.restEndpoint) || Y.getInstance().getQuickRestEndpoint(), Ne = (n == null ? void 0 : n.rpcEndpoint) || "", oe = (n == null ? void 0 : n.feeDenom) || "ulmn", he = (n == null ? void 0 : n.minGasPrice) ?? 0, de = (n == null ? void 0 : n.isLocal) ?? true, ke = m.useMemo(() => ((n == null ? void 0 : n.transferTargets) || []).map((D) => Vr(D)), [
      n
    ]), be = n ? ke : j, Le = u || Z, Ce = !!Le && /account not linked on chain yet|not linked on chain|missing pqc key|pqc signature required/i.test(Le), pe = it(o), H = m.useMemo(() => be.find((D) => D.key === _) || null, [
      be,
      _
    ]), Jt = U ? (H == null ? void 0 : H.addressPrefix) ? `${H.addressPrefix}1...` : "address on the other chain" : `${I}1...`, Yt = `Amount (${O})`, Xt = U ? `Transfer ${O} To Other Chain` : `Send ${O}`, ht = x ? Qr(se, x) : "";
    m.useEffect(() => {
      let D = false;
      return (async () => {
        try {
          q(true);
          const ee = await Gr(xe, p, z);
          D || $(ee);
        } catch (ee) {
          D || console.error("Balance fetch error:", ee);
        } finally {
          D || q(false);
        }
      })(), () => {
        D = true;
      };
    }, [
      p,
      z,
      xe
    ]), m.useEffect(() => {
      if (!U || n || j.length > 0) return;
      let D = false;
      return (async () => {
        try {
          T(true), E(null);
          const ee = await Ft();
          if (D) return;
          const Pe = ee.map((ye) => Bt(ye));
          if (w(Pe), !Pe.length) {
            E("No route to another chain is available right now.");
            return;
          }
          Promise.allSettled(ee.map((ye) => ye.knownMeta ? Promise.resolve(ye) : Ys(ye))).then((ye) => {
            if (D) return;
            const ts = ye.map((Ue, Je) => Ue.status === "fulfilled" ? Bt(Ue.value) : Pe[Je]).sort((Ue, Je) => Ue.chainLabel.localeCompare(Je.chainLabel));
            w(ts);
          });
        } catch (ee) {
          D || (w([]), E((ee == null ? void 0 : ee.message) || "Failed to load destinations."));
        } finally {
          D || T(false);
        }
      })(), () => {
        D = true;
      };
    }, [
      n,
      j.length,
      U
    ]), m.useEffect(() => {
      if (!U) return;
      if (!be.length) {
        R("");
        return;
      }
      if (H) return;
      const D = [
        ...be
      ].sort((fe, ee) => {
        const Pe = fe.addressPrefix && fe.addressPrefix === pe ? 100 : 0;
        return (ee.addressPrefix && ee.addressPrefix === pe ? 100 : 0) - Pe || fe.chainLabel.localeCompare(ee.chainLabel);
      });
      R(D[0].key);
    }, [
      be,
      U,
      pe,
      H
    ]), m.useEffect(() => {
      if (!U || !H) {
        Q("");
        return;
      }
      let D = false;
      return (async () => {
        try {
          const ee = H.defaultRecipient || (H.addressPrefix ? await De.deriveAddressWithPrefix(t.mnemonic, H.addressPrefix) : "");
          if (D) return;
          Q(ee), ee && (!o || o === re || pe === I) && (y(ee), X(ee));
        } catch {
          D || Q("");
        }
      })(), () => {
        D = true;
      };
    }, [
      t.mnemonic,
      U,
      re,
      o,
      pe,
      H,
      I
    ]), m.useEffect(() => {
      n && l === "ibc" && n.transferEnabled && h("ibc");
    }, [
      n,
      l
    ]), m.useEffect(() => {
      !x || G.current === x || (ge.saveTransaction(t.address, {
        hash: x,
        height: "0",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        type: "send",
        amount: g,
        denom: O,
        counterparty: o,
        status: "success"
      }), G.current = x);
    }, [
      t.address,
      g,
      U,
      o,
      O,
      x
    ]);
    const pt = (D) => {
      h(D), F(null), v(), N(false), L(false), D === "ibc" && E(null), D === "same-chain" && o === re && y("");
    }, Zt = (D) => {
      D.preventDefault(), F(null);
      const fe = o.trim();
      if (!fe || !g) return;
      const ee = parseFloat(g);
      if (isNaN(ee) || ee <= 0) {
        F(`Enter a valid ${O} amount.`);
        return;
      }
      if (ee > ne) {
        F(`Insufficient balance. Maximum available: ${Oe(ne)} ${O}`);
        return;
      }
      if (U) {
        if (!H) {
          F(A ? "Destinations are still loading." : "Please select another chain.");
          return;
        }
        if (!Qs(fe)) {
          F("Invalid destination address format.");
          return;
        }
        if (pe === I) {
          F(`This looks like a ${I.toUpperCase()} address. Use same-chain send instead.`);
          return;
        }
        if (H.addressPrefix && pe && pe !== H.addressPrefix) {
          F(`Recipient must use the ${H.addressPrefix} address format for ${H.chainLabel}.`);
          return;
        }
      } else if (pe !== I) {
        F(`Recipient must use the ${I.toUpperCase()} address format.`);
        return;
      }
      N(true);
    }, es = async () => {
      try {
        const D = o.trim();
        if (U) {
          if (!H) throw new Error("Missing destination route.");
          await d(t, D, g, {
            memo: P,
            sourceChannel: H.sourceChannel,
            sourcePort: H.sourcePort,
            timeoutSeconds: 600,
            denom: z,
            useStandardTx: !de,
            fromAddress: p,
            addressPrefix: I,
            rpcEndpoint: Ne,
            feeDenom: oe,
            minGasPrice: he
          });
        } else await i(t, D, g, P, {
          denom: z,
          useStandardTx: !de,
          fromAddress: p,
          addressPrefix: I,
          rpcEndpoint: Ne,
          feeDenom: oe,
          minGasPrice: he
        });
        N(false);
      } catch {
        N(false);
      }
    };
    return x ? e.jsxs("div", {
      className: "flex flex-col h-full animate-fade-in p-6 items-center justify-center text-center space-y-6",
      children: [
        e.jsx("div", {
          className: "w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center text-green-500 mb-2",
          children: e.jsx("svg", {
            className: "w-10 h-10",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "currentColor",
            children: e.jsx("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: 2,
              d: "M5 13l4 4L19 7"
            })
          })
        }),
        e.jsx("h2", {
          className: "text-2xl font-bold text-foreground",
          children: U ? "Transfer Submitted!" : "Transaction Sent!"
        }),
        e.jsxs("div", {
          className: "bg-surface border border-border rounded-xl p-4 w-full break-all",
          children: [
            e.jsx("p", {
              className: "text-[10px] text-[var(--text-muted)] uppercase font-bold mb-1",
              children: "Tx Hash"
            }),
            ht ? e.jsx("a", {
              href: ht,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-xs font-mono text-primary hover:underline hover:text-primary-hover transition-all",
              children: x
            }) : e.jsx("p", {
              className: "text-xs font-mono text-primary",
              children: x
            })
          ]
        }),
        e.jsx("button", {
          onClick: () => {
            v(), G.current = null, y(""), S(""), k(""), s();
          },
          className: "w-full bg-surface border border-border hover:bg-surfaceHighlight text-foreground font-bold py-3.5 rounded-xl transition-all",
          children: "Back to Dashboard"
        })
      ]
    }) : e.jsxs("div", {
      className: "flex flex-col h-full min-h-0 animate-fade-in relative",
      children: [
        e.jsxs("header", {
          className: "flex items-center gap-4 p-4 border-b border-border",
          children: [
            e.jsx("button", {
              onClick: s,
              className: "p-2 -ml-2 text-[var(--text-muted)] hover:text-foreground transition-colors rounded-lg hover:bg-surfaceHighlight",
              children: e.jsx("svg", {
                className: "w-5 h-5",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: e.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M10 19l-7-7m0 0l7-7m-7 7h18"
                })
              })
            }),
            e.jsx("h2", {
              className: "text-lg font-bold text-foreground",
              children: Xt
            })
          ]
        }),
        e.jsxs("form", {
          onSubmit: Zt,
          className: "p-6 pb-24 space-y-6 flex-1 overflow-y-auto",
          children: [
            n && e.jsxs("div", {
              className: "rounded-2xl border border-border bg-surface p-4 space-y-2",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between gap-3",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx("p", {
                          className: "text-xs font-semibold text-foreground",
                          children: ue
                        }),
                        e.jsxs("p", {
                          className: "text-[11px] text-[var(--text-muted)]",
                          children: [
                            ae,
                            " \xB7 ",
                            O
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "text-right",
                      children: [
                        e.jsxs("p", {
                          className: "text-xs font-semibold text-foreground",
                          children: [
                            Oe(ne),
                            " ",
                            O
                          ]
                        }),
                        e.jsx("p", {
                          className: "text-[11px] text-[var(--text-muted)] font-mono",
                          children: p
                        })
                      ]
                    })
                  ]
                }),
                n.traceLabel && e.jsx("p", {
                  className: "text-[11px] text-[var(--text-muted)]",
                  children: n.traceLabel
                }),
                n.routeLabel && e.jsx("p", {
                  className: "text-[11px] text-[var(--text-muted)]",
                  children: n.routeLabel
                })
              ]
            }),
            e.jsxs("div", {
              className: "grid grid-cols-2 gap-2 rounded-2xl bg-surface p-1 border border-border",
              children: [
                e.jsx("button", {
                  type: "button",
                  onClick: () => pt("same-chain"),
                  className: `rounded-xl px-4 py-3 text-sm font-bold transition-all ${U ? "text-[var(--text-muted)] hover:text-foreground hover:bg-surfaceHighlight" : "bg-primary text-white shadow-lg shadow-primary/20"}`,
                  children: "Same-chain"
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => pt("ibc"),
                  disabled: n ? !n.transferEnabled : false,
                  className: `rounded-xl px-4 py-3 text-sm font-bold transition-all ${U ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-[var(--text-muted)] hover:text-foreground hover:bg-surfaceHighlight"} ${n && !n.transferEnabled ? "opacity-50 cursor-not-allowed" : ""}`,
                  children: "To Other Chain"
                })
              ]
            }),
            U && e.jsxs("div", {
              className: "space-y-3 rounded-2xl border border-border bg-surface p-4",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between gap-3",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-medium text-[var(--text-muted)]",
                      children: "Other Chain"
                    }),
                    H && e.jsx("span", {
                      className: "text-[10px] font-bold uppercase tracking-wide text-primary",
                      children: H.chainLabel
                    })
                  ]
                }),
                e.jsxs("select", {
                  value: _,
                  onChange: (D) => {
                    R(D.target.value), F(null);
                  },
                  className: "w-full bg-background border border-border rounded-xl p-4 text-foreground text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all",
                  disabled: A || !be.length,
                  children: [
                    e.jsx("option", {
                      value: "",
                      children: A ? "Loading destinations..." : "Select another chain"
                    }),
                    be.map((D) => e.jsx("option", {
                      value: D.key,
                      children: D.chainLabel
                    }, D.key))
                  ]
                }),
                H && e.jsxs("div", {
                  className: "rounded-xl border border-border/70 bg-background/60 p-3 space-y-2",
                  children: [
                    e.jsxs("p", {
                      className: "text-[11px] text-[var(--text-muted)]",
                      children: [
                        "Transfer route: ",
                        e.jsx("span", {
                          className: "font-mono text-foreground",
                          children: H.routeLabel
                        })
                      ]
                    }),
                    e.jsxs("p", {
                      className: "text-[11px] text-[var(--text-muted)]",
                      children: [
                        "Source chain: ",
                        e.jsx("span", {
                          className: "text-foreground font-semibold",
                          children: ae
                        })
                      ]
                    }),
                    e.jsxs("p", {
                      className: "text-[11px] text-[var(--text-muted)]",
                      children: [
                        "Destination: ",
                        e.jsx("span", {
                          className: "text-foreground font-semibold",
                          children: H.chainLabel
                        }),
                        H.addressPrefix ? ` \xB7 ${H.addressPrefix}1...` : ""
                      ]
                    }),
                    H.expectedDestinationDisplayName && e.jsxs("p", {
                      className: "text-[11px] text-[var(--text-muted)]",
                      children: [
                        "Recipient gets: ",
                        e.jsx("span", {
                          className: "text-foreground font-semibold",
                          children: H.expectedDestinationDisplayName
                        })
                      ]
                    }),
                    H.expectedDestinationDenom && e.jsxs("p", {
                      className: "text-[11px] text-[var(--text-muted)] break-all",
                      children: [
                        "Expected denom: ",
                        e.jsx("span", {
                          className: "font-mono text-foreground",
                          children: H.expectedDestinationDenom
                        }),
                        H.expectedDestinationTracePath ? ` (${H.expectedDestinationTracePath}/${z})` : ""
                      ]
                    }),
                    K && e.jsxs("div", {
                      className: "flex items-center justify-between gap-3 pt-1",
                      children: [
                        e.jsxs("p", {
                          className: "text-[11px] text-[var(--text-muted)] truncate",
                          children: [
                            "Your wallet on the other chain: ",
                            e.jsx("span", {
                              className: "font-mono text-foreground",
                              children: K
                            })
                          ]
                        }),
                        e.jsx("button", {
                          type: "button",
                          onClick: () => {
                            y(K), X(K), F(null);
                          },
                          className: "shrink-0 text-[10px] font-bold text-primary hover:text-primary-hover transition-colors",
                          children: "Use mine"
                        })
                      ]
                    })
                  ]
                }),
                B && e.jsx("div", {
                  className: "p-3 bg-red-500/10 border border-red-500/20 rounded-xl",
                  children: e.jsx("p", {
                    className: "text-red-500 text-xs",
                    children: B
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between ml-1",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-medium text-[var(--text-muted)]",
                      children: U ? "Recipient on Other Chain" : "Recipient Address"
                    }),
                    !U && de && e.jsxs("button", {
                      type: "button",
                      onClick: () => L(true),
                      className: "text-[10px] text-primary hover:text-primary-hover font-bold flex items-center gap-1 transition-colors",
                      children: [
                        e.jsx(gs, {
                          className: "w-3 h-3"
                        }),
                        "Contacts"
                      ]
                    })
                  ]
                }),
                e.jsx("input", {
                  type: "text",
                  value: o,
                  onChange: (D) => {
                    y(D.target.value), F(null);
                  },
                  placeholder: Jt,
                  className: "w-full bg-surface border border-border rounded-xl p-4 text-foreground text-sm font-mono focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-[var(--text-dim)]",
                  required: true
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsxs("div", {
                  className: "flex justify-between items-center ml-1",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-medium text-[var(--text-muted)]",
                      children: Yt
                    }),
                    e.jsxs("button", {
                      type: "button",
                      onClick: () => S(Oe(ne)),
                      className: "text-[10px] font-bold text-primary hover:text-primary-hover transition-colors flex items-center gap-1",
                      children: [
                        "MAX: ",
                        W ? "..." : Oe(ne)
                      ]
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "relative",
                  children: [
                    e.jsx("input", {
                      type: "number",
                      step: "0.000001",
                      value: g,
                      onChange: (D) => {
                        S(D.target.value), F(null);
                      },
                      placeholder: "0.00",
                      className: "w-full bg-surface border border-border rounded-xl p-4 text-foreground text-lg font-bold focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-[var(--text-dim)]",
                      required: true
                    }),
                    e.jsx("span", {
                      className: "absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-[var(--text-muted)]",
                      children: O
                    })
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsx("label", {
                  className: "text-xs font-medium text-[var(--text-muted)] ml-1",
                  children: "Memo (Optional)"
                }),
                e.jsx("input", {
                  type: "text",
                  value: P,
                  onChange: (D) => k(D.target.value),
                  placeholder: U ? "Tx memo / IBC packet memo..." : "Public note...",
                  className: "w-full bg-surface border border-border rounded-xl p-4 text-foreground text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-[var(--text-dim)]"
                })
              ]
            }),
            Le && e.jsxs("div", {
              className: "p-4 bg-red-500/10 border border-red-500/20 rounded-xl",
              children: [
                e.jsx("p", {
                  className: "text-red-500 text-xs",
                  children: Le
                }),
                Ce && e.jsxs("p", {
                  className: "mt-2 text-[11px] text-red-300 leading-relaxed",
                  children: [
                    "Hint: open wallet settings and tap ",
                    e.jsx("span", {
                      className: "font-semibold text-red-200",
                      children: "Link PQC Account"
                    }),
                    " to register your post-quantum-resistant keys on-chain, then retry."
                  ]
                })
              ]
            }),
            e.jsx("div", {
              className: "pt-4",
              children: e.jsx("button", {
                type: "submit",
                disabled: !o || !g || c || U && (!H || A),
                className: "w-full bg-primary hover:bg-primary-hover disabled:opacity-50 text-white font-bold py-3.5 rounded-xl transition-all",
                children: U ? `Review ${O} Transfer` : `Review ${O} Send`
              })
            })
          ]
        }),
        C && e.jsx("div", {
          className: "absolute inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in",
          children: e.jsxs("div", {
            className: "bg-surface/90 border border-border/50 rounded-[32px] w-full max-w-[340px] p-6 animate-zoom-in space-y-6 shadow-2xl shadow-black/40",
            children: [
              e.jsxs("div", {
                className: "flex flex-col items-center text-center space-y-2",
                children: [
                  e.jsx("div", {
                    className: "w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-2",
                    children: e.jsx("svg", {
                      className: "w-6 h-6",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      children: e.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"
                      })
                    })
                  }),
                  e.jsx("h3", {
                    className: "text-xl font-bold text-foreground",
                    children: U ? "Confirm Transfer To Other Chain" : "Confirm Send"
                  }),
                  e.jsx("p", {
                    className: "text-xs text-[var(--text-muted)]",
                    children: "Please review the details below"
                  })
                ]
              }),
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsxs("div", {
                    className: "bg-primary/5 p-4 rounded-2xl border border-primary/10 space-y-1 text-center",
                    children: [
                      e.jsx("p", {
                        className: "text-[10px] text-primary/60 uppercase font-black tracking-widest",
                        children: "Amount to Send"
                      }),
                      e.jsxs("p", {
                        className: "text-3xl font-black text-primary",
                        children: [
                          g,
                          " ",
                          e.jsx("span", {
                            className: "text-sm font-bold opacity-70",
                            children: O
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "bg-surfaceHighlight/50 p-4 rounded-2xl border border-border/30 space-y-3",
                    children: [
                      e.jsxs("div", {
                        className: "space-y-1.5 text-center",
                        children: [
                          e.jsx("p", {
                            className: "text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-wider",
                            children: "Source Chain"
                          }),
                          e.jsx("p", {
                            className: "text-xs text-foreground",
                            children: ae
                          })
                        ]
                      }),
                      U && H && e.jsxs("div", {
                        className: "space-y-1.5 text-center",
                        children: [
                          e.jsx("p", {
                            className: "text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-wider",
                            children: "Transfer Route"
                          }),
                          e.jsxs("p", {
                            className: "text-xs text-foreground",
                            children: [
                              H.routeLabel,
                              " \u2192 ",
                              H.chainLabel
                            ]
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "space-y-1.5 text-center",
                        children: [
                          e.jsx("p", {
                            className: "text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-wider",
                            children: "Recipient Address"
                          }),
                          e.jsx("p", {
                            className: "text-[11px] font-mono text-foreground break-all leading-tight px-2",
                            children: o
                          })
                        ]
                      }),
                      P && e.jsxs("div", {
                        className: "pt-3 border-t border-border/10 space-y-1 text-center",
                        children: [
                          e.jsx("p", {
                            className: "text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-wider",
                            children: "Memo"
                          }),
                          e.jsxs("p", {
                            className: "text-xs text-foreground italic",
                            children: [
                              '"',
                              P,
                              '"'
                            ]
                          })
                        ]
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex flex-col gap-3",
                children: [
                  e.jsx("button", {
                    onClick: es,
                    disabled: c,
                    className: "w-full py-4 rounded-2xl font-bold text-white bg-primary hover:bg-primary-hover active:scale-[0.98] transition-all text-sm flex items-center justify-center gap-2 shadow-lg shadow-primary/20",
                    children: c ? e.jsx("span", {
                      className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"
                    }) : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx("svg", {
                          className: "w-4 h-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                          })
                        }),
                        U ? "Sign & Transfer" : "Sign & Send"
                      ]
                    })
                  }),
                  e.jsx("button", {
                    onClick: () => N(false),
                    className: "w-full py-3.5 rounded-2xl font-bold text-[var(--text-muted)] hover:text-foreground hover:bg-surfaceHighlight transition-all text-sm bg-transparent",
                    children: "Cancel"
                  })
                ]
              })
            ]
          })
        }),
        f && e.jsx(Fr, {
          onClose: () => L(false),
          onSelect: (D) => {
            y(D), L(false);
          }
        })
      ]
    });
  }, Yr = (t) => {
    try {
      return `${new URL(t).origin}/*`;
    } catch {
      return null;
    }
  };
  function Xr({ onClose: t }) {
    const [s, r] = m.useState([]), [a, n] = m.useState(0), [l, i] = m.useState(""), [d, c] = m.useState(true), [u, x] = m.useState(false), [v, b] = m.useState(null), h = "activeWalletAddress";
    m.useEffect(() => {
      o();
    }, []), m.useEffect(() => {
      const E = (_, R) => {
        if (R !== "local" || !_.pendingApprovalQueue) return;
        const K = _.pendingApprovalQueue.newValue, Q = Array.isArray(K) ? K : [];
        r(Q);
      };
      return chrome.storage.onChanged.addListener(E), () => chrome.storage.onChanged.removeListener(E);
    }, []), m.useEffect(() => {
      a >= s.length && s.length > 0 && n(s.length - 1);
    }, [
      a,
      s.length
    ]), m.useEffect(() => {
      s.length > 0 && y();
    }, [
      s.length
    ]);
    const o = async () => {
      try {
        const E = await chrome.storage.local.get("pendingApprovalQueue"), _ = Array.isArray(E.pendingApprovalQueue) ? E.pendingApprovalQueue : [];
        _.length > 0 ? (r(_), await y()) : c(false);
      } catch (E) {
        console.error("[ApprovalModal] Error checking pending request:", E), c(false);
      }
    }, y = async () => {
      try {
        if (!await V.hasWallet()) {
          c(false);
          return;
        }
        if (await V.isSessionExpired()) {
          x(true), c(false);
          return;
        }
        const R = await V.getWallets();
        if (R && R.length > 0) {
          const K = await chrome.storage.local.get(h), Q = R.find((re) => re.address === K.activeWalletAddress) || R[0];
          i(Q.address);
        }
      } catch (E) {
        console.error("[ApprovalModal] Failed to load wallet:", E);
      } finally {
        c(false);
      }
    }, g = s[a] || null, S = s.length, P = async () => {
      if (!g) return;
      if (b(null), g.type === "approval-request" && chrome.permissions) {
        const _ = Yr(g.origin);
        if (_ && !await chrome.permissions.contains({
          origins: [
            _
          ]
        }) && !await chrome.permissions.request({
          origins: [
            _
          ]
        })) {
          b("Site permission denied.");
          return;
        }
      }
      chrome.runtime.sendMessage({
        type: "user-response",
        requestId: g.requestId,
        approved: true
      });
      const E = s.filter((_, R) => R !== a);
      r(E), E.length === 0 ? (t(), setTimeout(() => {
        window.close();
      }, 50)) : a >= E.length && n(E.length - 1);
    }, k = () => {
      if (!g) return;
      chrome.runtime.sendMessage({
        type: "user-response",
        requestId: g.requestId,
        approved: false
      });
      const E = s.filter((_, R) => R !== a);
      r(E), E.length === 0 ? (t(), setTimeout(() => {
        window.close();
      }, 50)) : a >= E.length && n(E.length - 1);
    }, C = () => {
      navigator.clipboard.writeText(l);
    }, N = () => {
      a > 0 && n(a - 1);
    }, f = () => {
      a < S - 1 && n(a + 1);
    };
    if (!d && !g) return t(), null;
    let L = (g == null ? void 0 : g.origin) || "";
    try {
      (g == null ? void 0 : g.origin) && (L = new URL(g.origin).hostname);
    } catch {
    }
    const j = (g == null ? void 0 : g.type) === "transaction-request", w = (g == null ? void 0 : g.params) || {}, A = w.msgs || w.messages || [], B = j ? (() => {
      var _a2, _b, _c, _d;
      if (!A || A.length === 0) return null;
      const E = A[0], _ = E.typeUrl || E.type || "Transaction", R = E.value || E;
      return {
        type: _.split(".").pop().replace("Msg", ""),
        to: R.toAddress || R.to_address || "-",
        amount: R.amount ? Array.isArray(R.amount) ? `${(_a2 = R.amount[0]) == null ? void 0 : _a2.amount} ${(_b = R.amount[0]) == null ? void 0 : _b.denom}` : `${(_c = R.amount) == null ? void 0 : _c.amount} ${(_d = R.amount) == null ? void 0 : _d.denom}` : "-"
      };
    })() : null;
    return e.jsxs("div", {
      className: "fixed inset-0 z-50 flex items-center justify-center",
      children: [
        e.jsx("div", {
          className: "absolute inset-0 bg-black/80 backdrop-blur-sm",
          onClick: k
        }),
        e.jsx("div", {
          className: "relative bg-surface rounded-2xl w-full max-w-sm mx-4 shadow-2xl border border-border overflow-hidden animate-in fade-in zoom-in duration-200",
          children: d ? e.jsx("div", {
            className: "p-8 flex items-center justify-center",
            children: e.jsxs("div", {
              className: "text-center",
              children: [
                e.jsx("div", {
                  className: "animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-3"
                }),
                e.jsx("p", {
                  className: "text-sm text-gray-500",
                  children: "Loading..."
                })
              ]
            })
          }) : u ? e.jsxs("div", {
            className: "p-6 text-center",
            children: [
              e.jsx("div", {
                className: "w-16 h-16 mx-auto mb-4 rounded-full bg-yellow-500/20 flex items-center justify-center",
                children: e.jsx("svg", {
                  className: "w-8 h-8 text-yellow-500",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                  })
                })
              }),
              e.jsx("h3", {
                className: "text-lg font-bold text-foreground mb-2",
                children: "Wallet Locked"
              }),
              e.jsx("p", {
                className: "text-sm text-gray-500 mb-4",
                children: "Please unlock your wallet first to approve this connection."
              }),
              e.jsx("button", {
                onClick: k,
                className: "w-full py-2 px-4 bg-surfaceHighlight text-foreground rounded-lg hover:bg-surfaceHighlight/80",
                children: "Close"
              })
            ]
          }) : e.jsxs(e.Fragment, {
            children: [
              e.jsx("div", {
                className: "p-5 border-b border-border",
                children: e.jsxs("div", {
                  className: "flex items-center gap-3",
                  children: [
                    e.jsx("div", {
                      className: "w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center",
                      children: e.jsx("svg", {
                        className: "w-6 h-6 text-white",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                        })
                      })
                    }),
                    e.jsxs("div", {
                      className: "flex-1",
                      children: [
                        e.jsx("h2", {
                          className: "text-lg font-bold text-foreground",
                          children: j ? "Sign Transaction" : "Connect Request"
                        }),
                        e.jsx("p", {
                          className: "text-sm text-gray-500 truncate max-w-[200px]",
                          title: L,
                          children: L
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex flex-col items-end gap-1 text-[11px] text-gray-400",
                      children: [
                        e.jsx("span", {
                          className: "font-semibold text-foreground",
                          children: S > 0 ? `${a + 1}/${S}` : "0/0"
                        }),
                        e.jsxs("div", {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsx("button", {
                              onClick: N,
                              disabled: a === 0,
                              className: "px-2 py-1 rounded-md border border-border text-[10px] font-semibold disabled:opacity-40 hover:bg-surfaceHighlight",
                              children: "Prev"
                            }),
                            e.jsx("button", {
                              onClick: f,
                              disabled: a >= S - 1,
                              className: "px-2 py-1 rounded-md border border-border text-[10px] font-semibold disabled:opacity-40 hover:bg-surfaceHighlight",
                              children: "Next"
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              }),
              v && e.jsx("div", {
                className: "px-5 pt-4",
                children: e.jsx("div", {
                  className: "text-xs text-red-500 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2",
                  children: v
                })
              }),
              e.jsxs("div", {
                className: "p-5 space-y-4 max-h-72 overflow-y-auto",
                children: [
                  j ? e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      B ? e.jsxs("div", {
                        className: "bg-surfaceHighlight/50 rounded-xl p-4 space-y-3",
                        children: [
                          e.jsxs("div", {
                            className: "flex justify-between items-center pb-2 border-b border-white/5",
                            children: [
                              e.jsx("span", {
                                className: "text-xs text-[var(--text-muted)]",
                                children: "Type"
                              }),
                              e.jsx("span", {
                                className: "text-sm font-bold text-primary",
                                children: B.type
                              })
                            ]
                          }),
                          e.jsxs("div", {
                            className: "space-y-1",
                            children: [
                              e.jsx("span", {
                                className: "text-xs text-[var(--text-muted)] block",
                                children: "To"
                              }),
                              e.jsx("div", {
                                className: "text-xs font-mono text-foreground break-all",
                                children: B.to
                              })
                            ]
                          }),
                          e.jsxs("div", {
                            className: "space-y-1 pt-1",
                            children: [
                              e.jsx("span", {
                                className: "text-xs text-[var(--text-muted)] block",
                                children: "Amount"
                              }),
                              e.jsx("div", {
                                className: "text-sm font-bold text-foreground",
                                children: B.amount
                              })
                            ]
                          })
                        ]
                      }) : e.jsx("div", {
                        className: "text-xs text-[var(--text-muted)] text-center italic",
                        children: "Detailed preview not available for this message type."
                      }),
                      e.jsx("div", {
                        className: "bg-black/20 rounded-lg p-3",
                        children: e.jsxs("details", {
                          className: "text-xs",
                          children: [
                            e.jsx("summary", {
                              className: "cursor-pointer text-[var(--text-dim)] hover:text-primary transition-colors",
                              children: "View Raw Data"
                            }),
                            e.jsx("pre", {
                              className: "mt-2 text-[10px] text-gray-400 overflow-x-auto whitespace-pre-wrap font-mono",
                              children: JSON.stringify(A, null, 2)
                            })
                          ]
                        })
                      })
                    ]
                  }) : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("div", {
                        className: "text-sm text-center text-[var(--text-dim)]",
                        children: "This site is requesting your permission to:"
                      }),
                      e.jsxs("div", {
                        className: "bg-surfaceHighlight rounded-xl p-4",
                        children: [
                          e.jsx("h3", {
                            className: "text-xs font-semibold text-gray-500 uppercase mb-2",
                            children: "Permissions"
                          }),
                          e.jsx("ul", {
                            className: "space-y-2",
                            children: ((g == null ? void 0 : g.permissions) ?? []).map((E, _) => e.jsxs("li", {
                              className: "flex items-center gap-2 text-sm text-foreground",
                              children: [
                                e.jsx("svg", {
                                  className: "w-4 h-4 text-green-500 shrink-0",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  children: e.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M5 13l4 4L19 7"
                                  })
                                }),
                                e.jsx("span", {
                                  children: E
                                })
                              ]
                            }, _))
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "rounded-xl border border-border bg-surfaceHighlight/70 p-3 text-xs text-[var(--text-muted)]",
                        children: [
                          e.jsx("div", {
                            className: "font-semibold text-foreground mb-1",
                            children: "Network access required"
                          }),
                          "Chrome may ask to allow network access to Lumen RPC/REST endpoints. If denied, the connection will fail."
                        ]
                      })
                    ]
                  }),
                  l && e.jsxs("div", {
                    className: "bg-surfaceHighlight rounded-xl p-4",
                    children: [
                      e.jsx("h3", {
                        className: "text-xs font-semibold text-gray-500 uppercase mb-2",
                        children: "Your Wallet"
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsxs("div", {
                            className: "flex-1 font-mono text-sm text-gray-400 truncate",
                            children: [
                              l.slice(0, 10),
                              "...",
                              l.slice(-6)
                            ]
                          }),
                          e.jsx("button", {
                            onClick: C,
                            className: "p-1.5 hover:bg-surface rounded-lg transition-colors",
                            children: e.jsx("svg", {
                              className: "w-4 h-4 text-gray-400",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: e.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                              })
                            })
                          })
                        ]
                      })
                    ]
                  }),
                  !j && e.jsxs("div", {
                    className: "flex items-start gap-2 p-3 bg-yellow-500/10 rounded-lg",
                    children: [
                      e.jsx("svg", {
                        className: "w-4 h-4 text-yellow-500 shrink-0 mt-0.5",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        children: e.jsx("path", {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                        })
                      }),
                      e.jsx("p", {
                        className: "text-xs text-yellow-500",
                        children: "Only connect with sites you trust."
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "p-4 pt-0 flex gap-3",
                children: [
                  e.jsx("button", {
                    onClick: k,
                    className: "flex-1 py-3 px-4 border border-red-500/50 text-red-400 rounded-xl font-semibold hover:bg-red-500/10 transition-colors",
                    children: "Reject"
                  }),
                  e.jsx("button", {
                    onClick: P,
                    className: "flex-1 py-3 px-4 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors",
                    children: j ? "Sign" : "Connect"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  const Zr = [
    {
      id: "beezee-lmn-usdc",
      venue: "BeeZee DEX",
      title: "LMN / USDC",
      subtitle: "Open the BeeZee market page for LMN against USDC.",
      url: "https://dex.getbze.com/exchange/market?id=ibc/693DDB2D9B4260D67C8136C22D837F37488E0FBD81857D8E9C6022332EA26E33/ibc/6490A7EAB61059BFC1CDDEB05917DD70BDF3A611654162A1A47DB930D40D8AF4"
    }
  ];
  function en(t) {
    var _a2;
    const s = globalThis.chrome;
    if ((_a2 = s == null ? void 0 : s.tabs) == null ? void 0 : _a2.create) {
      s.tabs.create({
        url: t
      });
      return;
    }
    globalThis.open(t, "_blank", "noopener,noreferrer");
  }
  const tn = (t) => e.jsxs("div", {
    className: "flex flex-col h-full min-h-0 animate-fade-in",
    children: [
      e.jsx("header", {
        className: "flex items-center justify-between gap-4 p-4 border-b border-border",
        children: e.jsxs("div", {
          children: [
            e.jsx("h2", {
              className: "text-lg font-bold text-foreground",
              children: "Trade"
            }),
            e.jsx("p", {
              className: "text-[11px] text-[var(--text-muted)]",
              children: "Open supported markets in an external tab."
            })
          ]
        })
      }),
      e.jsx("div", {
        className: "flex-1 overflow-y-auto p-6 pb-24 space-y-4",
        children: Zr.map((s) => e.jsxs("div", {
          className: "rounded-2xl border border-border bg-surface p-4 space-y-4",
          children: [
            e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsx("div", {
                  className: "inline-flex items-center gap-2 rounded-full border border-border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-primary",
                  children: s.venue
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("h3", {
                      className: "text-xl font-black text-foreground tracking-tight",
                      children: s.title
                    }),
                    e.jsx("p", {
                      className: "text-[11px] text-[var(--text-muted)]",
                      children: s.subtitle
                    })
                  ]
                })
              ]
            }),
            e.jsxs("button", {
              onClick: () => en(s.url),
              className: "inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-primary-hover",
              children: [
                "Open Market",
                e.jsx(rt, {
                  className: "w-4 h-4"
                })
              ]
            })
          ]
        }, s.id))
      })
    ]
  }), we = globalThis.chrome, Tt = !!((_a = we == null ? void 0 : we.runtime) == null ? void 0 : _a.id);
  function sn() {
    var _a2, _b;
    const t = lt(), s = $t(), [r, a] = m.useState([]), [n, l] = m.useState(0), i = r[n] || null, [d, c] = m.useState(false), [u, x] = m.useState(false), [v, b] = m.useState(true), [h, o] = m.useState(false), [y, g] = m.useState(null), S = m.useRef(d), [P, k] = m.useState(0), C = "pendingApprovalQueue";
    m.useEffect(() => {
      S.current = d;
    }, [
      d
    ]);
    const [N, f] = m.useState(null), [L, j] = m.useState(false), [w, A] = m.useState(() => localStorage.getItem("theme") || "dark");
    m.useEffect(() => {
      document.documentElement.setAttribute("data-theme", w), localStorage.setItem("theme", w);
    }, [
      w
    ]);
    const T = () => {
      A(($) => $ === "dark" ? "light" : "dark");
    };
    m.useEffect(() => {
      var _a3;
      if (r.length > 0 && r[n]) {
        const $ = r[n].address;
        localStorage.setItem("lastActiveWalletAddress", $), Tt && ((_a3 = we == null ? void 0 : we.runtime) == null ? void 0 : _a3.sendMessage) && we.runtime.sendMessage({
          type: "sync-active-wallet",
          address: $
        }).catch(() => {
        });
      }
    }, [
      n,
      r
    ]);
    const B = async () => {
      var _a3;
      if (!((_a3 = we == null ? void 0 : we.storage) == null ? void 0 : _a3.local)) return k(0), [];
      const $ = await we.storage.local.get(C), W = Array.isArray($.pendingApprovalQueue) ? $.pendingApprovalQueue : [];
      return k(W.length), W;
    };
    m.useEffect(() => {
      var _a3;
      (async () => {
        try {
          (await B()).length > 0 ? await V.isSessionExpired() || o(true) : o(false);
        } catch {
        }
        const F = await V.hasWallet();
        if (x(F), F) try {
          const G = await V.getWallets();
          if (G && G.length > 0) {
            a(G), c(false);
            const U = localStorage.getItem("lastActiveWalletAddress"), se = G.findIndex((ae) => ae.address === U);
            se !== -1 && l(se), (s.pathname === "/" || s.pathname === "/onboarding") && t("/dashboard");
          } else c(true), s.pathname === "/onboarding" && t("/");
        } catch {
          c(true), s.pathname === "/onboarding" && t("/");
        }
        else {
          if (c(false), window.innerWidth < 400 && (s.pathname === "/onboarding" || s.pathname === "/")) {
            Pt("/wallet/create"), window.close();
            return;
          }
          (s.pathname === "/onboarding" || s.pathname === "/") && t("/wallet/create");
        }
        b(false);
      })();
      const W = (F, G) => {
        if (G !== "local" || !F.pendingApprovalQueue) return;
        const U = F.pendingApprovalQueue.newValue, se = Array.isArray(U) ? U : [];
        k(se.length), se.length > 0 && !S.current && (o(true), s.pathname !== "/dashboard" && t("/dashboard")), se.length === 0 && o(false);
      }, q = (_a3 = we == null ? void 0 : we.storage) == null ? void 0 : _a3.onChanged;
      q && q.addListener(W);
      const Z = setInterval(async () => {
        const F = await V.hasWallet();
        if (x(F), !F || S.current) return;
        await V.isSessionExpired() && R();
      }, 5e3);
      return () => {
        clearInterval(Z), q && q.removeListener(W);
      };
    }, []);
    const E = async ($) => {
      var _a3;
      try {
        Tt && ((_a3 = we == null ? void 0 : we.runtime) == null ? void 0 : _a3.sendMessage) && we.runtime.sendMessage({
          type: "sync-session",
          password: $
        }).catch(() => {
        });
        const W = await V.unlock($);
        a(W), x(true);
        const q = localStorage.getItem("lastActiveWalletAddress"), Z = W.findIndex((G) => G.address === q);
        Z !== -1 && l(Z), c(false), g(null), (await B()).length > 0 && o(true), t("/dashboard");
      } catch (W) {
        g((W == null ? void 0 : W.message) || "Incorrect password.");
      }
    }, _ = async () => {
      try {
        const $ = await V.getWallets();
        if (x(true), $.length > r.length && r.length > 0) l($.length - 1);
        else {
          const W = localStorage.getItem("lastActiveWalletAddress"), q = $.findIndex((Z) => Z.address === W);
          q !== -1 && l(q);
        }
        a($), c(false), t("/dashboard");
      } catch ($) {
        console.error("Wallet ready failed:", $), c(true);
      }
    }, R = async () => {
      await V.clearSession(), c(true), t("/");
    }, K = async ($) => {
      try {
        const W = r.findIndex((Z) => Z.address === $), q = await V.removeWallet($);
        a(q), q.length === 0 ? t("/") : n === W ? l(0) : n > W && l(n - 1);
      } catch (W) {
        console.error("Failed to delete wallet:", W);
      }
    }, Q = async ($, W) => {
      try {
        const q = [
          ...r
        ];
        q[$] = {
          ...q[$],
          pqcKey: {
            ...q[$].pqcKey,
            name: W
          },
          pqc: {
            ...q[$].pqc,
            name: W
          }
        }, await V.saveWallets(q), a(q);
      } catch (q) {
        console.error("Failed to rename wallet:", q);
      }
    }, re = async ($) => {
      try {
        const W = await V.getWallets(), q = W.findIndex((Z) => Z.address === $.address);
        if (q === -1) return;
        W[q] = {
          ...W[q],
          ...$
        }, await V.saveWallets(W), a(W);
      } catch (W) {
        console.error("Failed to update wallet in vault:", W);
      }
    }, X = async () => {
      i && !d && await V.touchSession();
    };
    return v ? e.jsx("div", {
      className: "h-full flex items-center justify-center bg-background text-primary",
      children: "Loading..."
    }) : (s.pathname.includes("/wallet/create") || s.pathname === "/onboarding") && r.length === 0 && !u ? e.jsx("div", {
      className: "bg-background text-foreground font-sans w-screen h-screen overflow-y-auto",
      onClick: X,
      children: e.jsx("main", {
        className: "w-full min-h-full flex flex-col",
        children: e.jsxs(gt, {
          children: [
            e.jsx(le, {
              path: "/wallet/create",
              element: e.jsx(et, {
                onWalletReady: _,
                activeKeys: null,
                isAdding: r.length > 0 || u,
                onCancel: () => t("/dashboard"),
                showLinkModal: false,
                onCloseLinkModal: () => {
                }
              })
            }),
            e.jsx(le, {
              path: "*",
              element: e.jsx(me, {
                to: "/wallet/create"
              })
            })
          ]
        })
      })
    }) : e.jsxs("div", {
      className: "bg-background text-foreground font-sans overflow-hidden flex flex-col h-full w-full max-w-md mx-auto",
      onClick: X,
      onKeyDown: X,
      onMouseMove: X,
      children: [
        !d && i && e.jsxs("header", {
          className: "h-16 premium-header flex items-center px-5 justify-between backdrop-blur-xl z-10 shrink-0",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2.5",
              children: [
                e.jsx("img", {
                  src: "/icons/logo.png",
                  alt: "Lumen",
                  className: "w-8 h-8 object-contain drop-shadow-[0_0_12px_rgba(99,102,241,0.4)] animate-pulse-slow"
                }),
                e.jsx("span", {
                  className: "font-bold text-foreground text-lg tracking-tight",
                  children: "Lumen"
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                e.jsx("button", {
                  onClick: T,
                  className: "p-2 rounded-full hover:bg-surfaceHighlight text-gray-500 hover:text-foreground transition-colors",
                  title: `Switch to ${w === "dark" ? "Light" : "Dark"} Mode`,
                  children: w === "dark" ? e.jsx("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                    })
                  }) : e.jsx("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                    })
                  })
                }),
                e.jsx(pr, {
                  wallets: r,
                  activeWalletIndex: n,
                  activeWalletName: ((_a2 = i.pqcKey) == null ? void 0 : _a2.name) || ((_b = i.pqc) == null ? void 0 : _b.name) || "Wallet",
                  onSwitch: ($) => {
                    l($), t("/dashboard");
                  },
                  onAdd: () => Pt("/wallet/create"),
                  onLock: R,
                  onSettings: () => t("/settings"),
                  onRename: Q,
                  onBackup: ($) => f($),
                  onLinkPqc: () => j(true),
                  onDelete: K
                })
              ]
            })
          ]
        }),
        N !== null && e.jsx(gr, {
          wallet: r[N],
          onClose: () => f(null)
        }),
        !d && i && L && e.jsx("div", {
          className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in",
          children: e.jsxs("div", {
            className: "w-full max-w-sm bg-surface border border-border rounded-xl relative",
            children: [
              e.jsx("button", {
                onClick: () => j(false),
                className: "absolute top-2 right-2 p-1 text-[var(--text-muted)] hover:text-foreground rounded-full hover:bg-white/5 transition-colors z-10",
                children: e.jsx("svg", {
                  className: "w-5 h-5",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M6 18L18 6M6 6l12 12"
                  })
                })
              }),
              e.jsx("div", {
                className: "p-4 pt-8",
                children: e.jsx(Ut, {
                  wallet: i,
                  onWalletUpdate: re,
                  isModal: true,
                  onClose: () => j(false)
                })
              })
            ]
          })
        }),
        e.jsxs("main", {
          className: "flex flex-1 min-h-0 flex-col overflow-hidden relative",
          children: [
            !d && P > 0 && e.jsx("div", {
              className: "mx-4 mt-3 rounded-2xl border border-border bg-surfaceHighlight/80 p-3 text-xs text-[var(--text-muted)]",
              children: e.jsx("div", {
                className: "flex items-center justify-between gap-3",
                children: e.jsxs("div", {
                  children: [
                    e.jsx("div", {
                      className: "font-semibold text-foreground",
                      children: "Pending requests"
                    }),
                    e.jsxs("div", {
                      children: [
                        P,
                        " waiting for your approval."
                      ]
                    })
                  ]
                })
              })
            }),
            e.jsx("div", {
              className: "flex-1 min-h-0",
              children: e.jsxs(gt, {
                children: [
                  e.jsx(le, {
                    path: "/",
                    element: d ? e.jsx("div", {
                      className: "h-full",
                      children: e.jsx(hr, {
                        onUnlock: E,
                        error: y
                      })
                    }) : r.length > 0 ? e.jsx(me, {
                      to: "/dashboard"
                    }) : e.jsx(me, {
                      to: "/wallet/create"
                    })
                  }),
                  e.jsx(le, {
                    path: "/dashboard",
                    element: i ? e.jsx(et, {
                      onWalletReady: _,
                      activeKeys: i,
                      isAdding: r.length > 0 || u,
                      onCancel: () => {
                      },
                      showLinkModal: false,
                      onCloseLinkModal: () => j(false)
                    }) : e.jsx(me, {
                      to: "/"
                    })
                  }),
                  e.jsx(le, {
                    path: "/wallet/create",
                    element: e.jsx("div", {
                      className: "h-full",
                      children: d && u ? e.jsx(me, {
                        to: "/"
                      }) : e.jsx(et, {
                        onWalletReady: _,
                        activeKeys: null,
                        isAdding: r.length > 0 || u,
                        onCancel: () => t("/dashboard"),
                        showLinkModal: false,
                        onCloseLinkModal: () => {
                        }
                      })
                    })
                  }),
                  e.jsx(le, {
                    path: "/trade",
                    element: i ? e.jsx(tn, {
                      walletKeys: i
                    }) : e.jsx(me, {
                      to: "/"
                    })
                  }),
                  e.jsx(le, {
                    path: "/swap",
                    element: e.jsx(me, {
                      to: "/trade",
                      replace: true
                    })
                  }),
                  e.jsx(le, {
                    path: "/send",
                    element: i ? e.jsx(Jr, {
                      activeKeys: i,
                      onBack: () => t("/dashboard")
                    }) : e.jsx(me, {
                      to: "/"
                    })
                  }),
                  e.jsx(le, {
                    path: "/stake",
                    element: i ? e.jsx(Cr, {
                      walletKeys: i,
                      onBack: () => t("/dashboard")
                    }) : e.jsx(me, {
                      to: "/"
                    })
                  }),
                  e.jsx(le, {
                    path: "/governance",
                    element: i ? e.jsx(Er, {
                      walletKeys: i,
                      onBack: () => t("/dashboard")
                    }) : e.jsx(me, {
                      to: "/"
                    })
                  }),
                  e.jsx(le, {
                    path: "/settings",
                    element: e.jsx(fr, {
                      onBack: () => t("/dashboard")
                    })
                  }),
                  e.jsx(le, {
                    path: "*",
                    element: e.jsx(me, {
                      to: "/"
                    })
                  })
                ]
              })
            })
          ]
        }),
        !d && i && s.pathname !== "/settings" && s.pathname !== "/wallet/create" && e.jsxs("footer", {
          className: "h-16 bg-surface/80 backdrop-blur-xl border-t border-border flex items-center justify-around px-2 z-10 shrink-0",
          children: [
            e.jsxs("button", {
              onClick: () => t("/dashboard"),
              className: `flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${s.pathname === "/dashboard" ? "text-primary scale-110" : "text-gray-500 hover:text-gray-300 hover:scale-105"} `,
              children: [
                e.jsx("svg", {
                  className: "w-6 h-6",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                  })
                }),
                e.jsx("span", {
                  className: "text-[10px] font-semibold",
                  children: "Wallet"
                })
              ]
            }),
            e.jsxs("button", {
              onClick: () => t("/trade"),
              className: `flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${s.pathname === "/trade" || s.pathname === "/swap" ? "text-primary scale-110" : "text-gray-500 hover:text-gray-300 hover:scale-105"} `,
              children: [
                e.jsx("svg", {
                  className: "w-6 h-6",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"
                  })
                }),
                e.jsx("span", {
                  className: "text-[10px] font-semibold",
                  children: "Trade"
                })
              ]
            }),
            e.jsxs("button", {
              disabled: true,
              className: "flex flex-col items-center gap-1 p-2 rounded-xl transition-all text-gray-700/50 cursor-not-allowed opacity-40",
              children: [
                e.jsx("svg", {
                  className: "w-6 h-6",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor",
                  children: e.jsx("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                  })
                }),
                e.jsx("span", {
                  className: "text-[10px] font-semibold",
                  children: "Bridge"
                })
              ]
            })
          ]
        }),
        (h || !d && P > 0) && e.jsx(Xr, {
          onClose: () => {
            o(false);
          }
        })
      ]
    });
  }
  class rn extends m.Component {
    constructor() {
      super(...arguments);
      __publicField(this, "state", {
        hasError: false,
        error: null,
        errorInfo: null
      });
    }
    static getDerivedStateFromError(s) {
      return {
        hasError: true,
        error: s,
        errorInfo: null
      };
    }
    componentDidCatch(s, r) {
      console.error("Uncaught error:", s, r), this.setState({
        error: s,
        errorInfo: r
      });
    }
    render() {
      return this.state.hasError ? e.jsxs("div", {
        className: "p-4 bg-gray-900 text-white h-screen overflow-auto",
        children: [
          e.jsx("h1", {
            className: "text-xl font-bold text-red-500 mb-2",
            children: "Something went wrong."
          }),
          e.jsxs("pre", {
            className: "text-xs bg-black p-2 rounded border border-gray-700 whitespace-pre-wrap",
            children: [
              this.state.error && this.state.error.toString(),
              e.jsx("br", {}),
              this.state.errorInfo && this.state.errorInfo.componentStack
            ]
          }),
          e.jsx("button", {
            onClick: () => window.location.reload(),
            className: "mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700",
            children: "Reload Extension"
          })
        ]
      }) : this.props.children;
    }
  }
  bs.createRoot(document.getElementById("root")).render(e.jsx(m.StrictMode, {
    children: e.jsx(rn, {
      children: e.jsx(ys, {
        children: e.jsx(sn, {})
      })
    })
  }));
});
