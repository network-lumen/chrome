(function() {
  const f = document.querySelector('script[data-lumen-injected="true"]'), c = f ? f.getAttribute("data-lumen-uuid") : null;
  if (!c) {
    console.error("[Lumen] UUID not found, provider injection failed");
    return;
  }
  if (window.lumen) return;
  const o = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map();
  let l = 0;
  const g = 60 * 1e3, w = (e) => {
    if (!e) return new Uint8Array();
    if (e instanceof Uint8Array) return e;
    if (Array.isArray(e)) return new Uint8Array(e);
    if (typeof e == "object") {
      const t = Object.values(e).filter((n) => typeof n == "number");
      return new Uint8Array(t);
    }
    return new Uint8Array();
  }, y = (e) => {
    if (!e) return "";
    if (typeof e == "string") return e;
    let t = e;
    if (Array.isArray(e)) t = new Uint8Array(e);
    else if (typeof e == "object" && !(e instanceof Uint8Array)) {
      const r = Object.values(e).filter((i) => typeof i == "number");
      t = new Uint8Array(r);
    }
    if (!(t instanceof Uint8Array)) return "";
    let n = "";
    for (let r = 0; r < t.length; r += 1) n += String.fromCharCode(t[r]);
    return btoa(n);
  }, d = (e) => {
    if (!e) return new Uint8Array();
    if (e instanceof Uint8Array) return e;
    if (Array.isArray(e)) return new Uint8Array(e);
    if (typeof e == "object") {
      const t = Object.values(e).filter((n) => typeof n == "number");
      return new Uint8Array(t);
    }
    if (typeof e != "string") return new Uint8Array();
    try {
      const t = atob(e), n = new Uint8Array(t.length);
      for (let r = 0; r < t.length; r += 1) n[r] = t.charCodeAt(r);
      return n;
    } catch {
      return new Uint8Array();
    }
  }, m = (e) => {
    var _a, _b;
    return !e || typeof e != "object" ? e : { ...e, accountNumber: ((_b = (_a = e.accountNumber) == null ? void 0 : _a.toString) == null ? void 0 : _b.call(_a)) ?? e.accountNumber, bodyBytes: y(e.bodyBytes), authInfoBytes: y(e.authInfoBytes) };
  }, b = (e) => !e || !e.signed ? e : { ...e, signed: { ...e.signed, bodyBytes: d(e.signed.bodyBytes), authInfoBytes: d(e.signed.authInfoBytes) } };
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const t = e.data;
    if (t.target === "lumen-provider" && t.uuid === c) {
      if (t.type === "response" && t.requestId !== void 0) {
        const n = u.get(t.requestId);
        n && (t.error ? n.reject(new Error(t.error)) : n.resolve(t.data), u.delete(t.requestId));
      }
      t.type === "event" && (o.get(t.eventName) || []).forEach((r) => {
        try {
          r(t.data);
        } catch (i) {
          console.error("[Lumen] Event listener error:", i);
        }
      });
    }
  });
  function s(e, t = {}) {
    return new Promise((n, r) => {
      const i = l++;
      u.set(i, { resolve: n, reject: r }), window.postMessage({ target: "lumen-content-script", uuid: c, type: "request", requestId: i, method: e, params: t }, "*"), setTimeout(() => {
        u.has(i) && (u.delete(i), r(new Error("Request timeout")));
      }, g);
    });
  }
  const a = { version: "1.0.5", request: async (e) => {
    if (!e || typeof e != "object") throw new Error("Request args must be an object");
    if (!e.method || typeof e.method != "string") throw new Error("Request must include a method string");
    return s(e.method, e.params);
  }, on: (e, t) => {
    o.has(e) || o.set(e, []), o.get(e).push(t);
  }, removeListener: (e, t) => {
    if (o.has(e)) {
      const n = o.get(e), r = n.indexOf(t);
      r > -1 && n.splice(r, 1);
    }
  }, isLumen: true, isConnected: () => true, enable: async (e) => s("enable", { chainId: e }), getKey: async (e) => s("getKey", { chainId: e }), getOfflineSigner: (e) => ({ getAccounts: async () => {
    const t = await s("getKey", { chainId: e }), n = (t == null ? void 0 : t.data) ?? t ?? {};
    return [{ address: n.bech32Address, algo: n.algo, pubkey: w(n.pubKey) }];
  }, signDirect: async (t, n) => {
    const r = await s("signDirect", { signerAddress: t, signDoc: m(n) });
    return b(r);
  }, signAmino: async (t, n) => s("signAmino", { signerAddress: t, signDoc: n }) }), getOfflineSignerAuto: async (e) => a.getOfflineSigner(e), experimentalSuggestChain: async (e) => s("experimentalSuggestChain", { chainInfo: e }), send: (e, t) => {
    if (typeof e == "string") return a.request({ method: e, params: t });
    typeof t == "function" && a.request(e).then((n) => t(null, { result: n })).catch((n) => t(n, null));
  } };
  Object.defineProperty(window, "lumen", { value: a, writable: false, configurable: false, enumerable: true }), window.dispatchEvent(new Event("lumen#initialized")), window.dispatchEvent(new Event("lumen_keystone_ready"));
})();
