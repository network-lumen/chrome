var _a, _b, _c, _d;
import { N as se, V as g } from "./assets/network-Bu5WsoSQ.js";
import { k as B, w as F, x as Y, y as oe, s as qe, m as te } from "./assets/vendor-cosmjs-CHW-r_ld.js";
import { R } from "./assets/vendor-Ds0KLgep.js";
import { p as f } from "./assets/vendor-lumen-BPhhsvED.js";
se.getInstance();
const z = "lumen", ne = 1952, re = 4e3, _e = new B.Registry(F.defaultRegistryTypes), be = new F.AminoTypes(F.createDefaultAminoConverters()), Pe = ["https://rpc.cosmos.directory/lumen/*", "https://rest.cosmos.directory/lumen/*", "https://rpc.lumen.chaintools.tech/*", "https://lumen.blocksync.me/*", "https://lumen-mainnet-rpc.mekonglabs.com/*", "https://rpc-lumen.onenov.xyz/*", "https://lumen-api.node9x.com/*", "https://api.lumen.chaintools.tech/*", "https://lumen-mainnet-api.mekonglabs.com/*"], M = (e) => {
  if (!e) return new Uint8Array(0);
  if (typeof e == "string") {
    const t = e.trim();
    if (t.length === 0) return new Uint8Array(0);
    if (/^[0-9a-fA-F]+$/.test(t)) try {
      const n = R.from(t, "hex");
      if (n.length > 0) return new Uint8Array(n);
    } catch {
    }
    try {
      const n = R.from(t, "base64");
      if (n.length > 0) return new Uint8Array(n);
    } catch {
    }
    try {
      const n = atob(t);
      return new Uint8Array(n.split("").map((r) => r.charCodeAt(0)));
    } catch {
      return new Uint8Array(0);
    }
  }
  return new Uint8Array(e);
}, q = (e, t) => {
  if (e == null) throw new Error(`Missing ${t}`);
  if (typeof e == "bigint") return Number(e);
  if (typeof e == "object" && e !== null && "toString" in e) {
    const r = e.toString(), o = Number(r);
    if (!Number.isFinite(o)) throw new Error(`Invalid ${t}: ${r}`);
    return o;
  }
  const n = Number(e);
  if (!Number.isFinite(n)) throw new Error(`Invalid ${t}: ${String(e)}`);
  return n;
}, ie = (e) => {
  var _a2, _b2, _c2, _d2;
  const t = ((_a2 = e.pqcKey) == null ? void 0 : _a2.publicKey) || ((_b2 = e.pqcKey) == null ? void 0 : _b2.public_key) ? e.pqcKey : ((_c2 = e.pqc) == null ? void 0 : _c2.publicKey) || ((_d2 = e.pqc) == null ? void 0 : _d2.public_key) ? e.pqc : e.pqcKey || e.pqc;
  if (!t) throw new Error("Wallet is missing PQC key data. Please re-import your wallet.");
  const n = t.privateKey || t.private_key || t.encryptedPrivateKey, r = t.publicKey || t.public_key;
  if (!n || !r) throw new Error("PQC keys missing sub-properties. Please re-import your wallet.");
  const o = M(n), s = M(r);
  if (s.length !== ne) throw new Error(`Invalid PQC Public Key. Expected ${ne} bytes, got ${s.length}.`);
  if (o.length !== re) throw new Error(`Invalid PQC Private Key. Expected ${re} bytes, got ${o.length}.`);
  return { pqcPrivKey: o, pqcPubKey: s };
};
typeof chrome < "u" && chrome.sidePanel && chrome.sidePanel.setPanelBehavior && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch((e) => console.error(e));
typeof chrome < "u" && chrome.runtime && chrome.runtime.onInstalled && chrome.runtime.onInstalled.addListener(() => {
  typeof chrome < "u" && chrome.contextMenus && chrome.contextMenus.create({ id: "openSidePanel", title: "Open Side Panel", contexts: ["all"] });
});
typeof chrome < "u" && chrome.contextMenus && chrome.contextMenus.onClicked && chrome.contextMenus.onClicked.addListener((e, t) => {
  e.menuItemId === "openSidePanel" && (t == null ? void 0 : t.windowId) && chrome.sidePanel && chrome.sidePanel.open && chrome.sidePanel.open({ windowId: t.windowId }).catch(console.error);
});
typeof chrome < "u" && chrome.alarms && (chrome.alarms.create("refresh-rpc", { periodInMinutes: 5 }), chrome.alarms.create("keepalive", { periodInMinutes: 1 }), chrome.alarms.onAlarm.addListener((e) => {
  e.name === "refresh-rpc" && se.getInstance().refreshBestRpc(), e.name === "keepalive" && chrome.storage.local.get(["connectedOrigins"]).catch(() => {
  });
}));
typeof chrome < "u" && chrome.runtime && chrome.runtime.onMessage && chrome.runtime.onMessage.addListener((e, t, n) => e.type === "lumen-ping" ? (n({ ok: true }), false) : e.type === "lumen-provider-request" ? (ae(e, t).then((r) => n(r)).catch((r) => {
  console.error("[Lumen Background] Error:", r), n({ error: r.message || "Request failed" });
}), true) : e.type === "user-response" ? (xe(e), n({ success: true }), false) : e.type === "sync-session" ? (g.unlock(e.password).then(() => n({ success: true })).catch((r) => {
  console.error("[Lumen Background] Session sync failed:", r), n({ error: r.message });
}), true) : e.type === "sync-active-wallet" ? e.address ? (chrome.storage.local.set({ [ce]: e.address }).then(() => n({ success: true })).catch((r) => n({ error: r.message })), true) : (n({ error: "Missing address" }), false) : false);
((_a = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : _a.onStartup) && chrome.runtime.onStartup.addListener(() => {
  h().catch(() => {
  });
});
((_b = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : _b.onInstalled) && chrome.runtime.onInstalled.addListener(() => {
  h().catch(() => {
  });
});
typeof chrome < "u" && chrome.runtime && chrome.runtime.onConnect && chrome.runtime.onConnect.addListener((e) => {
  e.name === "lumen-provider" && e.onMessage.addListener((t) => {
    (t == null ? void 0 : t.type) === "lumen-provider-request" && ae(t, e.sender).then((n) => {
      e.postMessage({ requestId: t.requestId, data: n == null ? void 0 : n.data, error: n == null ? void 0 : n.error });
    }).catch((n) => {
      e.postMessage({ requestId: t.requestId, error: (n == null ? void 0 : n.message) || "Request failed" });
    });
  });
});
async function ae(e, t) {
  const { method: n, params: r, origin: o } = e;
  try {
    if (await h(), (/* @__PURE__ */ new Set(["eth_requestAccounts", "eth_accounts", "eth_chainId", "net_version", "eth_sendTransaction", "personal_sign", "eth_sign", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"])).has(n)) throw new Error("Ethereum methods are disabled in this Cosmos-only wallet.");
    switch (n) {
      case "eth_requestAccounts":
      case "enable":
        return await Se(o, t.tab);
      case "eth_accounts":
        return await Be(o);
      case "eth_chainId":
      case "net_version":
        return await Re();
      case "eth_sendTransaction":
        return await Me(r, o, t.tab);
      case "personal_sign":
      case "eth_sign":
        return await Ce(r, o, t.tab);
      case "eth_signTypedData":
      case "eth_signTypedData_v3":
      case "eth_signTypedData_v4":
        return await ke(r, o, t.tab);
      case "wallet_addEthereumChain":
        return await De(r, o, t.tab);
      case "wallet_switchEthereumChain":
        return await Le(r, o, t.tab);
      case "cosmos_getKey":
      case "getKey":
        return await Oe(r == null ? void 0 : r.chainId, o);
      case "cosmos_signAmino":
      case "signAmino":
        return await Ne(r, o, t.tab);
      case "cosmos_signDirect":
      case "signDirect":
        return await Ke(r, o, t.tab);
      case "experimentalSuggestChain":
        return { data: null };
      default:
        throw new Error(`Unsupported method: ${n}`);
    }
  } catch (s) {
    return console.error(`[Lumen Background] Error handling ${n}:`, s), { error: s.message };
  }
}
const c = /* @__PURE__ */ new Map(), b = 60 * 1e3;
let G = false, V = false, m = null;
const _ = "lumen_popup_window_id", ce = "activeWalletAddress", j = "connectedOrigins", ue = "pendingApprovalQueue", Ie = (e) => {
  try {
    return `${new URL(e).origin}/*`;
  } catch {
    return null;
  }
};
async function Ae(e) {
  if (!chrome.permissions) return;
  const t = Ie(e);
  if (!t) return;
  const n = { origins: [t] };
  if (!await chrome.permissions.contains(n)) throw new Error("Site permission not granted.");
}
async function de() {
  try {
    return (await chrome.storage.local.get([ce])).activeWalletAddress || null;
  } catch {
    return null;
  }
}
async function J() {
  const e = await chrome.storage.local.get(ue);
  return Array.isArray(e.pendingApprovalQueue) ? e.pendingApprovalQueue : [];
}
async function X(e) {
  await chrome.storage.local.set({ [ue]: e });
  const t = e.length;
  chrome.action && chrome.action.setBadgeText && (await chrome.action.setBadgeText({ text: t > 0 ? String(t) : "" }), await chrome.action.setBadgeBackgroundColor({ color: t > 0 ? "#f5d996ff" : "#00000000" }), await chrome.action.setTitle({ title: t > 0 ? `Lumen Wallet (${t} pending request${t > 1 ? "s" : ""})` : "Lumen Wallet" }));
}
async function h() {
  const e = await J();
  if (!e.length) return;
  const t = Date.now(), n = [];
  for (const r of e) {
    const o = r.timestamp ?? 0;
    if (o > 0 && t - o > b) {
      const a = c.get(r.requestId);
      a && (a.reject(new Error("Request timeout")), c.delete(r.requestId));
      continue;
    }
    n.push(r);
  }
  n.length !== e.length && await X(n);
}
async function C(e) {
  await h();
  const t = await J(), n = [e, ...t.filter((r) => r.requestId !== e.requestId)];
  await X(n);
}
async function y(e) {
  const n = (await J()).filter((r) => r.requestId !== e);
  await X(n);
}
async function k(e) {
  var _a2, _b2, _c2, _d2, _e2, _f, _g;
  if (!(typeof chrome > "u" || !chrome.windows) && !(G || V)) try {
    if ((_a2 = chrome.sidePanel) == null ? void 0 : _a2.open) {
      V = true;
      try {
        if ((e == null ? void 0 : e.id) !== void 0) {
          await chrome.sidePanel.open({ tabId: e.id });
          return;
        }
        const s = await chrome.windows.getCurrent();
        if (s == null ? void 0 : s.id) {
          await chrome.sidePanel.open({ windowId: s.id });
          return;
        }
      } catch {
      } finally {
        setTimeout(() => {
          V = false;
        }, 500);
      }
    }
    G = true;
    let t = m;
    if (((_b2 = chrome.storage) == null ? void 0 : _b2.session) && (t = ((_c2 = await chrome.storage.session.get(_)) == null ? void 0 : _c2.lumen_popup_window_id) ?? t), t) try {
      const s = await chrome.windows.get(t);
      if (s == null ? void 0 : s.id) {
        m = s.id, await chrome.windows.update(s.id, { focused: true });
        return;
      }
    } catch {
      m = null, ((_d2 = chrome.storage) == null ? void 0 : _d2.session) && await chrome.storage.session.remove(_);
    }
    const r = (await chrome.windows.getAll({ populate: true, windowTypes: ["popup"] })).find((s) => {
      var _a3;
      return (_a3 = s.tabs) == null ? void 0 : _a3.some((a) => {
        var _a4;
        return (_a4 = a.url) == null ? void 0 : _a4.includes("index.html");
      });
    });
    if (r == null ? void 0 : r.id) {
      m = r.id, ((_e2 = chrome.storage) == null ? void 0 : _e2.session) && await chrome.storage.session.set({ [_]: r.id }), await chrome.windows.update(r.id, { focused: true });
      return;
    }
    if ((_f = chrome.action) == null ? void 0 : _f.openPopup) try {
      await chrome.action.openPopup();
      return;
    } catch {
    }
    const o = await chrome.windows.create({ url: chrome.runtime.getURL("index.html"), type: "popup", width: 360, height: 600 });
    (o == null ? void 0 : o.id) && (m = o.id, ((_g = chrome.storage) == null ? void 0 : _g.session) && await chrome.storage.session.set({ [_]: o.id }));
  } catch (t) {
    console.error("[Lumen] Failed to open popup:", t);
  } finally {
    setTimeout(() => {
      G = false;
    }, 1e3);
  }
}
typeof chrome < "u" && ((_c = chrome.windows) == null ? void 0 : _c.onRemoved) && chrome.windows.onRemoved.addListener((e) => {
  m && e === m && (m = null, chrome.storage.session.remove(_).catch(() => {
  }));
});
function D() {
  return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
async function Se(e, t) {
  try {
    const n = await ve(), o = (await P()).includes(e);
    if (!n && o) {
      await le();
      const i = await Z();
      if (!i) throw new Error("No wallet found");
      return { data: [i] };
    }
    await h();
    const s = D(), a = { requestId: s, origin: e, permissions: ["View wallet address", "Request transaction signatures"], type: n ? "pending-unlock-request" : "approval-request", timestamp: Date.now() };
    return await C(a), await k(t), new Promise((i, u) => {
      c.set(s, { resolve: i, reject: u, origin: e, type: "enable" }), setTimeout(() => {
        c.has(s) && (c.delete(s), y(s).catch(() => {
        }), u(new Error("Request timeout")));
      }, b);
    });
  } catch (n) {
    return console.error("[Lumen] Enable error:", n), { error: n.message || "Failed to connect wallet" };
  }
}
function xe(e) {
  const { requestId: t, approved: n } = e, r = c.get(t);
  if (!r) {
    y(t).catch(() => {
    });
    return;
  }
  c.delete(t), y(t).catch(() => {
  }), n ? (async () => {
    try {
      r.type === "enable" && (await Ae(r.origin), await le()), await Te(r.origin);
      const o = await Z();
      if (!o) throw new Error("No wallet found");
      r.resolve({ data: [o] });
    } catch (o) {
      await me(r.origin), r.reject(o);
    }
  })().catch((o) => r.reject(o)) : r.reject(new Error("User rejected the request"));
}
((_d = chrome.permissions) == null ? void 0 : _d.onRemoved) && chrome.permissions.onRemoved.addListener(({ origins: e }) => {
  !e || e.length === 0 || e.forEach((t) => {
    const n = t.replace(/\/\*$/, "");
    me(n).catch(() => {
    });
  });
});
async function ve() {
  try {
    return await g.hasWallet() ? await g.isSessionExpired() : true;
  } catch (e) {
    return console.error("[Lumen] Error checking wallet lock status:", e), true;
  }
}
async function le() {
  if (typeof chrome > "u" || !chrome.permissions) return;
  const e = { origins: Pe };
  if (!await chrome.permissions.contains(e)) throw new Error("Host permissions not granted.");
}
async function Z() {
  var _a2;
  try {
    const e = await g.getWallets();
    if (!e || e.length === 0) return null;
    const t = await de();
    if (t) {
      const n = e.find((r) => r.address === t);
      if (n) return n.address;
    }
    return e[0].address;
  } catch (e) {
    return ((_a2 = e.message) == null ? void 0 : _a2.includes("Session expired")) || console.error("[Lumen] Error getting wallet address:", e), null;
  }
}
async function P() {
  return (await chrome.storage.local.get([j])).connectedOrigins || [];
}
async function Te(e) {
  const t = await P();
  t.includes(e) || (t.push(e), await chrome.storage.local.set({ [j]: t }));
}
async function me(e) {
  const t = await P(), n = t.filter((r) => r !== e);
  n.length !== t.length && await chrome.storage.local.set({ [j]: n });
}
async function Be(e) {
  if (!(await P()).includes(e)) return { data: [] };
  const n = await Z();
  return { data: n ? [n] : [] };
}
async function Re() {
  return { data: "lumen" };
}
async function Me(e, t, n) {
  await h();
  const r = D(), o = { requestId: r, origin: t, permissions: ["Request transaction signatures"], type: "transaction-request", params: e, timestamp: Date.now() };
  return await C(o), chrome.runtime.sendMessage({ type: "show-approval" }).catch(() => {
  }), await k(n), await new Promise((s, a) => {
    c.set(r, { resolve: s, reject: a, origin: t, type: "transaction" }), setTimeout(() => {
      c.has(r) && (c.delete(r), y(r).catch(() => {
      }), a(new Error("Request timeout")));
    }, b);
  }), { error: "Signing implementation pending for generic transactions" };
}
async function Ce(e, t, n) {
  throw new Error("Message signing not yet implemented");
}
async function ke(e, t, n) {
  throw new Error("Typed data signing not yet implemented");
}
async function De(e, t, n) {
  return { data: null };
}
async function Le(e, t, n) {
  throw new Error("Chain switching not yet implemented");
}
async function Oe(e, t) {
  if (e && e !== z) throw new Error("Unsupported chain");
  if (t && !(await P()).includes(t)) throw new Error("Not connected. Call enable() first.");
  const n = await g.getWallets();
  if (!n || n.length === 0) throw new Error("Wallet is locked or empty");
  try {
    const r = await de(), o = r && n.find((p) => p.address === r) || n[0], i = (await (await Y.Secp256k1HdWallet.fromMnemonic(o.mnemonic, { prefix: "lmn" })).getAccounts())[0], u = oe.fromBech32(i.address).data;
    return { data: { name: "Lumen Wallet", algo: i.algo, pubKey: i.pubkey, address: u, bech32Address: i.address, isNanoLedger: false } };
  } catch (r) {
    throw console.error("[Lumen] getKey error:", r), new Error(r.message || "Failed to retrieve key");
  }
}
async function Ne(e, t, n) {
  await h();
  const r = D(), o = { requestId: r, origin: t, permissions: ["Request transaction signatures"], type: "transaction-request", params: { ...e, mode: "amino" }, timestamp: Date.now() };
  await C(o), chrome.runtime.sendMessage({ type: "show-approval" }).catch(() => {
  }), await k(n), await new Promise((s, a) => {
    c.set(r, { resolve: s, reject: a, origin: t, type: "transaction" }), setTimeout(() => {
      c.has(r) && (c.delete(r), y(r).catch(() => {
      }), a(new Error("Request timeout")));
    }, b);
  });
  try {
    const s = await g.getWallets(), a = e == null ? void 0 : e.signerAddress, i = e == null ? void 0 : e.signDoc;
    if (!a || !i) throw new Error("Missing signerAddress or signDoc");
    const u = s.find((H) => H.address === a);
    if (!u) throw new Error("Signer address not found in wallet");
    const p = await Y.Secp256k1HdWallet.fromMnemonic(u.mnemonic, { prefix: "lmn" }), E = await p.signAmino(a, i), [I] = await p.getAccounts();
    if (I.address !== a) throw new Error("Signer address mismatch");
    const { pqcPrivKey: A, pqcPubKey: L } = ie(u), S = i.chain_id || i.chainId || z, x = q(i.account_number ?? i.accountNumber, "account_number"), d = (E == null ? void 0 : E.signed) || i, w = d.fee;
    if (!w) throw new Error("Missing fee in signDoc");
    const O = q(w.gas, "fee.gas"), N = q(d.sequence ?? i.sequence, "sequence"), K = d.memo ?? i.memo ?? "", v = d.timeout_height ?? d.timeoutHeight ?? i.timeout_height ?? i.timeoutHeight, l = v !== void 0 ? q(v, "timeout_height") : void 0, $ = { messages: (d.msgs ?? i.msgs ?? []).map((H) => be.fromAmino(H)), memo: K };
    l !== void 0 && l !== 0 && ($.timeoutHeight = l);
    const T = _e.encode({ typeUrl: "/cosmos.tx.v1beta1.TxBody", value: $ }), he = B.encodePubkey(Y.getAminoPubkey(I)), Q = B.makeAuthInfoBytes([{ pubkey: he, sequence: N }], w.amount, O, w.granter, w.payer, qe.SignMode.SIGN_MODE_LEGACY_AMINO_JSON), we = { bodyBytes: T, authInfoBytes: Q, signatures: [] }, ge = f.computeSignBytes(S, x, we), pe = await f.signDilithium(ge, A), fe = { addr: u.address, scheme: "dilithium3", signature: new Uint8Array(pe), pubKey: L }, ee = f.withPqcExtension(T, [fe]), ye = te.TxRaw.fromPartial({ bodyBytes: ee, authInfoBytes: Q, signatures: [oe.fromBase64(E.signature.signature)] }), Ee = te.TxRaw.encode(ye).finish();
    return { data: { ...E, pqc: { bodyBytes: ee, authInfoBytes: Q, txRawBytes: Ee } } };
  } catch (s) {
    throw console.error("SignAmino failed:", s), new Error(s.message || "Signing failed");
  }
}
async function Ke(e, t, n) {
  var _a2, _b2;
  await h();
  const r = D(), o = { requestId: r, origin: t, permissions: ["Request transaction signatures"], type: "transaction-request", params: { ...e, mode: "direct" }, timestamp: Date.now() };
  await C(o), await k(n), await new Promise((s, a) => {
    c.set(r, { resolve: s, reject: a, origin: t, type: "transaction" }), setTimeout(() => {
      c.has(r) && (c.delete(r), y(r).catch(() => {
      }), a(new Error("Request timeout")));
    }, b);
  });
  try {
    const s = await g.getWallets(), a = e == null ? void 0 : e.signerAddress, i = e == null ? void 0 : e.signDoc;
    if (!a || !i) throw new Error("Missing signerAddress or signDoc");
    const u = s.find((T) => T.address === a);
    if (!u) throw new Error("Signer address not found in wallet");
    const p = await B.DirectSecp256k1HdWallet.fromMnemonic(u.mnemonic, { prefix: "lmn" }), { pqcPrivKey: E, pqcPubKey: I } = ie(u), A = i.chainId || z, L = q(i.accountNumber, "accountNumber"), S = M(i.bodyBytes), x = M(i.authInfoBytes), d = { bodyBytes: S, authInfoBytes: x, signatures: [] }, w = f.computeSignBytes(A, L, d), O = await f.signDilithium(w, E), N = { addr: u.address, scheme: "dilithium3", signature: new Uint8Array(O), pubKey: I }, K = f.withPqcExtension(S, [N]), v = { ...i, bodyBytes: K, authInfoBytes: x, chainId: A }, l = await p.signDirect(a, v), U = (_a2 = l == null ? void 0 : l.signed) == null ? void 0 : _a2.bodyBytes, W = (_b2 = l == null ? void 0 : l.signed) == null ? void 0 : _b2.authInfoBytes;
    return { data: { ...l, signed: { ...l.signed, bodyBytes: U ? R.from(U).toString("base64") : "", authInfoBytes: W ? R.from(W).toString("base64") : "" } } };
  } catch (s) {
    throw console.error("Signing failed:", s), new Error(s.message || "Signing failed");
  }
}
