(function() {
  function m() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
      const t = Math.random() * 16 | 0;
      return (e === "x" ? t : t & 3 | 8).toString(16);
    });
  }
  const n = m();
  function p() {
    try {
      const e = document.createElement("script");
      e.src = chrome.runtime.getURL("inject.js"), e.setAttribute("data-lumen-uuid", n), e.setAttribute("data-lumen-injected", "true"), (document.head || document.documentElement).appendChild(e), e.onload = () => {
        e.remove();
      }, e.onerror = (t) => {
        console.error("[Lumen Content Script] Failed to load inject.js:", t);
      };
    } catch (e) {
      console.error("[Lumen Content Script] Injection error:", e);
    }
  }
  window.addEventListener("message", async (e) => {
    if (e.source !== window) return;
    const t = e.data;
    if (t.target === "lumen-content-script" && t.uuid === n && t.type === "request") try {
      const r = ["enable", "eth_requestAccounts", "eth_sendTransaction", "personal_sign", "eth_sign", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "signDirect", "signAmino"].includes(t.method), c = { type: "lumen-provider-request", method: t.method, params: t.params, origin: window.location.origin, requestId: t.requestId }, a = r ? await new Promise((x, u) => {
        const o = chrome.runtime.connect({ name: "lumen-provider" });
        let s = false;
        const l = setTimeout(() => {
          if (!s) {
            s = true;
            try {
              o.disconnect();
            } catch {
            }
            u(new Error("Request timeout"));
          }
        }, 60 * 1e3), d = () => {
          if (!s) {
            s = true, clearTimeout(l);
            try {
              o.disconnect();
            } catch {
            }
          }
        };
        o.onMessage.addListener((i) => {
          (i == null ? void 0 : i.requestId) === t.requestId && (d(), x(i));
        }), o.onDisconnect.addListener(() => {
          var _a;
          if (s) return;
          const i = ((_a = chrome.runtime.lastError) == null ? void 0 : _a.message) || "Port disconnected";
          d(), u(new Error(i));
        }), o.postMessage(c);
      }) : await chrome.runtime.sendMessage(c);
      window.postMessage({ target: "lumen-provider", uuid: n, type: "response", requestId: t.requestId, data: a.data, error: a.error }, "*");
    } catch (r) {
      console.error("[Lumen Content Script] Error processing request:", r), window.postMessage({ target: "lumen-provider", uuid: n, type: "response", requestId: t.requestId, error: r.message || "Unknown error occurred" }, "*");
    }
  }), chrome.runtime.onMessage.addListener((e, t, r) => {
    e.type === "lumen-provider-event" && (window.postMessage({ target: "lumen-provider", uuid: n, type: "event", eventName: e.eventName, data: e.data }, "*"), r({ success: true }));
  }), p();
  try {
    chrome.runtime.sendMessage({ type: "lumen-ping" }).catch(() => {
    });
  } catch {
  }
})();
