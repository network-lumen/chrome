var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { y as Sr, z as sn, A as vr, C as d, L as _r, D as Pr, E as Nr, F as xr, G as Ur, H as Mr, I as Mt, J as s, K as Ir } from "./vendor-Ds0KLgep.js";
import { c as E, d as en, e as It, f as Er, g as Ar, h as H, j as Br } from "./vendor-cosmjs-CHW-r_ld.js";
const Rr = (n) => typeof n == "string" ? n : n.href || n.toString();
var Dr = Object.defineProperty, Or = Object.getOwnPropertyNames, Et = (n, t) => function() {
  return n && (t = (0, n[Or(n)[0]])(n = 0)), t;
}, tn = (n, t) => {
  for (var r in t) Dr(n, r, { get: t[r], enumerable: true });
}, Sn, fn, At, Bt, Rt, nn, ln, un, Dt, rn = Et({ "src/pqc/constants.ts"() {
  Sn = "PQCv1:", fn = "/lumen.pqc.v1.PQCSignatures", At = "pqc_keys", Bt = "keys.json", Rt = "links.json", nn = "dilithium3", ln = 1952, un = 4e3, Dt = 3293;
} }), Fr = {};
tn(Fr, { PqcKeyStore: () => mn, defaultHomeDir: () => vn });
async function En(n, t) {
  try {
    const r = await Ur(n, "utf8");
    return JSON.parse(r);
  } catch (r) {
    if (r.code === "ENOENT") return t;
    throw r;
  }
}
async function An(n, t) {
  const r = `${n}.tmp`;
  await Mr(r, JSON.stringify(t, null, 2)), await Mt.rename(r, n);
}
function Bn(n) {
  return { name: n.name, scheme: n.scheme, publicKey: E.fromBase64(n.publicKey), privateKey: E.fromBase64(n.privateKey), createdAt: new Date(n.createdAt) };
}
function vn() {
  const n = Sr.homedir();
  if (!n) throw new Error("Unable to resolve user home directory for pqc key store");
  return sn.join(n, ".lumen");
}
var mn, Ot = Et({ "src/pqc/keystore.ts"() {
  rn(), mn = class Ft {
    constructor(t, r, o, i) {
      this.keysPath = t, this.linksPath = r, this.keys = o, this.links = i;
    }
    static async open(t = vn()) {
      const r = sn.join(t, At);
      await vr();
      const o = sn.join(r, Bt), i = sn.join(r, Rt), e = await En(o, {}), l = await En(i, {});
      return new Ft(o, i, e, l);
    }
    listKeys() {
      return Object.values(this.keys).map(Bn);
    }
    getKey(t) {
      const r = this.keys[t];
      return r ? Bn(r) : void 0;
    }
    async saveKey(t) {
      const r = { name: t.name, scheme: t.scheme, publicKey: E.toBase64(t.publicKey), privateKey: E.toBase64(t.privateKey), createdAt: t.createdAt.toISOString() };
      this.keys[t.name] = r, await An(this.keysPath, this.keys);
    }
    listLinks() {
      return { ...this.links };
    }
    getLink(t) {
      return this.links[t];
    }
    async linkAddress(t, r) {
      this.links[t] = r, await An(this.linksPath, this.links);
    }
  };
} }), _n = { bech32Prefix: "lmn", gaslessTypeUrls: ["/lumen.gateway.v1.MsgCreateContract", "/lumen.gateway.v1.MsgRegisterGateway", "/lumen.gateway.v1.MsgUpdateGateway", "/lumen.gateway.v1.MsgClaimPayment", "/lumen.gateway.v1.MsgCancelContract", "/lumen.gateway.v1.MsgFinalizeContract", "/lumen.dns.v1.MsgRegister", "/lumen.dns.v1.MsgRenew", "/lumen.dns.v1.MsgTransfer", "/lumen.dns.v1.MsgUpdate", "/lumen.dns.v1.MsgBid", "/lumen.dns.v1.MsgSettle"] };
function Rn() {
  return { key: "", value: "", ttl: 0 };
}
var M = { encode(n, t = new d()) {
  return n.key !== "" && t.uint32(10).string(n.key), n.value !== "" && t.uint32(18).string(n.value), n.ttl !== 0 && t.uint32(24).uint64(n.ttl), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Rn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.key = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.value = r.string();
        continue;
      }
      case 3: {
        if (e !== 24) break;
        i.ttl = Cr(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { key: hn(n.key) ? globalThis.String(n.key) : "", value: hn(n.value) ? globalThis.String(n.value) : "", ttl: hn(n.ttl) ? globalThis.Number(n.ttl) : 0 };
}, toJSON(n) {
  const t = {};
  return n.key !== "" && (t.key = n.key), n.value !== "" && (t.value = n.value), n.ttl !== 0 && (t.ttl = Math.round(n.ttl)), t;
}, create(n) {
  return M.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Rn();
  return t.key = n.key ?? "", t.value = n.value ?? "", t.ttl = n.ttl ?? 0, t;
} };
function Cr(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function hn(n) {
  return n != null;
}
function Dn() {
  return { baseFeeDns: "", alpha: "", floor: "", ceiling: "", t: 0, graceDays: 0, auctionDays: 0, transferFeeUlmn: 0, bidFeeUlmn: 0, updateRateLimitSeconds: 0, updatePowDifficulty: 0, domainTiers: [], extTiers: [], minPriceUlmnPerMonth: 0, updateFeeUlmn: 0 };
}
var C = { encode(n, t = new d()) {
  n.baseFeeDns !== "" && t.uint32(10).string(n.baseFeeDns), n.alpha !== "" && t.uint32(18).string(n.alpha), n.floor !== "" && t.uint32(26).string(n.floor), n.ceiling !== "" && t.uint32(34).string(n.ceiling), n.t !== 0 && t.uint32(40).uint64(n.t), n.graceDays !== 0 && t.uint32(48).uint64(n.graceDays), n.auctionDays !== 0 && t.uint32(56).uint64(n.auctionDays), n.transferFeeUlmn !== 0 && t.uint32(96).uint64(n.transferFeeUlmn), n.bidFeeUlmn !== 0 && t.uint32(104).uint64(n.bidFeeUlmn), n.updateRateLimitSeconds !== 0 && t.uint32(112).uint64(n.updateRateLimitSeconds), n.updatePowDifficulty !== 0 && t.uint32(120).uint32(n.updatePowDifficulty);
  for (const r of n.domainTiers) N.encode(r, t.uint32(130).fork()).join();
  for (const r of n.extTiers) N.encode(r, t.uint32(138).fork()).join();
  return n.minPriceUlmnPerMonth !== 0 && t.uint32(144).uint64(n.minPriceUlmnPerMonth), n.updateFeeUlmn !== 0 && t.uint32(152).uint64(n.updateFeeUlmn), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Dn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.baseFeeDns = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.alpha = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.floor = r.string();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.ceiling = r.string();
        continue;
      }
      case 5: {
        if (e !== 40) break;
        i.t = R(r.uint64());
        continue;
      }
      case 6: {
        if (e !== 48) break;
        i.graceDays = R(r.uint64());
        continue;
      }
      case 7: {
        if (e !== 56) break;
        i.auctionDays = R(r.uint64());
        continue;
      }
      case 12: {
        if (e !== 96) break;
        i.transferFeeUlmn = R(r.uint64());
        continue;
      }
      case 13: {
        if (e !== 104) break;
        i.bidFeeUlmn = R(r.uint64());
        continue;
      }
      case 14: {
        if (e !== 112) break;
        i.updateRateLimitSeconds = R(r.uint64());
        continue;
      }
      case 15: {
        if (e !== 120) break;
        i.updatePowDifficulty = r.uint32();
        continue;
      }
      case 16: {
        if (e !== 130) break;
        i.domainTiers.push(N.decode(r, r.uint32()));
        continue;
      }
      case 17: {
        if (e !== 138) break;
        i.extTiers.push(N.decode(r, r.uint32()));
        continue;
      }
      case 18: {
        if (e !== 144) break;
        i.minPriceUlmnPerMonth = R(r.uint64());
        continue;
      }
      case 19: {
        if (e !== 152) break;
        i.updateFeeUlmn = R(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { baseFeeDns: y(n.baseFeeDns) ? globalThis.String(n.baseFeeDns) : y(n.base_fee_dns) ? globalThis.String(n.base_fee_dns) : "", alpha: y(n.alpha) ? globalThis.String(n.alpha) : "", floor: y(n.floor) ? globalThis.String(n.floor) : "", ceiling: y(n.ceiling) ? globalThis.String(n.ceiling) : "", t: y(n.t) ? globalThis.Number(n.t) : 0, graceDays: y(n.graceDays) ? globalThis.Number(n.graceDays) : y(n.grace_days) ? globalThis.Number(n.grace_days) : 0, auctionDays: y(n.auctionDays) ? globalThis.Number(n.auctionDays) : y(n.auction_days) ? globalThis.Number(n.auction_days) : 0, transferFeeUlmn: y(n.transferFeeUlmn) ? globalThis.Number(n.transferFeeUlmn) : y(n.transfer_fee_ulmn) ? globalThis.Number(n.transfer_fee_ulmn) : 0, bidFeeUlmn: y(n.bidFeeUlmn) ? globalThis.Number(n.bidFeeUlmn) : y(n.bid_fee_ulmn) ? globalThis.Number(n.bid_fee_ulmn) : 0, updateRateLimitSeconds: y(n.updateRateLimitSeconds) ? globalThis.Number(n.updateRateLimitSeconds) : y(n.update_rate_limit_seconds) ? globalThis.Number(n.update_rate_limit_seconds) : 0, updatePowDifficulty: y(n.updatePowDifficulty) ? globalThis.Number(n.updatePowDifficulty) : y(n.update_pow_difficulty) ? globalThis.Number(n.update_pow_difficulty) : 0, domainTiers: globalThis.Array.isArray(n == null ? void 0 : n.domainTiers) ? n.domainTiers.map((t) => N.fromJSON(t)) : globalThis.Array.isArray(n == null ? void 0 : n.domain_tiers) ? n.domain_tiers.map((t) => N.fromJSON(t)) : [], extTiers: globalThis.Array.isArray(n == null ? void 0 : n.extTiers) ? n.extTiers.map((t) => N.fromJSON(t)) : globalThis.Array.isArray(n == null ? void 0 : n.ext_tiers) ? n.ext_tiers.map((t) => N.fromJSON(t)) : [], minPriceUlmnPerMonth: y(n.minPriceUlmnPerMonth) ? globalThis.Number(n.minPriceUlmnPerMonth) : y(n.min_price_ulmn_per_month) ? globalThis.Number(n.min_price_ulmn_per_month) : 0, updateFeeUlmn: y(n.updateFeeUlmn) ? globalThis.Number(n.updateFeeUlmn) : y(n.update_fee_ulmn) ? globalThis.Number(n.update_fee_ulmn) : 0 };
}, toJSON(n) {
  var _a, _b;
  const t = {};
  return n.baseFeeDns !== "" && (t.baseFeeDns = n.baseFeeDns), n.alpha !== "" && (t.alpha = n.alpha), n.floor !== "" && (t.floor = n.floor), n.ceiling !== "" && (t.ceiling = n.ceiling), n.t !== 0 && (t.t = Math.round(n.t)), n.graceDays !== 0 && (t.graceDays = Math.round(n.graceDays)), n.auctionDays !== 0 && (t.auctionDays = Math.round(n.auctionDays)), n.transferFeeUlmn !== 0 && (t.transferFeeUlmn = Math.round(n.transferFeeUlmn)), n.bidFeeUlmn !== 0 && (t.bidFeeUlmn = Math.round(n.bidFeeUlmn)), n.updateRateLimitSeconds !== 0 && (t.updateRateLimitSeconds = Math.round(n.updateRateLimitSeconds)), n.updatePowDifficulty !== 0 && (t.updatePowDifficulty = Math.round(n.updatePowDifficulty)), ((_a = n.domainTiers) == null ? void 0 : _a.length) && (t.domainTiers = n.domainTiers.map((r) => N.toJSON(r))), ((_b = n.extTiers) == null ? void 0 : _b.length) && (t.extTiers = n.extTiers.map((r) => N.toJSON(r))), n.minPriceUlmnPerMonth !== 0 && (t.minPriceUlmnPerMonth = Math.round(n.minPriceUlmnPerMonth)), n.updateFeeUlmn !== 0 && (t.updateFeeUlmn = Math.round(n.updateFeeUlmn)), t;
}, create(n) {
  return C.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a, _b;
  const t = Dn();
  return t.baseFeeDns = n.baseFeeDns ?? "", t.alpha = n.alpha ?? "", t.floor = n.floor ?? "", t.ceiling = n.ceiling ?? "", t.t = n.t ?? 0, t.graceDays = n.graceDays ?? 0, t.auctionDays = n.auctionDays ?? 0, t.transferFeeUlmn = n.transferFeeUlmn ?? 0, t.bidFeeUlmn = n.bidFeeUlmn ?? 0, t.updateRateLimitSeconds = n.updateRateLimitSeconds ?? 0, t.updatePowDifficulty = n.updatePowDifficulty ?? 0, t.domainTiers = ((_a = n.domainTiers) == null ? void 0 : _a.map((r) => N.fromPartial(r))) || [], t.extTiers = ((_b = n.extTiers) == null ? void 0 : _b.map((r) => N.fromPartial(r))) || [], t.minPriceUlmnPerMonth = n.minPriceUlmnPerMonth ?? 0, t.updateFeeUlmn = n.updateFeeUlmn ?? 0, t;
} };
function On() {
  return { maxLen: 0, multiplierBps: 0 };
}
var N = { encode(n, t = new d()) {
  return n.maxLen !== 0 && t.uint32(8).uint32(n.maxLen), n.multiplierBps !== 0 && t.uint32(16).uint32(n.multiplierBps), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = On();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 8) break;
        i.maxLen = r.uint32();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.multiplierBps = r.uint32();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { maxLen: y(n.maxLen) ? globalThis.Number(n.maxLen) : y(n.max_len) ? globalThis.Number(n.max_len) : 0, multiplierBps: y(n.multiplierBps) ? globalThis.Number(n.multiplierBps) : y(n.multiplier_bps) ? globalThis.Number(n.multiplier_bps) : 0 };
}, toJSON(n) {
  const t = {};
  return n.maxLen !== 0 && (t.maxLen = Math.round(n.maxLen)), n.multiplierBps !== 0 && (t.multiplierBps = Math.round(n.multiplierBps)), t;
}, create(n) {
  return N.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = On();
  return t.maxLen = n.maxLen ?? 0, t.multiplierBps = n.multiplierBps ?? 0, t;
} };
function R(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function y(n) {
  return n != null;
}
function Fn() {
  return { authority: "", params: void 0 };
}
var Ct = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.params !== void 0 && C.encode(n.params, t.uint32(18).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Fn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.params = C.decode(r, r.uint32());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: m(n.authority) ? globalThis.String(n.authority) : "", params: m(n.params) ? C.fromJSON(n.params) : void 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.params !== void 0 && (t.params = C.toJSON(n.params)), t;
}, create(n) {
  return Ct.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Fn();
  return t.authority = n.authority ?? "", t.params = n.params !== void 0 && n.params !== null ? C.fromPartial(n.params) : void 0, t;
} };
function Cn() {
  return { creator: "", domain: "", ext: "", records: [], durationDays: 0, owner: "" };
}
var Jt = { encode(n, t = new d()) {
  n.creator !== "" && t.uint32(10).string(n.creator), n.domain !== "" && t.uint32(18).string(n.domain), n.ext !== "" && t.uint32(26).string(n.ext);
  for (const r of n.records) M.encode(r, t.uint32(50).fork()).join();
  return n.durationDays !== 0 && t.uint32(56).uint64(n.durationDays), n.owner !== "" && t.uint32(74).string(n.owner), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Cn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.domain = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.ext = r.string();
        continue;
      }
      case 6: {
        if (e !== 50) break;
        i.records.push(M.decode(r, r.uint32()));
        continue;
      }
      case 7: {
        if (e !== 56) break;
        i.durationDays = Pn(r.uint64());
        continue;
      }
      case 9: {
        if (e !== 74) break;
        i.owner = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: m(n.creator) ? globalThis.String(n.creator) : "", domain: m(n.domain) ? globalThis.String(n.domain) : "", ext: m(n.ext) ? globalThis.String(n.ext) : "", records: globalThis.Array.isArray(n == null ? void 0 : n.records) ? n.records.map((t) => M.fromJSON(t)) : [], durationDays: m(n.durationDays) ? globalThis.Number(n.durationDays) : m(n.duration_days) ? globalThis.Number(n.duration_days) : 0, owner: m(n.owner) ? globalThis.String(n.owner) : "" };
}, toJSON(n) {
  var _a;
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.domain !== "" && (t.domain = n.domain), n.ext !== "" && (t.ext = n.ext), ((_a = n.records) == null ? void 0 : _a.length) && (t.records = n.records.map((r) => M.toJSON(r))), n.durationDays !== 0 && (t.durationDays = Math.round(n.durationDays)), n.owner !== "" && (t.owner = n.owner), t;
}, create(n) {
  return Jt.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a;
  const t = Cn();
  return t.creator = n.creator ?? "", t.domain = n.domain ?? "", t.ext = n.ext ?? "", t.records = ((_a = n.records) == null ? void 0 : _a.map((r) => M.fromPartial(r))) || [], t.durationDays = n.durationDays ?? 0, t.owner = n.owner ?? "", t;
} };
function Jn() {
  return { creator: "", domain: "", ext: "", records: [], powNonce: 0 };
}
var Lt = { encode(n, t = new d()) {
  n.creator !== "" && t.uint32(10).string(n.creator), n.domain !== "" && t.uint32(18).string(n.domain), n.ext !== "" && t.uint32(26).string(n.ext);
  for (const r of n.records) M.encode(r, t.uint32(50).fork()).join();
  return n.powNonce !== 0 && t.uint32(56).uint64(n.powNonce), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Jn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.domain = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.ext = r.string();
        continue;
      }
      case 6: {
        if (e !== 50) break;
        i.records.push(M.decode(r, r.uint32()));
        continue;
      }
      case 7: {
        if (e !== 56) break;
        i.powNonce = Pn(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: m(n.creator) ? globalThis.String(n.creator) : "", domain: m(n.domain) ? globalThis.String(n.domain) : "", ext: m(n.ext) ? globalThis.String(n.ext) : "", records: globalThis.Array.isArray(n == null ? void 0 : n.records) ? n.records.map((t) => M.fromJSON(t)) : [], powNonce: m(n.powNonce) ? globalThis.Number(n.powNonce) : m(n.pow_nonce) ? globalThis.Number(n.pow_nonce) : 0 };
}, toJSON(n) {
  var _a;
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.domain !== "" && (t.domain = n.domain), n.ext !== "" && (t.ext = n.ext), ((_a = n.records) == null ? void 0 : _a.length) && (t.records = n.records.map((r) => M.toJSON(r))), n.powNonce !== 0 && (t.powNonce = Math.round(n.powNonce)), t;
}, create(n) {
  return Lt.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a;
  const t = Jn();
  return t.creator = n.creator ?? "", t.domain = n.domain ?? "", t.ext = n.ext ?? "", t.records = ((_a = n.records) == null ? void 0 : _a.map((r) => M.fromPartial(r))) || [], t.powNonce = n.powNonce ?? 0, t;
} };
function Ln() {
  return { creator: "", domain: "", ext: "", durationDays: 0 };
}
var Gt = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.domain !== "" && t.uint32(18).string(n.domain), n.ext !== "" && t.uint32(26).string(n.ext), n.durationDays !== 0 && t.uint32(32).uint64(n.durationDays), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Ln();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.domain = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.ext = r.string();
        continue;
      }
      case 4: {
        if (e !== 32) break;
        i.durationDays = Pn(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: m(n.creator) ? globalThis.String(n.creator) : "", domain: m(n.domain) ? globalThis.String(n.domain) : "", ext: m(n.ext) ? globalThis.String(n.ext) : "", durationDays: m(n.durationDays) ? globalThis.Number(n.durationDays) : m(n.duration_days) ? globalThis.Number(n.duration_days) : 0 };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.domain !== "" && (t.domain = n.domain), n.ext !== "" && (t.ext = n.ext), n.durationDays !== 0 && (t.durationDays = Math.round(n.durationDays)), t;
}, create(n) {
  return Gt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Ln();
  return t.creator = n.creator ?? "", t.domain = n.domain ?? "", t.ext = n.ext ?? "", t.durationDays = n.durationDays ?? 0, t;
} };
function Gn() {
  return { creator: "", domain: "", ext: "", newOwner: "" };
}
var Kt = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.domain !== "" && t.uint32(18).string(n.domain), n.ext !== "" && t.uint32(26).string(n.ext), n.newOwner !== "" && t.uint32(34).string(n.newOwner), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Gn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.domain = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.ext = r.string();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.newOwner = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: m(n.creator) ? globalThis.String(n.creator) : "", domain: m(n.domain) ? globalThis.String(n.domain) : "", ext: m(n.ext) ? globalThis.String(n.ext) : "", newOwner: m(n.newOwner) ? globalThis.String(n.newOwner) : m(n.new_owner) ? globalThis.String(n.new_owner) : "" };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.domain !== "" && (t.domain = n.domain), n.ext !== "" && (t.ext = n.ext), n.newOwner !== "" && (t.newOwner = n.newOwner), t;
}, create(n) {
  return Kt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Gn();
  return t.creator = n.creator ?? "", t.domain = n.domain ?? "", t.ext = n.ext ?? "", t.newOwner = n.newOwner ?? "", t;
} };
function Kn() {
  return { creator: "", domain: "", ext: "", amount: "" };
}
var zt = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.domain !== "" && t.uint32(18).string(n.domain), n.ext !== "" && t.uint32(26).string(n.ext), n.amount !== "" && t.uint32(34).string(n.amount), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Kn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.domain = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.ext = r.string();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.amount = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: m(n.creator) ? globalThis.String(n.creator) : "", domain: m(n.domain) ? globalThis.String(n.domain) : "", ext: m(n.ext) ? globalThis.String(n.ext) : "", amount: m(n.amount) ? globalThis.String(n.amount) : "" };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.domain !== "" && (t.domain = n.domain), n.ext !== "" && (t.ext = n.ext), n.amount !== "" && (t.amount = n.amount), t;
}, create(n) {
  return zt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Kn();
  return t.creator = n.creator ?? "", t.domain = n.domain ?? "", t.ext = n.ext ?? "", t.amount = n.amount ?? "", t;
} };
function zn() {
  return { creator: "", domain: "", ext: "" };
}
var qt = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.domain !== "" && t.uint32(18).string(n.domain), n.ext !== "" && t.uint32(26).string(n.ext), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = zn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.domain = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.ext = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: m(n.creator) ? globalThis.String(n.creator) : "", domain: m(n.domain) ? globalThis.String(n.domain) : "", ext: m(n.ext) ? globalThis.String(n.ext) : "" };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.domain !== "" && (t.domain = n.domain), n.ext !== "" && (t.ext = n.ext), t;
}, create(n) {
  return qt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = zn();
  return t.creator = n.creator ?? "", t.domain = n.domain ?? "", t.ext = n.ext ?? "", t;
} };
function Pn(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function m(n) {
  return n != null;
}
function qn() {
  return { value: false };
}
var bn = { encode(n, t = new d()) {
  return n.value !== false && t.uint32(8).bool(n.value), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = qn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 8) break;
        i.value = r.bool();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { value: Vt(n.value) ? globalThis.Boolean(n.value) : false };
}, toJSON(n) {
  const t = {};
  return n.value !== false && (t.value = n.value), t;
}, create(n) {
  return bn.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = qn();
  return t.value = n.value ?? false, t;
} };
function Vn() {
  return { value: "" };
}
var Z = { encode(n, t = new d()) {
  return n.value !== "" && t.uint32(10).string(n.value), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Vn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.value = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { value: Vt(n.value) ? globalThis.String(n.value) : "" };
}, toJSON(n) {
  const t = {};
  return n.value !== "" && (t.value = n.value), t;
}, create(n) {
  return Z.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Vn();
  return t.value = n.value ?? "", t;
} };
function Vt(n) {
  return n != null;
}
function $n() {
  return { platformCommissionBps: 0, monthSeconds: 0, finalizeDelayMonths: 0, finalizerRewardBps: 0, minPriceUlmnPerMonth: 0, maxActiveContractsPerGateway: 0, actionFeeUlmn: 0, registerGatewayFeeUlmn: 0 };
}
var J = { encode(n, t = new d()) {
  return n.platformCommissionBps !== 0 && t.uint32(8).uint32(n.platformCommissionBps), n.monthSeconds !== 0 && t.uint32(16).uint64(n.monthSeconds), n.finalizeDelayMonths !== 0 && t.uint32(24).uint32(n.finalizeDelayMonths), n.finalizerRewardBps !== 0 && t.uint32(32).uint32(n.finalizerRewardBps), n.minPriceUlmnPerMonth !== 0 && t.uint32(40).uint64(n.minPriceUlmnPerMonth), n.maxActiveContractsPerGateway !== 0 && t.uint32(48).uint32(n.maxActiveContractsPerGateway), n.actionFeeUlmn !== 0 && t.uint32(56).uint64(n.actionFeeUlmn), n.registerGatewayFeeUlmn !== 0 && t.uint32(64).uint64(n.registerGatewayFeeUlmn), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = $n();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 8) break;
        i.platformCommissionBps = r.uint32();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.monthSeconds = an(r.uint64());
        continue;
      }
      case 3: {
        if (e !== 24) break;
        i.finalizeDelayMonths = r.uint32();
        continue;
      }
      case 4: {
        if (e !== 32) break;
        i.finalizerRewardBps = r.uint32();
        continue;
      }
      case 5: {
        if (e !== 40) break;
        i.minPriceUlmnPerMonth = an(r.uint64());
        continue;
      }
      case 6: {
        if (e !== 48) break;
        i.maxActiveContractsPerGateway = r.uint32();
        continue;
      }
      case 7: {
        if (e !== 56) break;
        i.actionFeeUlmn = an(r.uint64());
        continue;
      }
      case 8: {
        if (e !== 64) break;
        i.registerGatewayFeeUlmn = an(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { platformCommissionBps: k(n.platformCommissionBps) ? globalThis.Number(n.platformCommissionBps) : k(n.platform_commission_bps) ? globalThis.Number(n.platform_commission_bps) : 0, monthSeconds: k(n.monthSeconds) ? globalThis.Number(n.monthSeconds) : k(n.month_seconds) ? globalThis.Number(n.month_seconds) : 0, finalizeDelayMonths: k(n.finalizeDelayMonths) ? globalThis.Number(n.finalizeDelayMonths) : k(n.finalize_delay_months) ? globalThis.Number(n.finalize_delay_months) : 0, finalizerRewardBps: k(n.finalizerRewardBps) ? globalThis.Number(n.finalizerRewardBps) : k(n.finalizer_reward_bps) ? globalThis.Number(n.finalizer_reward_bps) : 0, minPriceUlmnPerMonth: k(n.minPriceUlmnPerMonth) ? globalThis.Number(n.minPriceUlmnPerMonth) : k(n.min_price_ulmn_per_month) ? globalThis.Number(n.min_price_ulmn_per_month) : 0, maxActiveContractsPerGateway: k(n.maxActiveContractsPerGateway) ? globalThis.Number(n.maxActiveContractsPerGateway) : k(n.max_active_contracts_per_gateway) ? globalThis.Number(n.max_active_contracts_per_gateway) : 0, actionFeeUlmn: k(n.actionFeeUlmn) ? globalThis.Number(n.actionFeeUlmn) : k(n.action_fee_ulmn) ? globalThis.Number(n.action_fee_ulmn) : 0, registerGatewayFeeUlmn: k(n.registerGatewayFeeUlmn) ? globalThis.Number(n.registerGatewayFeeUlmn) : k(n.register_gateway_fee_ulmn) ? globalThis.Number(n.register_gateway_fee_ulmn) : 0 };
}, toJSON(n) {
  const t = {};
  return n.platformCommissionBps !== 0 && (t.platformCommissionBps = Math.round(n.platformCommissionBps)), n.monthSeconds !== 0 && (t.monthSeconds = Math.round(n.monthSeconds)), n.finalizeDelayMonths !== 0 && (t.finalizeDelayMonths = Math.round(n.finalizeDelayMonths)), n.finalizerRewardBps !== 0 && (t.finalizerRewardBps = Math.round(n.finalizerRewardBps)), n.minPriceUlmnPerMonth !== 0 && (t.minPriceUlmnPerMonth = Math.round(n.minPriceUlmnPerMonth)), n.maxActiveContractsPerGateway !== 0 && (t.maxActiveContractsPerGateway = Math.round(n.maxActiveContractsPerGateway)), n.actionFeeUlmn !== 0 && (t.actionFeeUlmn = Math.round(n.actionFeeUlmn)), n.registerGatewayFeeUlmn !== 0 && (t.registerGatewayFeeUlmn = Math.round(n.registerGatewayFeeUlmn)), t;
}, create(n) {
  return J.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = $n();
  return t.platformCommissionBps = n.platformCommissionBps ?? 0, t.monthSeconds = n.monthSeconds ?? 0, t.finalizeDelayMonths = n.finalizeDelayMonths ?? 0, t.finalizerRewardBps = n.finalizerRewardBps ?? 0, t.minPriceUlmnPerMonth = n.minPriceUlmnPerMonth ?? 0, t.maxActiveContractsPerGateway = n.maxActiveContractsPerGateway ?? 0, t.actionFeeUlmn = n.actionFeeUlmn ?? 0, t.registerGatewayFeeUlmn = n.registerGatewayFeeUlmn ?? 0, t;
} };
function an(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function k(n) {
  return n != null;
}
function Wn() {
  return { operator: "", payout: "", metadata: "" };
}
var $t = { encode(n, t = new d()) {
  return n.operator !== "" && t.uint32(10).string(n.operator), n.payout !== "" && t.uint32(18).string(n.payout), n.metadata !== "" && t.uint32(26).string(n.metadata), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Wn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.operator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.payout = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.metadata = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { operator: f(n.operator) ? globalThis.String(n.operator) : "", payout: f(n.payout) ? globalThis.String(n.payout) : "", metadata: f(n.metadata) ? globalThis.String(n.metadata) : "" };
}, toJSON(n) {
  const t = {};
  return n.operator !== "" && (t.operator = n.operator), n.payout !== "" && (t.payout = n.payout), n.metadata !== "" && (t.metadata = n.metadata), t;
}, create(n) {
  return $t.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Wn();
  return t.operator = n.operator ?? "", t.payout = n.payout ?? "", t.metadata = n.metadata ?? "", t;
} };
function Hn() {
  return { operator: "", gatewayId: 0, payout: void 0, metadata: void 0, active: void 0 };
}
var Wt = { encode(n, t = new d()) {
  return n.operator !== "" && t.uint32(10).string(n.operator), n.gatewayId !== 0 && t.uint32(16).uint64(n.gatewayId), n.payout !== void 0 && Z.encode({ value: n.payout }, t.uint32(26).fork()).join(), n.metadata !== void 0 && Z.encode({ value: n.metadata }, t.uint32(34).fork()).join(), n.active !== void 0 && bn.encode({ value: n.active }, t.uint32(42).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Hn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.operator = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.gatewayId = D(r.uint64());
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.payout = Z.decode(r, r.uint32()).value;
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.metadata = Z.decode(r, r.uint32()).value;
        continue;
      }
      case 5: {
        if (e !== 42) break;
        i.active = bn.decode(r, r.uint32()).value;
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { operator: f(n.operator) ? globalThis.String(n.operator) : "", gatewayId: f(n.gatewayId) ? globalThis.Number(n.gatewayId) : f(n.gateway_id) ? globalThis.Number(n.gateway_id) : 0, payout: f(n.payout) ? String(n.payout) : void 0, metadata: f(n.metadata) ? String(n.metadata) : void 0, active: f(n.active) ? !!n.active : void 0 };
}, toJSON(n) {
  const t = {};
  return n.operator !== "" && (t.operator = n.operator), n.gatewayId !== 0 && (t.gatewayId = Math.round(n.gatewayId)), n.payout !== void 0 && (t.payout = n.payout), n.metadata !== void 0 && (t.metadata = n.metadata), n.active !== void 0 && (t.active = n.active), t;
}, create(n) {
  return Wt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Hn();
  return t.operator = n.operator ?? "", t.gatewayId = n.gatewayId ?? 0, t.payout = n.payout ?? void 0, t.metadata = n.metadata ?? void 0, t.active = n.active ?? void 0, t;
} };
function Qn() {
  return { authority: "", params: void 0 };
}
var Ht = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.params !== void 0 && J.encode(n.params, t.uint32(18).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Qn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.params = J.decode(r, r.uint32());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: f(n.authority) ? globalThis.String(n.authority) : "", params: f(n.params) ? J.fromJSON(n.params) : void 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.params !== void 0 && (t.params = J.toJSON(n.params)), t;
}, create(n) {
  return Ht.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Qn();
  return t.authority = n.authority ?? "", t.params = n.params !== void 0 && n.params !== null ? J.fromPartial(n.params) : void 0, t;
} };
function Xn() {
  return { client: "", gatewayId: 0, priceUlmn: 0, storageGbPerMonth: 0, networkGbPerMonth: 0, monthsTotal: 0, metadata: "" };
}
var Qt = { encode(n, t = new d()) {
  return n.client !== "" && t.uint32(10).string(n.client), n.gatewayId !== 0 && t.uint32(16).uint64(n.gatewayId), n.priceUlmn !== 0 && t.uint32(24).uint64(n.priceUlmn), n.storageGbPerMonth !== 0 && t.uint32(32).uint64(n.storageGbPerMonth), n.networkGbPerMonth !== 0 && t.uint32(40).uint64(n.networkGbPerMonth), n.monthsTotal !== 0 && t.uint32(48).uint32(n.monthsTotal), n.metadata !== "" && t.uint32(58).string(n.metadata), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Xn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.client = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.gatewayId = D(r.uint64());
        continue;
      }
      case 3: {
        if (e !== 24) break;
        i.priceUlmn = D(r.uint64());
        continue;
      }
      case 4: {
        if (e !== 32) break;
        i.storageGbPerMonth = D(r.uint64());
        continue;
      }
      case 5: {
        if (e !== 40) break;
        i.networkGbPerMonth = D(r.uint64());
        continue;
      }
      case 6: {
        if (e !== 48) break;
        i.monthsTotal = r.uint32();
        continue;
      }
      case 7: {
        if (e !== 58) break;
        i.metadata = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { client: f(n.client) ? globalThis.String(n.client) : "", gatewayId: f(n.gatewayId) ? globalThis.Number(n.gatewayId) : f(n.gateway_id) ? globalThis.Number(n.gateway_id) : 0, priceUlmn: f(n.priceUlmn) ? globalThis.Number(n.priceUlmn) : f(n.price_ulmn) ? globalThis.Number(n.price_ulmn) : 0, storageGbPerMonth: f(n.storageGbPerMonth) ? globalThis.Number(n.storageGbPerMonth) : f(n.storage_gb_per_month) ? globalThis.Number(n.storage_gb_per_month) : 0, networkGbPerMonth: f(n.networkGbPerMonth) ? globalThis.Number(n.networkGbPerMonth) : f(n.network_gb_per_month) ? globalThis.Number(n.network_gb_per_month) : 0, monthsTotal: f(n.monthsTotal) ? globalThis.Number(n.monthsTotal) : f(n.months_total) ? globalThis.Number(n.months_total) : 0, metadata: f(n.metadata) ? globalThis.String(n.metadata) : "" };
}, toJSON(n) {
  const t = {};
  return n.client !== "" && (t.client = n.client), n.gatewayId !== 0 && (t.gatewayId = Math.round(n.gatewayId)), n.priceUlmn !== 0 && (t.priceUlmn = Math.round(n.priceUlmn)), n.storageGbPerMonth !== 0 && (t.storageGbPerMonth = Math.round(n.storageGbPerMonth)), n.networkGbPerMonth !== 0 && (t.networkGbPerMonth = Math.round(n.networkGbPerMonth)), n.monthsTotal !== 0 && (t.monthsTotal = Math.round(n.monthsTotal)), n.metadata !== "" && (t.metadata = n.metadata), t;
}, create(n) {
  return Qt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Xn();
  return t.client = n.client ?? "", t.gatewayId = n.gatewayId ?? 0, t.priceUlmn = n.priceUlmn ?? 0, t.storageGbPerMonth = n.storageGbPerMonth ?? 0, t.networkGbPerMonth = n.networkGbPerMonth ?? 0, t.monthsTotal = n.monthsTotal ?? 0, t.metadata = n.metadata ?? "", t;
} };
function Yn() {
  return { operator: "", contractId: 0 };
}
var Xt = { encode(n, t = new d()) {
  return n.operator !== "" && t.uint32(10).string(n.operator), n.contractId !== 0 && t.uint32(16).uint64(n.contractId), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Yn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.operator = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.contractId = D(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { operator: f(n.operator) ? globalThis.String(n.operator) : "", contractId: f(n.contractId) ? globalThis.Number(n.contractId) : f(n.contract_id) ? globalThis.Number(n.contract_id) : 0 };
}, toJSON(n) {
  const t = {};
  return n.operator !== "" && (t.operator = n.operator), n.contractId !== 0 && (t.contractId = Math.round(n.contractId)), t;
}, create(n) {
  return Xt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Yn();
  return t.operator = n.operator ?? "", t.contractId = n.contractId ?? 0, t;
} };
function Zn() {
  return { client: "", contractId: 0 };
}
var Yt = { encode(n, t = new d()) {
  return n.client !== "" && t.uint32(10).string(n.client), n.contractId !== 0 && t.uint32(16).uint64(n.contractId), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Zn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.client = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.contractId = D(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { client: f(n.client) ? globalThis.String(n.client) : "", contractId: f(n.contractId) ? globalThis.Number(n.contractId) : f(n.contract_id) ? globalThis.Number(n.contract_id) : 0 };
}, toJSON(n) {
  const t = {};
  return n.client !== "" && (t.client = n.client), n.contractId !== 0 && (t.contractId = Math.round(n.contractId)), t;
}, create(n) {
  return Yt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Zn();
  return t.client = n.client ?? "", t.contractId = n.contractId ?? 0, t;
} };
function jn() {
  return { finalizer: "", contractId: 0 };
}
var Zt = { encode(n, t = new d()) {
  return n.finalizer !== "" && t.uint32(10).string(n.finalizer), n.contractId !== 0 && t.uint32(16).uint64(n.contractId), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = jn();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.finalizer = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.contractId = D(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { finalizer: f(n.finalizer) ? globalThis.String(n.finalizer) : "", contractId: f(n.contractId) ? globalThis.Number(n.contractId) : f(n.contract_id) ? globalThis.Number(n.contract_id) : 0 };
}, toJSON(n) {
  const t = {};
  return n.finalizer !== "" && (t.finalizer = n.finalizer), n.contractId !== 0 && (t.contractId = Math.round(n.contractId)), t;
}, create(n) {
  return Zt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = jn();
  return t.finalizer = n.finalizer ?? "", t.contractId = n.contractId ?? 0, t;
} };
function D(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function f(n) {
  return n != null;
}
function nt() {
  return { allowedPublishers: [], channels: [], maxArtifacts: 0, maxUrlsPerArt: 0, maxSigsPerArt: 0, maxNotesLen: 0, publishFeeUlmn: 0, maxPendingTtl: 0, daoPublishers: [], rejectRefundBps: 0, requireValidationForStable: false };
}
var L = { encode(n, t = new d()) {
  for (const r of n.allowedPublishers) t.uint32(10).string(r);
  for (const r of n.channels) t.uint32(18).string(r);
  n.maxArtifacts !== 0 && t.uint32(24).uint32(n.maxArtifacts), n.maxUrlsPerArt !== 0 && t.uint32(32).uint32(n.maxUrlsPerArt), n.maxSigsPerArt !== 0 && t.uint32(40).uint32(n.maxSigsPerArt), n.maxNotesLen !== 0 && t.uint32(48).uint32(n.maxNotesLen), n.publishFeeUlmn !== 0 && t.uint32(56).uint64(n.publishFeeUlmn), n.maxPendingTtl !== 0 && t.uint32(64).uint64(n.maxPendingTtl);
  for (const r of n.daoPublishers) t.uint32(74).string(r);
  return n.rejectRefundBps !== 0 && t.uint32(80).uint32(n.rejectRefundBps), n.requireValidationForStable !== false && t.uint32(88).bool(n.requireValidationForStable), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = nt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.allowedPublishers.push(r.string());
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.channels.push(r.string());
        continue;
      }
      case 3: {
        if (e !== 24) break;
        i.maxArtifacts = r.uint32();
        continue;
      }
      case 4: {
        if (e !== 32) break;
        i.maxUrlsPerArt = r.uint32();
        continue;
      }
      case 5: {
        if (e !== 40) break;
        i.maxSigsPerArt = r.uint32();
        continue;
      }
      case 6: {
        if (e !== 48) break;
        i.maxNotesLen = r.uint32();
        continue;
      }
      case 7: {
        if (e !== 56) break;
        i.publishFeeUlmn = tt(r.uint64());
        continue;
      }
      case 8: {
        if (e !== 64) break;
        i.maxPendingTtl = tt(r.uint64());
        continue;
      }
      case 9: {
        if (e !== 74) break;
        i.daoPublishers.push(r.string());
        continue;
      }
      case 10: {
        if (e !== 80) break;
        i.rejectRefundBps = r.uint32();
        continue;
      }
      case 11: {
        if (e !== 88) break;
        i.requireValidationForStable = r.bool();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { allowedPublishers: globalThis.Array.isArray(n == null ? void 0 : n.allowedPublishers) ? n.allowedPublishers.map((t) => globalThis.String(t)) : globalThis.Array.isArray(n == null ? void 0 : n.allowed_publishers) ? n.allowed_publishers.map((t) => globalThis.String(t)) : [], channels: globalThis.Array.isArray(n == null ? void 0 : n.channels) ? n.channels.map((t) => globalThis.String(t)) : [], maxArtifacts: T(n.maxArtifacts) ? globalThis.Number(n.maxArtifacts) : T(n.max_artifacts) ? globalThis.Number(n.max_artifacts) : 0, maxUrlsPerArt: T(n.maxUrlsPerArt) ? globalThis.Number(n.maxUrlsPerArt) : T(n.max_urls_per_art) ? globalThis.Number(n.max_urls_per_art) : 0, maxSigsPerArt: T(n.maxSigsPerArt) ? globalThis.Number(n.maxSigsPerArt) : T(n.max_sigs_per_art) ? globalThis.Number(n.max_sigs_per_art) : 0, maxNotesLen: T(n.maxNotesLen) ? globalThis.Number(n.maxNotesLen) : T(n.max_notes_len) ? globalThis.Number(n.max_notes_len) : 0, publishFeeUlmn: T(n.publishFeeUlmn) ? globalThis.Number(n.publishFeeUlmn) : T(n.publish_fee_ulmn) ? globalThis.Number(n.publish_fee_ulmn) : 0, maxPendingTtl: T(n.maxPendingTtl) ? globalThis.Number(n.maxPendingTtl) : T(n.max_pending_ttl) ? globalThis.Number(n.max_pending_ttl) : 0, daoPublishers: globalThis.Array.isArray(n == null ? void 0 : n.daoPublishers) ? n.daoPublishers.map((t) => globalThis.String(t)) : globalThis.Array.isArray(n == null ? void 0 : n.dao_publishers) ? n.dao_publishers.map((t) => globalThis.String(t)) : [], rejectRefundBps: T(n.rejectRefundBps) ? globalThis.Number(n.rejectRefundBps) : T(n.reject_refund_bps) ? globalThis.Number(n.reject_refund_bps) : 0, requireValidationForStable: T(n.requireValidationForStable) ? globalThis.Boolean(n.requireValidationForStable) : T(n.require_validation_for_stable) ? globalThis.Boolean(n.require_validation_for_stable) : false };
}, toJSON(n) {
  var _a, _b, _c;
  const t = {};
  return ((_a = n.allowedPublishers) == null ? void 0 : _a.length) && (t.allowedPublishers = n.allowedPublishers), ((_b = n.channels) == null ? void 0 : _b.length) && (t.channels = n.channels), n.maxArtifacts !== 0 && (t.maxArtifacts = Math.round(n.maxArtifacts)), n.maxUrlsPerArt !== 0 && (t.maxUrlsPerArt = Math.round(n.maxUrlsPerArt)), n.maxSigsPerArt !== 0 && (t.maxSigsPerArt = Math.round(n.maxSigsPerArt)), n.maxNotesLen !== 0 && (t.maxNotesLen = Math.round(n.maxNotesLen)), n.publishFeeUlmn !== 0 && (t.publishFeeUlmn = Math.round(n.publishFeeUlmn)), n.maxPendingTtl !== 0 && (t.maxPendingTtl = Math.round(n.maxPendingTtl)), ((_c = n.daoPublishers) == null ? void 0 : _c.length) && (t.daoPublishers = n.daoPublishers), n.rejectRefundBps !== 0 && (t.rejectRefundBps = Math.round(n.rejectRefundBps)), n.requireValidationForStable !== false && (t.requireValidationForStable = n.requireValidationForStable), t;
}, create(n) {
  return L.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a, _b, _c;
  const t = nt();
  return t.allowedPublishers = ((_a = n.allowedPublishers) == null ? void 0 : _a.map((r) => r)) || [], t.channels = ((_b = n.channels) == null ? void 0 : _b.map((r) => r)) || [], t.maxArtifacts = n.maxArtifacts ?? 0, t.maxUrlsPerArt = n.maxUrlsPerArt ?? 0, t.maxSigsPerArt = n.maxSigsPerArt ?? 0, t.maxNotesLen = n.maxNotesLen ?? 0, t.publishFeeUlmn = n.publishFeeUlmn ?? 0, t.maxPendingTtl = n.maxPendingTtl ?? 0, t.daoPublishers = ((_c = n.daoPublishers) == null ? void 0 : _c.map((r) => r)) || [], t.rejectRefundBps = n.rejectRefundBps ?? 0, t.requireValidationForStable = n.requireValidationForStable ?? false, t;
} };
function tt(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function T(n) {
  return n != null;
}
function Jr(n) {
  switch (n) {
    case 0:
    case "PENDING":
      return 0;
    case 1:
    case "VALIDATED":
      return 1;
    case 2:
    case "REJECTED":
      return 2;
    case 3:
    case "EXPIRED":
      return 3;
    default:
      return -1;
  }
}
function Lr(n) {
  switch (n) {
    case 0:
      return "PENDING";
    case 1:
      return "VALIDATED";
    case 2:
      return "REJECTED";
    case 3:
      return "EXPIRED";
    default:
      return "UNRECOGNIZED";
  }
}
function rt() {
  return { keyId: "", algo: "", sig: new Uint8Array(0) };
}
var G = { encode(n, t = new d()) {
  return n.keyId !== "" && t.uint32(10).string(n.keyId), n.algo !== "" && t.uint32(18).string(n.algo), n.sig.length !== 0 && t.uint32(26).bytes(n.sig), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = rt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.keyId = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.algo = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.sig = r.bytes();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { keyId: w(n.keyId) ? globalThis.String(n.keyId) : w(n.key_id) ? globalThis.String(n.key_id) : "", algo: w(n.algo) ? globalThis.String(n.algo) : "", sig: w(n.sig) ? Gr(n.sig) : new Uint8Array(0) };
}, toJSON(n) {
  const t = {};
  return n.keyId !== "" && (t.keyId = n.keyId), n.algo !== "" && (t.algo = n.algo), n.sig.length !== 0 && (t.sig = Kr(n.sig)), t;
}, create(n) {
  return G.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = rt();
  return t.keyId = n.keyId ?? "", t.algo = n.algo ?? "", t.sig = n.sig ?? new Uint8Array(0), t;
} };
function et() {
  return { platform: "", kind: "", cid: "", sha256Hex: "", size: 0, urls: [], signatures: [] };
}
var K = { encode(n, t = new d()) {
  n.platform !== "" && t.uint32(10).string(n.platform), n.kind !== "" && t.uint32(18).string(n.kind), n.cid !== "" && t.uint32(26).string(n.cid), n.sha256Hex !== "" && t.uint32(34).string(n.sha256Hex), n.size !== 0 && t.uint32(40).uint64(n.size);
  for (const r of n.urls) t.uint32(50).string(r);
  for (const r of n.signatures) G.encode(r, t.uint32(58).fork()).join();
  return t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = et();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.platform = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.kind = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.cid = r.string();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.sha256Hex = r.string();
        continue;
      }
      case 5: {
        if (e !== 40) break;
        i.size = q(r.uint64());
        continue;
      }
      case 6: {
        if (e !== 50) break;
        i.urls.push(r.string());
        continue;
      }
      case 7: {
        if (e !== 58) break;
        i.signatures.push(G.decode(r, r.uint32()));
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { platform: w(n.platform) ? globalThis.String(n.platform) : "", kind: w(n.kind) ? globalThis.String(n.kind) : "", cid: w(n.cid) ? globalThis.String(n.cid) : "", sha256Hex: w(n.sha256Hex) ? globalThis.String(n.sha256Hex) : w(n.sha256_hex) ? globalThis.String(n.sha256_hex) : "", size: w(n.size) ? globalThis.Number(n.size) : 0, urls: globalThis.Array.isArray(n == null ? void 0 : n.urls) ? n.urls.map((t) => globalThis.String(t)) : [], signatures: globalThis.Array.isArray(n == null ? void 0 : n.signatures) ? n.signatures.map((t) => G.fromJSON(t)) : [] };
}, toJSON(n) {
  var _a, _b;
  const t = {};
  return n.platform !== "" && (t.platform = n.platform), n.kind !== "" && (t.kind = n.kind), n.cid !== "" && (t.cid = n.cid), n.sha256Hex !== "" && (t.sha256Hex = n.sha256Hex), n.size !== 0 && (t.size = Math.round(n.size)), ((_a = n.urls) == null ? void 0 : _a.length) && (t.urls = n.urls), ((_b = n.signatures) == null ? void 0 : _b.length) && (t.signatures = n.signatures.map((r) => G.toJSON(r))), t;
}, create(n) {
  return K.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a, _b;
  const t = et();
  return t.platform = n.platform ?? "", t.kind = n.kind ?? "", t.cid = n.cid ?? "", t.sha256Hex = n.sha256Hex ?? "", t.size = n.size ?? 0, t.urls = ((_a = n.urls) == null ? void 0 : _a.map((r) => r)) || [], t.signatures = ((_b = n.signatures) == null ? void 0 : _b.map((r) => G.fromPartial(r))) || [], t;
} };
function it() {
  return { id: 0, version: "", channel: "", artifacts: [], publisher: "", notes: "", createdAt: 0, yanked: false, supersedes: [], status: 0, emergencyOk: false, emergencyUntil: 0 };
}
var z = { encode(n, t = new d()) {
  n.id !== 0 && t.uint32(8).uint64(n.id), n.version !== "" && t.uint32(18).string(n.version), n.channel !== "" && t.uint32(26).string(n.channel);
  for (const r of n.artifacts) K.encode(r, t.uint32(34).fork()).join();
  n.publisher !== "" && t.uint32(42).string(n.publisher), n.notes !== "" && t.uint32(50).string(n.notes), n.createdAt !== 0 && t.uint32(56).int64(n.createdAt), n.yanked !== false && t.uint32(64).bool(n.yanked), t.uint32(74).fork();
  for (const r of n.supersedes) t.uint64(r);
  return t.join(), n.status !== 0 && t.uint32(80).int32(n.status), n.emergencyOk !== false && t.uint32(88).bool(n.emergencyOk), n.emergencyUntil !== 0 && t.uint32(96).int64(n.emergencyUntil), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = it();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 8) break;
        i.id = q(r.uint64());
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.version = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.channel = r.string();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.artifacts.push(K.decode(r, r.uint32()));
        continue;
      }
      case 5: {
        if (e !== 42) break;
        i.publisher = r.string();
        continue;
      }
      case 6: {
        if (e !== 50) break;
        i.notes = r.string();
        continue;
      }
      case 7: {
        if (e !== 56) break;
        i.createdAt = q(r.int64());
        continue;
      }
      case 8: {
        if (e !== 64) break;
        i.yanked = r.bool();
        continue;
      }
      case 9: {
        if (e === 72) {
          i.supersedes.push(q(r.uint64()));
          continue;
        }
        if (e === 74) {
          const l = r.uint32() + r.pos;
          for (; r.pos < l; ) i.supersedes.push(q(r.uint64()));
          continue;
        }
        break;
      }
      case 10: {
        if (e !== 80) break;
        i.status = r.int32();
        continue;
      }
      case 11: {
        if (e !== 88) break;
        i.emergencyOk = r.bool();
        continue;
      }
      case 12: {
        if (e !== 96) break;
        i.emergencyUntil = q(r.int64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { id: w(n.id) ? globalThis.Number(n.id) : 0, version: w(n.version) ? globalThis.String(n.version) : "", channel: w(n.channel) ? globalThis.String(n.channel) : "", artifacts: globalThis.Array.isArray(n == null ? void 0 : n.artifacts) ? n.artifacts.map((t) => K.fromJSON(t)) : [], publisher: w(n.publisher) ? globalThis.String(n.publisher) : "", notes: w(n.notes) ? globalThis.String(n.notes) : "", createdAt: w(n.createdAt) ? globalThis.Number(n.createdAt) : w(n.created_at) ? globalThis.Number(n.created_at) : 0, yanked: w(n.yanked) ? globalThis.Boolean(n.yanked) : false, supersedes: globalThis.Array.isArray(n == null ? void 0 : n.supersedes) ? n.supersedes.map((t) => globalThis.Number(t)) : [], status: w(n.status) ? Jr(n.status) : 0, emergencyOk: w(n.emergencyOk) ? globalThis.Boolean(n.emergencyOk) : w(n.emergency_ok) ? globalThis.Boolean(n.emergency_ok) : false, emergencyUntil: w(n.emergencyUntil) ? globalThis.Number(n.emergencyUntil) : w(n.emergency_until) ? globalThis.Number(n.emergency_until) : 0 };
}, toJSON(n) {
  var _a, _b;
  const t = {};
  return n.id !== 0 && (t.id = Math.round(n.id)), n.version !== "" && (t.version = n.version), n.channel !== "" && (t.channel = n.channel), ((_a = n.artifacts) == null ? void 0 : _a.length) && (t.artifacts = n.artifacts.map((r) => K.toJSON(r))), n.publisher !== "" && (t.publisher = n.publisher), n.notes !== "" && (t.notes = n.notes), n.createdAt !== 0 && (t.createdAt = Math.round(n.createdAt)), n.yanked !== false && (t.yanked = n.yanked), ((_b = n.supersedes) == null ? void 0 : _b.length) && (t.supersedes = n.supersedes.map((r) => Math.round(r))), n.status !== 0 && (t.status = Lr(n.status)), n.emergencyOk !== false && (t.emergencyOk = n.emergencyOk), n.emergencyUntil !== 0 && (t.emergencyUntil = Math.round(n.emergencyUntil)), t;
}, create(n) {
  return z.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a, _b;
  const t = it();
  return t.id = n.id ?? 0, t.version = n.version ?? "", t.channel = n.channel ?? "", t.artifacts = ((_a = n.artifacts) == null ? void 0 : _a.map((r) => K.fromPartial(r))) || [], t.publisher = n.publisher ?? "", t.notes = n.notes ?? "", t.createdAt = n.createdAt ?? 0, t.yanked = n.yanked ?? false, t.supersedes = ((_b = n.supersedes) == null ? void 0 : _b.map((r) => r)) || [], t.status = n.status ?? 0, t.emergencyOk = n.emergencyOk ?? false, t.emergencyUntil = n.emergencyUntil ?? 0, t;
} };
function Gr(n) {
  if (globalThis.Buffer) return Uint8Array.from(globalThis.Buffer.from(n, "base64"));
  {
    const t = globalThis.atob(n), r = new Uint8Array(t.length);
    for (let o = 0; o < t.length; ++o) r[o] = t.charCodeAt(o);
    return r;
  }
}
function Kr(n) {
  if (globalThis.Buffer) return globalThis.Buffer.from(n).toString("base64");
  {
    const t = [];
    return n.forEach((r) => {
      t.push(globalThis.String.fromCharCode(r));
    }), globalThis.btoa(t.join(""));
  }
}
function q(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function w(n) {
  return n != null;
}
function at() {
  return { creator: "", release: void 0 };
}
var jt = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.release !== void 0 && z.encode(n.release, t.uint32(18).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = at();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.release = z.decode(r, r.uint32());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: _(n.creator) ? globalThis.String(n.creator) : "", release: _(n.release) ? z.fromJSON(n.release) : void 0 };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.release !== void 0 && (t.release = z.toJSON(n.release)), t;
}, create(n) {
  return jt.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = at();
  return t.creator = n.creator ?? "", t.release = n.release !== void 0 && n.release !== null ? z.fromPartial(n.release) : void 0, t;
} };
function ot() {
  return { creator: "", id: 0, emergencyOk: false, emergencyTtl: 0 };
}
var nr = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.id !== 0 && t.uint32(16).uint64(n.id), n.emergencyOk !== false && t.uint32(24).bool(n.emergencyOk), n.emergencyTtl !== 0 && t.uint32(32).int64(n.emergencyTtl), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = ot();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.id = cn(r.uint64());
        continue;
      }
      case 3: {
        if (e !== 24) break;
        i.emergencyOk = r.bool();
        continue;
      }
      case 4: {
        if (e !== 32) break;
        i.emergencyTtl = cn(r.int64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: _(n.creator) ? globalThis.String(n.creator) : "", id: _(n.id) ? globalThis.Number(n.id) : 0, emergencyOk: _(n.emergencyOk) ? globalThis.Boolean(n.emergencyOk) : _(n.emergency_ok) ? globalThis.Boolean(n.emergency_ok) : false, emergencyTtl: _(n.emergencyTtl) ? globalThis.Number(n.emergencyTtl) : _(n.emergency_ttl) ? globalThis.Number(n.emergency_ttl) : 0 };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.id !== 0 && (t.id = Math.round(n.id)), n.emergencyOk !== false && (t.emergencyOk = n.emergencyOk), n.emergencyTtl !== 0 && (t.emergencyTtl = Math.round(n.emergencyTtl)), t;
}, create(n) {
  return nr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = ot();
  return t.creator = n.creator ?? "", t.id = n.id ?? 0, t.emergencyOk = n.emergencyOk ?? false, t.emergencyTtl = n.emergencyTtl ?? 0, t;
} };
function st() {
  return { authority: "", id: 0 };
}
var tr = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.id !== 0 && t.uint32(16).uint64(n.id), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = st();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.id = cn(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: _(n.authority) ? globalThis.String(n.authority) : "", id: _(n.id) ? globalThis.Number(n.id) : 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.id !== 0 && (t.id = Math.round(n.id)), t;
}, create(n) {
  return tr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = st();
  return t.authority = n.authority ?? "", t.id = n.id ?? 0, t;
} };
function lt() {
  return { authority: "", id: 0 };
}
var rr = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.id !== 0 && t.uint32(16).uint64(n.id), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = lt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.id = cn(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: _(n.authority) ? globalThis.String(n.authority) : "", id: _(n.id) ? globalThis.Number(n.id) : 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.id !== 0 && (t.id = Math.round(n.id)), t;
}, create(n) {
  return rr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = lt();
  return t.authority = n.authority ?? "", t.id = n.id ?? 0, t;
} };
function ut() {
  return { authority: "", params: void 0 };
}
var er = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.params !== void 0 && L.encode(n.params, t.uint32(18).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = ut();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.params = L.decode(r, r.uint32());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: _(n.authority) ? globalThis.String(n.authority) : "", params: _(n.params) ? L.fromJSON(n.params) : void 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.params !== void 0 && (t.params = L.toJSON(n.params)), t;
}, create(n) {
  return er.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = ut();
  return t.authority = n.authority ?? "", t.params = n.params !== void 0 && n.params !== null ? L.fromPartial(n.params) : void 0, t;
} };
function cn(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function _(n) {
  return n != null;
}
function ct() {
  return { denom: "", amount: "" };
}
var b = { encode(n, t = new d()) {
  return n.denom !== "" && t.uint32(10).string(n.denom), n.amount !== "" && t.uint32(18).string(n.amount), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = ct();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.denom = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.amount = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { denom: dt(n.denom) ? globalThis.String(n.denom) : "", amount: dt(n.amount) ? globalThis.String(n.amount) : "" };
}, toJSON(n) {
  const t = {};
  return n.denom !== "" && (t.denom = n.denom), n.amount !== "" && (t.amount = n.amount), t;
}, create(n) {
  return b.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = ct();
  return t.denom = n.denom ?? "", t.amount = n.amount ?? "", t;
} };
function dt(n) {
  return n != null;
}
function ft() {
  return { txTaxRate: "", initialRewardPerBlockLumn: 0, halvingIntervalBlocks: 0, supplyCapLumn: 0, decimals: 0, minSendUlmn: 0, denom: "", distributionIntervalBlocks: 0 };
}
var V = { encode(n, t = new d()) {
  return n.txTaxRate !== "" && t.uint32(10).string(n.txTaxRate), n.initialRewardPerBlockLumn !== 0 && t.uint32(16).uint64(n.initialRewardPerBlockLumn), n.halvingIntervalBlocks !== 0 && t.uint32(24).uint64(n.halvingIntervalBlocks), n.supplyCapLumn !== 0 && t.uint32(32).uint64(n.supplyCapLumn), n.decimals !== 0 && t.uint32(40).uint32(n.decimals), n.minSendUlmn !== 0 && t.uint32(48).uint64(n.minSendUlmn), n.denom !== "" && t.uint32(58).string(n.denom), n.distributionIntervalBlocks !== 0 && t.uint32(64).uint64(n.distributionIntervalBlocks), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = ft();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.txTaxRate = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.initialRewardPerBlockLumn = X(r.uint64());
        continue;
      }
      case 3: {
        if (e !== 24) break;
        i.halvingIntervalBlocks = X(r.uint64());
        continue;
      }
      case 4: {
        if (e !== 32) break;
        i.supplyCapLumn = X(r.uint64());
        continue;
      }
      case 5: {
        if (e !== 40) break;
        i.decimals = r.uint32();
        continue;
      }
      case 6: {
        if (e !== 48) break;
        i.minSendUlmn = X(r.uint64());
        continue;
      }
      case 7: {
        if (e !== 58) break;
        i.denom = r.string();
        continue;
      }
      case 8: {
        if (e !== 64) break;
        i.distributionIntervalBlocks = X(r.uint64());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { txTaxRate: v(n.txTaxRate) ? globalThis.String(n.txTaxRate) : v(n.tx_tax_rate) ? globalThis.String(n.tx_tax_rate) : "", initialRewardPerBlockLumn: v(n.initialRewardPerBlockLumn) ? globalThis.Number(n.initialRewardPerBlockLumn) : v(n.initial_reward_per_block_lumn) ? globalThis.Number(n.initial_reward_per_block_lumn) : 0, halvingIntervalBlocks: v(n.halvingIntervalBlocks) ? globalThis.Number(n.halvingIntervalBlocks) : v(n.halving_interval_blocks) ? globalThis.Number(n.halving_interval_blocks) : 0, supplyCapLumn: v(n.supplyCapLumn) ? globalThis.Number(n.supplyCapLumn) : v(n.supply_cap_lumn) ? globalThis.Number(n.supply_cap_lumn) : 0, decimals: v(n.decimals) ? globalThis.Number(n.decimals) : 0, minSendUlmn: v(n.minSendUlmn) ? globalThis.Number(n.minSendUlmn) : v(n.min_send_ulmn) ? globalThis.Number(n.min_send_ulmn) : 0, denom: v(n.denom) ? globalThis.String(n.denom) : "", distributionIntervalBlocks: v(n.distributionIntervalBlocks) ? globalThis.Number(n.distributionIntervalBlocks) : v(n.distribution_interval_blocks) ? globalThis.Number(n.distribution_interval_blocks) : 0 };
}, toJSON(n) {
  const t = {};
  return n.txTaxRate !== "" && (t.txTaxRate = n.txTaxRate), n.initialRewardPerBlockLumn !== 0 && (t.initialRewardPerBlockLumn = Math.round(n.initialRewardPerBlockLumn)), n.halvingIntervalBlocks !== 0 && (t.halvingIntervalBlocks = Math.round(n.halvingIntervalBlocks)), n.supplyCapLumn !== 0 && (t.supplyCapLumn = Math.round(n.supplyCapLumn)), n.decimals !== 0 && (t.decimals = Math.round(n.decimals)), n.minSendUlmn !== 0 && (t.minSendUlmn = Math.round(n.minSendUlmn)), n.denom !== "" && (t.denom = n.denom), n.distributionIntervalBlocks !== 0 && (t.distributionIntervalBlocks = Math.round(n.distributionIntervalBlocks)), t;
}, create(n) {
  return V.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = ft();
  return t.txTaxRate = n.txTaxRate ?? "", t.initialRewardPerBlockLumn = n.initialRewardPerBlockLumn ?? 0, t.halvingIntervalBlocks = n.halvingIntervalBlocks ?? 0, t.supplyCapLumn = n.supplyCapLumn ?? 0, t.decimals = n.decimals ?? 0, t.minSendUlmn = n.minSendUlmn ?? 0, t.denom = n.denom ?? "", t.distributionIntervalBlocks = n.distributionIntervalBlocks ?? 0, t;
} };
function X(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function v(n) {
  return n != null;
}
function mt() {
  return { authority: "", params: void 0 };
}
var ir = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.params !== void 0 && V.encode(n.params, t.uint32(18).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = mt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.params = V.decode(r, r.uint32());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: S(n.authority) ? globalThis.String(n.authority) : "", params: S(n.params) ? V.fromJSON(n.params) : void 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.params !== void 0 && (t.params = V.toJSON(n.params)), t;
}, create(n) {
  return ir.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = mt();
  return t.authority = n.authority ?? "", t.params = n.params !== void 0 && n.params !== null ? V.fromPartial(n.params) : void 0, t;
} };
function ht() {
  return { authority: "", minDeposit: [] };
}
var ar = { encode(n, t = new d()) {
  n.authority !== "" && t.uint32(10).string(n.authority);
  for (const r of n.minDeposit) b.encode(r, t.uint32(18).fork()).join();
  return t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = ht();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.minDeposit.push(b.decode(r, r.uint32()));
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: S(n.authority) ? globalThis.String(n.authority) : "", minDeposit: globalThis.Array.isArray(n == null ? void 0 : n.minDeposit) ? n.minDeposit.map((t) => b.fromJSON(t)) : globalThis.Array.isArray(n == null ? void 0 : n.min_deposit) ? n.min_deposit.map((t) => b.fromJSON(t)) : [] };
}, toJSON(n) {
  var _a;
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), ((_a = n.minDeposit) == null ? void 0 : _a.length) && (t.minDeposit = n.minDeposit.map((r) => b.toJSON(r))), t;
}, create(n) {
  return ar.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a;
  const t = ht();
  return t.authority = n.authority ?? "", t.minDeposit = ((_a = n.minDeposit) == null ? void 0 : _a.map((r) => b.fromPartial(r))) || [], t;
} };
function pt() {
  return { authority: "", recipient: "", amount: [] };
}
var or = { encode(n, t = new d()) {
  n.authority !== "" && t.uint32(10).string(n.authority), n.recipient !== "" && t.uint32(18).string(n.recipient);
  for (const r of n.amount) b.encode(r, t.uint32(26).fork()).join();
  return t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = pt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.recipient = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.amount.push(b.decode(r, r.uint32()));
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: S(n.authority) ? globalThis.String(n.authority) : "", recipient: S(n.recipient) ? globalThis.String(n.recipient) : "", amount: globalThis.Array.isArray(n == null ? void 0 : n.amount) ? n.amount.map((t) => b.fromJSON(t)) : [] };
}, toJSON(n) {
  var _a;
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.recipient !== "" && (t.recipient = n.recipient), ((_a = n.amount) == null ? void 0 : _a.length) && (t.amount = n.amount.map((r) => b.toJSON(r))), t;
}, create(n) {
  return or.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a;
  const t = pt();
  return t.authority = n.authority ?? "", t.recipient = n.recipient ?? "", t.amount = ((_a = n.amount) == null ? void 0 : _a.map((r) => b.fromPartial(r))) || [], t;
} };
function yt() {
  return { authority: "", slashFractionDowntime: "", downtimeJailDuration: "" };
}
var sr = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.slashFractionDowntime !== "" && t.uint32(18).string(n.slashFractionDowntime), n.downtimeJailDuration !== "" && t.uint32(26).string(n.downtimeJailDuration), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = yt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.slashFractionDowntime = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.downtimeJailDuration = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: S(n.authority) ? globalThis.String(n.authority) : "", slashFractionDowntime: S(n.slashFractionDowntime) ? globalThis.String(n.slashFractionDowntime) : S(n.slash_fraction_downtime) ? globalThis.String(n.slash_fraction_downtime) : "", downtimeJailDuration: S(n.downtimeJailDuration) ? globalThis.String(n.downtimeJailDuration) : S(n.downtime_jail_duration) ? globalThis.String(n.downtime_jail_duration) : "" };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.slashFractionDowntime !== "" && (t.slashFractionDowntime = n.slashFractionDowntime), n.downtimeJailDuration !== "" && (t.downtimeJailDuration = n.downtimeJailDuration), t;
}, create(n) {
  return sr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = yt();
  return t.authority = n.authority ?? "", t.slashFractionDowntime = n.slashFractionDowntime ?? "", t.downtimeJailDuration = n.downtimeJailDuration ?? "", t;
} };
function gt() {
  return { authority: "", signedBlocksWindow: 0, minSignedPerWindow: "" };
}
var lr = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.signedBlocksWindow !== 0 && t.uint32(16).int64(n.signedBlocksWindow), n.minSignedPerWindow !== "" && t.uint32(26).string(n.minSignedPerWindow), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = gt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 16) break;
        i.signedBlocksWindow = zr(r.int64());
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.minSignedPerWindow = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: S(n.authority) ? globalThis.String(n.authority) : "", signedBlocksWindow: S(n.signedBlocksWindow) ? globalThis.Number(n.signedBlocksWindow) : S(n.signed_blocks_window) ? globalThis.Number(n.signed_blocks_window) : 0, minSignedPerWindow: S(n.minSignedPerWindow) ? globalThis.String(n.minSignedPerWindow) : S(n.min_signed_per_window) ? globalThis.String(n.min_signed_per_window) : "" };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.signedBlocksWindow !== 0 && (t.signedBlocksWindow = Math.round(n.signedBlocksWindow)), n.minSignedPerWindow !== "" && (t.minSignedPerWindow = n.minSignedPerWindow), t;
}, create(n) {
  return lr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = gt();
  return t.authority = n.authority ?? "", t.signedBlocksWindow = n.signedBlocksWindow ?? 0, t.minSignedPerWindow = n.minSignedPerWindow ?? "", t;
} };
function zr(n) {
  const t = globalThis.Number(n.toString());
  if (t > globalThis.Number.MAX_SAFE_INTEGER) throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  if (t < globalThis.Number.MIN_SAFE_INTEGER) throw new globalThis.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
  return t;
}
function S(n) {
  return n != null;
}
function qr(n) {
  switch (n) {
    case 0:
    case "PQC_POLICY_DISABLED":
      return 0;
    case 1:
    case "PQC_POLICY_OPTIONAL":
      return 1;
    case 2:
    case "PQC_POLICY_REQUIRED":
      return 2;
    default:
      return -1;
  }
}
function Vr(n) {
  switch (n) {
    case 0:
      return "PQC_POLICY_DISABLED";
    case 1:
      return "PQC_POLICY_OPTIONAL";
    case 2:
      return "PQC_POLICY_REQUIRED";
    default:
      return "UNRECOGNIZED";
  }
}
function wt() {
  return { policy: 0, minScheme: "", minBalanceForLink: void 0, powDifficultyBits: 0, ibcRelayerAllowlist: [] };
}
var $ = { encode(n, t = new d()) {
  n.policy !== 0 && t.uint32(8).int32(n.policy), n.minScheme !== "" && t.uint32(26).string(n.minScheme), n.minBalanceForLink !== void 0 && b.encode(n.minBalanceForLink, t.uint32(42).fork()).join(), n.powDifficultyBits !== 0 && t.uint32(48).uint32(n.powDifficultyBits);
  for (const r of n.ibcRelayerAllowlist) t.uint32(58).string(r);
  return t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = wt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 8) break;
        i.policy = r.int32();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.minScheme = r.string();
        continue;
      }
      case 5: {
        if (e !== 42) break;
        i.minBalanceForLink = b.decode(r, r.uint32());
        continue;
      }
      case 6: {
        if (e !== 48) break;
        i.powDifficultyBits = r.uint32();
        continue;
      }
      case 7: {
        if (e !== 58) break;
        i.ibcRelayerAllowlist.push(r.string());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { policy: O(n.policy) ? qr(n.policy) : 0, minScheme: O(n.minScheme) ? globalThis.String(n.minScheme) : O(n.min_scheme) ? globalThis.String(n.min_scheme) : "", minBalanceForLink: O(n.minBalanceForLink) ? b.fromJSON(n.minBalanceForLink) : O(n.min_balance_for_link) ? b.fromJSON(n.min_balance_for_link) : void 0, powDifficultyBits: O(n.powDifficultyBits) ? globalThis.Number(n.powDifficultyBits) : O(n.pow_difficulty_bits) ? globalThis.Number(n.pow_difficulty_bits) : 0, ibcRelayerAllowlist: globalThis.Array.isArray(n == null ? void 0 : n.ibcRelayerAllowlist) ? n.ibcRelayerAllowlist.map((t) => globalThis.String(t)) : globalThis.Array.isArray(n == null ? void 0 : n.ibc_relayer_allowlist) ? n.ibc_relayer_allowlist.map((t) => globalThis.String(t)) : [] };
}, toJSON(n) {
  var _a;
  const t = {};
  return n.policy !== 0 && (t.policy = Vr(n.policy)), n.minScheme !== "" && (t.minScheme = n.minScheme), n.minBalanceForLink !== void 0 && (t.minBalanceForLink = b.toJSON(n.minBalanceForLink)), n.powDifficultyBits !== 0 && (t.powDifficultyBits = Math.round(n.powDifficultyBits)), ((_a = n.ibcRelayerAllowlist) == null ? void 0 : _a.length) && (t.ibcRelayerAllowlist = n.ibcRelayerAllowlist), t;
}, create(n) {
  return $.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a;
  const t = wt();
  return t.policy = n.policy ?? 0, t.minScheme = n.minScheme ?? "", t.minBalanceForLink = n.minBalanceForLink !== void 0 && n.minBalanceForLink !== null ? b.fromPartial(n.minBalanceForLink) : void 0, t.powDifficultyBits = n.powDifficultyBits ?? 0, t.ibcRelayerAllowlist = ((_a = n.ibcRelayerAllowlist) == null ? void 0 : _a.map((r) => r)) || [], t;
} };
function O(n) {
  return n != null;
}
function bt() {
  return { authority: "", params: void 0 };
}
var ur = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.params !== void 0 && $.encode(n.params, t.uint32(18).fork()).join(), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = bt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.params = $.decode(r, r.uint32());
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: U(n.authority) ? globalThis.String(n.authority) : "", params: U(n.params) ? $.fromJSON(n.params) : void 0 };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.params !== void 0 && (t.params = $.toJSON(n.params)), t;
}, create(n) {
  return ur.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = bt();
  return t.authority = n.authority ?? "", t.params = n.params !== void 0 && n.params !== null ? $.fromPartial(n.params) : void 0, t;
} };
function kt() {
  return { authority: "", relayer: "" };
}
var cr = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.relayer !== "" && t.uint32(18).string(n.relayer), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = kt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.relayer = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: U(n.authority) ? globalThis.String(n.authority) : "", relayer: U(n.relayer) ? globalThis.String(n.relayer) : "" };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.relayer !== "" && (t.relayer = n.relayer), t;
}, create(n) {
  return cr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = kt();
  return t.authority = n.authority ?? "", t.relayer = n.relayer ?? "", t;
} };
function Tt() {
  return { authority: "", relayer: "" };
}
var dr = { encode(n, t = new d()) {
  return n.authority !== "" && t.uint32(10).string(n.authority), n.relayer !== "" && t.uint32(18).string(n.relayer), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Tt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.authority = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.relayer = r.string();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { authority: U(n.authority) ? globalThis.String(n.authority) : "", relayer: U(n.relayer) ? globalThis.String(n.relayer) : "" };
}, toJSON(n) {
  const t = {};
  return n.authority !== "" && (t.authority = n.authority), n.relayer !== "" && (t.relayer = n.relayer), t;
}, create(n) {
  return dr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Tt();
  return t.authority = n.authority ?? "", t.relayer = n.relayer ?? "", t;
} };
function St() {
  return { creator: "", scheme: "", pubKey: new Uint8Array(0), powNonce: new Uint8Array(0) };
}
var fr = { encode(n, t = new d()) {
  return n.creator !== "" && t.uint32(10).string(n.creator), n.scheme !== "" && t.uint32(18).string(n.scheme), n.pubKey.length !== 0 && t.uint32(26).bytes(n.pubKey), n.powNonce.length !== 0 && t.uint32(34).bytes(n.powNonce), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = St();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.creator = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.scheme = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.pubKey = r.bytes();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.powNonce = r.bytes();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { creator: U(n.creator) ? globalThis.String(n.creator) : "", scheme: U(n.scheme) ? globalThis.String(n.scheme) : "", pubKey: U(n.pubKey) ? on(n.pubKey) : U(n.pub_key) ? on(n.pub_key) : new Uint8Array(0), powNonce: U(n.powNonce) ? on(n.powNonce) : U(n.pow_nonce) ? on(n.pow_nonce) : new Uint8Array(0) };
}, toJSON(n) {
  const t = {};
  return n.creator !== "" && (t.creator = n.creator), n.scheme !== "" && (t.scheme = n.scheme), n.pubKey.length !== 0 && (t.pubKey = vt(n.pubKey)), n.powNonce.length !== 0 && (t.powNonce = vt(n.powNonce)), t;
}, create(n) {
  return fr.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = St();
  return t.creator = n.creator ?? "", t.scheme = n.scheme ?? "", t.pubKey = n.pubKey ?? new Uint8Array(0), t.powNonce = n.powNonce ?? new Uint8Array(0), t;
} };
function on(n) {
  if (globalThis.Buffer) return Uint8Array.from(globalThis.Buffer.from(n, "base64"));
  {
    const t = globalThis.atob(n), r = new Uint8Array(t.length);
    for (let o = 0; o < t.length; ++o) r[o] = t.charCodeAt(o);
    return r;
  }
}
function vt(n) {
  if (globalThis.Buffer) return globalThis.Buffer.from(n).toString("base64");
  {
    const t = [];
    return n.forEach((r) => {
      t.push(globalThis.String.fromCharCode(r));
    }), globalThis.btoa(t.join(""));
  }
}
function U(n) {
  return n != null;
}
var $r = {};
tn($r, { DnsModule: () => Xr, GatewaysModule: () => Yr, GovModule: () => re, PqcModule: () => te, ReleasesModule: () => jr, TokenomicsModule: () => ne });
var Wr = 12e3;
async function Hr(n, t = {}) {
  const r = new AbortController(), o = setTimeout(() => r.abort(), t.timeoutMs ?? Wr);
  try {
    const i = await fetch(n, { ...t, signal: r.signal }), e = await i.text();
    let l = null;
    if (e) try {
      l = JSON.parse(e);
    } catch {
      l = e;
    }
    if (!i.ok) {
      const c = typeof l == "string" ? l : i.statusText;
      throw new Error(`${i.status} ${c}`);
    }
    return l;
  } finally {
    clearTimeout(o);
  }
}
function Qr(n, t) {
  if (!t) return n;
  const r = new URLSearchParams();
  for (const [i, e] of Object.entries(t)) e != null && r.set(i, String(e));
  const o = r.toString();
  return o ? `${n}?${o}` : n;
}
function F(n, t) {
  const r = n.replace(/\/+$/, ""), o = t.startsWith("/") ? t : `/${t}`;
  return `${r}${o}`;
}
var Q = class {
  constructor(n) {
    this.restEndpoint = n;
  }
  ensureRest() {
    if (!this.restEndpoint) throw new Error("REST endpoint is not configured on LumenClient");
    return this.restEndpoint;
  }
  async get(n, t, r) {
    const o = this.ensureRest(), i = Qr(F(o, n), t);
    return Hr(i, r);
  }
}, Xr = class extends Q {
  constructor(n) {
    const t = n ? F(n, "/lumen/dns/v1") : void 0;
    super(t);
    __publicField(this, "base");
    this.base = t;
  }
  async params() {
    return this.get("/params");
  }
  async resolve(n, t, r) {
    const o = [encodeURIComponent(n), encodeURIComponent(t), encodeURIComponent((r == null ? void 0 : r.records) ?? "-"), String((r == null ? void 0 : r.expireAt) ?? 0), encodeURIComponent((r == null ? void 0 : r.status) ?? "-")];
    return this.get(`/resolve/${o.join("/")}`);
  }
  async domainsByOwner(n) {
    return this.get(`/domains_by_owner/${encodeURIComponent(n)}`);
  }
  async auctionStatus(n, t) {
    const r = [encodeURIComponent(n), encodeURIComponent(t), "0", "-", "-"];
    return this.get(`/auction_status/${r.join("/")}`);
  }
  async baseFeeDns(n) {
    const t = [String((n == null ? void 0 : n.t) ?? 0), encodeURIComponent((n == null ? void 0 : n.alpha) ?? "-"), encodeURIComponent((n == null ? void 0 : n.floor) ?? "-"), encodeURIComponent((n == null ? void 0 : n.ceiling) ?? "-")];
    return this.get(`/base_fee_dns/${t.join("/")}`);
  }
  async domain(n) {
    return this.get(`/domain/${encodeURIComponent(n)}`);
  }
  async domains(n = {}) {
    return this.get("/domain", _t(n.pageKey, n.limit));
  }
  async auction(n) {
    return this.get(`/auction/${encodeURIComponent(n)}`);
  }
  async auctions(n = {}) {
    return this.get("/auction", _t(n.pageKey, n.limit));
  }
  msgUpdateParams(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgUpdateParams", value: Ct.fromPartial({ authority: n, params: t }) };
  }
  msgRegister(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgRegister", value: Jt.fromPartial({ creator: n, domain: t.domain, ext: t.ext, records: t.records ?? [], durationDays: t.durationDays ?? 0, owner: t.owner ?? "" }) };
  }
  msgUpdate(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgUpdate", value: Lt.fromPartial({ creator: n, domain: t.domain, ext: t.ext, records: t.records ?? [], powNonce: t.powNonce ?? 0 }) };
  }
  msgRenew(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgRenew", value: Gt.fromPartial({ creator: n, domain: t.domain, ext: t.ext, durationDays: t.durationDays ?? 0 }) };
  }
  msgTransfer(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgTransfer", value: Kt.fromPartial({ creator: n, domain: t.domain, ext: t.ext, newOwner: t.newOwner }) };
  }
  msgBid(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgBid", value: zt.fromPartial({ creator: n, domain: t.domain, ext: t.ext, amount: String(t.amount) }) };
  }
  msgSettle(n, t) {
    return { typeUrl: "/lumen.dns.v1.MsgSettle", value: qt.fromPartial({ creator: n, domain: t.domain, ext: t.ext }) };
  }
};
function _t(n, t) {
  const r = {};
  return n && (r["pagination.key"] = n), t != null && (r["pagination.limit"] = String(t)), r;
}
var Yr = class extends Q {
  constructor(n) {
    const t = n ? F(n, "/lumen/gateway/v1") : void 0;
    super(t);
  }
  params() {
    return this.get("/params");
  }
  authority() {
    return this.get("/authority");
  }
  moduleAccounts() {
    return this.get("/module_accounts");
  }
  gateways(n = {}) {
    return this.get("/gateways", Zr(n.offset, n.limit));
  }
  gateway(n) {
    return this.get(`/gateways/${encodeURIComponent(String(n))}`);
  }
  contracts(n = {}) {
    const t = {};
    return n.status && (t.status = String(n.status)), n.client && (t.client = String(n.client)), n.gatewayId != null && (t.gateway_id = String(n.gatewayId)), n.offset != null && (t.offset = String(n.offset)), n.limit != null && (t.limit = String(n.limit)), this.get("/contracts", t);
  }
  contract(n) {
    return this.get(`/contracts/${encodeURIComponent(String(n))}`);
  }
  msgUpdateParams(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgUpdateParams", value: Ht.fromPartial({ authority: n, params: t }) };
  }
  msgRegisterGateway(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgRegisterGateway", value: $t.fromPartial({ operator: n, payout: t.payout, metadata: t.metadata ?? "" }) };
  }
  msgUpdateGateway(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgUpdateGateway", value: Wt.fromPartial({ operator: n, gatewayId: Number(t.gatewayId), payout: t.payout ?? void 0, metadata: t.metadata ?? void 0, active: t.active ?? void 0 }) };
  }
  msgCreateContract(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgCreateContract", value: Qt.fromPartial({ client: n, gatewayId: Number(t.gatewayId), priceUlmn: Number(t.priceUlmn), storageGbPerMonth: Number(t.storageGbPerMonth), networkGbPerMonth: Number(t.networkGbPerMonth), monthsTotal: Number(t.monthsTotal), metadata: t.metadata ?? "" }) };
  }
  msgClaimPayment(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgClaimPayment", value: Xt.fromPartial({ operator: n, contractId: Number(t) }) };
  }
  msgCancelContract(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgCancelContract", value: Yt.fromPartial({ client: n, contractId: Number(t) }) };
  }
  msgFinalizeContract(n, t) {
    return { typeUrl: "/lumen.gateway.v1.MsgFinalizeContract", value: Zt.fromPartial({ finalizer: n, contractId: Number(t) }) };
  }
};
function Zr(n, t) {
  const r = {};
  return n != null && (r.offset = String(n)), t != null && (r.limit = String(t)), r;
}
var jr = class extends Q {
  constructor(n) {
    const t = n ? F(n, "/lumen/release") : void 0;
    super(t);
  }
  params() {
    return this.get("/params");
  }
  release(n) {
    return this.get(`/id/${encodeURIComponent(String(n))}`);
  }
  releaseById(n) {
    return this.get(`/release/${encodeURIComponent(String(n))}`);
  }
  releases(n = {}) {
    const t = {};
    return n.page != null && (t.page = String(n.page)), n.limit != null && (t.limit = String(Math.min(200, Math.max(1, n.limit)))), this.get("/releases", t);
  }
  latest() {
    return this.get("/latest");
  }
  latestCanon(n) {
    if (!n.channel || !n.platform || !n.kind) throw new Error("channel, platform, and kind are required");
    const t = [encodeURIComponent(n.channel), encodeURIComponent(n.platform), encodeURIComponent(n.kind)];
    return this.get(`/latest/${t.join("/")}`);
  }
  byVersion(n) {
    return this.get(`/by_version/${encodeURIComponent(n)}`);
  }
  msgPublishRelease(n, t) {
    return { typeUrl: "/lumen.release.v1.MsgPublishRelease", value: jt.fromPartial({ creator: n, release: t }) };
  }
  msgSetEmergency(n, t) {
    return { typeUrl: "/lumen.release.v1.MsgSetEmergency", value: nr.fromPartial({ creator: n, id: t.id, emergencyOk: t.emergencyOk, emergencyTtl: t.emergencyTtl ?? 0 }) };
  }
  msgValidateRelease(n, t) {
    return { typeUrl: "/lumen.release.v1.MsgValidateRelease", value: tr.fromPartial({ authority: n, id: t }) };
  }
  msgRejectRelease(n, t) {
    return { typeUrl: "/lumen.release.v1.MsgRejectRelease", value: rr.fromPartial({ authority: n, id: t }) };
  }
  msgUpdateParams(n, t) {
    return { typeUrl: "/lumen.release.v1.MsgUpdateParams", value: er.fromPartial({ authority: n, params: t }) };
  }
}, ne = class extends Q {
  constructor(n) {
    const t = n ? F(n, "/lumen/tokenomics/v1") : void 0;
    super(t);
  }
  params() {
    return this.get("/params");
  }
  msgUpdateParams(n, t) {
    return { typeUrl: "/lumen.tokenomics.v1.MsgUpdateParams", value: ir.fromPartial({ authority: n, params: t }) };
  }
  msgUpdateGovMinDeposit(n, t) {
    return { typeUrl: "/lumen.tokenomics.v1.MsgUpdateGovMinDeposit", value: ar.fromPartial({ authority: n, minDeposit: t }) };
  }
  msgCommunityPoolSpend(n, t) {
    return { typeUrl: "/lumen.tokenomics.v1.MsgCommunityPoolSpend", value: or.fromPartial({ authority: n, recipient: t.recipient, amount: t.amount }) };
  }
  msgUpdateSlashingDowntimeParams(n, t, r) {
    return { typeUrl: "/lumen.tokenomics.v1.MsgUpdateSlashingDowntimeParams", value: sr.fromPartial({ authority: n, slashFractionDowntime: t, downtimeJailDuration: r }) };
  }
  msgUpdateSlashingLivenessParams(n, t, r) {
    return { typeUrl: "/lumen.tokenomics.v1.MsgUpdateSlashingLivenessParams", value: lr.fromPartial({ authority: n, signedBlocksWindow: t, minSignedPerWindow: r }) };
  }
}, te = class extends Q {
  constructor(n) {
    const t = n ? F(n, "/lumen/pqc/v1") : void 0;
    super(t);
  }
  account(n) {
    return this.get(`/accounts/${encodeURIComponent(n)}`);
  }
  params() {
    return this.get("/params");
  }
  msgUpdateParams(n, t) {
    return { typeUrl: "/lumen.pqc.v1.MsgUpdateParams", value: ur.fromPartial({ authority: n, params: t }) };
  }
  msgAddIbcRelayer(n, t) {
    return { typeUrl: "/lumen.pqc.v1.MsgAddIBCRelayer", value: cr.fromPartial({ authority: n, relayer: t }) };
  }
  msgRemoveIbcRelayer(n, t) {
    return { typeUrl: "/lumen.pqc.v1.MsgRemoveIBCRelayer", value: dr.fromPartial({ authority: n, relayer: t }) };
  }
  msgLinkAccountPqc(n, t) {
    return { typeUrl: "/lumen.pqc.v1.MsgLinkAccountPQC", value: fr.fromPartial({ creator: n, scheme: t.scheme, pubKey: Pt(t.pubKey), powNonce: t.powNonce ? Pt(t.powNonce) : new Uint8Array() }) };
  }
};
function Pt(n) {
  if (n instanceof Uint8Array) return n;
  const t = n.trim();
  return /^[0-9a-f]+$/i.test(t) ? E.fromHex(t) : E.fromBase64(t);
}
var re = class extends Q {
  constructor(n) {
    const t = n ? F(n, "/cosmos/gov/v1") : void 0;
    super(t);
  }
  params(n) {
    return n ? this.get(`/params/${n}`) : this.get("/params");
  }
  proposal(n) {
    return this.get(`/proposals/${encodeURIComponent(String(n))}`);
  }
  proposals(n = {}) {
    const t = pn(n);
    return n.status && (t.proposal_status = n.status), n.voter && (t.voter = n.voter), n.depositor && (t.depositor = n.depositor), this.get("/proposals", t);
  }
  deposits(n, t = {}) {
    return this.get(`/proposals/${encodeURIComponent(String(n))}/deposits`, pn(t));
  }
  deposit(n, t) {
    return this.get(`/proposals/${encodeURIComponent(String(n))}/deposits/${encodeURIComponent(t)}`);
  }
  votes(n, t = {}) {
    return this.get(`/proposals/${encodeURIComponent(String(n))}/votes`, pn(t));
  }
  vote(n, t) {
    return this.get(`/proposals/${encodeURIComponent(String(n))}/votes/${encodeURIComponent(t)}`);
  }
  tallyResult(n) {
    return this.get(`/proposals/${encodeURIComponent(String(n))}/tally`);
  }
  msgSubmitProposal(n, t) {
    return { typeUrl: "/cosmos.gov.v1.MsgSubmitProposal", value: en.MsgSubmitProposal.fromPartial({ proposer: n, messages: t.messages ?? [], initialDeposit: t.initialDeposit ?? [], metadata: t.metadata ?? "", title: t.title ?? "", summary: t.summary ?? "" }) };
  }
  msgDeposit(n, t) {
    return { typeUrl: "/cosmos.gov.v1.MsgDeposit", value: en.MsgDeposit.fromPartial({ depositor: n, proposalId: yn(t.proposalId), amount: t.amount.slice() }) };
  }
  msgVote(n, t) {
    return { typeUrl: "/cosmos.gov.v1.MsgVote", value: en.MsgVote.fromPartial({ voter: n, proposalId: yn(t.proposalId), option: t.option }) };
  }
  msgVoteWeighted(n, t) {
    return { typeUrl: "/cosmos.gov.v1.MsgVoteWeighted", value: en.MsgVoteWeighted.fromPartial({ voter: n, proposalId: yn(t.proposalId), options: t.options.slice() }) };
  }
};
function pn(n) {
  const t = {};
  return n.pageKey && (t["pagination.key"] = n.pageKey), n.limit != null && (t["pagination.limit"] = String(n.limit)), t;
}
function yn(n) {
  return typeof n == "bigint" ? n : _r.isLong(n) ? BigInt(n.toString()) : BigInt(n);
}
var mr = {};
tn(mr, { isGaslessTx: () => ie, zeroFee: () => ae });
var ee = new Set(_n.gaslessTypeUrls);
function ie(n) {
  if (!Array.isArray(n) || n.length === 0) return false;
  for (const t of n) if (!(t == null ? void 0 : t.typeUrl) || !ee.has(t.typeUrl)) return false;
  return true;
}
function ae(n = "250000") {
  return { amount: [], gas: String(n) };
}
rn();
function Nt() {
  return { addr: "", scheme: "", signature: new Uint8Array(0), pubKey: new Uint8Array(0) };
}
var W = { encode(n, t = new d()) {
  return n.addr !== "" && t.uint32(10).string(n.addr), n.scheme !== "" && t.uint32(18).string(n.scheme), n.signature.length !== 0 && t.uint32(26).bytes(n.signature), n.pubKey.length !== 0 && t.uint32(34).bytes(n.pubKey), t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = Nt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.addr = r.string();
        continue;
      }
      case 2: {
        if (e !== 18) break;
        i.scheme = r.string();
        continue;
      }
      case 3: {
        if (e !== 26) break;
        i.signature = r.bytes();
        continue;
      }
      case 4: {
        if (e !== 34) break;
        i.pubKey = r.bytes();
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { addr: Y(n.addr) ? globalThis.String(n.addr) : "", scheme: Y(n.scheme) ? globalThis.String(n.scheme) : "", signature: Y(n.signature) ? gn(n.signature) : new Uint8Array(0), pubKey: Y(n.pubKey) ? gn(n.pubKey) : Y(n.pub_key) ? gn(n.pub_key) : new Uint8Array(0) };
}, toJSON(n) {
  const t = {};
  return n.addr !== "" && (t.addr = n.addr), n.scheme !== "" && (t.scheme = n.scheme), n.signature.length !== 0 && (t.signature = Ut(n.signature)), n.pubKey.length !== 0 && (t.pubKey = Ut(n.pubKey)), t;
}, create(n) {
  return W.fromPartial(n ?? {});
}, fromPartial(n) {
  const t = Nt();
  return t.addr = n.addr ?? "", t.scheme = n.scheme ?? "", t.signature = n.signature ?? new Uint8Array(0), t.pubKey = n.pubKey ?? new Uint8Array(0), t;
} };
function xt() {
  return { signatures: [] };
}
var kn = { encode(n, t = new d()) {
  for (const r of n.signatures) W.encode(r, t.uint32(10).fork()).join();
  return t;
}, decode(n, t) {
  const r = n instanceof s ? n : new s(n), o = t === void 0 ? r.len : r.pos + t, i = xt();
  for (; r.pos < o; ) {
    const e = r.uint32();
    switch (e >>> 3) {
      case 1: {
        if (e !== 10) break;
        i.signatures.push(W.decode(r, r.uint32()));
        continue;
      }
    }
    if ((e & 7) === 4 || e === 0) break;
    r.skip(e & 7);
  }
  return i;
}, fromJSON(n) {
  return { signatures: globalThis.Array.isArray(n == null ? void 0 : n.signatures) ? n.signatures.map((t) => W.fromJSON(t)) : [] };
}, toJSON(n) {
  var _a;
  const t = {};
  return ((_a = n.signatures) == null ? void 0 : _a.length) && (t.signatures = n.signatures.map((r) => W.toJSON(r))), t;
}, create(n) {
  return kn.fromPartial(n ?? {});
}, fromPartial(n) {
  var _a;
  const t = xt();
  return t.signatures = ((_a = n.signatures) == null ? void 0 : _a.map((r) => W.fromPartial(r))) || [], t;
} };
function gn(n) {
  if (globalThis.Buffer) return Uint8Array.from(globalThis.Buffer.from(n, "base64"));
  {
    const t = globalThis.atob(n), r = new Uint8Array(t.length);
    for (let o = 0; o < t.length; ++o) r[o] = t.charCodeAt(o);
    return r;
  }
}
function Ut(n) {
  if (globalThis.Buffer) return globalThis.Buffer.from(n).toString("base64");
  {
    const t = [];
    return n.forEach((r) => {
      t.push(globalThis.String.fromCharCode(r));
    }), globalThis.btoa(t.join(""));
  }
}
function Y(n) {
  return n != null;
}
function hr(n) {
  if (!(n == null ? void 0 : n.length)) throw new Error("tx body bytes missing");
  const t = H.TxBody.decode(n);
  return t.extensionOptions = dn(t.extensionOptions ?? []), t.nonCriticalExtensionOptions = dn(t.nonCriticalExtensionOptions ?? []), H.TxBody.encode(t).finish();
}
function oe(n, t, r) {
  var _a, _b;
  if (!((_a = r.bodyBytes) == null ? void 0 : _a.length) || !((_b = r.authInfoBytes) == null ? void 0 : _b.length)) throw new Error("tx raw missing body or auth info bytes");
  const o = hr(r.bodyBytes), i = H.SignDoc.fromPartial({ bodyBytes: o, authInfoBytes: r.authInfoBytes, chainId: n, accountNumber: BigInt(t) }), e = H.SignDoc.encode(i).finish();
  return le(e);
}
function se(n, t) {
  const r = H.TxBody.decode(n);
  if (r.extensionOptions = dn(r.extensionOptions ?? []), r.nonCriticalExtensionOptions = dn(r.nonCriticalExtensionOptions ?? []), t.length > 0) {
    const o = kn.fromPartial({ signatures: t }), i = Br.Any.fromPartial({ typeUrl: fn, value: kn.encode(o).finish() });
    r.nonCriticalExtensionOptions.push(i);
  }
  return H.TxBody.encode(r).finish();
}
function dn(n) {
  return n.filter((t) => (t == null ? void 0 : t.typeUrl) !== fn);
}
function le(n) {
  const t = new TextEncoder().encode(Sn), r = new Uint8Array(t.length + n.length);
  return r.set(t, 0), r.set(n, t.length), r;
}
(() => {
  if (typeof globalThis.__dirname == "string") return globalThis.__dirname;
  try {
    const n = typeof import.meta < "u" ? new URL("/assets/index-P3hWf8-k.js", import.meta.url).pathname : ".";
    return globalThis.__dirname = n, n;
  } catch {
    return globalThis.__dirname = ".", ".";
  }
})();
var ue = (() => {
  const n = () => {
    const i = new Error("not implemented");
    return i.code = "ENOSYS", i;
  };
  if (!globalThis.fs) {
    let i = "";
    globalThis.fs = { constants: { O_WRONLY: -1, O_RDWR: -1, O_CREAT: -1, O_TRUNC: -1, O_APPEND: -1, O_EXCL: -1, O_DIRECTORY: -1 }, writeSync(e, l) {
      i += r.decode(l);
      const c = i.lastIndexOf(`
`);
      return c != -1 && (console.log(i.substring(0, c)), i = i.substring(c + 1)), l.length;
    }, write(e, l, c, g, P, A) {
      if (c !== 0 || g !== l.length || P !== null) {
        A(n());
        return;
      }
      const B = this.writeSync(e, l);
      A(null, B);
    }, chmod(e, l, c) {
      c(n());
    }, chown(e, l, c, g) {
      g(n());
    }, close(e, l) {
      l(n());
    }, fchmod(e, l, c) {
      c(n());
    }, fchown(e, l, c, g) {
      g(n());
    }, fstat(e, l) {
      l(n());
    }, fsync(e, l) {
      l(null);
    }, ftruncate(e, l, c) {
      c(n());
    }, lchown(e, l, c, g) {
      g(n());
    }, link(e, l, c) {
      c(n());
    }, lstat(e, l) {
      l(n());
    }, mkdir(e, l, c) {
      c(n());
    }, open(e, l, c, g) {
      g(n());
    }, read(e, l, c, g, P, A) {
      A(n());
    }, readdir(e, l) {
      l(n());
    }, readlink(e, l) {
      l(n());
    }, rename(e, l, c) {
      c(n());
    }, rmdir(e, l) {
      l(n());
    }, stat(e, l) {
      l(n());
    }, symlink(e, l, c) {
      c(n());
    }, truncate(e, l, c) {
      c(n());
    }, unlink(e, l) {
      l(n());
    }, utimes(e, l, c, g) {
      g(n());
    } };
  }
  if (globalThis.process || (globalThis.process = { getuid() {
    return -1;
  }, getgid() {
    return -1;
  }, geteuid() {
    return -1;
  }, getegid() {
    return -1;
  }, getgroups() {
    throw n();
  }, pid: -1, ppid: -1, umask() {
    throw n();
  }, cwd() {
    throw n();
  }, chdir() {
    throw n();
  } }), globalThis.path || (globalThis.path = { resolve(...i) {
    return i.join("/");
  } }), !globalThis.crypto) throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");
  if (!globalThis.performance) throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");
  if (!globalThis.TextEncoder) throw new Error("globalThis.TextEncoder is not available, polyfill required");
  if (!globalThis.TextDecoder) throw new Error("globalThis.TextDecoder is not available, polyfill required");
  const t = new TextEncoder("utf-8"), r = new TextDecoder("utf-8");
  class o {
    constructor() {
      this.argv = ["js"], this.env = {}, this.exit = (a) => {
        a !== 0 && console.warn("exit code:", a);
      }, this._exitPromise = new Promise((a) => {
        this._resolveExitPromise = a;
      }), this._pendingEvent = null, this._scheduledTimeouts = /* @__PURE__ */ new Map(), this._nextCallbackTimeoutID = 1;
      const e = (a, u) => {
        this.mem.setUint32(a + 0, u, true), this.mem.setUint32(a + 4, Math.floor(u / 4294967296), true);
      }, l = (a) => {
        const u = this.mem.getUint32(a + 0, true), h = this.mem.getInt32(a + 4, true);
        return u + h * 4294967296;
      }, c = (a) => {
        const u = this.mem.getFloat64(a, true);
        if (u === 0) return;
        if (!isNaN(u)) return u;
        const h = this.mem.getUint32(a, true);
        return this._values[h];
      }, g = (a, u) => {
        if (typeof u == "number" && u !== 0) {
          if (isNaN(u)) {
            this.mem.setUint32(a + 4, 2146959360, true), this.mem.setUint32(a, 0, true);
            return;
          }
          this.mem.setFloat64(a, u, true);
          return;
        }
        if (u === void 0) {
          this.mem.setFloat64(a, 0, true);
          return;
        }
        let p = this._ids.get(u);
        p === void 0 && (p = this._idPool.pop(), p === void 0 && (p = this._values.length), this._values[p] = u, this._goRefCounts[p] = 0, this._ids.set(u, p)), this._goRefCounts[p]++;
        let x = 0;
        switch (typeof u) {
          case "object":
            u !== null && (x = 1);
            break;
          case "string":
            x = 2;
            break;
          case "symbol":
            x = 3;
            break;
          case "function":
            x = 4;
            break;
        }
        this.mem.setUint32(a + 4, 2146959360 | x, true), this.mem.setUint32(a, p, true);
      }, P = (a) => {
        const u = l(a + 0), h = l(a + 8);
        return new Uint8Array(this._inst.exports.mem.buffer, u, h);
      }, A = (a) => {
        const u = l(a + 0), h = l(a + 8), p = new Array(h);
        for (let x = 0; x < h; x++) p[x] = c(u + x * 8);
        return p;
      }, B = (a) => {
        const u = l(a + 0), h = l(a + 8);
        return r.decode(new DataView(this._inst.exports.mem.buffer, u, h));
      }, In = (a, u) => (this._inst.exports.testExport0(), this._inst.exports.testExport(a, u)), I = Date.now() - performance.now();
      this.importObject = { _gotest: { add: (a, u) => a + u, callExport: In }, gojs: { "runtime.wasmExit": (a) => {
        a >>>= 0;
        const u = this.mem.getInt32(a + 8, true);
        this.exited = true, delete this._inst, delete this._values, delete this._goRefCounts, delete this._ids, delete this._idPool, this.exit(u);
      }, "runtime.wasmWrite": (a) => {
        a >>>= 0;
        const u = l(a + 8), h = l(a + 16), p = this.mem.getInt32(a + 24, true);
        fs.writeSync(u, new Uint8Array(this._inst.exports.mem.buffer, h, p));
      }, "runtime.resetMemoryDataView": (a) => {
        this.mem = new DataView(this._inst.exports.mem.buffer);
      }, "runtime.nanotime1": (a) => {
        a >>>= 0, e(a + 8, (I + performance.now()) * 1e6);
      }, "runtime.walltime": (a) => {
        a >>>= 0;
        const u = (/* @__PURE__ */ new Date()).getTime();
        e(a + 8, u / 1e3), this.mem.setInt32(a + 16, u % 1e3 * 1e6, true);
      }, "runtime.scheduleTimeoutEvent": (a) => {
        a >>>= 0;
        const u = this._nextCallbackTimeoutID;
        this._nextCallbackTimeoutID++, this._scheduledTimeouts.set(u, setTimeout(() => {
          for (this._resume(); this._scheduledTimeouts.has(u); ) console.warn("scheduleTimeoutEvent: missed timeout event"), this._resume();
        }, l(a + 8))), this.mem.setInt32(a + 16, u, true);
      }, "runtime.clearTimeoutEvent": (a) => {
        a >>>= 0;
        const u = this.mem.getInt32(a + 8, true);
        clearTimeout(this._scheduledTimeouts.get(u)), this._scheduledTimeouts.delete(u);
      }, "runtime.getRandomData": (a) => {
        a >>>= 0, crypto.getRandomValues(P(a + 8));
      }, "syscall/js.finalizeRef": (a) => {
        a >>>= 0;
        const u = this.mem.getUint32(a + 8, true);
        if (this._goRefCounts[u]--, this._goRefCounts[u] === 0) {
          const h = this._values[u];
          this._values[u] = null, this._ids.delete(h), this._idPool.push(u);
        }
      }, "syscall/js.stringVal": (a) => {
        a >>>= 0, g(a + 24, B(a + 8));
      }, "syscall/js.valueGet": (a) => {
        a >>>= 0;
        const u = Reflect.get(c(a + 8), B(a + 16));
        a = this._inst.exports.getsp() >>> 0, g(a + 32, u);
      }, "syscall/js.valueSet": (a) => {
        a >>>= 0, Reflect.set(c(a + 8), B(a + 16), c(a + 32));
      }, "syscall/js.valueDelete": (a) => {
        a >>>= 0, Reflect.deleteProperty(c(a + 8), B(a + 16));
      }, "syscall/js.valueIndex": (a) => {
        a >>>= 0, g(a + 24, Reflect.get(c(a + 8), l(a + 16)));
      }, "syscall/js.valueSetIndex": (a) => {
        a >>>= 0, Reflect.set(c(a + 8), l(a + 16), c(a + 24));
      }, "syscall/js.valueCall": (a) => {
        a >>>= 0;
        try {
          const u = c(a + 8), h = Reflect.get(u, B(a + 16)), p = A(a + 32), x = Reflect.apply(h, u, p);
          a = this._inst.exports.getsp() >>> 0, g(a + 56, x), this.mem.setUint8(a + 64, 1);
        } catch (u) {
          a = this._inst.exports.getsp() >>> 0, g(a + 56, u), this.mem.setUint8(a + 64, 0);
        }
      }, "syscall/js.valueInvoke": (a) => {
        a >>>= 0;
        try {
          const u = c(a + 8), h = A(a + 16), p = Reflect.apply(u, void 0, h);
          a = this._inst.exports.getsp() >>> 0, g(a + 40, p), this.mem.setUint8(a + 48, 1);
        } catch (u) {
          a = this._inst.exports.getsp() >>> 0, g(a + 40, u), this.mem.setUint8(a + 48, 0);
        }
      }, "syscall/js.valueNew": (a) => {
        a >>>= 0;
        try {
          const u = c(a + 8), h = A(a + 16), p = Reflect.construct(u, h);
          a = this._inst.exports.getsp() >>> 0, g(a + 40, p), this.mem.setUint8(a + 48, 1);
        } catch (u) {
          a = this._inst.exports.getsp() >>> 0, g(a + 40, u), this.mem.setUint8(a + 48, 0);
        }
      }, "syscall/js.valueLength": (a) => {
        a >>>= 0, e(a + 16, parseInt(c(a + 8).length));
      }, "syscall/js.valuePrepareString": (a) => {
        a >>>= 0;
        const u = t.encode(String(c(a + 8)));
        g(a + 16, u), e(a + 24, u.length);
      }, "syscall/js.valueLoadString": (a) => {
        a >>>= 0;
        const u = c(a + 8);
        P(a + 16).set(u);
      }, "syscall/js.valueInstanceOf": (a) => {
        a >>>= 0, this.mem.setUint8(a + 24, c(a + 8) instanceof c(a + 16) ? 1 : 0);
      }, "syscall/js.copyBytesToGo": (a) => {
        a >>>= 0;
        const u = P(a + 8), h = c(a + 32);
        if (!(h instanceof Uint8Array || h instanceof Uint8ClampedArray)) {
          this.mem.setUint8(a + 48, 0);
          return;
        }
        const p = h.subarray(0, u.length);
        u.set(p), e(a + 40, p.length), this.mem.setUint8(a + 48, 1);
      }, "syscall/js.copyBytesToJS": (a) => {
        a >>>= 0;
        const u = c(a + 8), h = P(a + 16);
        if (!(u instanceof Uint8Array || u instanceof Uint8ClampedArray)) {
          this.mem.setUint8(a + 48, 0);
          return;
        }
        const p = h.subarray(0, u.length);
        u.set(p), e(a + 40, p.length), this.mem.setUint8(a + 48, 1);
      }, debug: (a) => {
        console.log(a);
      } } };
    }
    async run(e) {
      if (!(e instanceof WebAssembly.Instance)) throw new Error("Go.run: WebAssembly.Instance expected");
      this._inst = e, this.mem = new DataView(this._inst.exports.mem.buffer), this._values = [NaN, 0, null, true, false, globalThis, this], this._goRefCounts = new Array(this._values.length).fill(1 / 0), this._ids = /* @__PURE__ */ new Map([[0, 1], [null, 2], [true, 3], [false, 4], [globalThis, 5], [this, 6]]), this._idPool = [], this.exited = false;
      let l = 4096;
      const c = (I) => {
        const a = l, u = t.encode(I + "\0");
        return new Uint8Array(this.mem.buffer, l, u.length).set(u), l += u.length, l % 8 !== 0 && (l += 8 - l % 8), a;
      }, g = this.argv.length, P = [];
      this.argv.forEach((I) => {
        P.push(c(I));
      }), P.push(0), Object.keys(this.env).sort().forEach((I) => {
        P.push(c(`${I}=${this.env[I]}`));
      }), P.push(0);
      const B = l;
      if (P.forEach((I) => {
        this.mem.setUint32(l, I, true), this.mem.setUint32(l + 4, 0, true), l += 8;
      }), l >= 12288) throw new Error("total length of command line and environment variables exceeds limit");
      this._inst.exports.run(g, B), this.exited && this._resolveExitPromise(), await this._exitPromise;
    }
    _resume() {
      if (this.exited) throw new Error("Go program has already exited");
      this._inst.exports.resume(), this.exited && this._resolveExitPromise();
    }
    _makeFuncWrapper(e) {
      const l = this;
      return function() {
        const c = { id: e, this: this, args: arguments };
        return l._pendingEvent = c, l._resume(), c.result;
      };
    }
  }
  return globalThis.Go = o, o;
})(), ce = new URL("/assets/dilithium3-DhBnzFGs.wasm", import.meta.url), j = globalThis, wn = null;
async function pr() {
  j.__lumen_dilithium_ready__ || (wn || (wn = (async () => {
    const n = new ue(), t = Rr(ce), r = await Mt.readFile(Ir.resolve(t)), { instance: o } = await WebAssembly.instantiate(r, n.importObject);
    n.run(o), await de(() => typeof j.lumen_dilithium_sign == "function"), j.__lumen_dilithium_ready__ = true;
  })()), await wn);
}
function de(n, t = 10) {
  return new Promise((r) => {
    const o = () => {
      if (n()) {
        r();
        return;
      }
      setTimeout(o, t);
    };
    o();
  });
}
function Tn(n) {
  return new Uint8Array(n.buffer.slice(n.byteOffset, n.byteOffset + n.byteLength));
}
async function fe() {
  await pr();
  const n = j.lumen_dilithium_keygen();
  return { publicKey: Tn(n.publicKey), privateKey: Tn(n.privateKey) };
}
async function me(n, t) {
  await pr();
  const r = j.lumen_dilithium_sign(n, t);
  return Tn(r);
}
async function he() {
  return fe();
}
async function pe(n, t) {
  return me(t, n);
}
rn();
var ye = {};
tn(ye, { addressFromMnemonic: () => gr, bankSend: () => wr, coin: () => ge, coins: () => we, createWallet: () => ke, gas: () => mr, getWalletFrom: () => be, looksLikeMnemonic: () => yr, msg: () => ve, parseAddressMaybe: () => xn, resolveDomainOrAddress: () => Te, splitFqdn: () => Se, walletFromMnemonic: () => Nn });
var ge = { ulmn: (n) => It.coin(String(n), "ulmn"), toUlmn: (n) => Math.floor(n).toString(), fromUlmn: (n) => Number(n) }, we = { ulmn: (n) => It.coins(String(n), "ulmn") };
async function Nn(n, t = _n.bech32Prefix) {
  return Er.DirectSecp256k1HdWallet.fromMnemonic(n, { prefix: t });
}
function xn(n, t = _n.bech32Prefix) {
  try {
    return Pr.bech32.decode(n).prefix === t ? n : null;
  } catch {
    return null;
  }
}
function yr(n) {
  const t = n.trim().split(/\s+/);
  return t.length >= 12 && t.length <= 24;
}
async function gr(n) {
  const t = await Nn(n), [r] = await t.getAccounts();
  return r.address;
}
async function be(n) {
  const t = xn(n);
  if (t) return t;
  if (yr(n)) return gr(n);
  throw new Error("Input is neither a Lumen bech32 address nor a mnemonic");
}
async function ke(n = 256) {
  const t = Nr.generateMnemonic(n), r = await Nn(t), [o] = await r.getAccounts();
  return { mnemonic: t, address: o.address, signer: r };
}
async function Te(n, t) {
  var _a, _b;
  if (n.includes(".")) return n;
  const r = xn(n);
  if (!r) return null;
  try {
    const i = (_b = (_a = await t.dns().domainsByOwner(r)) == null ? void 0 : _a.domains) == null ? void 0 : _b[0];
    if (typeof i == "string") return i;
    if ((i == null ? void 0 : i.name) && (i == null ? void 0 : i.ext)) return `${i.name}.${i.ext}`;
  } catch {
  }
  return null;
}
function Se(n) {
  const r = n.trim().match(/^([^\.]+)\.([^\.]+)$/);
  if (!r) throw new Error(`Invalid domain: ${n}`);
  return { domain: r[1], ext: r[2] };
}
function wr(n, t, r) {
  return { typeUrl: "/cosmos.bank.v1beta1.MsgSend", value: Ar.MsgSend.fromPartial({ fromAddress: n, toAddress: t, amount: r.map((o) => ({ ...o })) }) };
}
var ve = { bankSend: wr }, _e = {};
tn(_e, { DEFAULT_SCHEME: () => nn, DILITHIUM3_PRIVATE_KEY_BYTES: () => un, DILITHIUM3_PUBLIC_KEY_BYTES: () => ln, DILITHIUM3_SIGNATURE_BYTES: () => Dt, DUAL_SIGNER_BACKUP_TYPE: () => Un, DUAL_SIGNER_BACKUP_VERSION: () => Mn, PQC_PREFIX: () => Sn, PQC_TYPE_URL: () => fn, PqcKeyStore: () => mn, computePowDigest: () => br, computePowNonce: () => Pe, computeSignBytes: () => oe, createKeyPair: () => he, defaultHomeDir: () => vn, exportDualSigner: () => xe, importDualSigner: () => Ue, leadingZeroBits: () => kr, sanitizeBodyBytes: () => hr, signDilithium: () => pe, withPqcExtension: () => se });
Ot();
function br(n, t) {
  const r = new Uint8Array(n.length + t.length);
  return r.set(n, 0), r.set(t, n.length), xr(r);
}
function kr(n) {
  let t = 0;
  for (const r of n) {
    if (r === 0) {
      t += 8;
      continue;
    }
    for (let o = 7; o >= 0; o--) if ((r >> o & 1) === 0) t += 1;
    else return t;
    return t;
  }
  return t;
}
function Pe(n, t, r = {}) {
  var _a;
  if (t <= 0) return new Uint8Array([0]);
  const o = r.nonceLength ?? 8, i = new Uint8Array(o), e = BigInt(r.maxIterations ?? Number.MAX_SAFE_INTEGER);
  for (let l = 0n; l < e; l++) {
    if ((_a = r.signal) == null ? void 0 : _a.aborted) throw new Error("pow cancelled");
    Ne(i, l);
    const c = br(n, i);
    if (kr(c) >= t) return i.slice();
  }
  throw new Error(`failed to find pow nonce after ${e} attempts (difficulty=${t})`);
}
function Ne(n, t) {
  let r = t;
  for (let o = n.length - 1; o >= 0; o--) n[o] = Number(r & 0xffn), r >>= 8n;
}
rn();
rn();
Ot();
var Un = "lumen/dual-signer", Mn = 1;
function xe(n) {
  var _a;
  const t = (_a = n.mnemonic) == null ? void 0 : _a.trim();
  if (!t) throw new Error("mnemonic is required to export dual signer data");
  const r = n.pqcKey;
  if (!r) throw new Error("pqcKey is required to export dual signer data");
  return Tr(r), { type: Un, version: Mn, mnemonic: t, bech32Prefix: n.bech32Prefix, address: n.address, pqc: { name: r.name, scheme: r.scheme, publicKey: E.toBase64(r.publicKey), privateKey: E.toBase64(r.privateKey), createdAt: r.createdAt.toISOString() } };
}
async function Ue(n, t = {}) {
  const r = Me(n), o = t.keyStore ?? await mn.open(t.homeDir), i = t.keyName ?? r.pqc.name;
  if (!t.overwrite && o.getKey(i)) throw new Error(`PQC key "${i}" already exists. Pass overwrite: true to replace it.`);
  const e = { name: i, scheme: r.pqc.scheme || nn, publicKey: E.fromBase64(r.pqc.publicKey), privateKey: E.fromBase64(r.pqc.privateKey), createdAt: r.pqc.createdAt ? new Date(r.pqc.createdAt) : /* @__PURE__ */ new Date() };
  Tr(e), await o.saveKey(e);
  const l = o.getKey(i);
  if (!l) throw new Error(`Failed to persist PQC key "${i}"`);
  const c = Ie(r, t.linkAddress);
  return c && await o.linkAddress(c, i), { mnemonic: r.mnemonic, key: l, keyStore: o, linkedAddress: c };
}
function Me(n) {
  var _a, _b, _c;
  const t = typeof n == "string" ? JSON.parse(n) : n;
  if (!t || typeof t != "object") throw new Error("dual signer backup is invalid");
  if (t.type !== Un) throw new Error(`unexpected backup type: ${t.type}`);
  if (t.version !== Mn) throw new Error(`unsupported backup version: ${t.version}`);
  if (!((_a = t.mnemonic) == null ? void 0 : _a.trim())) throw new Error("backup is missing mnemonic");
  if (!((_b = t.pqc) == null ? void 0 : _b.publicKey) || !((_c = t.pqc) == null ? void 0 : _c.privateKey)) throw new Error("backup is missing PQC key material");
  return { ...t, mnemonic: t.mnemonic.trim() };
}
function Ie(n, t) {
  if (t !== false) return typeof t == "string" && t.length > 0 ? t : n.address;
}
function Tr(n) {
  var _a;
  if ((((_a = n.scheme) == null ? void 0 : _a.toLowerCase()) || nn) === nn) {
    if (n.publicKey.length !== ln) throw new Error(`Dilithium3 public key must be ${ln} bytes`);
    if (n.privateKey.length !== un) throw new Error(`Dilithium3 private key must be ${un} bytes`);
  }
}
export {
  _e as p
};
