import { x as Ba, M as rh, N as a0, O as sh, P as u0, Q as n0 } from "./vendor-Ds0KLgep.js";
let B1, Y1, w1, O1, k1, U1, W1, C1, F1, I1, M1, eg, ug, ig, cg, fg, J1, x1, og, j1, $1, N1, K1, G1, X1, R1, H1, P1, q1, tg, lg, Q1, Z1, O, L1, V1, Ah, ng, ag, Ol, D1, cv;
let __tla = (async () => {
  var Cf = {
    exports: {}
  }, Uu = {};
  var wd;
  function i0() {
    if (wd) return Uu;
    wd = 1;
    var c = /* @__PURE__ */ Symbol.for("react.transitional.element"), s = /* @__PURE__ */ Symbol.for("react.fragment");
    function r(o, v, y) {
      var S = null;
      if (y !== void 0 && (S = "" + y), v.key !== void 0 && (S = "" + v.key), "key" in v) {
        y = {};
        for (var R in v) R !== "key" && (y[R] = v[R]);
      } else y = v;
      return v = y.ref, {
        $$typeof: c,
        type: o,
        key: S,
        ref: v !== void 0 ? v : null,
        props: y
      };
    }
    return Uu.Fragment = s, Uu.jsx = r, Uu.jsxs = r, Uu;
  }
  var $d;
  function c0() {
    return $d || ($d = 1, Cf.exports = i0()), Cf.exports;
  }
  let Df, $, kd;
  R1 = c0();
  Df = {
    exports: {}
  };
  $ = {};
  function f0() {
    if (kd) return $;
    kd = 1;
    var c = /* @__PURE__ */ Symbol.for("react.transitional.element"), s = /* @__PURE__ */ Symbol.for("react.portal"), r = /* @__PURE__ */ Symbol.for("react.fragment"), o = /* @__PURE__ */ Symbol.for("react.strict_mode"), v = /* @__PURE__ */ Symbol.for("react.profiler"), y = /* @__PURE__ */ Symbol.for("react.consumer"), S = /* @__PURE__ */ Symbol.for("react.context"), R = /* @__PURE__ */ Symbol.for("react.forward_ref"), b = /* @__PURE__ */ Symbol.for("react.suspense"), h = /* @__PURE__ */ Symbol.for("react.memo"), C = /* @__PURE__ */ Symbol.for("react.lazy"), _ = /* @__PURE__ */ Symbol.for("react.activity"), q = Symbol.iterator;
    function Z(g) {
      return g === null || typeof g != "object" ? null : (g = q && g[q] || g["@@iterator"], typeof g == "function" ? g : null);
    }
    var G = {
      isMounted: function() {
        return false;
      },
      enqueueForceUpdate: function() {
      },
      enqueueReplaceState: function() {
      },
      enqueueSetState: function() {
      }
    }, Y = Object.assign, L = {};
    function N(g, x, B) {
      this.props = g, this.context = x, this.refs = L, this.updater = B || G;
    }
    N.prototype.isReactComponent = {}, N.prototype.setState = function(g, x) {
      if (typeof g != "object" && typeof g != "function" && g != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, g, x, "setState");
    }, N.prototype.forceUpdate = function(g) {
      this.updater.enqueueForceUpdate(this, g, "forceUpdate");
    };
    function H() {
    }
    H.prototype = N.prototype;
    function w(g, x, B) {
      this.props = g, this.context = x, this.refs = L, this.updater = B || G;
    }
    var zt = w.prototype = new H();
    zt.constructor = w, Y(zt, N.prototype), zt.isPureReactComponent = true;
    var gt = Array.isArray;
    function qt() {
    }
    var F = {
      H: null,
      A: null,
      T: null,
      S: null
    }, Ot = Object.prototype.hasOwnProperty;
    function Xt(g, x, B) {
      var K = B.ref;
      return {
        $$typeof: c,
        type: g,
        key: x,
        ref: K !== void 0 ? K : null,
        props: B
      };
    }
    function Ee(g, x) {
      return Xt(g.type, x, g.props);
    }
    function Oe(g) {
      return typeof g == "object" && g !== null && g.$$typeof === c;
    }
    function ze(g) {
      var x = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + g.replace(/[=:]/g, function(B) {
        return x[B];
      });
    }
    var el = /\/+/g;
    function Te(g, x) {
      return typeof g == "object" && g !== null && g.key != null ? ze("" + g.key) : x.toString(36);
    }
    function Ae(g) {
      switch (g.status) {
        case "fulfilled":
          return g.value;
        case "rejected":
          throw g.reason;
        default:
          switch (typeof g.status == "string" ? g.then(qt, qt) : (g.status = "pending", g.then(function(x) {
            g.status === "pending" && (g.status = "fulfilled", g.value = x);
          }, function(x) {
            g.status === "pending" && (g.status = "rejected", g.reason = x);
          })), g.status) {
            case "fulfilled":
              return g.value;
            case "rejected":
              throw g.reason;
          }
      }
      throw g;
    }
    function X(g, x, B, K, I) {
      var P = typeof g;
      (P === "undefined" || P === "boolean") && (g = null);
      var ot = false;
      if (g === null) ot = true;
      else switch (P) {
        case "bigint":
        case "string":
        case "number":
          ot = true;
          break;
        case "object":
          switch (g.$$typeof) {
            case c:
            case s:
              ot = true;
              break;
            case C:
              return ot = g._init, X(ot(g._payload), x, B, K, I);
          }
      }
      if (ot) return I = I(g), ot = K === "" ? "." + Te(g, 0) : K, gt(I) ? (B = "", ot != null && (B = ot.replace(el, "$&/") + "/"), X(I, x, B, "", function(La) {
        return La;
      })) : I != null && (Oe(I) && (I = Ee(I, B + (I.key == null || g && g.key === I.key ? "" : ("" + I.key).replace(el, "$&/") + "/") + ot)), x.push(I)), 1;
      ot = 0;
      var Vt = K === "" ? "." : K + ":";
      if (gt(g)) for (var _t = 0; _t < g.length; _t++) K = g[_t], P = Vt + Te(K, _t), ot += X(K, x, B, P, I);
      else if (_t = Z(g), typeof _t == "function") for (g = _t.call(g), _t = 0; !(K = g.next()).done; ) K = K.value, P = Vt + Te(K, _t++), ot += X(K, x, B, P, I);
      else if (P === "object") {
        if (typeof g.then == "function") return X(Ae(g), x, B, K, I);
        throw x = String(g), Error("Objects are not valid as a React child (found: " + (x === "[object Object]" ? "object with keys {" + Object.keys(g).join(", ") + "}" : x) + "). If you meant to render a collection of children, use an array instead.");
      }
      return ot;
    }
    function lt(g, x, B) {
      if (g == null) return g;
      var K = [], I = 0;
      return X(g, K, "", "", function(P) {
        return x.call(B, P, I++);
      }), K;
    }
    function He(g) {
      if (g._status === -1) {
        var x = g._result;
        x = x(), x.then(function(B) {
          (g._status === 0 || g._status === -1) && (g._status = 1, g._result = B);
        }, function(B) {
          (g._status === 0 || g._status === -1) && (g._status = 2, g._result = B);
        }), g._status === -1 && (g._status = 0, g._result = x);
      }
      if (g._status === 1) return g._result.default;
      throw g._result;
    }
    var kl = typeof reportError == "function" ? reportError : function(g) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var x = new window.ErrorEvent("error", {
          bubbles: true,
          cancelable: true,
          message: typeof g == "object" && g !== null && typeof g.message == "string" ? String(g.message) : String(g),
          error: g
        });
        if (!window.dispatchEvent(x)) return;
      } else if (typeof Ba == "object" && typeof Ba.emit == "function") {
        Ba.emit("uncaughtException", g);
        return;
      }
      console.error(g);
    }, ll = {
      map: lt,
      forEach: function(g, x, B) {
        lt(g, function() {
          x.apply(this, arguments);
        }, B);
      },
      count: function(g) {
        var x = 0;
        return lt(g, function() {
          x++;
        }), x;
      },
      toArray: function(g) {
        return lt(g, function(x) {
          return x;
        }) || [];
      },
      only: function(g) {
        if (!Oe(g)) throw Error("React.Children.only expected to receive a single React element child.");
        return g;
      }
    };
    return $.Activity = _, $.Children = ll, $.Component = N, $.Fragment = r, $.Profiler = v, $.PureComponent = w, $.StrictMode = o, $.Suspense = b, $.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = F, $.__COMPILER_RUNTIME = {
      __proto__: null,
      c: function(g) {
        return F.H.useMemoCache(g);
      }
    }, $.cache = function(g) {
      return function() {
        return g.apply(null, arguments);
      };
    }, $.cacheSignal = function() {
      return null;
    }, $.cloneElement = function(g, x, B) {
      if (g == null) throw Error("The argument must be a React element, but you passed " + g + ".");
      var K = Y({}, g.props), I = g.key;
      if (x != null) for (P in x.key !== void 0 && (I = "" + x.key), x) !Ot.call(x, P) || P === "key" || P === "__self" || P === "__source" || P === "ref" && x.ref === void 0 || (K[P] = x[P]);
      var P = arguments.length - 2;
      if (P === 1) K.children = B;
      else if (1 < P) {
        for (var ot = Array(P), Vt = 0; Vt < P; Vt++) ot[Vt] = arguments[Vt + 2];
        K.children = ot;
      }
      return Xt(g.type, I, K);
    }, $.createContext = function(g) {
      return g = {
        $$typeof: S,
        _currentValue: g,
        _currentValue2: g,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      }, g.Provider = g, g.Consumer = {
        $$typeof: y,
        _context: g
      }, g;
    }, $.createElement = function(g, x, B) {
      var K, I = {}, P = null;
      if (x != null) for (K in x.key !== void 0 && (P = "" + x.key), x) Ot.call(x, K) && K !== "key" && K !== "__self" && K !== "__source" && (I[K] = x[K]);
      var ot = arguments.length - 2;
      if (ot === 1) I.children = B;
      else if (1 < ot) {
        for (var Vt = Array(ot), _t = 0; _t < ot; _t++) Vt[_t] = arguments[_t + 2];
        I.children = Vt;
      }
      if (g && g.defaultProps) for (K in ot = g.defaultProps, ot) I[K] === void 0 && (I[K] = ot[K]);
      return Xt(g, P, I);
    }, $.createRef = function() {
      return {
        current: null
      };
    }, $.forwardRef = function(g) {
      return {
        $$typeof: R,
        render: g
      };
    }, $.isValidElement = Oe, $.lazy = function(g) {
      return {
        $$typeof: C,
        _payload: {
          _status: -1,
          _result: g
        },
        _init: He
      };
    }, $.memo = function(g, x) {
      return {
        $$typeof: h,
        type: g,
        compare: x === void 0 ? null : x
      };
    }, $.startTransition = function(g) {
      var x = F.T, B = {};
      F.T = B;
      try {
        var K = g(), I = F.S;
        I !== null && I(B, K), typeof K == "object" && K !== null && typeof K.then == "function" && K.then(qt, kl);
      } catch (P) {
        kl(P);
      } finally {
        x !== null && B.types !== null && (x.types = B.types), F.T = x;
      }
    }, $.unstable_useCacheRefresh = function() {
      return F.H.useCacheRefresh();
    }, $.use = function(g) {
      return F.H.use(g);
    }, $.useActionState = function(g, x, B) {
      return F.H.useActionState(g, x, B);
    }, $.useCallback = function(g, x) {
      return F.H.useCallback(g, x);
    }, $.useContext = function(g) {
      return F.H.useContext(g);
    }, $.useDebugValue = function() {
    }, $.useDeferredValue = function(g, x) {
      return F.H.useDeferredValue(g, x);
    }, $.useEffect = function(g, x) {
      return F.H.useEffect(g, x);
    }, $.useEffectEvent = function(g) {
      return F.H.useEffectEvent(g);
    }, $.useId = function() {
      return F.H.useId();
    }, $.useImperativeHandle = function(g, x, B) {
      return F.H.useImperativeHandle(g, x, B);
    }, $.useInsertionEffect = function(g, x) {
      return F.H.useInsertionEffect(g, x);
    }, $.useLayoutEffect = function(g, x) {
      return F.H.useLayoutEffect(g, x);
    }, $.useMemo = function(g, x) {
      return F.H.useMemo(g, x);
    }, $.useOptimistic = function(g, x) {
      return F.H.useOptimistic(g, x);
    }, $.useReducer = function(g, x, B) {
      return F.H.useReducer(g, x, B);
    }, $.useRef = function(g) {
      return F.H.useRef(g);
    }, $.useState = function(g) {
      return F.H.useState(g);
    }, $.useSyncExternalStore = function(g, x, B) {
      return F.H.useSyncExternalStore(g, x, B);
    }, $.useTransition = function() {
      return F.H.useTransition();
    }, $.version = "19.2.3", $;
  }
  var Wd;
  function Bu() {
    return Wd || (Wd = 1, Df.exports = f0()), Df.exports;
  }
  O = Bu();
  M1 = rh(O);
  var Uf = {
    exports: {}
  }, xu = {}, xf = {
    exports: {}
  }, Zt = {};
  var Fd;
  function o0() {
    if (Fd) return Zt;
    Fd = 1;
    var c = Bu();
    function s(b) {
      var h = "https://react.dev/errors/" + b;
      if (1 < arguments.length) {
        h += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var C = 2; C < arguments.length; C++) h += "&args[]=" + encodeURIComponent(arguments[C]);
      }
      return "Minified React error #" + b + "; visit " + h + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function r() {
    }
    var o = {
      d: {
        f: r,
        r: function() {
          throw Error(s(522));
        },
        D: r,
        C: r,
        L: r,
        m: r,
        X: r,
        S: r,
        M: r
      },
      p: 0,
      findDOMNode: null
    }, v = /* @__PURE__ */ Symbol.for("react.portal");
    function y(b, h, C) {
      var _ = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return {
        $$typeof: v,
        key: _ == null ? null : "" + _,
        children: b,
        containerInfo: h,
        implementation: C
      };
    }
    var S = c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    function R(b, h) {
      if (b === "font") return "";
      if (typeof h == "string") return h === "use-credentials" ? h : "";
    }
    return Zt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = o, Zt.createPortal = function(b, h) {
      var C = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!h || h.nodeType !== 1 && h.nodeType !== 9 && h.nodeType !== 11) throw Error(s(299));
      return y(b, h, null, C);
    }, Zt.flushSync = function(b) {
      var h = S.T, C = o.p;
      try {
        if (S.T = null, o.p = 2, b) return b();
      } finally {
        S.T = h, o.p = C, o.d.f();
      }
    }, Zt.preconnect = function(b, h) {
      typeof b == "string" && (h ? (h = h.crossOrigin, h = typeof h == "string" ? h === "use-credentials" ? h : "" : void 0) : h = null, o.d.C(b, h));
    }, Zt.prefetchDNS = function(b) {
      typeof b == "string" && o.d.D(b);
    }, Zt.preinit = function(b, h) {
      if (typeof b == "string" && h && typeof h.as == "string") {
        var C = h.as, _ = R(C, h.crossOrigin), q = typeof h.integrity == "string" ? h.integrity : void 0, Z = typeof h.fetchPriority == "string" ? h.fetchPriority : void 0;
        C === "style" ? o.d.S(b, typeof h.precedence == "string" ? h.precedence : void 0, {
          crossOrigin: _,
          integrity: q,
          fetchPriority: Z
        }) : C === "script" && o.d.X(b, {
          crossOrigin: _,
          integrity: q,
          fetchPriority: Z,
          nonce: typeof h.nonce == "string" ? h.nonce : void 0
        });
      }
    }, Zt.preinitModule = function(b, h) {
      if (typeof b == "string") if (typeof h == "object" && h !== null) {
        if (h.as == null || h.as === "script") {
          var C = R(h.as, h.crossOrigin);
          o.d.M(b, {
            crossOrigin: C,
            integrity: typeof h.integrity == "string" ? h.integrity : void 0,
            nonce: typeof h.nonce == "string" ? h.nonce : void 0
          });
        }
      } else h == null && o.d.M(b);
    }, Zt.preload = function(b, h) {
      if (typeof b == "string" && typeof h == "object" && h !== null && typeof h.as == "string") {
        var C = h.as, _ = R(C, h.crossOrigin);
        o.d.L(b, C, {
          crossOrigin: _,
          integrity: typeof h.integrity == "string" ? h.integrity : void 0,
          nonce: typeof h.nonce == "string" ? h.nonce : void 0,
          type: typeof h.type == "string" ? h.type : void 0,
          fetchPriority: typeof h.fetchPriority == "string" ? h.fetchPriority : void 0,
          referrerPolicy: typeof h.referrerPolicy == "string" ? h.referrerPolicy : void 0,
          imageSrcSet: typeof h.imageSrcSet == "string" ? h.imageSrcSet : void 0,
          imageSizes: typeof h.imageSizes == "string" ? h.imageSizes : void 0,
          media: typeof h.media == "string" ? h.media : void 0
        });
      }
    }, Zt.preloadModule = function(b, h) {
      if (typeof b == "string") if (h) {
        var C = R(h.as, h.crossOrigin);
        o.d.m(b, {
          as: typeof h.as == "string" && h.as !== "script" ? h.as : void 0,
          crossOrigin: C,
          integrity: typeof h.integrity == "string" ? h.integrity : void 0
        });
      } else o.d.m(b);
    }, Zt.requestFormReset = function(b) {
      o.d.r(b);
    }, Zt.unstable_batchedUpdates = function(b, h) {
      return b(h);
    }, Zt.useFormState = function(b, h, C) {
      return S.H.useFormState(b, h, C);
    }, Zt.useFormStatus = function() {
      return S.H.useHostTransitionStatus();
    }, Zt.version = "19.2.3", Zt;
  }
  var Id;
  function dh() {
    if (Id) return xf.exports;
    Id = 1;
    function c() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(c);
      } catch (s) {
        console.error(s);
      }
    }
    return c(), xf.exports = o0(), xf.exports;
  }
  var Pd;
  function r0() {
    if (Pd) return xu;
    Pd = 1;
    var c = a0(), s = Bu(), r = dh();
    function o(t) {
      var e = "https://react.dev/errors/" + t;
      if (1 < arguments.length) {
        e += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var l = 2; l < arguments.length; l++) e += "&args[]=" + encodeURIComponent(arguments[l]);
      }
      return "Minified React error #" + t + "; visit " + e + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function v(t) {
      return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11);
    }
    function y(t) {
      var e = t, l = t;
      if (t.alternate) for (; e.return; ) e = e.return;
      else {
        t = e;
        do
          e = t, (e.flags & 4098) !== 0 && (l = e.return), t = e.return;
        while (t);
      }
      return e.tag === 3 ? l : null;
    }
    function S(t) {
      if (t.tag === 13) {
        var e = t.memoizedState;
        if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated;
      }
      return null;
    }
    function R(t) {
      if (t.tag === 31) {
        var e = t.memoizedState;
        if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated;
      }
      return null;
    }
    function b(t) {
      if (y(t) !== t) throw Error(o(188));
    }
    function h(t) {
      var e = t.alternate;
      if (!e) {
        if (e = y(t), e === null) throw Error(o(188));
        return e !== t ? null : t;
      }
      for (var l = t, a = e; ; ) {
        var u = l.return;
        if (u === null) break;
        var n = u.alternate;
        if (n === null) {
          if (a = u.return, a !== null) {
            l = a;
            continue;
          }
          break;
        }
        if (u.child === n.child) {
          for (n = u.child; n; ) {
            if (n === l) return b(u), t;
            if (n === a) return b(u), e;
            n = n.sibling;
          }
          throw Error(o(188));
        }
        if (l.return !== a.return) l = u, a = n;
        else {
          for (var i = false, f = u.child; f; ) {
            if (f === l) {
              i = true, l = u, a = n;
              break;
            }
            if (f === a) {
              i = true, a = u, l = n;
              break;
            }
            f = f.sibling;
          }
          if (!i) {
            for (f = n.child; f; ) {
              if (f === l) {
                i = true, l = n, a = u;
                break;
              }
              if (f === a) {
                i = true, a = n, l = u;
                break;
              }
              f = f.sibling;
            }
            if (!i) throw Error(o(189));
          }
        }
        if (l.alternate !== a) throw Error(o(190));
      }
      if (l.tag !== 3) throw Error(o(188));
      return l.stateNode.current === l ? t : e;
    }
    function C(t) {
      var e = t.tag;
      if (e === 5 || e === 26 || e === 27 || e === 6) return t;
      for (t = t.child; t !== null; ) {
        if (e = C(t), e !== null) return e;
        t = t.sibling;
      }
      return null;
    }
    var _ = Object.assign, q = /* @__PURE__ */ Symbol.for("react.element"), Z = /* @__PURE__ */ Symbol.for("react.transitional.element"), G = /* @__PURE__ */ Symbol.for("react.portal"), Y = /* @__PURE__ */ Symbol.for("react.fragment"), L = /* @__PURE__ */ Symbol.for("react.strict_mode"), N = /* @__PURE__ */ Symbol.for("react.profiler"), H = /* @__PURE__ */ Symbol.for("react.consumer"), w = /* @__PURE__ */ Symbol.for("react.context"), zt = /* @__PURE__ */ Symbol.for("react.forward_ref"), gt = /* @__PURE__ */ Symbol.for("react.suspense"), qt = /* @__PURE__ */ Symbol.for("react.suspense_list"), F = /* @__PURE__ */ Symbol.for("react.memo"), Ot = /* @__PURE__ */ Symbol.for("react.lazy"), Xt = /* @__PURE__ */ Symbol.for("react.activity"), Ee = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), Oe = Symbol.iterator;
    function ze(t) {
      return t === null || typeof t != "object" ? null : (t = Oe && t[Oe] || t["@@iterator"], typeof t == "function" ? t : null);
    }
    var el = /* @__PURE__ */ Symbol.for("react.client.reference");
    function Te(t) {
      if (t == null) return null;
      if (typeof t == "function") return t.$$typeof === el ? null : t.displayName || t.name || null;
      if (typeof t == "string") return t;
      switch (t) {
        case Y:
          return "Fragment";
        case N:
          return "Profiler";
        case L:
          return "StrictMode";
        case gt:
          return "Suspense";
        case qt:
          return "SuspenseList";
        case Xt:
          return "Activity";
      }
      if (typeof t == "object") switch (t.$$typeof) {
        case G:
          return "Portal";
        case w:
          return t.displayName || "Context";
        case H:
          return (t._context.displayName || "Context") + ".Consumer";
        case zt:
          var e = t.render;
          return t = t.displayName, t || (t = e.displayName || e.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
        case F:
          return e = t.displayName || null, e !== null ? e : Te(t.type) || "Memo";
        case Ot:
          e = t._payload, t = t._init;
          try {
            return Te(t(e));
          } catch {
          }
      }
      return null;
    }
    var Ae = Array.isArray, X = s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, lt = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, He = {
      pending: false,
      data: null,
      method: null,
      action: null
    }, kl = [], ll = -1;
    function g(t) {
      return {
        current: t
      };
    }
    function x(t) {
      0 > ll || (t.current = kl[ll], kl[ll] = null, ll--);
    }
    function B(t, e) {
      ll++, kl[ll] = t.current, t.current = e;
    }
    var K = g(null), I = g(null), P = g(null), ot = g(null);
    function Vt(t, e) {
      switch (B(P, e), B(I, t), B(K, null), e.nodeType) {
        case 9:
        case 11:
          t = (t = e.documentElement) && (t = t.namespaceURI) ? vd(t) : 0;
          break;
        default:
          if (t = e.tagName, e = e.namespaceURI) e = vd(e), t = gd(e, t);
          else switch (t) {
            case "svg":
              t = 1;
              break;
            case "math":
              t = 2;
              break;
            default:
              t = 0;
          }
      }
      x(K), B(K, t);
    }
    function _t() {
      x(K), x(I), x(P);
    }
    function La(t) {
      t.memoizedState !== null && B(ot, t);
      var e = K.current, l = gd(e, t.type);
      e !== l && (B(I, t), B(K, l));
    }
    function Lu(t) {
      I.current === t && (x(K), x(I)), ot.current === t && (x(ot), Mu._currentValue = He);
    }
    var ri, Kf;
    function Cl(t) {
      if (ri === void 0) try {
        throw Error();
      } catch (l) {
        var e = l.stack.trim().match(/\n( *(at )?)/);
        ri = e && e[1] || "", Kf = -1 < l.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < l.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
      return `
` + ri + t + Kf;
    }
    var si = false;
    function di(t, e) {
      if (!t || si) return "";
      si = true;
      var l = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var a = {
          DetermineComponentFrameRoot: function() {
            try {
              if (e) {
                var U = function() {
                  throw Error();
                };
                if (Object.defineProperty(U.prototype, "props", {
                  set: function() {
                    throw Error();
                  }
                }), typeof Reflect == "object" && Reflect.construct) {
                  try {
                    Reflect.construct(U, []);
                  } catch (A) {
                    var T = A;
                  }
                  Reflect.construct(t, [], U);
                } else {
                  try {
                    U.call();
                  } catch (A) {
                    T = A;
                  }
                  t.call(U.prototype);
                }
              } else {
                try {
                  throw Error();
                } catch (A) {
                  T = A;
                }
                (U = t()) && typeof U.catch == "function" && U.catch(function() {
                });
              }
            } catch (A) {
              if (A && T && typeof A.stack == "string") return [
                A.stack,
                T.stack
              ];
            }
            return [
              null,
              null
            ];
          }
        };
        a.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
        var u = Object.getOwnPropertyDescriptor(a.DetermineComponentFrameRoot, "name");
        u && u.configurable && Object.defineProperty(a.DetermineComponentFrameRoot, "name", {
          value: "DetermineComponentFrameRoot"
        });
        var n = a.DetermineComponentFrameRoot(), i = n[0], f = n[1];
        if (i && f) {
          var d = i.split(`
`), z = f.split(`
`);
          for (u = a = 0; a < d.length && !d[a].includes("DetermineComponentFrameRoot"); ) a++;
          for (; u < z.length && !z[u].includes("DetermineComponentFrameRoot"); ) u++;
          if (a === d.length || u === z.length) for (a = d.length - 1, u = z.length - 1; 1 <= a && 0 <= u && d[a] !== z[u]; ) u--;
          for (; 1 <= a && 0 <= u; a--, u--) if (d[a] !== z[u]) {
            if (a !== 1 || u !== 1) do
              if (a--, u--, 0 > u || d[a] !== z[u]) {
                var M = `
` + d[a].replace(" at new ", " at ");
                return t.displayName && M.includes("<anonymous>") && (M = M.replace("<anonymous>", t.displayName)), M;
              }
            while (1 <= a && 0 <= u);
            break;
          }
        }
      } finally {
        si = false, Error.prepareStackTrace = l;
      }
      return (l = t ? t.displayName || t.name : "") ? Cl(l) : "";
    }
    function Hh(t, e) {
      switch (t.tag) {
        case 26:
        case 27:
        case 5:
          return Cl(t.type);
        case 16:
          return Cl("Lazy");
        case 13:
          return t.child !== e && e !== null ? Cl("Suspense Fallback") : Cl("Suspense");
        case 19:
          return Cl("SuspenseList");
        case 0:
        case 15:
          return di(t.type, false);
        case 11:
          return di(t.type.render, false);
        case 1:
          return di(t.type, true);
        case 31:
          return Cl("Activity");
        default:
          return "";
      }
    }
    function Jf(t) {
      try {
        var e = "", l = null;
        do
          e += Hh(t, l), l = t, t = t.return;
        while (t);
        return e;
      } catch (a) {
        return `
Error generating stack: ` + a.message + `
` + a.stack;
      }
    }
    var hi = Object.prototype.hasOwnProperty, mi = c.unstable_scheduleCallback, yi = c.unstable_cancelCallback, Bh = c.unstable_shouldYield, qh = c.unstable_requestPaint, Pt = c.unstable_now, Yh = c.unstable_getCurrentPriorityLevel, wf = c.unstable_ImmediatePriority, $f = c.unstable_UserBlockingPriority, ju = c.unstable_NormalPriority, Lh = c.unstable_LowPriority, kf = c.unstable_IdlePriority, jh = c.log, Qh = c.unstable_setDisableYieldValue, ja = null, te = null;
    function al(t) {
      if (typeof jh == "function" && Qh(t), te && typeof te.setStrictMode == "function") try {
        te.setStrictMode(ja, t);
      } catch {
      }
    }
    var ee = Math.clz32 ? Math.clz32 : Zh, Gh = Math.log, Xh = Math.LN2;
    function Zh(t) {
      return t >>>= 0, t === 0 ? 32 : 31 - (Gh(t) / Xh | 0) | 0;
    }
    var Qu = 256, Gu = 262144, Xu = 4194304;
    function Dl(t) {
      var e = t & 42;
      if (e !== 0) return e;
      switch (t & -t) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return t & 261888;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return t & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return t;
      }
    }
    function Zu(t, e, l) {
      var a = t.pendingLanes;
      if (a === 0) return 0;
      var u = 0, n = t.suspendedLanes, i = t.pingedLanes;
      t = t.warmLanes;
      var f = a & 134217727;
      return f !== 0 ? (a = f & ~n, a !== 0 ? u = Dl(a) : (i &= f, i !== 0 ? u = Dl(i) : l || (l = f & ~t, l !== 0 && (u = Dl(l))))) : (f = a & ~n, f !== 0 ? u = Dl(f) : i !== 0 ? u = Dl(i) : l || (l = a & ~t, l !== 0 && (u = Dl(l)))), u === 0 ? 0 : e !== 0 && e !== u && (e & n) === 0 && (n = u & -u, l = e & -e, n >= l || n === 32 && (l & 4194048) !== 0) ? e : u;
    }
    function Qa(t, e) {
      return (t.pendingLanes & ~(t.suspendedLanes & ~t.pingedLanes) & e) === 0;
    }
    function Vh(t, e) {
      switch (t) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return e + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function Wf() {
      var t = Xu;
      return Xu <<= 1, (Xu & 62914560) === 0 && (Xu = 4194304), t;
    }
    function vi(t) {
      for (var e = [], l = 0; 31 > l; l++) e.push(t);
      return e;
    }
    function Ga(t, e) {
      t.pendingLanes |= e, e !== 268435456 && (t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0);
    }
    function Kh(t, e, l, a, u, n) {
      var i = t.pendingLanes;
      t.pendingLanes = l, t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0, t.expiredLanes &= l, t.entangledLanes &= l, t.errorRecoveryDisabledLanes &= l, t.shellSuspendCounter = 0;
      var f = t.entanglements, d = t.expirationTimes, z = t.hiddenUpdates;
      for (l = i & ~l; 0 < l; ) {
        var M = 31 - ee(l), U = 1 << M;
        f[M] = 0, d[M] = -1;
        var T = z[M];
        if (T !== null) for (z[M] = null, M = 0; M < T.length; M++) {
          var A = T[M];
          A !== null && (A.lane &= -536870913);
        }
        l &= ~U;
      }
      a !== 0 && Ff(t, a, 0), n !== 0 && u === 0 && t.tag !== 0 && (t.suspendedLanes |= n & ~(i & ~e));
    }
    function Ff(t, e, l) {
      t.pendingLanes |= e, t.suspendedLanes &= ~e;
      var a = 31 - ee(e);
      t.entangledLanes |= e, t.entanglements[a] = t.entanglements[a] | 1073741824 | l & 261930;
    }
    function If(t, e) {
      var l = t.entangledLanes |= e;
      for (t = t.entanglements; l; ) {
        var a = 31 - ee(l), u = 1 << a;
        u & e | t[a] & e && (t[a] |= e), l &= ~u;
      }
    }
    function Pf(t, e) {
      var l = e & -e;
      return l = (l & 42) !== 0 ? 1 : gi(l), (l & (t.suspendedLanes | e)) !== 0 ? 0 : l;
    }
    function gi(t) {
      switch (t) {
        case 2:
          t = 1;
          break;
        case 8:
          t = 4;
          break;
        case 32:
          t = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          t = 128;
          break;
        case 268435456:
          t = 134217728;
          break;
        default:
          t = 0;
      }
      return t;
    }
    function pi(t) {
      return t &= -t, 2 < t ? 8 < t ? (t & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
    }
    function to() {
      var t = lt.p;
      return t !== 0 ? t : (t = window.event, t === void 0 ? 32 : Qd(t.type));
    }
    function eo(t, e) {
      var l = lt.p;
      try {
        return lt.p = t, e();
      } finally {
        lt.p = l;
      }
    }
    var ul = Math.random().toString(36).slice(2), Yt = "__reactFiber$" + ul, Jt = "__reactProps$" + ul, Wl = "__reactContainer$" + ul, Si = "__reactEvents$" + ul, Jh = "__reactListeners$" + ul, wh = "__reactHandles$" + ul, lo = "__reactResources$" + ul, Xa = "__reactMarker$" + ul;
    function bi(t) {
      delete t[Yt], delete t[Jt], delete t[Si], delete t[Jh], delete t[wh];
    }
    function Fl(t) {
      var e = t[Yt];
      if (e) return e;
      for (var l = t.parentNode; l; ) {
        if (e = l[Wl] || l[Yt]) {
          if (l = e.alternate, e.child !== null || l !== null && l.child !== null) for (t = Ad(t); t !== null; ) {
            if (l = t[Yt]) return l;
            t = Ad(t);
          }
          return e;
        }
        t = l, l = t.parentNode;
      }
      return null;
    }
    function Il(t) {
      if (t = t[Yt] || t[Wl]) {
        var e = t.tag;
        if (e === 5 || e === 6 || e === 13 || e === 31 || e === 26 || e === 27 || e === 3) return t;
      }
      return null;
    }
    function Za(t) {
      var e = t.tag;
      if (e === 5 || e === 26 || e === 27 || e === 6) return t.stateNode;
      throw Error(o(33));
    }
    function Pl(t) {
      var e = t[lo];
      return e || (e = t[lo] = {
        hoistableStyles: /* @__PURE__ */ new Map(),
        hoistableScripts: /* @__PURE__ */ new Map()
      }), e;
    }
    function Ht(t) {
      t[Xa] = true;
    }
    var ao = /* @__PURE__ */ new Set(), uo = {};
    function Ul(t, e) {
      ta(t, e), ta(t + "Capture", e);
    }
    function ta(t, e) {
      for (uo[t] = e, t = 0; t < e.length; t++) ao.add(e[t]);
    }
    var $h = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), no = {}, io = {};
    function kh(t) {
      return hi.call(io, t) ? true : hi.call(no, t) ? false : $h.test(t) ? io[t] = true : (no[t] = true, false);
    }
    function Vu(t, e, l) {
      if (kh(e)) if (l === null) t.removeAttribute(e);
      else {
        switch (typeof l) {
          case "undefined":
          case "function":
          case "symbol":
            t.removeAttribute(e);
            return;
          case "boolean":
            var a = e.toLowerCase().slice(0, 5);
            if (a !== "data-" && a !== "aria-") {
              t.removeAttribute(e);
              return;
            }
        }
        t.setAttribute(e, "" + l);
      }
    }
    function Ku(t, e, l) {
      if (l === null) t.removeAttribute(e);
      else {
        switch (typeof l) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            t.removeAttribute(e);
            return;
        }
        t.setAttribute(e, "" + l);
      }
    }
    function Be(t, e, l, a) {
      if (a === null) t.removeAttribute(l);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            t.removeAttribute(l);
            return;
        }
        t.setAttributeNS(e, l, "" + a);
      }
    }
    function se(t) {
      switch (typeof t) {
        case "bigint":
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return t;
        case "object":
          return t;
        default:
          return "";
      }
    }
    function co(t) {
      var e = t.type;
      return (t = t.nodeName) && t.toLowerCase() === "input" && (e === "checkbox" || e === "radio");
    }
    function Wh(t, e, l) {
      var a = Object.getOwnPropertyDescriptor(t.constructor.prototype, e);
      if (!t.hasOwnProperty(e) && typeof a < "u" && typeof a.get == "function" && typeof a.set == "function") {
        var u = a.get, n = a.set;
        return Object.defineProperty(t, e, {
          configurable: true,
          get: function() {
            return u.call(this);
          },
          set: function(i) {
            l = "" + i, n.call(this, i);
          }
        }), Object.defineProperty(t, e, {
          enumerable: a.enumerable
        }), {
          getValue: function() {
            return l;
          },
          setValue: function(i) {
            l = "" + i;
          },
          stopTracking: function() {
            t._valueTracker = null, delete t[e];
          }
        };
      }
    }
    function Ei(t) {
      if (!t._valueTracker) {
        var e = co(t) ? "checked" : "value";
        t._valueTracker = Wh(t, e, "" + t[e]);
      }
    }
    function fo(t) {
      if (!t) return false;
      var e = t._valueTracker;
      if (!e) return true;
      var l = e.getValue(), a = "";
      return t && (a = co(t) ? t.checked ? "true" : "false" : t.value), t = a, t !== l ? (e.setValue(t), true) : false;
    }
    function Ju(t) {
      if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
      try {
        return t.activeElement || t.body;
      } catch {
        return t.body;
      }
    }
    var Fh = /[\n"\\]/g;
    function de(t) {
      return t.replace(Fh, function(e) {
        return "\\" + e.charCodeAt(0).toString(16) + " ";
      });
    }
    function zi(t, e, l, a, u, n, i, f) {
      t.name = "", i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" ? t.type = i : t.removeAttribute("type"), e != null ? i === "number" ? (e === 0 && t.value === "" || t.value != e) && (t.value = "" + se(e)) : t.value !== "" + se(e) && (t.value = "" + se(e)) : i !== "submit" && i !== "reset" || t.removeAttribute("value"), e != null ? Ti(t, i, se(e)) : l != null ? Ti(t, i, se(l)) : a != null && t.removeAttribute("value"), u == null && n != null && (t.defaultChecked = !!n), u != null && (t.checked = u && typeof u != "function" && typeof u != "symbol"), f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" ? t.name = "" + se(f) : t.removeAttribute("name");
    }
    function oo(t, e, l, a, u, n, i, f) {
      if (n != null && typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && (t.type = n), e != null || l != null) {
        if (!(n !== "submit" && n !== "reset" || e != null)) {
          Ei(t);
          return;
        }
        l = l != null ? "" + se(l) : "", e = e != null ? "" + se(e) : l, f || e === t.value || (t.value = e), t.defaultValue = e;
      }
      a = a ?? u, a = typeof a != "function" && typeof a != "symbol" && !!a, t.checked = f ? t.checked : !!a, t.defaultChecked = !!a, i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" && (t.name = i), Ei(t);
    }
    function Ti(t, e, l) {
      e === "number" && Ju(t.ownerDocument) === t || t.defaultValue === "" + l || (t.defaultValue = "" + l);
    }
    function ea(t, e, l, a) {
      if (t = t.options, e) {
        e = {};
        for (var u = 0; u < l.length; u++) e["$" + l[u]] = true;
        for (l = 0; l < t.length; l++) u = e.hasOwnProperty("$" + t[l].value), t[l].selected !== u && (t[l].selected = u), u && a && (t[l].defaultSelected = true);
      } else {
        for (l = "" + se(l), e = null, u = 0; u < t.length; u++) {
          if (t[u].value === l) {
            t[u].selected = true, a && (t[u].defaultSelected = true);
            return;
          }
          e !== null || t[u].disabled || (e = t[u]);
        }
        e !== null && (e.selected = true);
      }
    }
    function ro(t, e, l) {
      if (e != null && (e = "" + se(e), e !== t.value && (t.value = e), l == null)) {
        t.defaultValue !== e && (t.defaultValue = e);
        return;
      }
      t.defaultValue = l != null ? "" + se(l) : "";
    }
    function so(t, e, l, a) {
      if (e == null) {
        if (a != null) {
          if (l != null) throw Error(o(92));
          if (Ae(a)) {
            if (1 < a.length) throw Error(o(93));
            a = a[0];
          }
          l = a;
        }
        l == null && (l = ""), e = l;
      }
      l = se(e), t.defaultValue = l, a = t.textContent, a === l && a !== "" && a !== null && (t.value = a), Ei(t);
    }
    function la(t, e) {
      if (e) {
        var l = t.firstChild;
        if (l && l === t.lastChild && l.nodeType === 3) {
          l.nodeValue = e;
          return;
        }
      }
      t.textContent = e;
    }
    var Ih = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
    function ho(t, e, l) {
      var a = e.indexOf("--") === 0;
      l == null || typeof l == "boolean" || l === "" ? a ? t.setProperty(e, "") : e === "float" ? t.cssFloat = "" : t[e] = "" : a ? t.setProperty(e, l) : typeof l != "number" || l === 0 || Ih.has(e) ? e === "float" ? t.cssFloat = l : t[e] = ("" + l).trim() : t[e] = l + "px";
    }
    function mo(t, e, l) {
      if (e != null && typeof e != "object") throw Error(o(62));
      if (t = t.style, l != null) {
        for (var a in l) !l.hasOwnProperty(a) || e != null && e.hasOwnProperty(a) || (a.indexOf("--") === 0 ? t.setProperty(a, "") : a === "float" ? t.cssFloat = "" : t[a] = "");
        for (var u in e) a = e[u], e.hasOwnProperty(u) && l[u] !== a && ho(t, u, a);
      } else for (var n in e) e.hasOwnProperty(n) && ho(t, n, e[n]);
    }
    function Ai(t) {
      if (t.indexOf("-") === -1) return false;
      switch (t) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var Ph = /* @__PURE__ */ new Map([
      [
        "acceptCharset",
        "accept-charset"
      ],
      [
        "htmlFor",
        "for"
      ],
      [
        "httpEquiv",
        "http-equiv"
      ],
      [
        "crossOrigin",
        "crossorigin"
      ],
      [
        "accentHeight",
        "accent-height"
      ],
      [
        "alignmentBaseline",
        "alignment-baseline"
      ],
      [
        "arabicForm",
        "arabic-form"
      ],
      [
        "baselineShift",
        "baseline-shift"
      ],
      [
        "capHeight",
        "cap-height"
      ],
      [
        "clipPath",
        "clip-path"
      ],
      [
        "clipRule",
        "clip-rule"
      ],
      [
        "colorInterpolation",
        "color-interpolation"
      ],
      [
        "colorInterpolationFilters",
        "color-interpolation-filters"
      ],
      [
        "colorProfile",
        "color-profile"
      ],
      [
        "colorRendering",
        "color-rendering"
      ],
      [
        "dominantBaseline",
        "dominant-baseline"
      ],
      [
        "enableBackground",
        "enable-background"
      ],
      [
        "fillOpacity",
        "fill-opacity"
      ],
      [
        "fillRule",
        "fill-rule"
      ],
      [
        "floodColor",
        "flood-color"
      ],
      [
        "floodOpacity",
        "flood-opacity"
      ],
      [
        "fontFamily",
        "font-family"
      ],
      [
        "fontSize",
        "font-size"
      ],
      [
        "fontSizeAdjust",
        "font-size-adjust"
      ],
      [
        "fontStretch",
        "font-stretch"
      ],
      [
        "fontStyle",
        "font-style"
      ],
      [
        "fontVariant",
        "font-variant"
      ],
      [
        "fontWeight",
        "font-weight"
      ],
      [
        "glyphName",
        "glyph-name"
      ],
      [
        "glyphOrientationHorizontal",
        "glyph-orientation-horizontal"
      ],
      [
        "glyphOrientationVertical",
        "glyph-orientation-vertical"
      ],
      [
        "horizAdvX",
        "horiz-adv-x"
      ],
      [
        "horizOriginX",
        "horiz-origin-x"
      ],
      [
        "imageRendering",
        "image-rendering"
      ],
      [
        "letterSpacing",
        "letter-spacing"
      ],
      [
        "lightingColor",
        "lighting-color"
      ],
      [
        "markerEnd",
        "marker-end"
      ],
      [
        "markerMid",
        "marker-mid"
      ],
      [
        "markerStart",
        "marker-start"
      ],
      [
        "overlinePosition",
        "overline-position"
      ],
      [
        "overlineThickness",
        "overline-thickness"
      ],
      [
        "paintOrder",
        "paint-order"
      ],
      [
        "panose-1",
        "panose-1"
      ],
      [
        "pointerEvents",
        "pointer-events"
      ],
      [
        "renderingIntent",
        "rendering-intent"
      ],
      [
        "shapeRendering",
        "shape-rendering"
      ],
      [
        "stopColor",
        "stop-color"
      ],
      [
        "stopOpacity",
        "stop-opacity"
      ],
      [
        "strikethroughPosition",
        "strikethrough-position"
      ],
      [
        "strikethroughThickness",
        "strikethrough-thickness"
      ],
      [
        "strokeDasharray",
        "stroke-dasharray"
      ],
      [
        "strokeDashoffset",
        "stroke-dashoffset"
      ],
      [
        "strokeLinecap",
        "stroke-linecap"
      ],
      [
        "strokeLinejoin",
        "stroke-linejoin"
      ],
      [
        "strokeMiterlimit",
        "stroke-miterlimit"
      ],
      [
        "strokeOpacity",
        "stroke-opacity"
      ],
      [
        "strokeWidth",
        "stroke-width"
      ],
      [
        "textAnchor",
        "text-anchor"
      ],
      [
        "textDecoration",
        "text-decoration"
      ],
      [
        "textRendering",
        "text-rendering"
      ],
      [
        "transformOrigin",
        "transform-origin"
      ],
      [
        "underlinePosition",
        "underline-position"
      ],
      [
        "underlineThickness",
        "underline-thickness"
      ],
      [
        "unicodeBidi",
        "unicode-bidi"
      ],
      [
        "unicodeRange",
        "unicode-range"
      ],
      [
        "unitsPerEm",
        "units-per-em"
      ],
      [
        "vAlphabetic",
        "v-alphabetic"
      ],
      [
        "vHanging",
        "v-hanging"
      ],
      [
        "vIdeographic",
        "v-ideographic"
      ],
      [
        "vMathematical",
        "v-mathematical"
      ],
      [
        "vectorEffect",
        "vector-effect"
      ],
      [
        "vertAdvY",
        "vert-adv-y"
      ],
      [
        "vertOriginX",
        "vert-origin-x"
      ],
      [
        "vertOriginY",
        "vert-origin-y"
      ],
      [
        "wordSpacing",
        "word-spacing"
      ],
      [
        "writingMode",
        "writing-mode"
      ],
      [
        "xmlnsXlink",
        "xmlns:xlink"
      ],
      [
        "xHeight",
        "x-height"
      ]
    ]), tm = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
    function wu(t) {
      return tm.test("" + t) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : t;
    }
    function qe() {
    }
    var _i = null;
    function Ri(t) {
      return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t;
    }
    var aa = null, ua = null;
    function yo(t) {
      var e = Il(t);
      if (e && (t = e.stateNode)) {
        var l = t[Jt] || null;
        t: switch (t = e.stateNode, e.type) {
          case "input":
            if (zi(t, l.value, l.defaultValue, l.defaultValue, l.checked, l.defaultChecked, l.type, l.name), e = l.name, l.type === "radio" && e != null) {
              for (l = t; l.parentNode; ) l = l.parentNode;
              for (l = l.querySelectorAll('input[name="' + de("" + e) + '"][type="radio"]'), e = 0; e < l.length; e++) {
                var a = l[e];
                if (a !== t && a.form === t.form) {
                  var u = a[Jt] || null;
                  if (!u) throw Error(o(90));
                  zi(a, u.value, u.defaultValue, u.defaultValue, u.checked, u.defaultChecked, u.type, u.name);
                }
              }
              for (e = 0; e < l.length; e++) a = l[e], a.form === t.form && fo(a);
            }
            break t;
          case "textarea":
            ro(t, l.value, l.defaultValue);
            break t;
          case "select":
            e = l.value, e != null && ea(t, !!l.multiple, e, false);
        }
      }
    }
    var Mi = false;
    function vo(t, e, l) {
      if (Mi) return t(e, l);
      Mi = true;
      try {
        var a = t(e);
        return a;
      } finally {
        if (Mi = false, (aa !== null || ua !== null) && (Bn(), aa && (e = aa, t = ua, ua = aa = null, yo(e), t))) for (e = 0; e < t.length; e++) yo(t[e]);
      }
    }
    function Va(t, e) {
      var l = t.stateNode;
      if (l === null) return null;
      var a = l[Jt] || null;
      if (a === null) return null;
      l = a[e];
      t: switch (e) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (a = !a.disabled) || (t = t.type, a = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !a;
          break t;
        default:
          t = false;
      }
      if (t) return null;
      if (l && typeof l != "function") throw Error(o(231, e, typeof l));
      return l;
    }
    var Ye = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Oi = false;
    if (Ye) try {
      var Ka = {};
      Object.defineProperty(Ka, "passive", {
        get: function() {
          Oi = true;
        }
      }), window.addEventListener("test", Ka, Ka), window.removeEventListener("test", Ka, Ka);
    } catch {
      Oi = false;
    }
    var nl = null, Ci = null, $u = null;
    function go() {
      if ($u) return $u;
      var t, e = Ci, l = e.length, a, u = "value" in nl ? nl.value : nl.textContent, n = u.length;
      for (t = 0; t < l && e[t] === u[t]; t++) ;
      var i = l - t;
      for (a = 1; a <= i && e[l - a] === u[n - a]; a++) ;
      return $u = u.slice(t, 1 < a ? 1 - a : void 0);
    }
    function ku(t) {
      var e = t.keyCode;
      return "charCode" in t ? (t = t.charCode, t === 0 && e === 13 && (t = 13)) : t = e, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0;
    }
    function Wu() {
      return true;
    }
    function po() {
      return false;
    }
    function wt(t) {
      function e(l, a, u, n, i) {
        this._reactName = l, this._targetInst = u, this.type = a, this.nativeEvent = n, this.target = i, this.currentTarget = null;
        for (var f in t) t.hasOwnProperty(f) && (l = t[f], this[f] = l ? l(n) : n[f]);
        return this.isDefaultPrevented = (n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === false) ? Wu : po, this.isPropagationStopped = po, this;
      }
      return _(e.prototype, {
        preventDefault: function() {
          this.defaultPrevented = true;
          var l = this.nativeEvent;
          l && (l.preventDefault ? l.preventDefault() : typeof l.returnValue != "unknown" && (l.returnValue = false), this.isDefaultPrevented = Wu);
        },
        stopPropagation: function() {
          var l = this.nativeEvent;
          l && (l.stopPropagation ? l.stopPropagation() : typeof l.cancelBubble != "unknown" && (l.cancelBubble = true), this.isPropagationStopped = Wu);
        },
        persist: function() {
        },
        isPersistent: Wu
      }), e;
    }
    var xl = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function(t) {
        return t.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0
    }, Fu = wt(xl), Ja = _({}, xl, {
      view: 0,
      detail: 0
    }), em = wt(Ja), Di, Ui, wa, Iu = _({}, Ja, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Ni,
      button: 0,
      buttons: 0,
      relatedTarget: function(t) {
        return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget;
      },
      movementX: function(t) {
        return "movementX" in t ? t.movementX : (t !== wa && (wa && t.type === "mousemove" ? (Di = t.screenX - wa.screenX, Ui = t.screenY - wa.screenY) : Ui = Di = 0, wa = t), Di);
      },
      movementY: function(t) {
        return "movementY" in t ? t.movementY : Ui;
      }
    }), So = wt(Iu), lm = _({}, Iu, {
      dataTransfer: 0
    }), am = wt(lm), um = _({}, Ja, {
      relatedTarget: 0
    }), xi = wt(um), nm = _({}, xl, {
      animationName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), im = wt(nm), cm = _({}, xl, {
      clipboardData: function(t) {
        return "clipboardData" in t ? t.clipboardData : window.clipboardData;
      }
    }), fm = wt(cm), om = _({}, xl, {
      data: 0
    }), bo = wt(om), rm = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified"
    }, sm = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta"
    }, dm = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey"
    };
    function hm(t) {
      var e = this.nativeEvent;
      return e.getModifierState ? e.getModifierState(t) : (t = dm[t]) ? !!e[t] : false;
    }
    function Ni() {
      return hm;
    }
    var mm = _({}, Ja, {
      key: function(t) {
        if (t.key) {
          var e = rm[t.key] || t.key;
          if (e !== "Unidentified") return e;
        }
        return t.type === "keypress" ? (t = ku(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? sm[t.keyCode] || "Unidentified" : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Ni,
      charCode: function(t) {
        return t.type === "keypress" ? ku(t) : 0;
      },
      keyCode: function(t) {
        return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
      },
      which: function(t) {
        return t.type === "keypress" ? ku(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
      }
    }), ym = wt(mm), vm = _({}, Iu, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0
    }), Eo = wt(vm), gm = _({}, Ja, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Ni
    }), pm = wt(gm), Sm = _({}, xl, {
      propertyName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), bm = wt(Sm), Em = _({}, Iu, {
      deltaX: function(t) {
        return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0;
      },
      deltaY: function(t) {
        return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0;
      },
      deltaZ: 0,
      deltaMode: 0
    }), zm = wt(Em), Tm = _({}, xl, {
      newState: 0,
      oldState: 0
    }), Am = wt(Tm), _m = [
      9,
      13,
      27,
      32
    ], Hi = Ye && "CompositionEvent" in window, $a = null;
    Ye && "documentMode" in document && ($a = document.documentMode);
    var Rm = Ye && "TextEvent" in window && !$a, zo = Ye && (!Hi || $a && 8 < $a && 11 >= $a), To = " ", Ao = false;
    function _o(t, e) {
      switch (t) {
        case "keyup":
          return _m.indexOf(e.keyCode) !== -1;
        case "keydown":
          return e.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function Ro(t) {
      return t = t.detail, typeof t == "object" && "data" in t ? t.data : null;
    }
    var na = false;
    function Mm(t, e) {
      switch (t) {
        case "compositionend":
          return Ro(e);
        case "keypress":
          return e.which !== 32 ? null : (Ao = true, To);
        case "textInput":
          return t = e.data, t === To && Ao ? null : t;
        default:
          return null;
      }
    }
    function Om(t, e) {
      if (na) return t === "compositionend" || !Hi && _o(t, e) ? (t = go(), $u = Ci = nl = null, na = false, t) : null;
      switch (t) {
        case "paste":
          return null;
        case "keypress":
          if (!(e.ctrlKey || e.altKey || e.metaKey) || e.ctrlKey && e.altKey) {
            if (e.char && 1 < e.char.length) return e.char;
            if (e.which) return String.fromCharCode(e.which);
          }
          return null;
        case "compositionend":
          return zo && e.locale !== "ko" ? null : e.data;
        default:
          return null;
      }
    }
    var Cm = {
      color: true,
      date: true,
      datetime: true,
      "datetime-local": true,
      email: true,
      month: true,
      number: true,
      password: true,
      range: true,
      search: true,
      tel: true,
      text: true,
      time: true,
      url: true,
      week: true
    };
    function Mo(t) {
      var e = t && t.nodeName && t.nodeName.toLowerCase();
      return e === "input" ? !!Cm[t.type] : e === "textarea";
    }
    function Oo(t, e, l, a) {
      aa ? ua ? ua.push(a) : ua = [
        a
      ] : aa = a, e = Xn(e, "onChange"), 0 < e.length && (l = new Fu("onChange", "change", null, l, a), t.push({
        event: l,
        listeners: e
      }));
    }
    var ka = null, Wa = null;
    function Dm(t) {
      rd(t, 0);
    }
    function Pu(t) {
      var e = Za(t);
      if (fo(e)) return t;
    }
    function Co(t, e) {
      if (t === "change") return e;
    }
    var Do = false;
    if (Ye) {
      var Bi;
      if (Ye) {
        var qi = "oninput" in document;
        if (!qi) {
          var Uo = document.createElement("div");
          Uo.setAttribute("oninput", "return;"), qi = typeof Uo.oninput == "function";
        }
        Bi = qi;
      } else Bi = false;
      Do = Bi && (!document.documentMode || 9 < document.documentMode);
    }
    function xo() {
      ka && (ka.detachEvent("onpropertychange", No), Wa = ka = null);
    }
    function No(t) {
      if (t.propertyName === "value" && Pu(Wa)) {
        var e = [];
        Oo(e, Wa, t, Ri(t)), vo(Dm, e);
      }
    }
    function Um(t, e, l) {
      t === "focusin" ? (xo(), ka = e, Wa = l, ka.attachEvent("onpropertychange", No)) : t === "focusout" && xo();
    }
    function xm(t) {
      if (t === "selectionchange" || t === "keyup" || t === "keydown") return Pu(Wa);
    }
    function Nm(t, e) {
      if (t === "click") return Pu(e);
    }
    function Hm(t, e) {
      if (t === "input" || t === "change") return Pu(e);
    }
    function Bm(t, e) {
      return t === e && (t !== 0 || 1 / t === 1 / e) || t !== t && e !== e;
    }
    var le = typeof Object.is == "function" ? Object.is : Bm;
    function Fa(t, e) {
      if (le(t, e)) return true;
      if (typeof t != "object" || t === null || typeof e != "object" || e === null) return false;
      var l = Object.keys(t), a = Object.keys(e);
      if (l.length !== a.length) return false;
      for (a = 0; a < l.length; a++) {
        var u = l[a];
        if (!hi.call(e, u) || !le(t[u], e[u])) return false;
      }
      return true;
    }
    function Ho(t) {
      for (; t && t.firstChild; ) t = t.firstChild;
      return t;
    }
    function Bo(t, e) {
      var l = Ho(t);
      t = 0;
      for (var a; l; ) {
        if (l.nodeType === 3) {
          if (a = t + l.textContent.length, t <= e && a >= e) return {
            node: l,
            offset: e - t
          };
          t = a;
        }
        t: {
          for (; l; ) {
            if (l.nextSibling) {
              l = l.nextSibling;
              break t;
            }
            l = l.parentNode;
          }
          l = void 0;
        }
        l = Ho(l);
      }
    }
    function qo(t, e) {
      return t && e ? t === e ? true : t && t.nodeType === 3 ? false : e && e.nodeType === 3 ? qo(t, e.parentNode) : "contains" in t ? t.contains(e) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(e) & 16) : false : false;
    }
    function Yo(t) {
      t = t != null && t.ownerDocument != null && t.ownerDocument.defaultView != null ? t.ownerDocument.defaultView : window;
      for (var e = Ju(t.document); e instanceof t.HTMLIFrameElement; ) {
        try {
          var l = typeof e.contentWindow.location.href == "string";
        } catch {
          l = false;
        }
        if (l) t = e.contentWindow;
        else break;
        e = Ju(t.document);
      }
      return e;
    }
    function Yi(t) {
      var e = t && t.nodeName && t.nodeName.toLowerCase();
      return e && (e === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || e === "textarea" || t.contentEditable === "true");
    }
    var qm = Ye && "documentMode" in document && 11 >= document.documentMode, ia = null, Li = null, Ia = null, ji = false;
    function Lo(t, e, l) {
      var a = l.window === l ? l.document : l.nodeType === 9 ? l : l.ownerDocument;
      ji || ia == null || ia !== Ju(a) || (a = ia, "selectionStart" in a && Yi(a) ? a = {
        start: a.selectionStart,
        end: a.selectionEnd
      } : (a = (a.ownerDocument && a.ownerDocument.defaultView || window).getSelection(), a = {
        anchorNode: a.anchorNode,
        anchorOffset: a.anchorOffset,
        focusNode: a.focusNode,
        focusOffset: a.focusOffset
      }), Ia && Fa(Ia, a) || (Ia = a, a = Xn(Li, "onSelect"), 0 < a.length && (e = new Fu("onSelect", "select", null, e, l), t.push({
        event: e,
        listeners: a
      }), e.target = ia)));
    }
    function Nl(t, e) {
      var l = {};
      return l[t.toLowerCase()] = e.toLowerCase(), l["Webkit" + t] = "webkit" + e, l["Moz" + t] = "moz" + e, l;
    }
    var ca = {
      animationend: Nl("Animation", "AnimationEnd"),
      animationiteration: Nl("Animation", "AnimationIteration"),
      animationstart: Nl("Animation", "AnimationStart"),
      transitionrun: Nl("Transition", "TransitionRun"),
      transitionstart: Nl("Transition", "TransitionStart"),
      transitioncancel: Nl("Transition", "TransitionCancel"),
      transitionend: Nl("Transition", "TransitionEnd")
    }, Qi = {}, jo = {};
    Ye && (jo = document.createElement("div").style, "AnimationEvent" in window || (delete ca.animationend.animation, delete ca.animationiteration.animation, delete ca.animationstart.animation), "TransitionEvent" in window || delete ca.transitionend.transition);
    function Hl(t) {
      if (Qi[t]) return Qi[t];
      if (!ca[t]) return t;
      var e = ca[t], l;
      for (l in e) if (e.hasOwnProperty(l) && l in jo) return Qi[t] = e[l];
      return t;
    }
    var Qo = Hl("animationend"), Go = Hl("animationiteration"), Xo = Hl("animationstart"), Ym = Hl("transitionrun"), Lm = Hl("transitionstart"), jm = Hl("transitioncancel"), Zo = Hl("transitionend"), Vo = /* @__PURE__ */ new Map(), Gi = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    Gi.push("scrollEnd");
    function _e(t, e) {
      Vo.set(t, e), Ul(e, [
        t
      ]);
    }
    var tn = typeof reportError == "function" ? reportError : function(t) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var e = new window.ErrorEvent("error", {
          bubbles: true,
          cancelable: true,
          message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
          error: t
        });
        if (!window.dispatchEvent(e)) return;
      } else if (typeof Ba == "object" && typeof Ba.emit == "function") {
        Ba.emit("uncaughtException", t);
        return;
      }
      console.error(t);
    }, he = [], fa = 0, Xi = 0;
    function en() {
      for (var t = fa, e = Xi = fa = 0; e < t; ) {
        var l = he[e];
        he[e++] = null;
        var a = he[e];
        he[e++] = null;
        var u = he[e];
        he[e++] = null;
        var n = he[e];
        if (he[e++] = null, a !== null && u !== null) {
          var i = a.pending;
          i === null ? u.next = u : (u.next = i.next, i.next = u), a.pending = u;
        }
        n !== 0 && Ko(l, u, n);
      }
    }
    function ln(t, e, l, a) {
      he[fa++] = t, he[fa++] = e, he[fa++] = l, he[fa++] = a, Xi |= a, t.lanes |= a, t = t.alternate, t !== null && (t.lanes |= a);
    }
    function Zi(t, e, l, a) {
      return ln(t, e, l, a), an(t);
    }
    function Bl(t, e) {
      return ln(t, null, null, e), an(t);
    }
    function Ko(t, e, l) {
      t.lanes |= l;
      var a = t.alternate;
      a !== null && (a.lanes |= l);
      for (var u = false, n = t.return; n !== null; ) n.childLanes |= l, a = n.alternate, a !== null && (a.childLanes |= l), n.tag === 22 && (t = n.stateNode, t === null || t._visibility & 1 || (u = true)), t = n, n = n.return;
      return t.tag === 3 ? (n = t.stateNode, u && e !== null && (u = 31 - ee(l), t = n.hiddenUpdates, a = t[u], a === null ? t[u] = [
        e
      ] : a.push(e), e.lane = l | 536870912), n) : null;
    }
    function an(t) {
      if (50 < bu) throw bu = 0, Ic = null, Error(o(185));
      for (var e = t.return; e !== null; ) t = e, e = t.return;
      return t.tag === 3 ? t.stateNode : null;
    }
    var oa = {};
    function Qm(t, e, l, a) {
      this.tag = t, this.key = l, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = e, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = a, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
    }
    function ae(t, e, l, a) {
      return new Qm(t, e, l, a);
    }
    function Vi(t) {
      return t = t.prototype, !(!t || !t.isReactComponent);
    }
    function Le(t, e) {
      var l = t.alternate;
      return l === null ? (l = ae(t.tag, e, t.key, t.mode), l.elementType = t.elementType, l.type = t.type, l.stateNode = t.stateNode, l.alternate = t, t.alternate = l) : (l.pendingProps = e, l.type = t.type, l.flags = 0, l.subtreeFlags = 0, l.deletions = null), l.flags = t.flags & 65011712, l.childLanes = t.childLanes, l.lanes = t.lanes, l.child = t.child, l.memoizedProps = t.memoizedProps, l.memoizedState = t.memoizedState, l.updateQueue = t.updateQueue, e = t.dependencies, l.dependencies = e === null ? null : {
        lanes: e.lanes,
        firstContext: e.firstContext
      }, l.sibling = t.sibling, l.index = t.index, l.ref = t.ref, l.refCleanup = t.refCleanup, l;
    }
    function Jo(t, e) {
      t.flags &= 65011714;
      var l = t.alternate;
      return l === null ? (t.childLanes = 0, t.lanes = e, t.child = null, t.subtreeFlags = 0, t.memoizedProps = null, t.memoizedState = null, t.updateQueue = null, t.dependencies = null, t.stateNode = null) : (t.childLanes = l.childLanes, t.lanes = l.lanes, t.child = l.child, t.subtreeFlags = 0, t.deletions = null, t.memoizedProps = l.memoizedProps, t.memoizedState = l.memoizedState, t.updateQueue = l.updateQueue, t.type = l.type, e = l.dependencies, t.dependencies = e === null ? null : {
        lanes: e.lanes,
        firstContext: e.firstContext
      }), t;
    }
    function un(t, e, l, a, u, n) {
      var i = 0;
      if (a = t, typeof t == "function") Vi(t) && (i = 1);
      else if (typeof t == "string") i = Ky(t, l, K.current) ? 26 : t === "html" || t === "head" || t === "body" ? 27 : 5;
      else t: switch (t) {
        case Xt:
          return t = ae(31, l, e, u), t.elementType = Xt, t.lanes = n, t;
        case Y:
          return ql(l.children, u, n, e);
        case L:
          i = 8, u |= 24;
          break;
        case N:
          return t = ae(12, l, e, u | 2), t.elementType = N, t.lanes = n, t;
        case gt:
          return t = ae(13, l, e, u), t.elementType = gt, t.lanes = n, t;
        case qt:
          return t = ae(19, l, e, u), t.elementType = qt, t.lanes = n, t;
        default:
          if (typeof t == "object" && t !== null) switch (t.$$typeof) {
            case w:
              i = 10;
              break t;
            case H:
              i = 9;
              break t;
            case zt:
              i = 11;
              break t;
            case F:
              i = 14;
              break t;
            case Ot:
              i = 16, a = null;
              break t;
          }
          i = 29, l = Error(o(130, t === null ? "null" : typeof t, "")), a = null;
      }
      return e = ae(i, l, e, u), e.elementType = t, e.type = a, e.lanes = n, e;
    }
    function ql(t, e, l, a) {
      return t = ae(7, t, a, e), t.lanes = l, t;
    }
    function Ki(t, e, l) {
      return t = ae(6, t, null, e), t.lanes = l, t;
    }
    function wo(t) {
      var e = ae(18, null, null, 0);
      return e.stateNode = t, e;
    }
    function Ji(t, e, l) {
      return e = ae(4, t.children !== null ? t.children : [], t.key, e), e.lanes = l, e.stateNode = {
        containerInfo: t.containerInfo,
        pendingChildren: null,
        implementation: t.implementation
      }, e;
    }
    var $o = /* @__PURE__ */ new WeakMap();
    function me(t, e) {
      if (typeof t == "object" && t !== null) {
        var l = $o.get(t);
        return l !== void 0 ? l : (e = {
          value: t,
          source: e,
          stack: Jf(e)
        }, $o.set(t, e), e);
      }
      return {
        value: t,
        source: e,
        stack: Jf(e)
      };
    }
    var ra = [], sa = 0, nn = null, Pa = 0, ye = [], ve = 0, il = null, Ce = 1, De = "";
    function je(t, e) {
      ra[sa++] = Pa, ra[sa++] = nn, nn = t, Pa = e;
    }
    function ko(t, e, l) {
      ye[ve++] = Ce, ye[ve++] = De, ye[ve++] = il, il = t;
      var a = Ce;
      t = De;
      var u = 32 - ee(a) - 1;
      a &= ~(1 << u), l += 1;
      var n = 32 - ee(e) + u;
      if (30 < n) {
        var i = u - u % 5;
        n = (a & (1 << i) - 1).toString(32), a >>= i, u -= i, Ce = 1 << 32 - ee(e) + u | l << u | a, De = n + t;
      } else Ce = 1 << n | l << u | a, De = t;
    }
    function wi(t) {
      t.return !== null && (je(t, 1), ko(t, 1, 0));
    }
    function $i(t) {
      for (; t === nn; ) nn = ra[--sa], ra[sa] = null, Pa = ra[--sa], ra[sa] = null;
      for (; t === il; ) il = ye[--ve], ye[ve] = null, De = ye[--ve], ye[ve] = null, Ce = ye[--ve], ye[ve] = null;
    }
    function Wo(t, e) {
      ye[ve++] = Ce, ye[ve++] = De, ye[ve++] = il, Ce = e.id, De = e.overflow, il = t;
    }
    var Lt = null, pt = null, nt = false, cl = null, ge = false, ki = Error(o(519));
    function fl(t) {
      var e = Error(o(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", ""));
      throw tu(me(e, t)), ki;
    }
    function Fo(t) {
      var e = t.stateNode, l = t.type, a = t.memoizedProps;
      switch (e[Yt] = t, e[Jt] = a, l) {
        case "dialog":
          et("cancel", e), et("close", e);
          break;
        case "iframe":
        case "object":
        case "embed":
          et("load", e);
          break;
        case "video":
        case "audio":
          for (l = 0; l < zu.length; l++) et(zu[l], e);
          break;
        case "source":
          et("error", e);
          break;
        case "img":
        case "image":
        case "link":
          et("error", e), et("load", e);
          break;
        case "details":
          et("toggle", e);
          break;
        case "input":
          et("invalid", e), oo(e, a.value, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name, true);
          break;
        case "select":
          et("invalid", e);
          break;
        case "textarea":
          et("invalid", e), so(e, a.value, a.defaultValue, a.children);
      }
      l = a.children, typeof l != "string" && typeof l != "number" && typeof l != "bigint" || e.textContent === "" + l || a.suppressHydrationWarning === true || md(e.textContent, l) ? (a.popover != null && (et("beforetoggle", e), et("toggle", e)), a.onScroll != null && et("scroll", e), a.onScrollEnd != null && et("scrollend", e), a.onClick != null && (e.onclick = qe), e = true) : e = false, e || fl(t, true);
    }
    function Io(t) {
      for (Lt = t.return; Lt; ) switch (Lt.tag) {
        case 5:
        case 31:
        case 13:
          ge = false;
          return;
        case 27:
        case 3:
          ge = true;
          return;
        default:
          Lt = Lt.return;
      }
    }
    function da(t) {
      if (t !== Lt) return false;
      if (!nt) return Io(t), nt = true, false;
      var e = t.tag, l;
      if ((l = e !== 3 && e !== 27) && ((l = e === 5) && (l = t.type, l = !(l !== "form" && l !== "button") || mf(t.type, t.memoizedProps)), l = !l), l && pt && fl(t), Io(t), e === 13) {
        if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(o(317));
        pt = Td(t);
      } else if (e === 31) {
        if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(o(317));
        pt = Td(t);
      } else e === 27 ? (e = pt, zl(t.type) ? (t = Sf, Sf = null, pt = t) : pt = e) : pt = Lt ? Se(t.stateNode.nextSibling) : null;
      return true;
    }
    function Yl() {
      pt = Lt = null, nt = false;
    }
    function Wi() {
      var t = cl;
      return t !== null && (Ft === null ? Ft = t : Ft.push.apply(Ft, t), cl = null), t;
    }
    function tu(t) {
      cl === null ? cl = [
        t
      ] : cl.push(t);
    }
    var Fi = g(null), Ll = null, Qe = null;
    function ol(t, e, l) {
      B(Fi, e._currentValue), e._currentValue = l;
    }
    function Ge(t) {
      t._currentValue = Fi.current, x(Fi);
    }
    function Ii(t, e, l) {
      for (; t !== null; ) {
        var a = t.alternate;
        if ((t.childLanes & e) !== e ? (t.childLanes |= e, a !== null && (a.childLanes |= e)) : a !== null && (a.childLanes & e) !== e && (a.childLanes |= e), t === l) break;
        t = t.return;
      }
    }
    function Pi(t, e, l, a) {
      var u = t.child;
      for (u !== null && (u.return = t); u !== null; ) {
        var n = u.dependencies;
        if (n !== null) {
          var i = u.child;
          n = n.firstContext;
          t: for (; n !== null; ) {
            var f = n;
            n = u;
            for (var d = 0; d < e.length; d++) if (f.context === e[d]) {
              n.lanes |= l, f = n.alternate, f !== null && (f.lanes |= l), Ii(n.return, l, t), a || (i = null);
              break t;
            }
            n = f.next;
          }
        } else if (u.tag === 18) {
          if (i = u.return, i === null) throw Error(o(341));
          i.lanes |= l, n = i.alternate, n !== null && (n.lanes |= l), Ii(i, l, t), i = null;
        } else i = u.child;
        if (i !== null) i.return = u;
        else for (i = u; i !== null; ) {
          if (i === t) {
            i = null;
            break;
          }
          if (u = i.sibling, u !== null) {
            u.return = i.return, i = u;
            break;
          }
          i = i.return;
        }
        u = i;
      }
    }
    function ha(t, e, l, a) {
      t = null;
      for (var u = e, n = false; u !== null; ) {
        if (!n) {
          if ((u.flags & 524288) !== 0) n = true;
          else if ((u.flags & 262144) !== 0) break;
        }
        if (u.tag === 10) {
          var i = u.alternate;
          if (i === null) throw Error(o(387));
          if (i = i.memoizedProps, i !== null) {
            var f = u.type;
            le(u.pendingProps.value, i.value) || (t !== null ? t.push(f) : t = [
              f
            ]);
          }
        } else if (u === ot.current) {
          if (i = u.alternate, i === null) throw Error(o(387));
          i.memoizedState.memoizedState !== u.memoizedState.memoizedState && (t !== null ? t.push(Mu) : t = [
            Mu
          ]);
        }
        u = u.return;
      }
      t !== null && Pi(e, t, l, a), e.flags |= 262144;
    }
    function cn(t) {
      for (t = t.firstContext; t !== null; ) {
        if (!le(t.context._currentValue, t.memoizedValue)) return true;
        t = t.next;
      }
      return false;
    }
    function jl(t) {
      Ll = t, Qe = null, t = t.dependencies, t !== null && (t.firstContext = null);
    }
    function jt(t) {
      return Po(Ll, t);
    }
    function fn(t, e) {
      return Ll === null && jl(t), Po(t, e);
    }
    function Po(t, e) {
      var l = e._currentValue;
      if (e = {
        context: e,
        memoizedValue: l,
        next: null
      }, Qe === null) {
        if (t === null) throw Error(o(308));
        Qe = e, t.dependencies = {
          lanes: 0,
          firstContext: e
        }, t.flags |= 524288;
      } else Qe = Qe.next = e;
      return l;
    }
    var Gm = typeof AbortController < "u" ? AbortController : function() {
      var t = [], e = this.signal = {
        aborted: false,
        addEventListener: function(l, a) {
          t.push(a);
        }
      };
      this.abort = function() {
        e.aborted = true, t.forEach(function(l) {
          return l();
        });
      };
    }, Xm = c.unstable_scheduleCallback, Zm = c.unstable_NormalPriority, Ct = {
      $$typeof: w,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0
    };
    function tc() {
      return {
        controller: new Gm(),
        data: /* @__PURE__ */ new Map(),
        refCount: 0
      };
    }
    function eu(t) {
      t.refCount--, t.refCount === 0 && Xm(Zm, function() {
        t.controller.abort();
      });
    }
    var lu = null, ec = 0, ma = 0, ya = null;
    function Vm(t, e) {
      if (lu === null) {
        var l = lu = [];
        ec = 0, ma = uf(), ya = {
          status: "pending",
          value: void 0,
          then: function(a) {
            l.push(a);
          }
        };
      }
      return ec++, e.then(tr, tr), e;
    }
    function tr() {
      if (--ec === 0 && lu !== null) {
        ya !== null && (ya.status = "fulfilled");
        var t = lu;
        lu = null, ma = 0, ya = null;
        for (var e = 0; e < t.length; e++) (0, t[e])();
      }
    }
    function Km(t, e) {
      var l = [], a = {
        status: "pending",
        value: null,
        reason: null,
        then: function(u) {
          l.push(u);
        }
      };
      return t.then(function() {
        a.status = "fulfilled", a.value = e;
        for (var u = 0; u < l.length; u++) (0, l[u])(e);
      }, function(u) {
        for (a.status = "rejected", a.reason = u, u = 0; u < l.length; u++) (0, l[u])(void 0);
      }), a;
    }
    var er = X.S;
    X.S = function(t, e) {
      Ls = Pt(), typeof e == "object" && e !== null && typeof e.then == "function" && Vm(t, e), er !== null && er(t, e);
    };
    var Ql = g(null);
    function lc() {
      var t = Ql.current;
      return t !== null ? t : vt.pooledCache;
    }
    function on(t, e) {
      e === null ? B(Ql, Ql.current) : B(Ql, e.pool);
    }
    function lr() {
      var t = lc();
      return t === null ? null : {
        parent: Ct._currentValue,
        pool: t
      };
    }
    var va = Error(o(460)), ac = Error(o(474)), rn = Error(o(542)), sn = {
      then: function() {
      }
    };
    function ar(t) {
      return t = t.status, t === "fulfilled" || t === "rejected";
    }
    function ur(t, e, l) {
      switch (l = t[l], l === void 0 ? t.push(e) : l !== e && (e.then(qe, qe), e = l), e.status) {
        case "fulfilled":
          return e.value;
        case "rejected":
          throw t = e.reason, ir(t), t;
        default:
          if (typeof e.status == "string") e.then(qe, qe);
          else {
            if (t = vt, t !== null && 100 < t.shellSuspendCounter) throw Error(o(482));
            t = e, t.status = "pending", t.then(function(a) {
              if (e.status === "pending") {
                var u = e;
                u.status = "fulfilled", u.value = a;
              }
            }, function(a) {
              if (e.status === "pending") {
                var u = e;
                u.status = "rejected", u.reason = a;
              }
            });
          }
          switch (e.status) {
            case "fulfilled":
              return e.value;
            case "rejected":
              throw t = e.reason, ir(t), t;
          }
          throw Xl = e, va;
      }
    }
    function Gl(t) {
      try {
        var e = t._init;
        return e(t._payload);
      } catch (l) {
        throw l !== null && typeof l == "object" && typeof l.then == "function" ? (Xl = l, va) : l;
      }
    }
    var Xl = null;
    function nr() {
      if (Xl === null) throw Error(o(459));
      var t = Xl;
      return Xl = null, t;
    }
    function ir(t) {
      if (t === va || t === rn) throw Error(o(483));
    }
    var ga = null, au = 0;
    function dn(t) {
      var e = au;
      return au += 1, ga === null && (ga = []), ur(ga, t, e);
    }
    function uu(t, e) {
      e = e.props.ref, t.ref = e !== void 0 ? e : null;
    }
    function hn(t, e) {
      throw e.$$typeof === q ? Error(o(525)) : (t = Object.prototype.toString.call(e), Error(o(31, t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t)));
    }
    function cr(t) {
      function e(p, m) {
        if (t) {
          var E = p.deletions;
          E === null ? (p.deletions = [
            m
          ], p.flags |= 16) : E.push(m);
        }
      }
      function l(p, m) {
        if (!t) return null;
        for (; m !== null; ) e(p, m), m = m.sibling;
        return null;
      }
      function a(p) {
        for (var m = /* @__PURE__ */ new Map(); p !== null; ) p.key !== null ? m.set(p.key, p) : m.set(p.index, p), p = p.sibling;
        return m;
      }
      function u(p, m) {
        return p = Le(p, m), p.index = 0, p.sibling = null, p;
      }
      function n(p, m, E) {
        return p.index = E, t ? (E = p.alternate, E !== null ? (E = E.index, E < m ? (p.flags |= 67108866, m) : E) : (p.flags |= 67108866, m)) : (p.flags |= 1048576, m);
      }
      function i(p) {
        return t && p.alternate === null && (p.flags |= 67108866), p;
      }
      function f(p, m, E, D) {
        return m === null || m.tag !== 6 ? (m = Ki(E, p.mode, D), m.return = p, m) : (m = u(m, E), m.return = p, m);
      }
      function d(p, m, E, D) {
        var V = E.type;
        return V === Y ? M(p, m, E.props.children, D, E.key) : m !== null && (m.elementType === V || typeof V == "object" && V !== null && V.$$typeof === Ot && Gl(V) === m.type) ? (m = u(m, E.props), uu(m, E), m.return = p, m) : (m = un(E.type, E.key, E.props, null, p.mode, D), uu(m, E), m.return = p, m);
      }
      function z(p, m, E, D) {
        return m === null || m.tag !== 4 || m.stateNode.containerInfo !== E.containerInfo || m.stateNode.implementation !== E.implementation ? (m = Ji(E, p.mode, D), m.return = p, m) : (m = u(m, E.children || []), m.return = p, m);
      }
      function M(p, m, E, D, V) {
        return m === null || m.tag !== 7 ? (m = ql(E, p.mode, D, V), m.return = p, m) : (m = u(m, E), m.return = p, m);
      }
      function U(p, m, E) {
        if (typeof m == "string" && m !== "" || typeof m == "number" || typeof m == "bigint") return m = Ki("" + m, p.mode, E), m.return = p, m;
        if (typeof m == "object" && m !== null) {
          switch (m.$$typeof) {
            case Z:
              return E = un(m.type, m.key, m.props, null, p.mode, E), uu(E, m), E.return = p, E;
            case G:
              return m = Ji(m, p.mode, E), m.return = p, m;
            case Ot:
              return m = Gl(m), U(p, m, E);
          }
          if (Ae(m) || ze(m)) return m = ql(m, p.mode, E, null), m.return = p, m;
          if (typeof m.then == "function") return U(p, dn(m), E);
          if (m.$$typeof === w) return U(p, fn(p, m), E);
          hn(p, m);
        }
        return null;
      }
      function T(p, m, E, D) {
        var V = m !== null ? m.key : null;
        if (typeof E == "string" && E !== "" || typeof E == "number" || typeof E == "bigint") return V !== null ? null : f(p, m, "" + E, D);
        if (typeof E == "object" && E !== null) {
          switch (E.$$typeof) {
            case Z:
              return E.key === V ? d(p, m, E, D) : null;
            case G:
              return E.key === V ? z(p, m, E, D) : null;
            case Ot:
              return E = Gl(E), T(p, m, E, D);
          }
          if (Ae(E) || ze(E)) return V !== null ? null : M(p, m, E, D, null);
          if (typeof E.then == "function") return T(p, m, dn(E), D);
          if (E.$$typeof === w) return T(p, m, fn(p, E), D);
          hn(p, E);
        }
        return null;
      }
      function A(p, m, E, D, V) {
        if (typeof D == "string" && D !== "" || typeof D == "number" || typeof D == "bigint") return p = p.get(E) || null, f(m, p, "" + D, V);
        if (typeof D == "object" && D !== null) {
          switch (D.$$typeof) {
            case Z:
              return p = p.get(D.key === null ? E : D.key) || null, d(m, p, D, V);
            case G:
              return p = p.get(D.key === null ? E : D.key) || null, z(m, p, D, V);
            case Ot:
              return D = Gl(D), A(p, m, E, D, V);
          }
          if (Ae(D) || ze(D)) return p = p.get(E) || null, M(m, p, D, V, null);
          if (typeof D.then == "function") return A(p, m, E, dn(D), V);
          if (D.$$typeof === w) return A(p, m, E, fn(m, D), V);
          hn(m, D);
        }
        return null;
      }
      function j(p, m, E, D) {
        for (var V = null, it = null, Q = m, W = m = 0, ut = null; Q !== null && W < E.length; W++) {
          Q.index > W ? (ut = Q, Q = null) : ut = Q.sibling;
          var ct = T(p, Q, E[W], D);
          if (ct === null) {
            Q === null && (Q = ut);
            break;
          }
          t && Q && ct.alternate === null && e(p, Q), m = n(ct, m, W), it === null ? V = ct : it.sibling = ct, it = ct, Q = ut;
        }
        if (W === E.length) return l(p, Q), nt && je(p, W), V;
        if (Q === null) {
          for (; W < E.length; W++) Q = U(p, E[W], D), Q !== null && (m = n(Q, m, W), it === null ? V = Q : it.sibling = Q, it = Q);
          return nt && je(p, W), V;
        }
        for (Q = a(Q); W < E.length; W++) ut = A(Q, p, W, E[W], D), ut !== null && (t && ut.alternate !== null && Q.delete(ut.key === null ? W : ut.key), m = n(ut, m, W), it === null ? V = ut : it.sibling = ut, it = ut);
        return t && Q.forEach(function(Ml) {
          return e(p, Ml);
        }), nt && je(p, W), V;
      }
      function J(p, m, E, D) {
        if (E == null) throw Error(o(151));
        for (var V = null, it = null, Q = m, W = m = 0, ut = null, ct = E.next(); Q !== null && !ct.done; W++, ct = E.next()) {
          Q.index > W ? (ut = Q, Q = null) : ut = Q.sibling;
          var Ml = T(p, Q, ct.value, D);
          if (Ml === null) {
            Q === null && (Q = ut);
            break;
          }
          t && Q && Ml.alternate === null && e(p, Q), m = n(Ml, m, W), it === null ? V = Ml : it.sibling = Ml, it = Ml, Q = ut;
        }
        if (ct.done) return l(p, Q), nt && je(p, W), V;
        if (Q === null) {
          for (; !ct.done; W++, ct = E.next()) ct = U(p, ct.value, D), ct !== null && (m = n(ct, m, W), it === null ? V = ct : it.sibling = ct, it = ct);
          return nt && je(p, W), V;
        }
        for (Q = a(Q); !ct.done; W++, ct = E.next()) ct = A(Q, p, W, ct.value, D), ct !== null && (t && ct.alternate !== null && Q.delete(ct.key === null ? W : ct.key), m = n(ct, m, W), it === null ? V = ct : it.sibling = ct, it = ct);
        return t && Q.forEach(function(l0) {
          return e(p, l0);
        }), nt && je(p, W), V;
      }
      function yt(p, m, E, D) {
        if (typeof E == "object" && E !== null && E.type === Y && E.key === null && (E = E.props.children), typeof E == "object" && E !== null) {
          switch (E.$$typeof) {
            case Z:
              t: {
                for (var V = E.key; m !== null; ) {
                  if (m.key === V) {
                    if (V = E.type, V === Y) {
                      if (m.tag === 7) {
                        l(p, m.sibling), D = u(m, E.props.children), D.return = p, p = D;
                        break t;
                      }
                    } else if (m.elementType === V || typeof V == "object" && V !== null && V.$$typeof === Ot && Gl(V) === m.type) {
                      l(p, m.sibling), D = u(m, E.props), uu(D, E), D.return = p, p = D;
                      break t;
                    }
                    l(p, m);
                    break;
                  } else e(p, m);
                  m = m.sibling;
                }
                E.type === Y ? (D = ql(E.props.children, p.mode, D, E.key), D.return = p, p = D) : (D = un(E.type, E.key, E.props, null, p.mode, D), uu(D, E), D.return = p, p = D);
              }
              return i(p);
            case G:
              t: {
                for (V = E.key; m !== null; ) {
                  if (m.key === V) if (m.tag === 4 && m.stateNode.containerInfo === E.containerInfo && m.stateNode.implementation === E.implementation) {
                    l(p, m.sibling), D = u(m, E.children || []), D.return = p, p = D;
                    break t;
                  } else {
                    l(p, m);
                    break;
                  }
                  else e(p, m);
                  m = m.sibling;
                }
                D = Ji(E, p.mode, D), D.return = p, p = D;
              }
              return i(p);
            case Ot:
              return E = Gl(E), yt(p, m, E, D);
          }
          if (Ae(E)) return j(p, m, E, D);
          if (ze(E)) {
            if (V = ze(E), typeof V != "function") throw Error(o(150));
            return E = V.call(E), J(p, m, E, D);
          }
          if (typeof E.then == "function") return yt(p, m, dn(E), D);
          if (E.$$typeof === w) return yt(p, m, fn(p, E), D);
          hn(p, E);
        }
        return typeof E == "string" && E !== "" || typeof E == "number" || typeof E == "bigint" ? (E = "" + E, m !== null && m.tag === 6 ? (l(p, m.sibling), D = u(m, E), D.return = p, p = D) : (l(p, m), D = Ki(E, p.mode, D), D.return = p, p = D), i(p)) : l(p, m);
      }
      return function(p, m, E, D) {
        try {
          au = 0;
          var V = yt(p, m, E, D);
          return ga = null, V;
        } catch (Q) {
          if (Q === va || Q === rn) throw Q;
          var it = ae(29, Q, null, p.mode);
          return it.lanes = D, it.return = p, it;
        }
      };
    }
    var Zl = cr(true), fr = cr(false), rl = false;
    function uc(t) {
      t.updateQueue = {
        baseState: t.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
          pending: null,
          lanes: 0,
          hiddenCallbacks: null
        },
        callbacks: null
      };
    }
    function nc(t, e) {
      t = t.updateQueue, e.updateQueue === t && (e.updateQueue = {
        baseState: t.baseState,
        firstBaseUpdate: t.firstBaseUpdate,
        lastBaseUpdate: t.lastBaseUpdate,
        shared: t.shared,
        callbacks: null
      });
    }
    function sl(t) {
      return {
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
      };
    }
    function dl(t, e, l) {
      var a = t.updateQueue;
      if (a === null) return null;
      if (a = a.shared, (ft & 2) !== 0) {
        var u = a.pending;
        return u === null ? e.next = e : (e.next = u.next, u.next = e), a.pending = e, e = an(t), Ko(t, null, l), e;
      }
      return ln(t, a, e, l), an(t);
    }
    function nu(t, e, l) {
      if (e = e.updateQueue, e !== null && (e = e.shared, (l & 4194048) !== 0)) {
        var a = e.lanes;
        a &= t.pendingLanes, l |= a, e.lanes = l, If(t, l);
      }
    }
    function ic(t, e) {
      var l = t.updateQueue, a = t.alternate;
      if (a !== null && (a = a.updateQueue, l === a)) {
        var u = null, n = null;
        if (l = l.firstBaseUpdate, l !== null) {
          do {
            var i = {
              lane: l.lane,
              tag: l.tag,
              payload: l.payload,
              callback: null,
              next: null
            };
            n === null ? u = n = i : n = n.next = i, l = l.next;
          } while (l !== null);
          n === null ? u = n = e : n = n.next = e;
        } else u = n = e;
        l = {
          baseState: a.baseState,
          firstBaseUpdate: u,
          lastBaseUpdate: n,
          shared: a.shared,
          callbacks: a.callbacks
        }, t.updateQueue = l;
        return;
      }
      t = l.lastBaseUpdate, t === null ? l.firstBaseUpdate = e : t.next = e, l.lastBaseUpdate = e;
    }
    var cc = false;
    function iu() {
      if (cc) {
        var t = ya;
        if (t !== null) throw t;
      }
    }
    function cu(t, e, l, a) {
      cc = false;
      var u = t.updateQueue;
      rl = false;
      var n = u.firstBaseUpdate, i = u.lastBaseUpdate, f = u.shared.pending;
      if (f !== null) {
        u.shared.pending = null;
        var d = f, z = d.next;
        d.next = null, i === null ? n = z : i.next = z, i = d;
        var M = t.alternate;
        M !== null && (M = M.updateQueue, f = M.lastBaseUpdate, f !== i && (f === null ? M.firstBaseUpdate = z : f.next = z, M.lastBaseUpdate = d));
      }
      if (n !== null) {
        var U = u.baseState;
        i = 0, M = z = d = null, f = n;
        do {
          var T = f.lane & -536870913, A = T !== f.lane;
          if (A ? (at & T) === T : (a & T) === T) {
            T !== 0 && T === ma && (cc = true), M !== null && (M = M.next = {
              lane: 0,
              tag: f.tag,
              payload: f.payload,
              callback: null,
              next: null
            });
            t: {
              var j = t, J = f;
              T = e;
              var yt = l;
              switch (J.tag) {
                case 1:
                  if (j = J.payload, typeof j == "function") {
                    U = j.call(yt, U, T);
                    break t;
                  }
                  U = j;
                  break t;
                case 3:
                  j.flags = j.flags & -65537 | 128;
                case 0:
                  if (j = J.payload, T = typeof j == "function" ? j.call(yt, U, T) : j, T == null) break t;
                  U = _({}, U, T);
                  break t;
                case 2:
                  rl = true;
              }
            }
            T = f.callback, T !== null && (t.flags |= 64, A && (t.flags |= 8192), A = u.callbacks, A === null ? u.callbacks = [
              T
            ] : A.push(T));
          } else A = {
            lane: T,
            tag: f.tag,
            payload: f.payload,
            callback: f.callback,
            next: null
          }, M === null ? (z = M = A, d = U) : M = M.next = A, i |= T;
          if (f = f.next, f === null) {
            if (f = u.shared.pending, f === null) break;
            A = f, f = A.next, A.next = null, u.lastBaseUpdate = A, u.shared.pending = null;
          }
        } while (true);
        M === null && (d = U), u.baseState = d, u.firstBaseUpdate = z, u.lastBaseUpdate = M, n === null && (u.shared.lanes = 0), gl |= i, t.lanes = i, t.memoizedState = U;
      }
    }
    function or(t, e) {
      if (typeof t != "function") throw Error(o(191, t));
      t.call(e);
    }
    function rr(t, e) {
      var l = t.callbacks;
      if (l !== null) for (t.callbacks = null, t = 0; t < l.length; t++) or(l[t], e);
    }
    var pa = g(null), mn = g(0);
    function sr(t, e) {
      t = We, B(mn, t), B(pa, e), We = t | e.baseLanes;
    }
    function fc() {
      B(mn, We), B(pa, pa.current);
    }
    function oc() {
      We = mn.current, x(pa), x(mn);
    }
    var ue = g(null), pe = null;
    function hl(t) {
      var e = t.alternate;
      B(Rt, Rt.current & 1), B(ue, t), pe === null && (e === null || pa.current !== null || e.memoizedState !== null) && (pe = t);
    }
    function rc(t) {
      B(Rt, Rt.current), B(ue, t), pe === null && (pe = t);
    }
    function dr(t) {
      t.tag === 22 ? (B(Rt, Rt.current), B(ue, t), pe === null && (pe = t)) : ml();
    }
    function ml() {
      B(Rt, Rt.current), B(ue, ue.current);
    }
    function ne(t) {
      x(ue), pe === t && (pe = null), x(Rt);
    }
    var Rt = g(0);
    function yn(t) {
      for (var e = t; e !== null; ) {
        if (e.tag === 13) {
          var l = e.memoizedState;
          if (l !== null && (l = l.dehydrated, l === null || gf(l) || pf(l))) return e;
        } else if (e.tag === 19 && (e.memoizedProps.revealOrder === "forwards" || e.memoizedProps.revealOrder === "backwards" || e.memoizedProps.revealOrder === "unstable_legacy-backwards" || e.memoizedProps.revealOrder === "together")) {
          if ((e.flags & 128) !== 0) return e;
        } else if (e.child !== null) {
          e.child.return = e, e = e.child;
          continue;
        }
        if (e === t) break;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t) return null;
          e = e.return;
        }
        e.sibling.return = e.return, e = e.sibling;
      }
      return null;
    }
    var Xe = 0, k = null, ht = null, Dt = null, vn = false, Sa = false, Vl = false, gn = 0, fu = 0, ba = null, Jm = 0;
    function Tt() {
      throw Error(o(321));
    }
    function sc(t, e) {
      if (e === null) return false;
      for (var l = 0; l < e.length && l < t.length; l++) if (!le(t[l], e[l])) return false;
      return true;
    }
    function dc(t, e, l, a, u, n) {
      return Xe = n, k = e, e.memoizedState = null, e.updateQueue = null, e.lanes = 0, X.H = t === null || t.memoizedState === null ? kr : Mc, Vl = false, n = l(a, u), Vl = false, Sa && (n = mr(e, l, a, u)), hr(t), n;
    }
    function hr(t) {
      X.H = su;
      var e = ht !== null && ht.next !== null;
      if (Xe = 0, Dt = ht = k = null, vn = false, fu = 0, ba = null, e) throw Error(o(300));
      t === null || Ut || (t = t.dependencies, t !== null && cn(t) && (Ut = true));
    }
    function mr(t, e, l, a) {
      k = t;
      var u = 0;
      do {
        if (Sa && (ba = null), fu = 0, Sa = false, 25 <= u) throw Error(o(301));
        if (u += 1, Dt = ht = null, t.updateQueue != null) {
          var n = t.updateQueue;
          n.lastEffect = null, n.events = null, n.stores = null, n.memoCache != null && (n.memoCache.index = 0);
        }
        X.H = Wr, n = e(l, a);
      } while (Sa);
      return n;
    }
    function wm() {
      var t = X.H, e = t.useState()[0];
      return e = typeof e.then == "function" ? ou(e) : e, t = t.useState()[0], (ht !== null ? ht.memoizedState : null) !== t && (k.flags |= 1024), e;
    }
    function hc() {
      var t = gn !== 0;
      return gn = 0, t;
    }
    function mc(t, e, l) {
      e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~l;
    }
    function yc(t) {
      if (vn) {
        for (t = t.memoizedState; t !== null; ) {
          var e = t.queue;
          e !== null && (e.pending = null), t = t.next;
        }
        vn = false;
      }
      Xe = 0, Dt = ht = k = null, Sa = false, fu = gn = 0, ba = null;
    }
    function Kt() {
      var t = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
      };
      return Dt === null ? k.memoizedState = Dt = t : Dt = Dt.next = t, Dt;
    }
    function Mt() {
      if (ht === null) {
        var t = k.alternate;
        t = t !== null ? t.memoizedState : null;
      } else t = ht.next;
      var e = Dt === null ? k.memoizedState : Dt.next;
      if (e !== null) Dt = e, ht = t;
      else {
        if (t === null) throw k.alternate === null ? Error(o(467)) : Error(o(310));
        ht = t, t = {
          memoizedState: ht.memoizedState,
          baseState: ht.baseState,
          baseQueue: ht.baseQueue,
          queue: ht.queue,
          next: null
        }, Dt === null ? k.memoizedState = Dt = t : Dt = Dt.next = t;
      }
      return Dt;
    }
    function pn() {
      return {
        lastEffect: null,
        events: null,
        stores: null,
        memoCache: null
      };
    }
    function ou(t) {
      var e = fu;
      return fu += 1, ba === null && (ba = []), t = ur(ba, t, e), e = k, (Dt === null ? e.memoizedState : Dt.next) === null && (e = e.alternate, X.H = e === null || e.memoizedState === null ? kr : Mc), t;
    }
    function Sn(t) {
      if (t !== null && typeof t == "object") {
        if (typeof t.then == "function") return ou(t);
        if (t.$$typeof === w) return jt(t);
      }
      throw Error(o(438, String(t)));
    }
    function vc(t) {
      var e = null, l = k.updateQueue;
      if (l !== null && (e = l.memoCache), e == null) {
        var a = k.alternate;
        a !== null && (a = a.updateQueue, a !== null && (a = a.memoCache, a != null && (e = {
          data: a.data.map(function(u) {
            return u.slice();
          }),
          index: 0
        })));
      }
      if (e == null && (e = {
        data: [],
        index: 0
      }), l === null && (l = pn(), k.updateQueue = l), l.memoCache = e, l = e.data[e.index], l === void 0) for (l = e.data[e.index] = Array(t), a = 0; a < t; a++) l[a] = Ee;
      return e.index++, l;
    }
    function Ze(t, e) {
      return typeof e == "function" ? e(t) : e;
    }
    function bn(t) {
      var e = Mt();
      return gc(e, ht, t);
    }
    function gc(t, e, l) {
      var a = t.queue;
      if (a === null) throw Error(o(311));
      a.lastRenderedReducer = l;
      var u = t.baseQueue, n = a.pending;
      if (n !== null) {
        if (u !== null) {
          var i = u.next;
          u.next = n.next, n.next = i;
        }
        e.baseQueue = u = n, a.pending = null;
      }
      if (n = t.baseState, u === null) t.memoizedState = n;
      else {
        e = u.next;
        var f = i = null, d = null, z = e, M = false;
        do {
          var U = z.lane & -536870913;
          if (U !== z.lane ? (at & U) === U : (Xe & U) === U) {
            var T = z.revertLane;
            if (T === 0) d !== null && (d = d.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: z.action,
              hasEagerState: z.hasEagerState,
              eagerState: z.eagerState,
              next: null
            }), U === ma && (M = true);
            else if ((Xe & T) === T) {
              z = z.next, T === ma && (M = true);
              continue;
            } else U = {
              lane: 0,
              revertLane: z.revertLane,
              gesture: null,
              action: z.action,
              hasEagerState: z.hasEagerState,
              eagerState: z.eagerState,
              next: null
            }, d === null ? (f = d = U, i = n) : d = d.next = U, k.lanes |= T, gl |= T;
            U = z.action, Vl && l(n, U), n = z.hasEagerState ? z.eagerState : l(n, U);
          } else T = {
            lane: U,
            revertLane: z.revertLane,
            gesture: z.gesture,
            action: z.action,
            hasEagerState: z.hasEagerState,
            eagerState: z.eagerState,
            next: null
          }, d === null ? (f = d = T, i = n) : d = d.next = T, k.lanes |= U, gl |= U;
          z = z.next;
        } while (z !== null && z !== e);
        if (d === null ? i = n : d.next = f, !le(n, t.memoizedState) && (Ut = true, M && (l = ya, l !== null))) throw l;
        t.memoizedState = n, t.baseState = i, t.baseQueue = d, a.lastRenderedState = n;
      }
      return u === null && (a.lanes = 0), [
        t.memoizedState,
        a.dispatch
      ];
    }
    function pc(t) {
      var e = Mt(), l = e.queue;
      if (l === null) throw Error(o(311));
      l.lastRenderedReducer = t;
      var a = l.dispatch, u = l.pending, n = e.memoizedState;
      if (u !== null) {
        l.pending = null;
        var i = u = u.next;
        do
          n = t(n, i.action), i = i.next;
        while (i !== u);
        le(n, e.memoizedState) || (Ut = true), e.memoizedState = n, e.baseQueue === null && (e.baseState = n), l.lastRenderedState = n;
      }
      return [
        n,
        a
      ];
    }
    function yr(t, e, l) {
      var a = k, u = Mt(), n = nt;
      if (n) {
        if (l === void 0) throw Error(o(407));
        l = l();
      } else l = e();
      var i = !le((ht || u).memoizedState, l);
      if (i && (u.memoizedState = l, Ut = true), u = u.queue, Ec(pr.bind(null, a, u, t), [
        t
      ]), u.getSnapshot !== e || i || Dt !== null && Dt.memoizedState.tag & 1) {
        if (a.flags |= 2048, Ea(9, {
          destroy: void 0
        }, gr.bind(null, a, u, l, e), null), vt === null) throw Error(o(349));
        n || (Xe & 127) !== 0 || vr(a, e, l);
      }
      return l;
    }
    function vr(t, e, l) {
      t.flags |= 16384, t = {
        getSnapshot: e,
        value: l
      }, e = k.updateQueue, e === null ? (e = pn(), k.updateQueue = e, e.stores = [
        t
      ]) : (l = e.stores, l === null ? e.stores = [
        t
      ] : l.push(t));
    }
    function gr(t, e, l, a) {
      e.value = l, e.getSnapshot = a, Sr(e) && br(t);
    }
    function pr(t, e, l) {
      return l(function() {
        Sr(e) && br(t);
      });
    }
    function Sr(t) {
      var e = t.getSnapshot;
      t = t.value;
      try {
        var l = e();
        return !le(t, l);
      } catch {
        return true;
      }
    }
    function br(t) {
      var e = Bl(t, 2);
      e !== null && It(e, t, 2);
    }
    function Sc(t) {
      var e = Kt();
      if (typeof t == "function") {
        var l = t;
        if (t = l(), Vl) {
          al(true);
          try {
            l();
          } finally {
            al(false);
          }
        }
      }
      return e.memoizedState = e.baseState = t, e.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Ze,
        lastRenderedState: t
      }, e;
    }
    function Er(t, e, l, a) {
      return t.baseState = l, gc(t, ht, typeof a == "function" ? a : Ze);
    }
    function $m(t, e, l, a, u) {
      if (Tn(t)) throw Error(o(485));
      if (t = e.action, t !== null) {
        var n = {
          payload: u,
          action: t,
          next: null,
          isTransition: true,
          status: "pending",
          value: null,
          reason: null,
          listeners: [],
          then: function(i) {
            n.listeners.push(i);
          }
        };
        X.T !== null ? l(true) : n.isTransition = false, a(n), l = e.pending, l === null ? (n.next = e.pending = n, zr(e, n)) : (n.next = l.next, e.pending = l.next = n);
      }
    }
    function zr(t, e) {
      var l = e.action, a = e.payload, u = t.state;
      if (e.isTransition) {
        var n = X.T, i = {};
        X.T = i;
        try {
          var f = l(u, a), d = X.S;
          d !== null && d(i, f), Tr(t, e, f);
        } catch (z) {
          bc(t, e, z);
        } finally {
          n !== null && i.types !== null && (n.types = i.types), X.T = n;
        }
      } else try {
        n = l(u, a), Tr(t, e, n);
      } catch (z) {
        bc(t, e, z);
      }
    }
    function Tr(t, e, l) {
      l !== null && typeof l == "object" && typeof l.then == "function" ? l.then(function(a) {
        Ar(t, e, a);
      }, function(a) {
        return bc(t, e, a);
      }) : Ar(t, e, l);
    }
    function Ar(t, e, l) {
      e.status = "fulfilled", e.value = l, _r(e), t.state = l, e = t.pending, e !== null && (l = e.next, l === e ? t.pending = null : (l = l.next, e.next = l, zr(t, l)));
    }
    function bc(t, e, l) {
      var a = t.pending;
      if (t.pending = null, a !== null) {
        a = a.next;
        do
          e.status = "rejected", e.reason = l, _r(e), e = e.next;
        while (e !== a);
      }
      t.action = null;
    }
    function _r(t) {
      t = t.listeners;
      for (var e = 0; e < t.length; e++) (0, t[e])();
    }
    function Rr(t, e) {
      return e;
    }
    function Mr(t, e) {
      if (nt) {
        var l = vt.formState;
        if (l !== null) {
          t: {
            var a = k;
            if (nt) {
              if (pt) {
                e: {
                  for (var u = pt, n = ge; u.nodeType !== 8; ) {
                    if (!n) {
                      u = null;
                      break e;
                    }
                    if (u = Se(u.nextSibling), u === null) {
                      u = null;
                      break e;
                    }
                  }
                  n = u.data, u = n === "F!" || n === "F" ? u : null;
                }
                if (u) {
                  pt = Se(u.nextSibling), a = u.data === "F!";
                  break t;
                }
              }
              fl(a);
            }
            a = false;
          }
          a && (e = l[0]);
        }
      }
      return l = Kt(), l.memoizedState = l.baseState = e, a = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Rr,
        lastRenderedState: e
      }, l.queue = a, l = Jr.bind(null, k, a), a.dispatch = l, a = Sc(false), n = Rc.bind(null, k, false, a.queue), a = Kt(), u = {
        state: e,
        dispatch: null,
        action: t,
        pending: null
      }, a.queue = u, l = $m.bind(null, k, u, n, l), u.dispatch = l, a.memoizedState = t, [
        e,
        l,
        false
      ];
    }
    function Or(t) {
      var e = Mt();
      return Cr(e, ht, t);
    }
    function Cr(t, e, l) {
      if (e = gc(t, e, Rr)[0], t = bn(Ze)[0], typeof e == "object" && e !== null && typeof e.then == "function") try {
        var a = ou(e);
      } catch (i) {
        throw i === va ? rn : i;
      }
      else a = e;
      e = Mt();
      var u = e.queue, n = u.dispatch;
      return l !== e.memoizedState && (k.flags |= 2048, Ea(9, {
        destroy: void 0
      }, km.bind(null, u, l), null)), [
        a,
        n,
        t
      ];
    }
    function km(t, e) {
      t.action = e;
    }
    function Dr(t) {
      var e = Mt(), l = ht;
      if (l !== null) return Cr(e, l, t);
      Mt(), e = e.memoizedState, l = Mt();
      var a = l.queue.dispatch;
      return l.memoizedState = t, [
        e,
        a,
        false
      ];
    }
    function Ea(t, e, l, a) {
      return t = {
        tag: t,
        create: l,
        deps: a,
        inst: e,
        next: null
      }, e = k.updateQueue, e === null && (e = pn(), k.updateQueue = e), l = e.lastEffect, l === null ? e.lastEffect = t.next = t : (a = l.next, l.next = t, t.next = a, e.lastEffect = t), t;
    }
    function Ur() {
      return Mt().memoizedState;
    }
    function En(t, e, l, a) {
      var u = Kt();
      k.flags |= t, u.memoizedState = Ea(1 | e, {
        destroy: void 0
      }, l, a === void 0 ? null : a);
    }
    function zn(t, e, l, a) {
      var u = Mt();
      a = a === void 0 ? null : a;
      var n = u.memoizedState.inst;
      ht !== null && a !== null && sc(a, ht.memoizedState.deps) ? u.memoizedState = Ea(e, n, l, a) : (k.flags |= t, u.memoizedState = Ea(1 | e, n, l, a));
    }
    function xr(t, e) {
      En(8390656, 8, t, e);
    }
    function Ec(t, e) {
      zn(2048, 8, t, e);
    }
    function Wm(t) {
      k.flags |= 4;
      var e = k.updateQueue;
      if (e === null) e = pn(), k.updateQueue = e, e.events = [
        t
      ];
      else {
        var l = e.events;
        l === null ? e.events = [
          t
        ] : l.push(t);
      }
    }
    function Nr(t) {
      var e = Mt().memoizedState;
      return Wm({
        ref: e,
        nextImpl: t
      }), function() {
        if ((ft & 2) !== 0) throw Error(o(440));
        return e.impl.apply(void 0, arguments);
      };
    }
    function Hr(t, e) {
      return zn(4, 2, t, e);
    }
    function Br(t, e) {
      return zn(4, 4, t, e);
    }
    function qr(t, e) {
      if (typeof e == "function") {
        t = t();
        var l = e(t);
        return function() {
          typeof l == "function" ? l() : e(null);
        };
      }
      if (e != null) return t = t(), e.current = t, function() {
        e.current = null;
      };
    }
    function Yr(t, e, l) {
      l = l != null ? l.concat([
        t
      ]) : null, zn(4, 4, qr.bind(null, e, t), l);
    }
    function zc() {
    }
    function Lr(t, e) {
      var l = Mt();
      e = e === void 0 ? null : e;
      var a = l.memoizedState;
      return e !== null && sc(e, a[1]) ? a[0] : (l.memoizedState = [
        t,
        e
      ], t);
    }
    function jr(t, e) {
      var l = Mt();
      e = e === void 0 ? null : e;
      var a = l.memoizedState;
      if (e !== null && sc(e, a[1])) return a[0];
      if (a = t(), Vl) {
        al(true);
        try {
          t();
        } finally {
          al(false);
        }
      }
      return l.memoizedState = [
        a,
        e
      ], a;
    }
    function Tc(t, e, l) {
      return l === void 0 || (Xe & 1073741824) !== 0 && (at & 261930) === 0 ? t.memoizedState = e : (t.memoizedState = l, t = Qs(), k.lanes |= t, gl |= t, l);
    }
    function Qr(t, e, l, a) {
      return le(l, e) ? l : pa.current !== null ? (t = Tc(t, l, a), le(t, e) || (Ut = true), t) : (Xe & 42) === 0 || (Xe & 1073741824) !== 0 && (at & 261930) === 0 ? (Ut = true, t.memoizedState = l) : (t = Qs(), k.lanes |= t, gl |= t, e);
    }
    function Gr(t, e, l, a, u) {
      var n = lt.p;
      lt.p = n !== 0 && 8 > n ? n : 8;
      var i = X.T, f = {};
      X.T = f, Rc(t, false, e, l);
      try {
        var d = u(), z = X.S;
        if (z !== null && z(f, d), d !== null && typeof d == "object" && typeof d.then == "function") {
          var M = Km(d, a);
          ru(t, e, M, fe(t));
        } else ru(t, e, a, fe(t));
      } catch (U) {
        ru(t, e, {
          then: function() {
          },
          status: "rejected",
          reason: U
        }, fe());
      } finally {
        lt.p = n, i !== null && f.types !== null && (i.types = f.types), X.T = i;
      }
    }
    function Fm() {
    }
    function Ac(t, e, l, a) {
      if (t.tag !== 5) throw Error(o(476));
      var u = Xr(t).queue;
      Gr(t, u, e, He, l === null ? Fm : function() {
        return Zr(t), l(a);
      });
    }
    function Xr(t) {
      var e = t.memoizedState;
      if (e !== null) return e;
      e = {
        memoizedState: He,
        baseState: He,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Ze,
          lastRenderedState: He
        },
        next: null
      };
      var l = {};
      return e.next = {
        memoizedState: l,
        baseState: l,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Ze,
          lastRenderedState: l
        },
        next: null
      }, t.memoizedState = e, t = t.alternate, t !== null && (t.memoizedState = e), e;
    }
    function Zr(t) {
      var e = Xr(t);
      e.next === null && (e = t.alternate.memoizedState), ru(t, e.next.queue, {}, fe());
    }
    function _c() {
      return jt(Mu);
    }
    function Vr() {
      return Mt().memoizedState;
    }
    function Kr() {
      return Mt().memoizedState;
    }
    function Im(t) {
      for (var e = t.return; e !== null; ) {
        switch (e.tag) {
          case 24:
          case 3:
            var l = fe();
            t = sl(l);
            var a = dl(e, t, l);
            a !== null && (It(a, e, l), nu(a, e, l)), e = {
              cache: tc()
            }, t.payload = e;
            return;
        }
        e = e.return;
      }
    }
    function Pm(t, e, l) {
      var a = fe();
      l = {
        lane: a,
        revertLane: 0,
        gesture: null,
        action: l,
        hasEagerState: false,
        eagerState: null,
        next: null
      }, Tn(t) ? wr(e, l) : (l = Zi(t, e, l, a), l !== null && (It(l, t, a), $r(l, e, a)));
    }
    function Jr(t, e, l) {
      var a = fe();
      ru(t, e, l, a);
    }
    function ru(t, e, l, a) {
      var u = {
        lane: a,
        revertLane: 0,
        gesture: null,
        action: l,
        hasEagerState: false,
        eagerState: null,
        next: null
      };
      if (Tn(t)) wr(e, u);
      else {
        var n = t.alternate;
        if (t.lanes === 0 && (n === null || n.lanes === 0) && (n = e.lastRenderedReducer, n !== null)) try {
          var i = e.lastRenderedState, f = n(i, l);
          if (u.hasEagerState = true, u.eagerState = f, le(f, i)) return ln(t, e, u, 0), vt === null && en(), false;
        } catch {
        }
        if (l = Zi(t, e, u, a), l !== null) return It(l, t, a), $r(l, e, a), true;
      }
      return false;
    }
    function Rc(t, e, l, a) {
      if (a = {
        lane: 2,
        revertLane: uf(),
        gesture: null,
        action: a,
        hasEagerState: false,
        eagerState: null,
        next: null
      }, Tn(t)) {
        if (e) throw Error(o(479));
      } else e = Zi(t, l, a, 2), e !== null && It(e, t, 2);
    }
    function Tn(t) {
      var e = t.alternate;
      return t === k || e !== null && e === k;
    }
    function wr(t, e) {
      Sa = vn = true;
      var l = t.pending;
      l === null ? e.next = e : (e.next = l.next, l.next = e), t.pending = e;
    }
    function $r(t, e, l) {
      if ((l & 4194048) !== 0) {
        var a = e.lanes;
        a &= t.pendingLanes, l |= a, e.lanes = l, If(t, l);
      }
    }
    var su = {
      readContext: jt,
      use: Sn,
      useCallback: Tt,
      useContext: Tt,
      useEffect: Tt,
      useImperativeHandle: Tt,
      useLayoutEffect: Tt,
      useInsertionEffect: Tt,
      useMemo: Tt,
      useReducer: Tt,
      useRef: Tt,
      useState: Tt,
      useDebugValue: Tt,
      useDeferredValue: Tt,
      useTransition: Tt,
      useSyncExternalStore: Tt,
      useId: Tt,
      useHostTransitionStatus: Tt,
      useFormState: Tt,
      useActionState: Tt,
      useOptimistic: Tt,
      useMemoCache: Tt,
      useCacheRefresh: Tt
    };
    su.useEffectEvent = Tt;
    var kr = {
      readContext: jt,
      use: Sn,
      useCallback: function(t, e) {
        return Kt().memoizedState = [
          t,
          e === void 0 ? null : e
        ], t;
      },
      useContext: jt,
      useEffect: xr,
      useImperativeHandle: function(t, e, l) {
        l = l != null ? l.concat([
          t
        ]) : null, En(4194308, 4, qr.bind(null, e, t), l);
      },
      useLayoutEffect: function(t, e) {
        return En(4194308, 4, t, e);
      },
      useInsertionEffect: function(t, e) {
        En(4, 2, t, e);
      },
      useMemo: function(t, e) {
        var l = Kt();
        e = e === void 0 ? null : e;
        var a = t();
        if (Vl) {
          al(true);
          try {
            t();
          } finally {
            al(false);
          }
        }
        return l.memoizedState = [
          a,
          e
        ], a;
      },
      useReducer: function(t, e, l) {
        var a = Kt();
        if (l !== void 0) {
          var u = l(e);
          if (Vl) {
            al(true);
            try {
              l(e);
            } finally {
              al(false);
            }
          }
        } else u = e;
        return a.memoizedState = a.baseState = u, t = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: t,
          lastRenderedState: u
        }, a.queue = t, t = t.dispatch = Pm.bind(null, k, t), [
          a.memoizedState,
          t
        ];
      },
      useRef: function(t) {
        var e = Kt();
        return t = {
          current: t
        }, e.memoizedState = t;
      },
      useState: function(t) {
        t = Sc(t);
        var e = t.queue, l = Jr.bind(null, k, e);
        return e.dispatch = l, [
          t.memoizedState,
          l
        ];
      },
      useDebugValue: zc,
      useDeferredValue: function(t, e) {
        var l = Kt();
        return Tc(l, t, e);
      },
      useTransition: function() {
        var t = Sc(false);
        return t = Gr.bind(null, k, t.queue, true, false), Kt().memoizedState = t, [
          false,
          t
        ];
      },
      useSyncExternalStore: function(t, e, l) {
        var a = k, u = Kt();
        if (nt) {
          if (l === void 0) throw Error(o(407));
          l = l();
        } else {
          if (l = e(), vt === null) throw Error(o(349));
          (at & 127) !== 0 || vr(a, e, l);
        }
        u.memoizedState = l;
        var n = {
          value: l,
          getSnapshot: e
        };
        return u.queue = n, xr(pr.bind(null, a, n, t), [
          t
        ]), a.flags |= 2048, Ea(9, {
          destroy: void 0
        }, gr.bind(null, a, n, l, e), null), l;
      },
      useId: function() {
        var t = Kt(), e = vt.identifierPrefix;
        if (nt) {
          var l = De, a = Ce;
          l = (a & ~(1 << 32 - ee(a) - 1)).toString(32) + l, e = "_" + e + "R_" + l, l = gn++, 0 < l && (e += "H" + l.toString(32)), e += "_";
        } else l = Jm++, e = "_" + e + "r_" + l.toString(32) + "_";
        return t.memoizedState = e;
      },
      useHostTransitionStatus: _c,
      useFormState: Mr,
      useActionState: Mr,
      useOptimistic: function(t) {
        var e = Kt();
        e.memoizedState = e.baseState = t;
        var l = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: null,
          lastRenderedState: null
        };
        return e.queue = l, e = Rc.bind(null, k, true, l), l.dispatch = e, [
          t,
          e
        ];
      },
      useMemoCache: vc,
      useCacheRefresh: function() {
        return Kt().memoizedState = Im.bind(null, k);
      },
      useEffectEvent: function(t) {
        var e = Kt(), l = {
          impl: t
        };
        return e.memoizedState = l, function() {
          if ((ft & 2) !== 0) throw Error(o(440));
          return l.impl.apply(void 0, arguments);
        };
      }
    }, Mc = {
      readContext: jt,
      use: Sn,
      useCallback: Lr,
      useContext: jt,
      useEffect: Ec,
      useImperativeHandle: Yr,
      useInsertionEffect: Hr,
      useLayoutEffect: Br,
      useMemo: jr,
      useReducer: bn,
      useRef: Ur,
      useState: function() {
        return bn(Ze);
      },
      useDebugValue: zc,
      useDeferredValue: function(t, e) {
        var l = Mt();
        return Qr(l, ht.memoizedState, t, e);
      },
      useTransition: function() {
        var t = bn(Ze)[0], e = Mt().memoizedState;
        return [
          typeof t == "boolean" ? t : ou(t),
          e
        ];
      },
      useSyncExternalStore: yr,
      useId: Vr,
      useHostTransitionStatus: _c,
      useFormState: Or,
      useActionState: Or,
      useOptimistic: function(t, e) {
        var l = Mt();
        return Er(l, ht, t, e);
      },
      useMemoCache: vc,
      useCacheRefresh: Kr
    };
    Mc.useEffectEvent = Nr;
    var Wr = {
      readContext: jt,
      use: Sn,
      useCallback: Lr,
      useContext: jt,
      useEffect: Ec,
      useImperativeHandle: Yr,
      useInsertionEffect: Hr,
      useLayoutEffect: Br,
      useMemo: jr,
      useReducer: pc,
      useRef: Ur,
      useState: function() {
        return pc(Ze);
      },
      useDebugValue: zc,
      useDeferredValue: function(t, e) {
        var l = Mt();
        return ht === null ? Tc(l, t, e) : Qr(l, ht.memoizedState, t, e);
      },
      useTransition: function() {
        var t = pc(Ze)[0], e = Mt().memoizedState;
        return [
          typeof t == "boolean" ? t : ou(t),
          e
        ];
      },
      useSyncExternalStore: yr,
      useId: Vr,
      useHostTransitionStatus: _c,
      useFormState: Dr,
      useActionState: Dr,
      useOptimistic: function(t, e) {
        var l = Mt();
        return ht !== null ? Er(l, ht, t, e) : (l.baseState = t, [
          t,
          l.queue.dispatch
        ]);
      },
      useMemoCache: vc,
      useCacheRefresh: Kr
    };
    Wr.useEffectEvent = Nr;
    function Oc(t, e, l, a) {
      e = t.memoizedState, l = l(a, e), l = l == null ? e : _({}, e, l), t.memoizedState = l, t.lanes === 0 && (t.updateQueue.baseState = l);
    }
    var Cc = {
      enqueueSetState: function(t, e, l) {
        t = t._reactInternals;
        var a = fe(), u = sl(a);
        u.payload = e, l != null && (u.callback = l), e = dl(t, u, a), e !== null && (It(e, t, a), nu(e, t, a));
      },
      enqueueReplaceState: function(t, e, l) {
        t = t._reactInternals;
        var a = fe(), u = sl(a);
        u.tag = 1, u.payload = e, l != null && (u.callback = l), e = dl(t, u, a), e !== null && (It(e, t, a), nu(e, t, a));
      },
      enqueueForceUpdate: function(t, e) {
        t = t._reactInternals;
        var l = fe(), a = sl(l);
        a.tag = 2, e != null && (a.callback = e), e = dl(t, a, l), e !== null && (It(e, t, l), nu(e, t, l));
      }
    };
    function Fr(t, e, l, a, u, n, i) {
      return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(a, n, i) : e.prototype && e.prototype.isPureReactComponent ? !Fa(l, a) || !Fa(u, n) : true;
    }
    function Ir(t, e, l, a) {
      t = e.state, typeof e.componentWillReceiveProps == "function" && e.componentWillReceiveProps(l, a), typeof e.UNSAFE_componentWillReceiveProps == "function" && e.UNSAFE_componentWillReceiveProps(l, a), e.state !== t && Cc.enqueueReplaceState(e, e.state, null);
    }
    function Kl(t, e) {
      var l = e;
      if ("ref" in e) {
        l = {};
        for (var a in e) a !== "ref" && (l[a] = e[a]);
      }
      if (t = t.defaultProps) {
        l === e && (l = _({}, l));
        for (var u in t) l[u] === void 0 && (l[u] = t[u]);
      }
      return l;
    }
    function Pr(t) {
      tn(t);
    }
    function ts(t) {
      console.error(t);
    }
    function es(t) {
      tn(t);
    }
    function An(t, e) {
      try {
        var l = t.onUncaughtError;
        l(e.value, {
          componentStack: e.stack
        });
      } catch (a) {
        setTimeout(function() {
          throw a;
        });
      }
    }
    function ls(t, e, l) {
      try {
        var a = t.onCaughtError;
        a(l.value, {
          componentStack: l.stack,
          errorBoundary: e.tag === 1 ? e.stateNode : null
        });
      } catch (u) {
        setTimeout(function() {
          throw u;
        });
      }
    }
    function Dc(t, e, l) {
      return l = sl(l), l.tag = 3, l.payload = {
        element: null
      }, l.callback = function() {
        An(t, e);
      }, l;
    }
    function as(t) {
      return t = sl(t), t.tag = 3, t;
    }
    function us(t, e, l, a) {
      var u = l.type.getDerivedStateFromError;
      if (typeof u == "function") {
        var n = a.value;
        t.payload = function() {
          return u(n);
        }, t.callback = function() {
          ls(e, l, a);
        };
      }
      var i = l.stateNode;
      i !== null && typeof i.componentDidCatch == "function" && (t.callback = function() {
        ls(e, l, a), typeof u != "function" && (pl === null ? pl = /* @__PURE__ */ new Set([
          this
        ]) : pl.add(this));
        var f = a.stack;
        this.componentDidCatch(a.value, {
          componentStack: f !== null ? f : ""
        });
      });
    }
    function ty(t, e, l, a, u) {
      if (l.flags |= 32768, a !== null && typeof a == "object" && typeof a.then == "function") {
        if (e = l.alternate, e !== null && ha(e, l, u, true), l = ue.current, l !== null) {
          switch (l.tag) {
            case 31:
            case 13:
              return pe === null ? qn() : l.alternate === null && At === 0 && (At = 3), l.flags &= -257, l.flags |= 65536, l.lanes = u, a === sn ? l.flags |= 16384 : (e = l.updateQueue, e === null ? l.updateQueue = /* @__PURE__ */ new Set([
                a
              ]) : e.add(a), ef(t, a, u)), false;
            case 22:
              return l.flags |= 65536, a === sn ? l.flags |= 16384 : (e = l.updateQueue, e === null ? (e = {
                transitions: null,
                markerInstances: null,
                retryQueue: /* @__PURE__ */ new Set([
                  a
                ])
              }, l.updateQueue = e) : (l = e.retryQueue, l === null ? e.retryQueue = /* @__PURE__ */ new Set([
                a
              ]) : l.add(a)), ef(t, a, u)), false;
          }
          throw Error(o(435, l.tag));
        }
        return ef(t, a, u), qn(), false;
      }
      if (nt) return e = ue.current, e !== null ? ((e.flags & 65536) === 0 && (e.flags |= 256), e.flags |= 65536, e.lanes = u, a !== ki && (t = Error(o(422), {
        cause: a
      }), tu(me(t, l)))) : (a !== ki && (e = Error(o(423), {
        cause: a
      }), tu(me(e, l))), t = t.current.alternate, t.flags |= 65536, u &= -u, t.lanes |= u, a = me(a, l), u = Dc(t.stateNode, a, u), ic(t, u), At !== 4 && (At = 2)), false;
      var n = Error(o(520), {
        cause: a
      });
      if (n = me(n, l), Su === null ? Su = [
        n
      ] : Su.push(n), At !== 4 && (At = 2), e === null) return true;
      a = me(a, l), l = e;
      do {
        switch (l.tag) {
          case 3:
            return l.flags |= 65536, t = u & -u, l.lanes |= t, t = Dc(l.stateNode, a, t), ic(l, t), false;
          case 1:
            if (e = l.type, n = l.stateNode, (l.flags & 128) === 0 && (typeof e.getDerivedStateFromError == "function" || n !== null && typeof n.componentDidCatch == "function" && (pl === null || !pl.has(n)))) return l.flags |= 65536, u &= -u, l.lanes |= u, u = as(u), us(u, t, l, a), ic(l, u), false;
        }
        l = l.return;
      } while (l !== null);
      return false;
    }
    var Uc = Error(o(461)), Ut = false;
    function Qt(t, e, l, a) {
      e.child = t === null ? fr(e, null, l, a) : Zl(e, t.child, l, a);
    }
    function ns(t, e, l, a, u) {
      l = l.render;
      var n = e.ref;
      if ("ref" in a) {
        var i = {};
        for (var f in a) f !== "ref" && (i[f] = a[f]);
      } else i = a;
      return jl(e), a = dc(t, e, l, i, n, u), f = hc(), t !== null && !Ut ? (mc(t, e, u), Ve(t, e, u)) : (nt && f && wi(e), e.flags |= 1, Qt(t, e, a, u), e.child);
    }
    function is(t, e, l, a, u) {
      if (t === null) {
        var n = l.type;
        return typeof n == "function" && !Vi(n) && n.defaultProps === void 0 && l.compare === null ? (e.tag = 15, e.type = n, cs(t, e, n, a, u)) : (t = un(l.type, null, a, e, e.mode, u), t.ref = e.ref, t.return = e, e.child = t);
      }
      if (n = t.child, !jc(t, u)) {
        var i = n.memoizedProps;
        if (l = l.compare, l = l !== null ? l : Fa, l(i, a) && t.ref === e.ref) return Ve(t, e, u);
      }
      return e.flags |= 1, t = Le(n, a), t.ref = e.ref, t.return = e, e.child = t;
    }
    function cs(t, e, l, a, u) {
      if (t !== null) {
        var n = t.memoizedProps;
        if (Fa(n, a) && t.ref === e.ref) if (Ut = false, e.pendingProps = a = n, jc(t, u)) (t.flags & 131072) !== 0 && (Ut = true);
        else return e.lanes = t.lanes, Ve(t, e, u);
      }
      return xc(t, e, l, a, u);
    }
    function fs(t, e, l, a) {
      var u = a.children, n = t !== null ? t.memoizedState : null;
      if (t === null && e.stateNode === null && (e.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      }), a.mode === "hidden") {
        if ((e.flags & 128) !== 0) {
          if (n = n !== null ? n.baseLanes | l : l, t !== null) {
            for (a = e.child = t.child, u = 0; a !== null; ) u = u | a.lanes | a.childLanes, a = a.sibling;
            a = u & ~n;
          } else a = 0, e.child = null;
          return os(t, e, n, l, a);
        }
        if ((l & 536870912) !== 0) e.memoizedState = {
          baseLanes: 0,
          cachePool: null
        }, t !== null && on(e, n !== null ? n.cachePool : null), n !== null ? sr(e, n) : fc(), dr(e);
        else return a = e.lanes = 536870912, os(t, e, n !== null ? n.baseLanes | l : l, l, a);
      } else n !== null ? (on(e, n.cachePool), sr(e, n), ml(), e.memoizedState = null) : (t !== null && on(e, null), fc(), ml());
      return Qt(t, e, u, l), e.child;
    }
    function du(t, e) {
      return t !== null && t.tag === 22 || e.stateNode !== null || (e.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      }), e.sibling;
    }
    function os(t, e, l, a, u) {
      var n = lc();
      return n = n === null ? null : {
        parent: Ct._currentValue,
        pool: n
      }, e.memoizedState = {
        baseLanes: l,
        cachePool: n
      }, t !== null && on(e, null), fc(), dr(e), t !== null && ha(t, e, a, true), e.childLanes = u, null;
    }
    function _n(t, e) {
      return e = Mn({
        mode: e.mode,
        children: e.children
      }, t.mode), e.ref = t.ref, t.child = e, e.return = t, e;
    }
    function rs(t, e, l) {
      return Zl(e, t.child, null, l), t = _n(e, e.pendingProps), t.flags |= 2, ne(e), e.memoizedState = null, t;
    }
    function ey(t, e, l) {
      var a = e.pendingProps, u = (e.flags & 128) !== 0;
      if (e.flags &= -129, t === null) {
        if (nt) {
          if (a.mode === "hidden") return t = _n(e, a), e.lanes = 536870912, du(null, t);
          if (rc(e), (t = pt) ? (t = zd(t, ge), t = t !== null && t.data === "&" ? t : null, t !== null && (e.memoizedState = {
            dehydrated: t,
            treeContext: il !== null ? {
              id: Ce,
              overflow: De
            } : null,
            retryLane: 536870912,
            hydrationErrors: null
          }, l = wo(t), l.return = e, e.child = l, Lt = e, pt = null)) : t = null, t === null) throw fl(e);
          return e.lanes = 536870912, null;
        }
        return _n(e, a);
      }
      var n = t.memoizedState;
      if (n !== null) {
        var i = n.dehydrated;
        if (rc(e), u) if (e.flags & 256) e.flags &= -257, e = rs(t, e, l);
        else if (e.memoizedState !== null) e.child = t.child, e.flags |= 128, e = null;
        else throw Error(o(558));
        else if (Ut || ha(t, e, l, false), u = (l & t.childLanes) !== 0, Ut || u) {
          if (a = vt, a !== null && (i = Pf(a, l), i !== 0 && i !== n.retryLane)) throw n.retryLane = i, Bl(t, i), It(a, t, i), Uc;
          qn(), e = rs(t, e, l);
        } else t = n.treeContext, pt = Se(i.nextSibling), Lt = e, nt = true, cl = null, ge = false, t !== null && Wo(e, t), e = _n(e, a), e.flags |= 4096;
        return e;
      }
      return t = Le(t.child, {
        mode: a.mode,
        children: a.children
      }), t.ref = e.ref, e.child = t, t.return = e, t;
    }
    function Rn(t, e) {
      var l = e.ref;
      if (l === null) t !== null && t.ref !== null && (e.flags |= 4194816);
      else {
        if (typeof l != "function" && typeof l != "object") throw Error(o(284));
        (t === null || t.ref !== l) && (e.flags |= 4194816);
      }
    }
    function xc(t, e, l, a, u) {
      return jl(e), l = dc(t, e, l, a, void 0, u), a = hc(), t !== null && !Ut ? (mc(t, e, u), Ve(t, e, u)) : (nt && a && wi(e), e.flags |= 1, Qt(t, e, l, u), e.child);
    }
    function ss(t, e, l, a, u, n) {
      return jl(e), e.updateQueue = null, l = mr(e, a, l, u), hr(t), a = hc(), t !== null && !Ut ? (mc(t, e, n), Ve(t, e, n)) : (nt && a && wi(e), e.flags |= 1, Qt(t, e, l, n), e.child);
    }
    function ds(t, e, l, a, u) {
      if (jl(e), e.stateNode === null) {
        var n = oa, i = l.contextType;
        typeof i == "object" && i !== null && (n = jt(i)), n = new l(a, n), e.memoizedState = n.state !== null && n.state !== void 0 ? n.state : null, n.updater = Cc, e.stateNode = n, n._reactInternals = e, n = e.stateNode, n.props = a, n.state = e.memoizedState, n.refs = {}, uc(e), i = l.contextType, n.context = typeof i == "object" && i !== null ? jt(i) : oa, n.state = e.memoizedState, i = l.getDerivedStateFromProps, typeof i == "function" && (Oc(e, l, i, a), n.state = e.memoizedState), typeof l.getDerivedStateFromProps == "function" || typeof n.getSnapshotBeforeUpdate == "function" || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (i = n.state, typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount(), i !== n.state && Cc.enqueueReplaceState(n, n.state, null), cu(e, a, n, u), iu(), n.state = e.memoizedState), typeof n.componentDidMount == "function" && (e.flags |= 4194308), a = true;
      } else if (t === null) {
        n = e.stateNode;
        var f = e.memoizedProps, d = Kl(l, f);
        n.props = d;
        var z = n.context, M = l.contextType;
        i = oa, typeof M == "object" && M !== null && (i = jt(M));
        var U = l.getDerivedStateFromProps;
        M = typeof U == "function" || typeof n.getSnapshotBeforeUpdate == "function", f = e.pendingProps !== f, M || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (f || z !== i) && Ir(e, n, a, i), rl = false;
        var T = e.memoizedState;
        n.state = T, cu(e, a, n, u), iu(), z = e.memoizedState, f || T !== z || rl ? (typeof U == "function" && (Oc(e, l, U, a), z = e.memoizedState), (d = rl || Fr(e, l, d, a, T, z, i)) ? (M || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount()), typeof n.componentDidMount == "function" && (e.flags |= 4194308)) : (typeof n.componentDidMount == "function" && (e.flags |= 4194308), e.memoizedProps = a, e.memoizedState = z), n.props = a, n.state = z, n.context = i, a = d) : (typeof n.componentDidMount == "function" && (e.flags |= 4194308), a = false);
      } else {
        n = e.stateNode, nc(t, e), i = e.memoizedProps, M = Kl(l, i), n.props = M, U = e.pendingProps, T = n.context, z = l.contextType, d = oa, typeof z == "object" && z !== null && (d = jt(z)), f = l.getDerivedStateFromProps, (z = typeof f == "function" || typeof n.getSnapshotBeforeUpdate == "function") || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (i !== U || T !== d) && Ir(e, n, a, d), rl = false, T = e.memoizedState, n.state = T, cu(e, a, n, u), iu();
        var A = e.memoizedState;
        i !== U || T !== A || rl || t !== null && t.dependencies !== null && cn(t.dependencies) ? (typeof f == "function" && (Oc(e, l, f, a), A = e.memoizedState), (M = rl || Fr(e, l, M, a, T, A, d) || t !== null && t.dependencies !== null && cn(t.dependencies)) ? (z || typeof n.UNSAFE_componentWillUpdate != "function" && typeof n.componentWillUpdate != "function" || (typeof n.componentWillUpdate == "function" && n.componentWillUpdate(a, A, d), typeof n.UNSAFE_componentWillUpdate == "function" && n.UNSAFE_componentWillUpdate(a, A, d)), typeof n.componentDidUpdate == "function" && (e.flags |= 4), typeof n.getSnapshotBeforeUpdate == "function" && (e.flags |= 1024)) : (typeof n.componentDidUpdate != "function" || i === t.memoizedProps && T === t.memoizedState || (e.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || i === t.memoizedProps && T === t.memoizedState || (e.flags |= 1024), e.memoizedProps = a, e.memoizedState = A), n.props = a, n.state = A, n.context = d, a = M) : (typeof n.componentDidUpdate != "function" || i === t.memoizedProps && T === t.memoizedState || (e.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || i === t.memoizedProps && T === t.memoizedState || (e.flags |= 1024), a = false);
      }
      return n = a, Rn(t, e), a = (e.flags & 128) !== 0, n || a ? (n = e.stateNode, l = a && typeof l.getDerivedStateFromError != "function" ? null : n.render(), e.flags |= 1, t !== null && a ? (e.child = Zl(e, t.child, null, u), e.child = Zl(e, null, l, u)) : Qt(t, e, l, u), e.memoizedState = n.state, t = e.child) : t = Ve(t, e, u), t;
    }
    function hs(t, e, l, a) {
      return Yl(), e.flags |= 256, Qt(t, e, l, a), e.child;
    }
    var Nc = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0,
      hydrationErrors: null
    };
    function Hc(t) {
      return {
        baseLanes: t,
        cachePool: lr()
      };
    }
    function Bc(t, e, l) {
      return t = t !== null ? t.childLanes & ~l : 0, e && (t |= ce), t;
    }
    function ms(t, e, l) {
      var a = e.pendingProps, u = false, n = (e.flags & 128) !== 0, i;
      if ((i = n) || (i = t !== null && t.memoizedState === null ? false : (Rt.current & 2) !== 0), i && (u = true, e.flags &= -129), i = (e.flags & 32) !== 0, e.flags &= -33, t === null) {
        if (nt) {
          if (u ? hl(e) : ml(), (t = pt) ? (t = zd(t, ge), t = t !== null && t.data !== "&" ? t : null, t !== null && (e.memoizedState = {
            dehydrated: t,
            treeContext: il !== null ? {
              id: Ce,
              overflow: De
            } : null,
            retryLane: 536870912,
            hydrationErrors: null
          }, l = wo(t), l.return = e, e.child = l, Lt = e, pt = null)) : t = null, t === null) throw fl(e);
          return pf(t) ? e.lanes = 32 : e.lanes = 536870912, null;
        }
        var f = a.children;
        return a = a.fallback, u ? (ml(), u = e.mode, f = Mn({
          mode: "hidden",
          children: f
        }, u), a = ql(a, u, l, null), f.return = e, a.return = e, f.sibling = a, e.child = f, a = e.child, a.memoizedState = Hc(l), a.childLanes = Bc(t, i, l), e.memoizedState = Nc, du(null, a)) : (hl(e), qc(e, f));
      }
      var d = t.memoizedState;
      if (d !== null && (f = d.dehydrated, f !== null)) {
        if (n) e.flags & 256 ? (hl(e), e.flags &= -257, e = Yc(t, e, l)) : e.memoizedState !== null ? (ml(), e.child = t.child, e.flags |= 128, e = null) : (ml(), f = a.fallback, u = e.mode, a = Mn({
          mode: "visible",
          children: a.children
        }, u), f = ql(f, u, l, null), f.flags |= 2, a.return = e, f.return = e, a.sibling = f, e.child = a, Zl(e, t.child, null, l), a = e.child, a.memoizedState = Hc(l), a.childLanes = Bc(t, i, l), e.memoizedState = Nc, e = du(null, a));
        else if (hl(e), pf(f)) {
          if (i = f.nextSibling && f.nextSibling.dataset, i) var z = i.dgst;
          i = z, a = Error(o(419)), a.stack = "", a.digest = i, tu({
            value: a,
            source: null,
            stack: null
          }), e = Yc(t, e, l);
        } else if (Ut || ha(t, e, l, false), i = (l & t.childLanes) !== 0, Ut || i) {
          if (i = vt, i !== null && (a = Pf(i, l), a !== 0 && a !== d.retryLane)) throw d.retryLane = a, Bl(t, a), It(i, t, a), Uc;
          gf(f) || qn(), e = Yc(t, e, l);
        } else gf(f) ? (e.flags |= 192, e.child = t.child, e = null) : (t = d.treeContext, pt = Se(f.nextSibling), Lt = e, nt = true, cl = null, ge = false, t !== null && Wo(e, t), e = qc(e, a.children), e.flags |= 4096);
        return e;
      }
      return u ? (ml(), f = a.fallback, u = e.mode, d = t.child, z = d.sibling, a = Le(d, {
        mode: "hidden",
        children: a.children
      }), a.subtreeFlags = d.subtreeFlags & 65011712, z !== null ? f = Le(z, f) : (f = ql(f, u, l, null), f.flags |= 2), f.return = e, a.return = e, a.sibling = f, e.child = a, du(null, a), a = e.child, f = t.child.memoizedState, f === null ? f = Hc(l) : (u = f.cachePool, u !== null ? (d = Ct._currentValue, u = u.parent !== d ? {
        parent: d,
        pool: d
      } : u) : u = lr(), f = {
        baseLanes: f.baseLanes | l,
        cachePool: u
      }), a.memoizedState = f, a.childLanes = Bc(t, i, l), e.memoizedState = Nc, du(t.child, a)) : (hl(e), l = t.child, t = l.sibling, l = Le(l, {
        mode: "visible",
        children: a.children
      }), l.return = e, l.sibling = null, t !== null && (i = e.deletions, i === null ? (e.deletions = [
        t
      ], e.flags |= 16) : i.push(t)), e.child = l, e.memoizedState = null, l);
    }
    function qc(t, e) {
      return e = Mn({
        mode: "visible",
        children: e
      }, t.mode), e.return = t, t.child = e;
    }
    function Mn(t, e) {
      return t = ae(22, t, null, e), t.lanes = 0, t;
    }
    function Yc(t, e, l) {
      return Zl(e, t.child, null, l), t = qc(e, e.pendingProps.children), t.flags |= 2, e.memoizedState = null, t;
    }
    function ys(t, e, l) {
      t.lanes |= e;
      var a = t.alternate;
      a !== null && (a.lanes |= e), Ii(t.return, e, l);
    }
    function Lc(t, e, l, a, u, n) {
      var i = t.memoizedState;
      i === null ? t.memoizedState = {
        isBackwards: e,
        rendering: null,
        renderingStartTime: 0,
        last: a,
        tail: l,
        tailMode: u,
        treeForkCount: n
      } : (i.isBackwards = e, i.rendering = null, i.renderingStartTime = 0, i.last = a, i.tail = l, i.tailMode = u, i.treeForkCount = n);
    }
    function vs(t, e, l) {
      var a = e.pendingProps, u = a.revealOrder, n = a.tail;
      a = a.children;
      var i = Rt.current, f = (i & 2) !== 0;
      if (f ? (i = i & 1 | 2, e.flags |= 128) : i &= 1, B(Rt, i), Qt(t, e, a, l), a = nt ? Pa : 0, !f && t !== null && (t.flags & 128) !== 0) t: for (t = e.child; t !== null; ) {
        if (t.tag === 13) t.memoizedState !== null && ys(t, l, e);
        else if (t.tag === 19) ys(t, l, e);
        else if (t.child !== null) {
          t.child.return = t, t = t.child;
          continue;
        }
        if (t === e) break t;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e) break t;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
      switch (u) {
        case "forwards":
          for (l = e.child, u = null; l !== null; ) t = l.alternate, t !== null && yn(t) === null && (u = l), l = l.sibling;
          l = u, l === null ? (u = e.child, e.child = null) : (u = l.sibling, l.sibling = null), Lc(e, false, u, l, n, a);
          break;
        case "backwards":
        case "unstable_legacy-backwards":
          for (l = null, u = e.child, e.child = null; u !== null; ) {
            if (t = u.alternate, t !== null && yn(t) === null) {
              e.child = u;
              break;
            }
            t = u.sibling, u.sibling = l, l = u, u = t;
          }
          Lc(e, true, l, null, n, a);
          break;
        case "together":
          Lc(e, false, null, null, void 0, a);
          break;
        default:
          e.memoizedState = null;
      }
      return e.child;
    }
    function Ve(t, e, l) {
      if (t !== null && (e.dependencies = t.dependencies), gl |= e.lanes, (l & e.childLanes) === 0) if (t !== null) {
        if (ha(t, e, l, false), (l & e.childLanes) === 0) return null;
      } else return null;
      if (t !== null && e.child !== t.child) throw Error(o(153));
      if (e.child !== null) {
        for (t = e.child, l = Le(t, t.pendingProps), e.child = l, l.return = e; t.sibling !== null; ) t = t.sibling, l = l.sibling = Le(t, t.pendingProps), l.return = e;
        l.sibling = null;
      }
      return e.child;
    }
    function jc(t, e) {
      return (t.lanes & e) !== 0 ? true : (t = t.dependencies, !!(t !== null && cn(t)));
    }
    function ly(t, e, l) {
      switch (e.tag) {
        case 3:
          Vt(e, e.stateNode.containerInfo), ol(e, Ct, t.memoizedState.cache), Yl();
          break;
        case 27:
        case 5:
          La(e);
          break;
        case 4:
          Vt(e, e.stateNode.containerInfo);
          break;
        case 10:
          ol(e, e.type, e.memoizedProps.value);
          break;
        case 31:
          if (e.memoizedState !== null) return e.flags |= 128, rc(e), null;
          break;
        case 13:
          var a = e.memoizedState;
          if (a !== null) return a.dehydrated !== null ? (hl(e), e.flags |= 128, null) : (l & e.child.childLanes) !== 0 ? ms(t, e, l) : (hl(e), t = Ve(t, e, l), t !== null ? t.sibling : null);
          hl(e);
          break;
        case 19:
          var u = (t.flags & 128) !== 0;
          if (a = (l & e.childLanes) !== 0, a || (ha(t, e, l, false), a = (l & e.childLanes) !== 0), u) {
            if (a) return vs(t, e, l);
            e.flags |= 128;
          }
          if (u = e.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), B(Rt, Rt.current), a) break;
          return null;
        case 22:
          return e.lanes = 0, fs(t, e, l, e.pendingProps);
        case 24:
          ol(e, Ct, t.memoizedState.cache);
      }
      return Ve(t, e, l);
    }
    function gs(t, e, l) {
      if (t !== null) if (t.memoizedProps !== e.pendingProps) Ut = true;
      else {
        if (!jc(t, l) && (e.flags & 128) === 0) return Ut = false, ly(t, e, l);
        Ut = (t.flags & 131072) !== 0;
      }
      else Ut = false, nt && (e.flags & 1048576) !== 0 && ko(e, Pa, e.index);
      switch (e.lanes = 0, e.tag) {
        case 16:
          t: {
            var a = e.pendingProps;
            if (t = Gl(e.elementType), e.type = t, typeof t == "function") Vi(t) ? (a = Kl(t, a), e.tag = 1, e = ds(null, e, t, a, l)) : (e.tag = 0, e = xc(null, e, t, a, l));
            else {
              if (t != null) {
                var u = t.$$typeof;
                if (u === zt) {
                  e.tag = 11, e = ns(null, e, t, a, l);
                  break t;
                } else if (u === F) {
                  e.tag = 14, e = is(null, e, t, a, l);
                  break t;
                }
              }
              throw e = Te(t) || t, Error(o(306, e, ""));
            }
          }
          return e;
        case 0:
          return xc(t, e, e.type, e.pendingProps, l);
        case 1:
          return a = e.type, u = Kl(a, e.pendingProps), ds(t, e, a, u, l);
        case 3:
          t: {
            if (Vt(e, e.stateNode.containerInfo), t === null) throw Error(o(387));
            a = e.pendingProps;
            var n = e.memoizedState;
            u = n.element, nc(t, e), cu(e, a, null, l);
            var i = e.memoizedState;
            if (a = i.cache, ol(e, Ct, a), a !== n.cache && Pi(e, [
              Ct
            ], l, true), iu(), a = i.element, n.isDehydrated) if (n = {
              element: a,
              isDehydrated: false,
              cache: i.cache
            }, e.updateQueue.baseState = n, e.memoizedState = n, e.flags & 256) {
              e = hs(t, e, a, l);
              break t;
            } else if (a !== u) {
              u = me(Error(o(424)), e), tu(u), e = hs(t, e, a, l);
              break t;
            } else for (t = e.stateNode.containerInfo, t.nodeType === 9 ? t = t.body : t = t.nodeName === "HTML" ? t.ownerDocument.body : t, pt = Se(t.firstChild), Lt = e, nt = true, cl = null, ge = true, l = fr(e, null, a, l), e.child = l; l; ) l.flags = l.flags & -3 | 4096, l = l.sibling;
            else {
              if (Yl(), a === u) {
                e = Ve(t, e, l);
                break t;
              }
              Qt(t, e, a, l);
            }
            e = e.child;
          }
          return e;
        case 26:
          return Rn(t, e), t === null ? (l = Od(e.type, null, e.pendingProps, null)) ? e.memoizedState = l : nt || (l = e.type, t = e.pendingProps, a = Zn(P.current).createElement(l), a[Yt] = e, a[Jt] = t, Gt(a, l, t), Ht(a), e.stateNode = a) : e.memoizedState = Od(e.type, t.memoizedProps, e.pendingProps, t.memoizedState), null;
        case 27:
          return La(e), t === null && nt && (a = e.stateNode = _d(e.type, e.pendingProps, P.current), Lt = e, ge = true, u = pt, zl(e.type) ? (Sf = u, pt = Se(a.firstChild)) : pt = u), Qt(t, e, e.pendingProps.children, l), Rn(t, e), t === null && (e.flags |= 4194304), e.child;
        case 5:
          return t === null && nt && ((u = a = pt) && (a = xy(a, e.type, e.pendingProps, ge), a !== null ? (e.stateNode = a, Lt = e, pt = Se(a.firstChild), ge = false, u = true) : u = false), u || fl(e)), La(e), u = e.type, n = e.pendingProps, i = t !== null ? t.memoizedProps : null, a = n.children, mf(u, n) ? a = null : i !== null && mf(u, i) && (e.flags |= 32), e.memoizedState !== null && (u = dc(t, e, wm, null, null, l), Mu._currentValue = u), Rn(t, e), Qt(t, e, a, l), e.child;
        case 6:
          return t === null && nt && ((t = l = pt) && (l = Ny(l, e.pendingProps, ge), l !== null ? (e.stateNode = l, Lt = e, pt = null, t = true) : t = false), t || fl(e)), null;
        case 13:
          return ms(t, e, l);
        case 4:
          return Vt(e, e.stateNode.containerInfo), a = e.pendingProps, t === null ? e.child = Zl(e, null, a, l) : Qt(t, e, a, l), e.child;
        case 11:
          return ns(t, e, e.type, e.pendingProps, l);
        case 7:
          return Qt(t, e, e.pendingProps, l), e.child;
        case 8:
          return Qt(t, e, e.pendingProps.children, l), e.child;
        case 12:
          return Qt(t, e, e.pendingProps.children, l), e.child;
        case 10:
          return a = e.pendingProps, ol(e, e.type, a.value), Qt(t, e, a.children, l), e.child;
        case 9:
          return u = e.type._context, a = e.pendingProps.children, jl(e), u = jt(u), a = a(u), e.flags |= 1, Qt(t, e, a, l), e.child;
        case 14:
          return is(t, e, e.type, e.pendingProps, l);
        case 15:
          return cs(t, e, e.type, e.pendingProps, l);
        case 19:
          return vs(t, e, l);
        case 31:
          return ey(t, e, l);
        case 22:
          return fs(t, e, l, e.pendingProps);
        case 24:
          return jl(e), a = jt(Ct), t === null ? (u = lc(), u === null && (u = vt, n = tc(), u.pooledCache = n, n.refCount++, n !== null && (u.pooledCacheLanes |= l), u = n), e.memoizedState = {
            parent: a,
            cache: u
          }, uc(e), ol(e, Ct, u)) : ((t.lanes & l) !== 0 && (nc(t, e), cu(e, null, null, l), iu()), u = t.memoizedState, n = e.memoizedState, u.parent !== a ? (u = {
            parent: a,
            cache: a
          }, e.memoizedState = u, e.lanes === 0 && (e.memoizedState = e.updateQueue.baseState = u), ol(e, Ct, a)) : (a = n.cache, ol(e, Ct, a), a !== u.cache && Pi(e, [
            Ct
          ], l, true))), Qt(t, e, e.pendingProps.children, l), e.child;
        case 29:
          throw e.pendingProps;
      }
      throw Error(o(156, e.tag));
    }
    function Ke(t) {
      t.flags |= 4;
    }
    function Qc(t, e, l, a, u) {
      if ((e = (t.mode & 32) !== 0) && (e = false), e) {
        if (t.flags |= 16777216, (u & 335544128) === u) if (t.stateNode.complete) t.flags |= 8192;
        else if (Vs()) t.flags |= 8192;
        else throw Xl = sn, ac;
      } else t.flags &= -16777217;
    }
    function ps(t, e) {
      if (e.type !== "stylesheet" || (e.state.loading & 4) !== 0) t.flags &= -16777217;
      else if (t.flags |= 16777216, !Nd(e)) if (Vs()) t.flags |= 8192;
      else throw Xl = sn, ac;
    }
    function On(t, e) {
      e !== null && (t.flags |= 4), t.flags & 16384 && (e = t.tag !== 22 ? Wf() : 536870912, t.lanes |= e, _a |= e);
    }
    function hu(t, e) {
      if (!nt) switch (t.tailMode) {
        case "hidden":
          e = t.tail;
          for (var l = null; e !== null; ) e.alternate !== null && (l = e), e = e.sibling;
          l === null ? t.tail = null : l.sibling = null;
          break;
        case "collapsed":
          l = t.tail;
          for (var a = null; l !== null; ) l.alternate !== null && (a = l), l = l.sibling;
          a === null ? e || t.tail === null ? t.tail = null : t.tail.sibling = null : a.sibling = null;
      }
    }
    function St(t) {
      var e = t.alternate !== null && t.alternate.child === t.child, l = 0, a = 0;
      if (e) for (var u = t.child; u !== null; ) l |= u.lanes | u.childLanes, a |= u.subtreeFlags & 65011712, a |= u.flags & 65011712, u.return = t, u = u.sibling;
      else for (u = t.child; u !== null; ) l |= u.lanes | u.childLanes, a |= u.subtreeFlags, a |= u.flags, u.return = t, u = u.sibling;
      return t.subtreeFlags |= a, t.childLanes = l, e;
    }
    function ay(t, e, l) {
      var a = e.pendingProps;
      switch ($i(e), e.tag) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return St(e), null;
        case 1:
          return St(e), null;
        case 3:
          return l = e.stateNode, a = null, t !== null && (a = t.memoizedState.cache), e.memoizedState.cache !== a && (e.flags |= 2048), Ge(Ct), _t(), l.pendingContext && (l.context = l.pendingContext, l.pendingContext = null), (t === null || t.child === null) && (da(e) ? Ke(e) : t === null || t.memoizedState.isDehydrated && (e.flags & 256) === 0 || (e.flags |= 1024, Wi())), St(e), null;
        case 26:
          var u = e.type, n = e.memoizedState;
          return t === null ? (Ke(e), n !== null ? (St(e), ps(e, n)) : (St(e), Qc(e, u, null, a, l))) : n ? n !== t.memoizedState ? (Ke(e), St(e), ps(e, n)) : (St(e), e.flags &= -16777217) : (t = t.memoizedProps, t !== a && Ke(e), St(e), Qc(e, u, t, a, l)), null;
        case 27:
          if (Lu(e), l = P.current, u = e.type, t !== null && e.stateNode != null) t.memoizedProps !== a && Ke(e);
          else {
            if (!a) {
              if (e.stateNode === null) throw Error(o(166));
              return St(e), null;
            }
            t = K.current, da(e) ? Fo(e) : (t = _d(u, a, l), e.stateNode = t, Ke(e));
          }
          return St(e), null;
        case 5:
          if (Lu(e), u = e.type, t !== null && e.stateNode != null) t.memoizedProps !== a && Ke(e);
          else {
            if (!a) {
              if (e.stateNode === null) throw Error(o(166));
              return St(e), null;
            }
            if (n = K.current, da(e)) Fo(e);
            else {
              var i = Zn(P.current);
              switch (n) {
                case 1:
                  n = i.createElementNS("http://www.w3.org/2000/svg", u);
                  break;
                case 2:
                  n = i.createElementNS("http://www.w3.org/1998/Math/MathML", u);
                  break;
                default:
                  switch (u) {
                    case "svg":
                      n = i.createElementNS("http://www.w3.org/2000/svg", u);
                      break;
                    case "math":
                      n = i.createElementNS("http://www.w3.org/1998/Math/MathML", u);
                      break;
                    case "script":
                      n = i.createElement("div"), n.innerHTML = "<script><\/script>", n = n.removeChild(n.firstChild);
                      break;
                    case "select":
                      n = typeof a.is == "string" ? i.createElement("select", {
                        is: a.is
                      }) : i.createElement("select"), a.multiple ? n.multiple = true : a.size && (n.size = a.size);
                      break;
                    default:
                      n = typeof a.is == "string" ? i.createElement(u, {
                        is: a.is
                      }) : i.createElement(u);
                  }
              }
              n[Yt] = e, n[Jt] = a;
              t: for (i = e.child; i !== null; ) {
                if (i.tag === 5 || i.tag === 6) n.appendChild(i.stateNode);
                else if (i.tag !== 4 && i.tag !== 27 && i.child !== null) {
                  i.child.return = i, i = i.child;
                  continue;
                }
                if (i === e) break t;
                for (; i.sibling === null; ) {
                  if (i.return === null || i.return === e) break t;
                  i = i.return;
                }
                i.sibling.return = i.return, i = i.sibling;
              }
              e.stateNode = n;
              t: switch (Gt(n, u, a), u) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  a = !!a.autoFocus;
                  break t;
                case "img":
                  a = true;
                  break t;
                default:
                  a = false;
              }
              a && Ke(e);
            }
          }
          return St(e), Qc(e, e.type, t === null ? null : t.memoizedProps, e.pendingProps, l), null;
        case 6:
          if (t && e.stateNode != null) t.memoizedProps !== a && Ke(e);
          else {
            if (typeof a != "string" && e.stateNode === null) throw Error(o(166));
            if (t = P.current, da(e)) {
              if (t = e.stateNode, l = e.memoizedProps, a = null, u = Lt, u !== null) switch (u.tag) {
                case 27:
                case 5:
                  a = u.memoizedProps;
              }
              t[Yt] = e, t = !!(t.nodeValue === l || a !== null && a.suppressHydrationWarning === true || md(t.nodeValue, l)), t || fl(e, true);
            } else t = Zn(t).createTextNode(a), t[Yt] = e, e.stateNode = t;
          }
          return St(e), null;
        case 31:
          if (l = e.memoizedState, t === null || t.memoizedState !== null) {
            if (a = da(e), l !== null) {
              if (t === null) {
                if (!a) throw Error(o(318));
                if (t = e.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(o(557));
                t[Yt] = e;
              } else Yl(), (e.flags & 128) === 0 && (e.memoizedState = null), e.flags |= 4;
              St(e), t = false;
            } else l = Wi(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = l), t = true;
            if (!t) return e.flags & 256 ? (ne(e), e) : (ne(e), null);
            if ((e.flags & 128) !== 0) throw Error(o(558));
          }
          return St(e), null;
        case 13:
          if (a = e.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
            if (u = da(e), a !== null && a.dehydrated !== null) {
              if (t === null) {
                if (!u) throw Error(o(318));
                if (u = e.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error(o(317));
                u[Yt] = e;
              } else Yl(), (e.flags & 128) === 0 && (e.memoizedState = null), e.flags |= 4;
              St(e), u = false;
            } else u = Wi(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = u), u = true;
            if (!u) return e.flags & 256 ? (ne(e), e) : (ne(e), null);
          }
          return ne(e), (e.flags & 128) !== 0 ? (e.lanes = l, e) : (l = a !== null, t = t !== null && t.memoizedState !== null, l && (a = e.child, u = null, a.alternate !== null && a.alternate.memoizedState !== null && a.alternate.memoizedState.cachePool !== null && (u = a.alternate.memoizedState.cachePool.pool), n = null, a.memoizedState !== null && a.memoizedState.cachePool !== null && (n = a.memoizedState.cachePool.pool), n !== u && (a.flags |= 2048)), l !== t && l && (e.child.flags |= 8192), On(e, e.updateQueue), St(e), null);
        case 4:
          return _t(), t === null && of(e.stateNode.containerInfo), St(e), null;
        case 10:
          return Ge(e.type), St(e), null;
        case 19:
          if (x(Rt), a = e.memoizedState, a === null) return St(e), null;
          if (u = (e.flags & 128) !== 0, n = a.rendering, n === null) if (u) hu(a, false);
          else {
            if (At !== 0 || t !== null && (t.flags & 128) !== 0) for (t = e.child; t !== null; ) {
              if (n = yn(t), n !== null) {
                for (e.flags |= 128, hu(a, false), t = n.updateQueue, e.updateQueue = t, On(e, t), e.subtreeFlags = 0, t = l, l = e.child; l !== null; ) Jo(l, t), l = l.sibling;
                return B(Rt, Rt.current & 1 | 2), nt && je(e, a.treeForkCount), e.child;
              }
              t = t.sibling;
            }
            a.tail !== null && Pt() > Nn && (e.flags |= 128, u = true, hu(a, false), e.lanes = 4194304);
          }
          else {
            if (!u) if (t = yn(n), t !== null) {
              if (e.flags |= 128, u = true, t = t.updateQueue, e.updateQueue = t, On(e, t), hu(a, true), a.tail === null && a.tailMode === "hidden" && !n.alternate && !nt) return St(e), null;
            } else 2 * Pt() - a.renderingStartTime > Nn && l !== 536870912 && (e.flags |= 128, u = true, hu(a, false), e.lanes = 4194304);
            a.isBackwards ? (n.sibling = e.child, e.child = n) : (t = a.last, t !== null ? t.sibling = n : e.child = n, a.last = n);
          }
          return a.tail !== null ? (t = a.tail, a.rendering = t, a.tail = t.sibling, a.renderingStartTime = Pt(), t.sibling = null, l = Rt.current, B(Rt, u ? l & 1 | 2 : l & 1), nt && je(e, a.treeForkCount), t) : (St(e), null);
        case 22:
        case 23:
          return ne(e), oc(), a = e.memoizedState !== null, t !== null ? t.memoizedState !== null !== a && (e.flags |= 8192) : a && (e.flags |= 8192), a ? (l & 536870912) !== 0 && (e.flags & 128) === 0 && (St(e), e.subtreeFlags & 6 && (e.flags |= 8192)) : St(e), l = e.updateQueue, l !== null && On(e, l.retryQueue), l = null, t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), a = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (a = e.memoizedState.cachePool.pool), a !== l && (e.flags |= 2048), t !== null && x(Ql), null;
        case 24:
          return l = null, t !== null && (l = t.memoizedState.cache), e.memoizedState.cache !== l && (e.flags |= 2048), Ge(Ct), St(e), null;
        case 25:
          return null;
        case 30:
          return null;
      }
      throw Error(o(156, e.tag));
    }
    function uy(t, e) {
      switch ($i(e), e.tag) {
        case 1:
          return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
        case 3:
          return Ge(Ct), _t(), t = e.flags, (t & 65536) !== 0 && (t & 128) === 0 ? (e.flags = t & -65537 | 128, e) : null;
        case 26:
        case 27:
        case 5:
          return Lu(e), null;
        case 31:
          if (e.memoizedState !== null) {
            if (ne(e), e.alternate === null) throw Error(o(340));
            Yl();
          }
          return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
        case 13:
          if (ne(e), t = e.memoizedState, t !== null && t.dehydrated !== null) {
            if (e.alternate === null) throw Error(o(340));
            Yl();
          }
          return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
        case 19:
          return x(Rt), null;
        case 4:
          return _t(), null;
        case 10:
          return Ge(e.type), null;
        case 22:
        case 23:
          return ne(e), oc(), t !== null && x(Ql), t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
        case 24:
          return Ge(Ct), null;
        case 25:
          return null;
        default:
          return null;
      }
    }
    function Ss(t, e) {
      switch ($i(e), e.tag) {
        case 3:
          Ge(Ct), _t();
          break;
        case 26:
        case 27:
        case 5:
          Lu(e);
          break;
        case 4:
          _t();
          break;
        case 31:
          e.memoizedState !== null && ne(e);
          break;
        case 13:
          ne(e);
          break;
        case 19:
          x(Rt);
          break;
        case 10:
          Ge(e.type);
          break;
        case 22:
        case 23:
          ne(e), oc(), t !== null && x(Ql);
          break;
        case 24:
          Ge(Ct);
      }
    }
    function mu(t, e) {
      try {
        var l = e.updateQueue, a = l !== null ? l.lastEffect : null;
        if (a !== null) {
          var u = a.next;
          l = u;
          do {
            if ((l.tag & t) === t) {
              a = void 0;
              var n = l.create, i = l.inst;
              a = n(), i.destroy = a;
            }
            l = l.next;
          } while (l !== u);
        }
      } catch (f) {
        dt(e, e.return, f);
      }
    }
    function yl(t, e, l) {
      try {
        var a = e.updateQueue, u = a !== null ? a.lastEffect : null;
        if (u !== null) {
          var n = u.next;
          a = n;
          do {
            if ((a.tag & t) === t) {
              var i = a.inst, f = i.destroy;
              if (f !== void 0) {
                i.destroy = void 0, u = e;
                var d = l, z = f;
                try {
                  z();
                } catch (M) {
                  dt(u, d, M);
                }
              }
            }
            a = a.next;
          } while (a !== n);
        }
      } catch (M) {
        dt(e, e.return, M);
      }
    }
    function bs(t) {
      var e = t.updateQueue;
      if (e !== null) {
        var l = t.stateNode;
        try {
          rr(e, l);
        } catch (a) {
          dt(t, t.return, a);
        }
      }
    }
    function Es(t, e, l) {
      l.props = Kl(t.type, t.memoizedProps), l.state = t.memoizedState;
      try {
        l.componentWillUnmount();
      } catch (a) {
        dt(t, e, a);
      }
    }
    function yu(t, e) {
      try {
        var l = t.ref;
        if (l !== null) {
          switch (t.tag) {
            case 26:
            case 27:
            case 5:
              var a = t.stateNode;
              break;
            case 30:
              a = t.stateNode;
              break;
            default:
              a = t.stateNode;
          }
          typeof l == "function" ? t.refCleanup = l(a) : l.current = a;
        }
      } catch (u) {
        dt(t, e, u);
      }
    }
    function Ue(t, e) {
      var l = t.ref, a = t.refCleanup;
      if (l !== null) if (typeof a == "function") try {
        a();
      } catch (u) {
        dt(t, e, u);
      } finally {
        t.refCleanup = null, t = t.alternate, t != null && (t.refCleanup = null);
      }
      else if (typeof l == "function") try {
        l(null);
      } catch (u) {
        dt(t, e, u);
      }
      else l.current = null;
    }
    function zs(t) {
      var e = t.type, l = t.memoizedProps, a = t.stateNode;
      try {
        t: switch (e) {
          case "button":
          case "input":
          case "select":
          case "textarea":
            l.autoFocus && a.focus();
            break t;
          case "img":
            l.src ? a.src = l.src : l.srcSet && (a.srcset = l.srcSet);
        }
      } catch (u) {
        dt(t, t.return, u);
      }
    }
    function Gc(t, e, l) {
      try {
        var a = t.stateNode;
        Ry(a, t.type, l, e), a[Jt] = e;
      } catch (u) {
        dt(t, t.return, u);
      }
    }
    function Ts(t) {
      return t.tag === 5 || t.tag === 3 || t.tag === 26 || t.tag === 27 && zl(t.type) || t.tag === 4;
    }
    function Xc(t) {
      t: for (; ; ) {
        for (; t.sibling === null; ) {
          if (t.return === null || Ts(t.return)) return null;
          t = t.return;
        }
        for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18; ) {
          if (t.tag === 27 && zl(t.type) || t.flags & 2 || t.child === null || t.tag === 4) continue t;
          t.child.return = t, t = t.child;
        }
        if (!(t.flags & 2)) return t.stateNode;
      }
    }
    function Zc(t, e, l) {
      var a = t.tag;
      if (a === 5 || a === 6) t = t.stateNode, e ? (l.nodeType === 9 ? l.body : l.nodeName === "HTML" ? l.ownerDocument.body : l).insertBefore(t, e) : (e = l.nodeType === 9 ? l.body : l.nodeName === "HTML" ? l.ownerDocument.body : l, e.appendChild(t), l = l._reactRootContainer, l != null || e.onclick !== null || (e.onclick = qe));
      else if (a !== 4 && (a === 27 && zl(t.type) && (l = t.stateNode, e = null), t = t.child, t !== null)) for (Zc(t, e, l), t = t.sibling; t !== null; ) Zc(t, e, l), t = t.sibling;
    }
    function Cn(t, e, l) {
      var a = t.tag;
      if (a === 5 || a === 6) t = t.stateNode, e ? l.insertBefore(t, e) : l.appendChild(t);
      else if (a !== 4 && (a === 27 && zl(t.type) && (l = t.stateNode), t = t.child, t !== null)) for (Cn(t, e, l), t = t.sibling; t !== null; ) Cn(t, e, l), t = t.sibling;
    }
    function As(t) {
      var e = t.stateNode, l = t.memoizedProps;
      try {
        for (var a = t.type, u = e.attributes; u.length; ) e.removeAttributeNode(u[0]);
        Gt(e, a, l), e[Yt] = t, e[Jt] = l;
      } catch (n) {
        dt(t, t.return, n);
      }
    }
    var Je = false, xt = false, Vc = false, _s = typeof WeakSet == "function" ? WeakSet : Set, Bt = null;
    function ny(t, e) {
      if (t = t.containerInfo, df = Wn, t = Yo(t), Yi(t)) {
        if ("selectionStart" in t) var l = {
          start: t.selectionStart,
          end: t.selectionEnd
        };
        else t: {
          l = (l = t.ownerDocument) && l.defaultView || window;
          var a = l.getSelection && l.getSelection();
          if (a && a.rangeCount !== 0) {
            l = a.anchorNode;
            var u = a.anchorOffset, n = a.focusNode;
            a = a.focusOffset;
            try {
              l.nodeType, n.nodeType;
            } catch {
              l = null;
              break t;
            }
            var i = 0, f = -1, d = -1, z = 0, M = 0, U = t, T = null;
            e: for (; ; ) {
              for (var A; U !== l || u !== 0 && U.nodeType !== 3 || (f = i + u), U !== n || a !== 0 && U.nodeType !== 3 || (d = i + a), U.nodeType === 3 && (i += U.nodeValue.length), (A = U.firstChild) !== null; ) T = U, U = A;
              for (; ; ) {
                if (U === t) break e;
                if (T === l && ++z === u && (f = i), T === n && ++M === a && (d = i), (A = U.nextSibling) !== null) break;
                U = T, T = U.parentNode;
              }
              U = A;
            }
            l = f === -1 || d === -1 ? null : {
              start: f,
              end: d
            };
          } else l = null;
        }
        l = l || {
          start: 0,
          end: 0
        };
      } else l = null;
      for (hf = {
        focusedElem: t,
        selectionRange: l
      }, Wn = false, Bt = e; Bt !== null; ) if (e = Bt, t = e.child, (e.subtreeFlags & 1028) !== 0 && t !== null) t.return = e, Bt = t;
      else for (; Bt !== null; ) {
        switch (e = Bt, n = e.alternate, t = e.flags, e.tag) {
          case 0:
            if ((t & 4) !== 0 && (t = e.updateQueue, t = t !== null ? t.events : null, t !== null)) for (l = 0; l < t.length; l++) u = t[l], u.ref.impl = u.nextImpl;
            break;
          case 11:
          case 15:
            break;
          case 1:
            if ((t & 1024) !== 0 && n !== null) {
              t = void 0, l = e, u = n.memoizedProps, n = n.memoizedState, a = l.stateNode;
              try {
                var j = Kl(l.type, u);
                t = a.getSnapshotBeforeUpdate(j, n), a.__reactInternalSnapshotBeforeUpdate = t;
              } catch (J) {
                dt(l, l.return, J);
              }
            }
            break;
          case 3:
            if ((t & 1024) !== 0) {
              if (t = e.stateNode.containerInfo, l = t.nodeType, l === 9) vf(t);
              else if (l === 1) switch (t.nodeName) {
                case "HEAD":
                case "HTML":
                case "BODY":
                  vf(t);
                  break;
                default:
                  t.textContent = "";
              }
            }
            break;
          case 5:
          case 26:
          case 27:
          case 6:
          case 4:
          case 17:
            break;
          default:
            if ((t & 1024) !== 0) throw Error(o(163));
        }
        if (t = e.sibling, t !== null) {
          t.return = e.return, Bt = t;
          break;
        }
        Bt = e.return;
      }
    }
    function Rs(t, e, l) {
      var a = l.flags;
      switch (l.tag) {
        case 0:
        case 11:
        case 15:
          $e(t, l), a & 4 && mu(5, l);
          break;
        case 1:
          if ($e(t, l), a & 4) if (t = l.stateNode, e === null) try {
            t.componentDidMount();
          } catch (i) {
            dt(l, l.return, i);
          }
          else {
            var u = Kl(l.type, e.memoizedProps);
            e = e.memoizedState;
            try {
              t.componentDidUpdate(u, e, t.__reactInternalSnapshotBeforeUpdate);
            } catch (i) {
              dt(l, l.return, i);
            }
          }
          a & 64 && bs(l), a & 512 && yu(l, l.return);
          break;
        case 3:
          if ($e(t, l), a & 64 && (t = l.updateQueue, t !== null)) {
            if (e = null, l.child !== null) switch (l.child.tag) {
              case 27:
              case 5:
                e = l.child.stateNode;
                break;
              case 1:
                e = l.child.stateNode;
            }
            try {
              rr(t, e);
            } catch (i) {
              dt(l, l.return, i);
            }
          }
          break;
        case 27:
          e === null && a & 4 && As(l);
        case 26:
        case 5:
          $e(t, l), e === null && a & 4 && zs(l), a & 512 && yu(l, l.return);
          break;
        case 12:
          $e(t, l);
          break;
        case 31:
          $e(t, l), a & 4 && Cs(t, l);
          break;
        case 13:
          $e(t, l), a & 4 && Ds(t, l), a & 64 && (t = l.memoizedState, t !== null && (t = t.dehydrated, t !== null && (l = my.bind(null, l), Hy(t, l))));
          break;
        case 22:
          if (a = l.memoizedState !== null || Je, !a) {
            e = e !== null && e.memoizedState !== null || xt, u = Je;
            var n = xt;
            Je = a, (xt = e) && !n ? ke(t, l, (l.subtreeFlags & 8772) !== 0) : $e(t, l), Je = u, xt = n;
          }
          break;
        case 30:
          break;
        default:
          $e(t, l);
      }
    }
    function Ms(t) {
      var e = t.alternate;
      e !== null && (t.alternate = null, Ms(e)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (e = t.stateNode, e !== null && bi(e)), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null;
    }
    var bt = null, $t = false;
    function we(t, e, l) {
      for (l = l.child; l !== null; ) Os(t, e, l), l = l.sibling;
    }
    function Os(t, e, l) {
      if (te && typeof te.onCommitFiberUnmount == "function") try {
        te.onCommitFiberUnmount(ja, l);
      } catch {
      }
      switch (l.tag) {
        case 26:
          xt || Ue(l, e), we(t, e, l), l.memoizedState ? l.memoizedState.count-- : l.stateNode && (l = l.stateNode, l.parentNode.removeChild(l));
          break;
        case 27:
          xt || Ue(l, e);
          var a = bt, u = $t;
          zl(l.type) && (bt = l.stateNode, $t = false), we(t, e, l), Au(l.stateNode), bt = a, $t = u;
          break;
        case 5:
          xt || Ue(l, e);
        case 6:
          if (a = bt, u = $t, bt = null, we(t, e, l), bt = a, $t = u, bt !== null) if ($t) try {
            (bt.nodeType === 9 ? bt.body : bt.nodeName === "HTML" ? bt.ownerDocument.body : bt).removeChild(l.stateNode);
          } catch (n) {
            dt(l, e, n);
          }
          else try {
            bt.removeChild(l.stateNode);
          } catch (n) {
            dt(l, e, n);
          }
          break;
        case 18:
          bt !== null && ($t ? (t = bt, bd(t.nodeType === 9 ? t.body : t.nodeName === "HTML" ? t.ownerDocument.body : t, l.stateNode), Na(t)) : bd(bt, l.stateNode));
          break;
        case 4:
          a = bt, u = $t, bt = l.stateNode.containerInfo, $t = true, we(t, e, l), bt = a, $t = u;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          yl(2, l, e), xt || yl(4, l, e), we(t, e, l);
          break;
        case 1:
          xt || (Ue(l, e), a = l.stateNode, typeof a.componentWillUnmount == "function" && Es(l, e, a)), we(t, e, l);
          break;
        case 21:
          we(t, e, l);
          break;
        case 22:
          xt = (a = xt) || l.memoizedState !== null, we(t, e, l), xt = a;
          break;
        default:
          we(t, e, l);
      }
    }
    function Cs(t, e) {
      if (e.memoizedState === null && (t = e.alternate, t !== null && (t = t.memoizedState, t !== null))) {
        t = t.dehydrated;
        try {
          Na(t);
        } catch (l) {
          dt(e, e.return, l);
        }
      }
    }
    function Ds(t, e) {
      if (e.memoizedState === null && (t = e.alternate, t !== null && (t = t.memoizedState, t !== null && (t = t.dehydrated, t !== null)))) try {
        Na(t);
      } catch (l) {
        dt(e, e.return, l);
      }
    }
    function iy(t) {
      switch (t.tag) {
        case 31:
        case 13:
        case 19:
          var e = t.stateNode;
          return e === null && (e = t.stateNode = new _s()), e;
        case 22:
          return t = t.stateNode, e = t._retryCache, e === null && (e = t._retryCache = new _s()), e;
        default:
          throw Error(o(435, t.tag));
      }
    }
    function Dn(t, e) {
      var l = iy(t);
      e.forEach(function(a) {
        if (!l.has(a)) {
          l.add(a);
          var u = yy.bind(null, t, a);
          a.then(u, u);
        }
      });
    }
    function kt(t, e) {
      var l = e.deletions;
      if (l !== null) for (var a = 0; a < l.length; a++) {
        var u = l[a], n = t, i = e, f = i;
        t: for (; f !== null; ) {
          switch (f.tag) {
            case 27:
              if (zl(f.type)) {
                bt = f.stateNode, $t = false;
                break t;
              }
              break;
            case 5:
              bt = f.stateNode, $t = false;
              break t;
            case 3:
            case 4:
              bt = f.stateNode.containerInfo, $t = true;
              break t;
          }
          f = f.return;
        }
        if (bt === null) throw Error(o(160));
        Os(n, i, u), bt = null, $t = false, n = u.alternate, n !== null && (n.return = null), u.return = null;
      }
      if (e.subtreeFlags & 13886) for (e = e.child; e !== null; ) Us(e, t), e = e.sibling;
    }
    var Re = null;
    function Us(t, e) {
      var l = t.alternate, a = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          kt(e, t), Wt(t), a & 4 && (yl(3, t, t.return), mu(3, t), yl(5, t, t.return));
          break;
        case 1:
          kt(e, t), Wt(t), a & 512 && (xt || l === null || Ue(l, l.return)), a & 64 && Je && (t = t.updateQueue, t !== null && (a = t.callbacks, a !== null && (l = t.shared.hiddenCallbacks, t.shared.hiddenCallbacks = l === null ? a : l.concat(a))));
          break;
        case 26:
          var u = Re;
          if (kt(e, t), Wt(t), a & 512 && (xt || l === null || Ue(l, l.return)), a & 4) {
            var n = l !== null ? l.memoizedState : null;
            if (a = t.memoizedState, l === null) if (a === null) if (t.stateNode === null) {
              t: {
                a = t.type, l = t.memoizedProps, u = u.ownerDocument || u;
                e: switch (a) {
                  case "title":
                    n = u.getElementsByTagName("title")[0], (!n || n[Xa] || n[Yt] || n.namespaceURI === "http://www.w3.org/2000/svg" || n.hasAttribute("itemprop")) && (n = u.createElement(a), u.head.insertBefore(n, u.querySelector("head > title"))), Gt(n, a, l), n[Yt] = t, Ht(n), a = n;
                    break t;
                  case "link":
                    var i = Ud("link", "href", u).get(a + (l.href || ""));
                    if (i) {
                      for (var f = 0; f < i.length; f++) if (n = i[f], n.getAttribute("href") === (l.href == null || l.href === "" ? null : l.href) && n.getAttribute("rel") === (l.rel == null ? null : l.rel) && n.getAttribute("title") === (l.title == null ? null : l.title) && n.getAttribute("crossorigin") === (l.crossOrigin == null ? null : l.crossOrigin)) {
                        i.splice(f, 1);
                        break e;
                      }
                    }
                    n = u.createElement(a), Gt(n, a, l), u.head.appendChild(n);
                    break;
                  case "meta":
                    if (i = Ud("meta", "content", u).get(a + (l.content || ""))) {
                      for (f = 0; f < i.length; f++) if (n = i[f], n.getAttribute("content") === (l.content == null ? null : "" + l.content) && n.getAttribute("name") === (l.name == null ? null : l.name) && n.getAttribute("property") === (l.property == null ? null : l.property) && n.getAttribute("http-equiv") === (l.httpEquiv == null ? null : l.httpEquiv) && n.getAttribute("charset") === (l.charSet == null ? null : l.charSet)) {
                        i.splice(f, 1);
                        break e;
                      }
                    }
                    n = u.createElement(a), Gt(n, a, l), u.head.appendChild(n);
                    break;
                  default:
                    throw Error(o(468, a));
                }
                n[Yt] = t, Ht(n), a = n;
              }
              t.stateNode = a;
            } else xd(u, t.type, t.stateNode);
            else t.stateNode = Dd(u, a, t.memoizedProps);
            else n !== a ? (n === null ? l.stateNode !== null && (l = l.stateNode, l.parentNode.removeChild(l)) : n.count--, a === null ? xd(u, t.type, t.stateNode) : Dd(u, a, t.memoizedProps)) : a === null && t.stateNode !== null && Gc(t, t.memoizedProps, l.memoizedProps);
          }
          break;
        case 27:
          kt(e, t), Wt(t), a & 512 && (xt || l === null || Ue(l, l.return)), l !== null && a & 4 && Gc(t, t.memoizedProps, l.memoizedProps);
          break;
        case 5:
          if (kt(e, t), Wt(t), a & 512 && (xt || l === null || Ue(l, l.return)), t.flags & 32) {
            u = t.stateNode;
            try {
              la(u, "");
            } catch (j) {
              dt(t, t.return, j);
            }
          }
          a & 4 && t.stateNode != null && (u = t.memoizedProps, Gc(t, u, l !== null ? l.memoizedProps : u)), a & 1024 && (Vc = true);
          break;
        case 6:
          if (kt(e, t), Wt(t), a & 4) {
            if (t.stateNode === null) throw Error(o(162));
            a = t.memoizedProps, l = t.stateNode;
            try {
              l.nodeValue = a;
            } catch (j) {
              dt(t, t.return, j);
            }
          }
          break;
        case 3:
          if (Jn = null, u = Re, Re = Vn(e.containerInfo), kt(e, t), Re = u, Wt(t), a & 4 && l !== null && l.memoizedState.isDehydrated) try {
            Na(e.containerInfo);
          } catch (j) {
            dt(t, t.return, j);
          }
          Vc && (Vc = false, xs(t));
          break;
        case 4:
          a = Re, Re = Vn(t.stateNode.containerInfo), kt(e, t), Wt(t), Re = a;
          break;
        case 12:
          kt(e, t), Wt(t);
          break;
        case 31:
          kt(e, t), Wt(t), a & 4 && (a = t.updateQueue, a !== null && (t.updateQueue = null, Dn(t, a)));
          break;
        case 13:
          kt(e, t), Wt(t), t.child.flags & 8192 && t.memoizedState !== null != (l !== null && l.memoizedState !== null) && (xn = Pt()), a & 4 && (a = t.updateQueue, a !== null && (t.updateQueue = null, Dn(t, a)));
          break;
        case 22:
          u = t.memoizedState !== null;
          var d = l !== null && l.memoizedState !== null, z = Je, M = xt;
          if (Je = z || u, xt = M || d, kt(e, t), xt = M, Je = z, Wt(t), a & 8192) t: for (e = t.stateNode, e._visibility = u ? e._visibility & -2 : e._visibility | 1, u && (l === null || d || Je || xt || Jl(t)), l = null, e = t; ; ) {
            if (e.tag === 5 || e.tag === 26) {
              if (l === null) {
                d = l = e;
                try {
                  if (n = d.stateNode, u) i = n.style, typeof i.setProperty == "function" ? i.setProperty("display", "none", "important") : i.display = "none";
                  else {
                    f = d.stateNode;
                    var U = d.memoizedProps.style, T = U != null && U.hasOwnProperty("display") ? U.display : null;
                    f.style.display = T == null || typeof T == "boolean" ? "" : ("" + T).trim();
                  }
                } catch (j) {
                  dt(d, d.return, j);
                }
              }
            } else if (e.tag === 6) {
              if (l === null) {
                d = e;
                try {
                  d.stateNode.nodeValue = u ? "" : d.memoizedProps;
                } catch (j) {
                  dt(d, d.return, j);
                }
              }
            } else if (e.tag === 18) {
              if (l === null) {
                d = e;
                try {
                  var A = d.stateNode;
                  u ? Ed(A, true) : Ed(d.stateNode, false);
                } catch (j) {
                  dt(d, d.return, j);
                }
              }
            } else if ((e.tag !== 22 && e.tag !== 23 || e.memoizedState === null || e === t) && e.child !== null) {
              e.child.return = e, e = e.child;
              continue;
            }
            if (e === t) break t;
            for (; e.sibling === null; ) {
              if (e.return === null || e.return === t) break t;
              l === e && (l = null), e = e.return;
            }
            l === e && (l = null), e.sibling.return = e.return, e = e.sibling;
          }
          a & 4 && (a = t.updateQueue, a !== null && (l = a.retryQueue, l !== null && (a.retryQueue = null, Dn(t, l))));
          break;
        case 19:
          kt(e, t), Wt(t), a & 4 && (a = t.updateQueue, a !== null && (t.updateQueue = null, Dn(t, a)));
          break;
        case 30:
          break;
        case 21:
          break;
        default:
          kt(e, t), Wt(t);
      }
    }
    function Wt(t) {
      var e = t.flags;
      if (e & 2) {
        try {
          for (var l, a = t.return; a !== null; ) {
            if (Ts(a)) {
              l = a;
              break;
            }
            a = a.return;
          }
          if (l == null) throw Error(o(160));
          switch (l.tag) {
            case 27:
              var u = l.stateNode, n = Xc(t);
              Cn(t, n, u);
              break;
            case 5:
              var i = l.stateNode;
              l.flags & 32 && (la(i, ""), l.flags &= -33);
              var f = Xc(t);
              Cn(t, f, i);
              break;
            case 3:
            case 4:
              var d = l.stateNode.containerInfo, z = Xc(t);
              Zc(t, z, d);
              break;
            default:
              throw Error(o(161));
          }
        } catch (M) {
          dt(t, t.return, M);
        }
        t.flags &= -3;
      }
      e & 4096 && (t.flags &= -4097);
    }
    function xs(t) {
      if (t.subtreeFlags & 1024) for (t = t.child; t !== null; ) {
        var e = t;
        xs(e), e.tag === 5 && e.flags & 1024 && e.stateNode.reset(), t = t.sibling;
      }
    }
    function $e(t, e) {
      if (e.subtreeFlags & 8772) for (e = e.child; e !== null; ) Rs(t, e.alternate, e), e = e.sibling;
    }
    function Jl(t) {
      for (t = t.child; t !== null; ) {
        var e = t;
        switch (e.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            yl(4, e, e.return), Jl(e);
            break;
          case 1:
            Ue(e, e.return);
            var l = e.stateNode;
            typeof l.componentWillUnmount == "function" && Es(e, e.return, l), Jl(e);
            break;
          case 27:
            Au(e.stateNode);
          case 26:
          case 5:
            Ue(e, e.return), Jl(e);
            break;
          case 22:
            e.memoizedState === null && Jl(e);
            break;
          case 30:
            Jl(e);
            break;
          default:
            Jl(e);
        }
        t = t.sibling;
      }
    }
    function ke(t, e, l) {
      for (l = l && (e.subtreeFlags & 8772) !== 0, e = e.child; e !== null; ) {
        var a = e.alternate, u = t, n = e, i = n.flags;
        switch (n.tag) {
          case 0:
          case 11:
          case 15:
            ke(u, n, l), mu(4, n);
            break;
          case 1:
            if (ke(u, n, l), a = n, u = a.stateNode, typeof u.componentDidMount == "function") try {
              u.componentDidMount();
            } catch (z) {
              dt(a, a.return, z);
            }
            if (a = n, u = a.updateQueue, u !== null) {
              var f = a.stateNode;
              try {
                var d = u.shared.hiddenCallbacks;
                if (d !== null) for (u.shared.hiddenCallbacks = null, u = 0; u < d.length; u++) or(d[u], f);
              } catch (z) {
                dt(a, a.return, z);
              }
            }
            l && i & 64 && bs(n), yu(n, n.return);
            break;
          case 27:
            As(n);
          case 26:
          case 5:
            ke(u, n, l), l && a === null && i & 4 && zs(n), yu(n, n.return);
            break;
          case 12:
            ke(u, n, l);
            break;
          case 31:
            ke(u, n, l), l && i & 4 && Cs(u, n);
            break;
          case 13:
            ke(u, n, l), l && i & 4 && Ds(u, n);
            break;
          case 22:
            n.memoizedState === null && ke(u, n, l), yu(n, n.return);
            break;
          case 30:
            break;
          default:
            ke(u, n, l);
        }
        e = e.sibling;
      }
    }
    function Kc(t, e) {
      var l = null;
      t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), t = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (t = e.memoizedState.cachePool.pool), t !== l && (t != null && t.refCount++, l != null && eu(l));
    }
    function Jc(t, e) {
      t = null, e.alternate !== null && (t = e.alternate.memoizedState.cache), e = e.memoizedState.cache, e !== t && (e.refCount++, t != null && eu(t));
    }
    function Me(t, e, l, a) {
      if (e.subtreeFlags & 10256) for (e = e.child; e !== null; ) Ns(t, e, l, a), e = e.sibling;
    }
    function Ns(t, e, l, a) {
      var u = e.flags;
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          Me(t, e, l, a), u & 2048 && mu(9, e);
          break;
        case 1:
          Me(t, e, l, a);
          break;
        case 3:
          Me(t, e, l, a), u & 2048 && (t = null, e.alternate !== null && (t = e.alternate.memoizedState.cache), e = e.memoizedState.cache, e !== t && (e.refCount++, t != null && eu(t)));
          break;
        case 12:
          if (u & 2048) {
            Me(t, e, l, a), t = e.stateNode;
            try {
              var n = e.memoizedProps, i = n.id, f = n.onPostCommit;
              typeof f == "function" && f(i, e.alternate === null ? "mount" : "update", t.passiveEffectDuration, -0);
            } catch (d) {
              dt(e, e.return, d);
            }
          } else Me(t, e, l, a);
          break;
        case 31:
          Me(t, e, l, a);
          break;
        case 13:
          Me(t, e, l, a);
          break;
        case 23:
          break;
        case 22:
          n = e.stateNode, i = e.alternate, e.memoizedState !== null ? n._visibility & 2 ? Me(t, e, l, a) : vu(t, e) : n._visibility & 2 ? Me(t, e, l, a) : (n._visibility |= 2, za(t, e, l, a, (e.subtreeFlags & 10256) !== 0 || false)), u & 2048 && Kc(i, e);
          break;
        case 24:
          Me(t, e, l, a), u & 2048 && Jc(e.alternate, e);
          break;
        default:
          Me(t, e, l, a);
      }
    }
    function za(t, e, l, a, u) {
      for (u = u && ((e.subtreeFlags & 10256) !== 0 || false), e = e.child; e !== null; ) {
        var n = t, i = e, f = l, d = a, z = i.flags;
        switch (i.tag) {
          case 0:
          case 11:
          case 15:
            za(n, i, f, d, u), mu(8, i);
            break;
          case 23:
            break;
          case 22:
            var M = i.stateNode;
            i.memoizedState !== null ? M._visibility & 2 ? za(n, i, f, d, u) : vu(n, i) : (M._visibility |= 2, za(n, i, f, d, u)), u && z & 2048 && Kc(i.alternate, i);
            break;
          case 24:
            za(n, i, f, d, u), u && z & 2048 && Jc(i.alternate, i);
            break;
          default:
            za(n, i, f, d, u);
        }
        e = e.sibling;
      }
    }
    function vu(t, e) {
      if (e.subtreeFlags & 10256) for (e = e.child; e !== null; ) {
        var l = t, a = e, u = a.flags;
        switch (a.tag) {
          case 22:
            vu(l, a), u & 2048 && Kc(a.alternate, a);
            break;
          case 24:
            vu(l, a), u & 2048 && Jc(a.alternate, a);
            break;
          default:
            vu(l, a);
        }
        e = e.sibling;
      }
    }
    var gu = 8192;
    function Ta(t, e, l) {
      if (t.subtreeFlags & gu) for (t = t.child; t !== null; ) Hs(t, e, l), t = t.sibling;
    }
    function Hs(t, e, l) {
      switch (t.tag) {
        case 26:
          Ta(t, e, l), t.flags & gu && t.memoizedState !== null && Jy(l, Re, t.memoizedState, t.memoizedProps);
          break;
        case 5:
          Ta(t, e, l);
          break;
        case 3:
        case 4:
          var a = Re;
          Re = Vn(t.stateNode.containerInfo), Ta(t, e, l), Re = a;
          break;
        case 22:
          t.memoizedState === null && (a = t.alternate, a !== null && a.memoizedState !== null ? (a = gu, gu = 16777216, Ta(t, e, l), gu = a) : Ta(t, e, l));
          break;
        default:
          Ta(t, e, l);
      }
    }
    function Bs(t) {
      var e = t.alternate;
      if (e !== null && (t = e.child, t !== null)) {
        e.child = null;
        do
          e = t.sibling, t.sibling = null, t = e;
        while (t !== null);
      }
    }
    function pu(t) {
      var e = t.deletions;
      if ((t.flags & 16) !== 0) {
        if (e !== null) for (var l = 0; l < e.length; l++) {
          var a = e[l];
          Bt = a, Ys(a, t);
        }
        Bs(t);
      }
      if (t.subtreeFlags & 10256) for (t = t.child; t !== null; ) qs(t), t = t.sibling;
    }
    function qs(t) {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          pu(t), t.flags & 2048 && yl(9, t, t.return);
          break;
        case 3:
          pu(t);
          break;
        case 12:
          pu(t);
          break;
        case 22:
          var e = t.stateNode;
          t.memoizedState !== null && e._visibility & 2 && (t.return === null || t.return.tag !== 13) ? (e._visibility &= -3, Un(t)) : pu(t);
          break;
        default:
          pu(t);
      }
    }
    function Un(t) {
      var e = t.deletions;
      if ((t.flags & 16) !== 0) {
        if (e !== null) for (var l = 0; l < e.length; l++) {
          var a = e[l];
          Bt = a, Ys(a, t);
        }
        Bs(t);
      }
      for (t = t.child; t !== null; ) {
        switch (e = t, e.tag) {
          case 0:
          case 11:
          case 15:
            yl(8, e, e.return), Un(e);
            break;
          case 22:
            l = e.stateNode, l._visibility & 2 && (l._visibility &= -3, Un(e));
            break;
          default:
            Un(e);
        }
        t = t.sibling;
      }
    }
    function Ys(t, e) {
      for (; Bt !== null; ) {
        var l = Bt;
        switch (l.tag) {
          case 0:
          case 11:
          case 15:
            yl(8, l, e);
            break;
          case 23:
          case 22:
            if (l.memoizedState !== null && l.memoizedState.cachePool !== null) {
              var a = l.memoizedState.cachePool.pool;
              a != null && a.refCount++;
            }
            break;
          case 24:
            eu(l.memoizedState.cache);
        }
        if (a = l.child, a !== null) a.return = l, Bt = a;
        else t: for (l = t; Bt !== null; ) {
          a = Bt;
          var u = a.sibling, n = a.return;
          if (Ms(a), a === l) {
            Bt = null;
            break t;
          }
          if (u !== null) {
            u.return = n, Bt = u;
            break t;
          }
          Bt = n;
        }
      }
    }
    var cy = {
      getCacheForType: function(t) {
        var e = jt(Ct), l = e.data.get(t);
        return l === void 0 && (l = t(), e.data.set(t, l)), l;
      },
      cacheSignal: function() {
        return jt(Ct).controller.signal;
      }
    }, fy = typeof WeakMap == "function" ? WeakMap : Map, ft = 0, vt = null, tt = null, at = 0, st = 0, ie = null, vl = false, Aa = false, wc = false, We = 0, At = 0, gl = 0, wl = 0, $c = 0, ce = 0, _a = 0, Su = null, Ft = null, kc = false, xn = 0, Ls = 0, Nn = 1 / 0, Hn = null, pl = null, Nt = 0, Sl = null, Ra = null, Fe = 0, Wc = 0, Fc = null, js = null, bu = 0, Ic = null;
    function fe() {
      return (ft & 2) !== 0 && at !== 0 ? at & -at : X.T !== null ? uf() : to();
    }
    function Qs() {
      if (ce === 0) if ((at & 536870912) === 0 || nt) {
        var t = Gu;
        Gu <<= 1, (Gu & 3932160) === 0 && (Gu = 262144), ce = t;
      } else ce = 536870912;
      return t = ue.current, t !== null && (t.flags |= 32), ce;
    }
    function It(t, e, l) {
      (t === vt && (st === 2 || st === 9) || t.cancelPendingCommit !== null) && (Ma(t, 0), bl(t, at, ce, false)), Ga(t, l), ((ft & 2) === 0 || t !== vt) && (t === vt && ((ft & 2) === 0 && (wl |= l), At === 4 && bl(t, at, ce, false)), xe(t));
    }
    function Gs(t, e, l) {
      if ((ft & 6) !== 0) throw Error(o(327));
      var a = !l && (e & 127) === 0 && (e & t.expiredLanes) === 0 || Qa(t, e), u = a ? sy(t, e) : tf(t, e, true), n = a;
      do {
        if (u === 0) {
          Aa && !a && bl(t, e, 0, false);
          break;
        } else {
          if (l = t.current.alternate, n && !oy(l)) {
            u = tf(t, e, false), n = false;
            continue;
          }
          if (u === 2) {
            if (n = e, t.errorRecoveryDisabledLanes & n) var i = 0;
            else i = t.pendingLanes & -536870913, i = i !== 0 ? i : i & 536870912 ? 536870912 : 0;
            if (i !== 0) {
              e = i;
              t: {
                var f = t;
                u = Su;
                var d = f.current.memoizedState.isDehydrated;
                if (d && (Ma(f, i).flags |= 256), i = tf(f, i, false), i !== 2) {
                  if (wc && !d) {
                    f.errorRecoveryDisabledLanes |= n, wl |= n, u = 4;
                    break t;
                  }
                  n = Ft, Ft = u, n !== null && (Ft === null ? Ft = n : Ft.push.apply(Ft, n));
                }
                u = i;
              }
              if (n = false, u !== 2) continue;
            }
          }
          if (u === 1) {
            Ma(t, 0), bl(t, e, 0, true);
            break;
          }
          t: {
            switch (a = t, n = u, n) {
              case 0:
              case 1:
                throw Error(o(345));
              case 4:
                if ((e & 4194048) !== e) break;
              case 6:
                bl(a, e, ce, !vl);
                break t;
              case 2:
                Ft = null;
                break;
              case 3:
              case 5:
                break;
              default:
                throw Error(o(329));
            }
            if ((e & 62914560) === e && (u = xn + 300 - Pt(), 10 < u)) {
              if (bl(a, e, ce, !vl), Zu(a, 0, true) !== 0) break t;
              Fe = e, a.timeoutHandle = pd(Xs.bind(null, a, l, Ft, Hn, kc, e, ce, wl, _a, vl, n, "Throttled", -0, 0), u);
              break t;
            }
            Xs(a, l, Ft, Hn, kc, e, ce, wl, _a, vl, n, null, -0, 0);
          }
        }
        break;
      } while (true);
      xe(t);
    }
    function Xs(t, e, l, a, u, n, i, f, d, z, M, U, T, A) {
      if (t.timeoutHandle = -1, U = e.subtreeFlags, U & 8192 || (U & 16785408) === 16785408) {
        U = {
          stylesheets: null,
          count: 0,
          imgCount: 0,
          imgBytes: 0,
          suspenseyImages: [],
          waitingForImages: true,
          waitingForViewTransition: false,
          unsuspend: qe
        }, Hs(e, n, U);
        var j = (n & 62914560) === n ? xn - Pt() : (n & 4194048) === n ? Ls - Pt() : 0;
        if (j = wy(U, j), j !== null) {
          Fe = n, t.cancelPendingCommit = j(Ws.bind(null, t, e, n, l, a, u, i, f, d, M, U, null, T, A)), bl(t, n, i, !z);
          return;
        }
      }
      Ws(t, e, n, l, a, u, i, f, d);
    }
    function oy(t) {
      for (var e = t; ; ) {
        var l = e.tag;
        if ((l === 0 || l === 11 || l === 15) && e.flags & 16384 && (l = e.updateQueue, l !== null && (l = l.stores, l !== null))) for (var a = 0; a < l.length; a++) {
          var u = l[a], n = u.getSnapshot;
          u = u.value;
          try {
            if (!le(n(), u)) return false;
          } catch {
            return false;
          }
        }
        if (l = e.child, e.subtreeFlags & 16384 && l !== null) l.return = e, e = l;
        else {
          if (e === t) break;
          for (; e.sibling === null; ) {
            if (e.return === null || e.return === t) return true;
            e = e.return;
          }
          e.sibling.return = e.return, e = e.sibling;
        }
      }
      return true;
    }
    function bl(t, e, l, a) {
      e &= ~$c, e &= ~wl, t.suspendedLanes |= e, t.pingedLanes &= ~e, a && (t.warmLanes |= e), a = t.expirationTimes;
      for (var u = e; 0 < u; ) {
        var n = 31 - ee(u), i = 1 << n;
        a[n] = -1, u &= ~i;
      }
      l !== 0 && Ff(t, l, e);
    }
    function Bn() {
      return (ft & 6) === 0 ? (Eu(0), false) : true;
    }
    function Pc() {
      if (tt !== null) {
        if (st === 0) var t = tt.return;
        else t = tt, Qe = Ll = null, yc(t), ga = null, au = 0, t = tt;
        for (; t !== null; ) Ss(t.alternate, t), t = t.return;
        tt = null;
      }
    }
    function Ma(t, e) {
      var l = t.timeoutHandle;
      l !== -1 && (t.timeoutHandle = -1, Cy(l)), l = t.cancelPendingCommit, l !== null && (t.cancelPendingCommit = null, l()), Fe = 0, Pc(), vt = t, tt = l = Le(t.current, null), at = e, st = 0, ie = null, vl = false, Aa = Qa(t, e), wc = false, _a = ce = $c = wl = gl = At = 0, Ft = Su = null, kc = false, (e & 8) !== 0 && (e |= e & 32);
      var a = t.entangledLanes;
      if (a !== 0) for (t = t.entanglements, a &= e; 0 < a; ) {
        var u = 31 - ee(a), n = 1 << u;
        e |= t[u], a &= ~n;
      }
      return We = e, en(), l;
    }
    function Zs(t, e) {
      k = null, X.H = su, e === va || e === rn ? (e = nr(), st = 3) : e === ac ? (e = nr(), st = 4) : st = e === Uc ? 8 : e !== null && typeof e == "object" && typeof e.then == "function" ? 6 : 1, ie = e, tt === null && (At = 1, An(t, me(e, t.current)));
    }
    function Vs() {
      var t = ue.current;
      return t === null ? true : (at & 4194048) === at ? pe === null : (at & 62914560) === at || (at & 536870912) !== 0 ? t === pe : false;
    }
    function Ks() {
      var t = X.H;
      return X.H = su, t === null ? su : t;
    }
    function Js() {
      var t = X.A;
      return X.A = cy, t;
    }
    function qn() {
      At = 4, vl || (at & 4194048) !== at && ue.current !== null || (Aa = true), (gl & 134217727) === 0 && (wl & 134217727) === 0 || vt === null || bl(vt, at, ce, false);
    }
    function tf(t, e, l) {
      var a = ft;
      ft |= 2;
      var u = Ks(), n = Js();
      (vt !== t || at !== e) && (Hn = null, Ma(t, e)), e = false;
      var i = At;
      t: do
        try {
          if (st !== 0 && tt !== null) {
            var f = tt, d = ie;
            switch (st) {
              case 8:
                Pc(), i = 6;
                break t;
              case 3:
              case 2:
              case 9:
              case 6:
                ue.current === null && (e = true);
                var z = st;
                if (st = 0, ie = null, Oa(t, f, d, z), l && Aa) {
                  i = 0;
                  break t;
                }
                break;
              default:
                z = st, st = 0, ie = null, Oa(t, f, d, z);
            }
          }
          ry(), i = At;
          break;
        } catch (M) {
          Zs(t, M);
        }
      while (true);
      return e && t.shellSuspendCounter++, Qe = Ll = null, ft = a, X.H = u, X.A = n, tt === null && (vt = null, at = 0, en()), i;
    }
    function ry() {
      for (; tt !== null; ) ws(tt);
    }
    function sy(t, e) {
      var l = ft;
      ft |= 2;
      var a = Ks(), u = Js();
      vt !== t || at !== e ? (Hn = null, Nn = Pt() + 500, Ma(t, e)) : Aa = Qa(t, e);
      t: do
        try {
          if (st !== 0 && tt !== null) {
            e = tt;
            var n = ie;
            e: switch (st) {
              case 1:
                st = 0, ie = null, Oa(t, e, n, 1);
                break;
              case 2:
              case 9:
                if (ar(n)) {
                  st = 0, ie = null, $s(e);
                  break;
                }
                e = function() {
                  st !== 2 && st !== 9 || vt !== t || (st = 7), xe(t);
                }, n.then(e, e);
                break t;
              case 3:
                st = 7;
                break t;
              case 4:
                st = 5;
                break t;
              case 7:
                ar(n) ? (st = 0, ie = null, $s(e)) : (st = 0, ie = null, Oa(t, e, n, 7));
                break;
              case 5:
                var i = null;
                switch (tt.tag) {
                  case 26:
                    i = tt.memoizedState;
                  case 5:
                  case 27:
                    var f = tt;
                    if (i ? Nd(i) : f.stateNode.complete) {
                      st = 0, ie = null;
                      var d = f.sibling;
                      if (d !== null) tt = d;
                      else {
                        var z = f.return;
                        z !== null ? (tt = z, Yn(z)) : tt = null;
                      }
                      break e;
                    }
                }
                st = 0, ie = null, Oa(t, e, n, 5);
                break;
              case 6:
                st = 0, ie = null, Oa(t, e, n, 6);
                break;
              case 8:
                Pc(), At = 6;
                break t;
              default:
                throw Error(o(462));
            }
          }
          dy();
          break;
        } catch (M) {
          Zs(t, M);
        }
      while (true);
      return Qe = Ll = null, X.H = a, X.A = u, ft = l, tt !== null ? 0 : (vt = null, at = 0, en(), At);
    }
    function dy() {
      for (; tt !== null && !Bh(); ) ws(tt);
    }
    function ws(t) {
      var e = gs(t.alternate, t, We);
      t.memoizedProps = t.pendingProps, e === null ? Yn(t) : tt = e;
    }
    function $s(t) {
      var e = t, l = e.alternate;
      switch (e.tag) {
        case 15:
        case 0:
          e = ss(l, e, e.pendingProps, e.type, void 0, at);
          break;
        case 11:
          e = ss(l, e, e.pendingProps, e.type.render, e.ref, at);
          break;
        case 5:
          yc(e);
        default:
          Ss(l, e), e = tt = Jo(e, We), e = gs(l, e, We);
      }
      t.memoizedProps = t.pendingProps, e === null ? Yn(t) : tt = e;
    }
    function Oa(t, e, l, a) {
      Qe = Ll = null, yc(e), ga = null, au = 0;
      var u = e.return;
      try {
        if (ty(t, u, e, l, at)) {
          At = 1, An(t, me(l, t.current)), tt = null;
          return;
        }
      } catch (n) {
        if (u !== null) throw tt = u, n;
        At = 1, An(t, me(l, t.current)), tt = null;
        return;
      }
      e.flags & 32768 ? (nt || a === 1 ? t = true : Aa || (at & 536870912) !== 0 ? t = false : (vl = t = true, (a === 2 || a === 9 || a === 3 || a === 6) && (a = ue.current, a !== null && a.tag === 13 && (a.flags |= 16384))), ks(e, t)) : Yn(e);
    }
    function Yn(t) {
      var e = t;
      do {
        if ((e.flags & 32768) !== 0) {
          ks(e, vl);
          return;
        }
        t = e.return;
        var l = ay(e.alternate, e, We);
        if (l !== null) {
          tt = l;
          return;
        }
        if (e = e.sibling, e !== null) {
          tt = e;
          return;
        }
        tt = e = t;
      } while (e !== null);
      At === 0 && (At = 5);
    }
    function ks(t, e) {
      do {
        var l = uy(t.alternate, t);
        if (l !== null) {
          l.flags &= 32767, tt = l;
          return;
        }
        if (l = t.return, l !== null && (l.flags |= 32768, l.subtreeFlags = 0, l.deletions = null), !e && (t = t.sibling, t !== null)) {
          tt = t;
          return;
        }
        tt = t = l;
      } while (t !== null);
      At = 6, tt = null;
    }
    function Ws(t, e, l, a, u, n, i, f, d) {
      t.cancelPendingCommit = null;
      do
        Ln();
      while (Nt !== 0);
      if ((ft & 6) !== 0) throw Error(o(327));
      if (e !== null) {
        if (e === t.current) throw Error(o(177));
        if (n = e.lanes | e.childLanes, n |= Xi, Kh(t, l, n, i, f, d), t === vt && (tt = vt = null, at = 0), Ra = e, Sl = t, Fe = l, Wc = n, Fc = u, js = a, (e.subtreeFlags & 10256) !== 0 || (e.flags & 10256) !== 0 ? (t.callbackNode = null, t.callbackPriority = 0, vy(ju, function() {
          return ed(), null;
        })) : (t.callbackNode = null, t.callbackPriority = 0), a = (e.flags & 13878) !== 0, (e.subtreeFlags & 13878) !== 0 || a) {
          a = X.T, X.T = null, u = lt.p, lt.p = 2, i = ft, ft |= 4;
          try {
            ny(t, e, l);
          } finally {
            ft = i, lt.p = u, X.T = a;
          }
        }
        Nt = 1, Fs(), Is(), Ps();
      }
    }
    function Fs() {
      if (Nt === 1) {
        Nt = 0;
        var t = Sl, e = Ra, l = (e.flags & 13878) !== 0;
        if ((e.subtreeFlags & 13878) !== 0 || l) {
          l = X.T, X.T = null;
          var a = lt.p;
          lt.p = 2;
          var u = ft;
          ft |= 4;
          try {
            Us(e, t);
            var n = hf, i = Yo(t.containerInfo), f = n.focusedElem, d = n.selectionRange;
            if (i !== f && f && f.ownerDocument && qo(f.ownerDocument.documentElement, f)) {
              if (d !== null && Yi(f)) {
                var z = d.start, M = d.end;
                if (M === void 0 && (M = z), "selectionStart" in f) f.selectionStart = z, f.selectionEnd = Math.min(M, f.value.length);
                else {
                  var U = f.ownerDocument || document, T = U && U.defaultView || window;
                  if (T.getSelection) {
                    var A = T.getSelection(), j = f.textContent.length, J = Math.min(d.start, j), yt = d.end === void 0 ? J : Math.min(d.end, j);
                    !A.extend && J > yt && (i = yt, yt = J, J = i);
                    var p = Bo(f, J), m = Bo(f, yt);
                    if (p && m && (A.rangeCount !== 1 || A.anchorNode !== p.node || A.anchorOffset !== p.offset || A.focusNode !== m.node || A.focusOffset !== m.offset)) {
                      var E = U.createRange();
                      E.setStart(p.node, p.offset), A.removeAllRanges(), J > yt ? (A.addRange(E), A.extend(m.node, m.offset)) : (E.setEnd(m.node, m.offset), A.addRange(E));
                    }
                  }
                }
              }
              for (U = [], A = f; A = A.parentNode; ) A.nodeType === 1 && U.push({
                element: A,
                left: A.scrollLeft,
                top: A.scrollTop
              });
              for (typeof f.focus == "function" && f.focus(), f = 0; f < U.length; f++) {
                var D = U[f];
                D.element.scrollLeft = D.left, D.element.scrollTop = D.top;
              }
            }
            Wn = !!df, hf = df = null;
          } finally {
            ft = u, lt.p = a, X.T = l;
          }
        }
        t.current = e, Nt = 2;
      }
    }
    function Is() {
      if (Nt === 2) {
        Nt = 0;
        var t = Sl, e = Ra, l = (e.flags & 8772) !== 0;
        if ((e.subtreeFlags & 8772) !== 0 || l) {
          l = X.T, X.T = null;
          var a = lt.p;
          lt.p = 2;
          var u = ft;
          ft |= 4;
          try {
            Rs(t, e.alternate, e);
          } finally {
            ft = u, lt.p = a, X.T = l;
          }
        }
        Nt = 3;
      }
    }
    function Ps() {
      if (Nt === 4 || Nt === 3) {
        Nt = 0, qh();
        var t = Sl, e = Ra, l = Fe, a = js;
        (e.subtreeFlags & 10256) !== 0 || (e.flags & 10256) !== 0 ? Nt = 5 : (Nt = 0, Ra = Sl = null, td(t, t.pendingLanes));
        var u = t.pendingLanes;
        if (u === 0 && (pl = null), pi(l), e = e.stateNode, te && typeof te.onCommitFiberRoot == "function") try {
          te.onCommitFiberRoot(ja, e, void 0, (e.current.flags & 128) === 128);
        } catch {
        }
        if (a !== null) {
          e = X.T, u = lt.p, lt.p = 2, X.T = null;
          try {
            for (var n = t.onRecoverableError, i = 0; i < a.length; i++) {
              var f = a[i];
              n(f.value, {
                componentStack: f.stack
              });
            }
          } finally {
            X.T = e, lt.p = u;
          }
        }
        (Fe & 3) !== 0 && Ln(), xe(t), u = t.pendingLanes, (l & 261930) !== 0 && (u & 42) !== 0 ? t === Ic ? bu++ : (bu = 0, Ic = t) : bu = 0, Eu(0);
      }
    }
    function td(t, e) {
      (t.pooledCacheLanes &= e) === 0 && (e = t.pooledCache, e != null && (t.pooledCache = null, eu(e)));
    }
    function Ln() {
      return Fs(), Is(), Ps(), ed();
    }
    function ed() {
      if (Nt !== 5) return false;
      var t = Sl, e = Wc;
      Wc = 0;
      var l = pi(Fe), a = X.T, u = lt.p;
      try {
        lt.p = 32 > l ? 32 : l, X.T = null, l = Fc, Fc = null;
        var n = Sl, i = Fe;
        if (Nt = 0, Ra = Sl = null, Fe = 0, (ft & 6) !== 0) throw Error(o(331));
        var f = ft;
        if (ft |= 4, qs(n.current), Ns(n, n.current, i, l), ft = f, Eu(0, false), te && typeof te.onPostCommitFiberRoot == "function") try {
          te.onPostCommitFiberRoot(ja, n);
        } catch {
        }
        return true;
      } finally {
        lt.p = u, X.T = a, td(t, e);
      }
    }
    function ld(t, e, l) {
      e = me(l, e), e = Dc(t.stateNode, e, 2), t = dl(t, e, 2), t !== null && (Ga(t, 2), xe(t));
    }
    function dt(t, e, l) {
      if (t.tag === 3) ld(t, t, l);
      else for (; e !== null; ) {
        if (e.tag === 3) {
          ld(e, t, l);
          break;
        } else if (e.tag === 1) {
          var a = e.stateNode;
          if (typeof e.type.getDerivedStateFromError == "function" || typeof a.componentDidCatch == "function" && (pl === null || !pl.has(a))) {
            t = me(l, t), l = as(2), a = dl(e, l, 2), a !== null && (us(l, a, e, t), Ga(a, 2), xe(a));
            break;
          }
        }
        e = e.return;
      }
    }
    function ef(t, e, l) {
      var a = t.pingCache;
      if (a === null) {
        a = t.pingCache = new fy();
        var u = /* @__PURE__ */ new Set();
        a.set(e, u);
      } else u = a.get(e), u === void 0 && (u = /* @__PURE__ */ new Set(), a.set(e, u));
      u.has(l) || (wc = true, u.add(l), t = hy.bind(null, t, e, l), e.then(t, t));
    }
    function hy(t, e, l) {
      var a = t.pingCache;
      a !== null && a.delete(e), t.pingedLanes |= t.suspendedLanes & l, t.warmLanes &= ~l, vt === t && (at & l) === l && (At === 4 || At === 3 && (at & 62914560) === at && 300 > Pt() - xn ? (ft & 2) === 0 && Ma(t, 0) : $c |= l, _a === at && (_a = 0)), xe(t);
    }
    function ad(t, e) {
      e === 0 && (e = Wf()), t = Bl(t, e), t !== null && (Ga(t, e), xe(t));
    }
    function my(t) {
      var e = t.memoizedState, l = 0;
      e !== null && (l = e.retryLane), ad(t, l);
    }
    function yy(t, e) {
      var l = 0;
      switch (t.tag) {
        case 31:
        case 13:
          var a = t.stateNode, u = t.memoizedState;
          u !== null && (l = u.retryLane);
          break;
        case 19:
          a = t.stateNode;
          break;
        case 22:
          a = t.stateNode._retryCache;
          break;
        default:
          throw Error(o(314));
      }
      a !== null && a.delete(e), ad(t, l);
    }
    function vy(t, e) {
      return mi(t, e);
    }
    var jn = null, Ca = null, lf = false, Qn = false, af = false, El = 0;
    function xe(t) {
      t !== Ca && t.next === null && (Ca === null ? jn = Ca = t : Ca = Ca.next = t), Qn = true, lf || (lf = true, py());
    }
    function Eu(t, e) {
      if (!af && Qn) {
        af = true;
        do
          for (var l = false, a = jn; a !== null; ) {
            if (t !== 0) {
              var u = a.pendingLanes;
              if (u === 0) var n = 0;
              else {
                var i = a.suspendedLanes, f = a.pingedLanes;
                n = (1 << 31 - ee(42 | t) + 1) - 1, n &= u & ~(i & ~f), n = n & 201326741 ? n & 201326741 | 1 : n ? n | 2 : 0;
              }
              n !== 0 && (l = true, cd(a, n));
            } else n = at, n = Zu(a, a === vt ? n : 0, a.cancelPendingCommit !== null || a.timeoutHandle !== -1), (n & 3) === 0 || Qa(a, n) || (l = true, cd(a, n));
            a = a.next;
          }
        while (l);
        af = false;
      }
    }
    function gy() {
      ud();
    }
    function ud() {
      Qn = lf = false;
      var t = 0;
      El !== 0 && Oy() && (t = El);
      for (var e = Pt(), l = null, a = jn; a !== null; ) {
        var u = a.next, n = nd(a, e);
        n === 0 ? (a.next = null, l === null ? jn = u : l.next = u, u === null && (Ca = l)) : (l = a, (t !== 0 || (n & 3) !== 0) && (Qn = true)), a = u;
      }
      Nt !== 0 && Nt !== 5 || Eu(t), El !== 0 && (El = 0);
    }
    function nd(t, e) {
      for (var l = t.suspendedLanes, a = t.pingedLanes, u = t.expirationTimes, n = t.pendingLanes & -62914561; 0 < n; ) {
        var i = 31 - ee(n), f = 1 << i, d = u[i];
        d === -1 ? ((f & l) === 0 || (f & a) !== 0) && (u[i] = Vh(f, e)) : d <= e && (t.expiredLanes |= f), n &= ~f;
      }
      if (e = vt, l = at, l = Zu(t, t === e ? l : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), a = t.callbackNode, l === 0 || t === e && (st === 2 || st === 9) || t.cancelPendingCommit !== null) return a !== null && a !== null && yi(a), t.callbackNode = null, t.callbackPriority = 0;
      if ((l & 3) === 0 || Qa(t, l)) {
        if (e = l & -l, e === t.callbackPriority) return e;
        switch (a !== null && yi(a), pi(l)) {
          case 2:
          case 8:
            l = $f;
            break;
          case 32:
            l = ju;
            break;
          case 268435456:
            l = kf;
            break;
          default:
            l = ju;
        }
        return a = id.bind(null, t), l = mi(l, a), t.callbackPriority = e, t.callbackNode = l, e;
      }
      return a !== null && a !== null && yi(a), t.callbackPriority = 2, t.callbackNode = null, 2;
    }
    function id(t, e) {
      if (Nt !== 0 && Nt !== 5) return t.callbackNode = null, t.callbackPriority = 0, null;
      var l = t.callbackNode;
      if (Ln() && t.callbackNode !== l) return null;
      var a = at;
      return a = Zu(t, t === vt ? a : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), a === 0 ? null : (Gs(t, a, e), nd(t, Pt()), t.callbackNode != null && t.callbackNode === l ? id.bind(null, t) : null);
    }
    function cd(t, e) {
      if (Ln()) return null;
      Gs(t, e, true);
    }
    function py() {
      Dy(function() {
        (ft & 6) !== 0 ? mi(wf, gy) : ud();
      });
    }
    function uf() {
      if (El === 0) {
        var t = ma;
        t === 0 && (t = Qu, Qu <<= 1, (Qu & 261888) === 0 && (Qu = 256)), El = t;
      }
      return El;
    }
    function fd(t) {
      return t == null || typeof t == "symbol" || typeof t == "boolean" ? null : typeof t == "function" ? t : wu("" + t);
    }
    function od(t, e) {
      var l = e.ownerDocument.createElement("input");
      return l.name = e.name, l.value = e.value, t.id && l.setAttribute("form", t.id), e.parentNode.insertBefore(l, e), t = new FormData(t), l.parentNode.removeChild(l), t;
    }
    function Sy(t, e, l, a, u) {
      if (e === "submit" && l && l.stateNode === u) {
        var n = fd((u[Jt] || null).action), i = a.submitter;
        i && (e = (e = i[Jt] || null) ? fd(e.formAction) : i.getAttribute("formAction"), e !== null && (n = e, i = null));
        var f = new Fu("action", "action", null, a, u);
        t.push({
          event: f,
          listeners: [
            {
              instance: null,
              listener: function() {
                if (a.defaultPrevented) {
                  if (El !== 0) {
                    var d = i ? od(u, i) : new FormData(u);
                    Ac(l, {
                      pending: true,
                      data: d,
                      method: u.method,
                      action: n
                    }, null, d);
                  }
                } else typeof n == "function" && (f.preventDefault(), d = i ? od(u, i) : new FormData(u), Ac(l, {
                  pending: true,
                  data: d,
                  method: u.method,
                  action: n
                }, n, d));
              },
              currentTarget: u
            }
          ]
        });
      }
    }
    for (var nf = 0; nf < Gi.length; nf++) {
      var cf = Gi[nf], by = cf.toLowerCase(), Ey = cf[0].toUpperCase() + cf.slice(1);
      _e(by, "on" + Ey);
    }
    _e(Qo, "onAnimationEnd"), _e(Go, "onAnimationIteration"), _e(Xo, "onAnimationStart"), _e("dblclick", "onDoubleClick"), _e("focusin", "onFocus"), _e("focusout", "onBlur"), _e(Ym, "onTransitionRun"), _e(Lm, "onTransitionStart"), _e(jm, "onTransitionCancel"), _e(Zo, "onTransitionEnd"), ta("onMouseEnter", [
      "mouseout",
      "mouseover"
    ]), ta("onMouseLeave", [
      "mouseout",
      "mouseover"
    ]), ta("onPointerEnter", [
      "pointerout",
      "pointerover"
    ]), ta("onPointerLeave", [
      "pointerout",
      "pointerover"
    ]), Ul("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), Ul("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), Ul("onBeforeInput", [
      "compositionend",
      "keypress",
      "textInput",
      "paste"
    ]), Ul("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), Ul("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), Ul("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var zu = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), zy = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(zu));
    function rd(t, e) {
      e = (e & 4) !== 0;
      for (var l = 0; l < t.length; l++) {
        var a = t[l], u = a.event;
        a = a.listeners;
        t: {
          var n = void 0;
          if (e) for (var i = a.length - 1; 0 <= i; i--) {
            var f = a[i], d = f.instance, z = f.currentTarget;
            if (f = f.listener, d !== n && u.isPropagationStopped()) break t;
            n = f, u.currentTarget = z;
            try {
              n(u);
            } catch (M) {
              tn(M);
            }
            u.currentTarget = null, n = d;
          }
          else for (i = 0; i < a.length; i++) {
            if (f = a[i], d = f.instance, z = f.currentTarget, f = f.listener, d !== n && u.isPropagationStopped()) break t;
            n = f, u.currentTarget = z;
            try {
              n(u);
            } catch (M) {
              tn(M);
            }
            u.currentTarget = null, n = d;
          }
        }
      }
    }
    function et(t, e) {
      var l = e[Si];
      l === void 0 && (l = e[Si] = /* @__PURE__ */ new Set());
      var a = t + "__bubble";
      l.has(a) || (sd(e, t, 2, false), l.add(a));
    }
    function ff(t, e, l) {
      var a = 0;
      e && (a |= 4), sd(l, t, a, e);
    }
    var Gn = "_reactListening" + Math.random().toString(36).slice(2);
    function of(t) {
      if (!t[Gn]) {
        t[Gn] = true, ao.forEach(function(l) {
          l !== "selectionchange" && (zy.has(l) || ff(l, false, t), ff(l, true, t));
        });
        var e = t.nodeType === 9 ? t : t.ownerDocument;
        e === null || e[Gn] || (e[Gn] = true, ff("selectionchange", false, e));
      }
    }
    function sd(t, e, l, a) {
      switch (Qd(e)) {
        case 2:
          var u = Wy;
          break;
        case 8:
          u = Fy;
          break;
        default:
          u = Af;
      }
      l = u.bind(null, e, l, t), u = void 0, !Oi || e !== "touchstart" && e !== "touchmove" && e !== "wheel" || (u = true), a ? u !== void 0 ? t.addEventListener(e, l, {
        capture: true,
        passive: u
      }) : t.addEventListener(e, l, true) : u !== void 0 ? t.addEventListener(e, l, {
        passive: u
      }) : t.addEventListener(e, l, false);
    }
    function rf(t, e, l, a, u) {
      var n = a;
      if ((e & 1) === 0 && (e & 2) === 0 && a !== null) t: for (; ; ) {
        if (a === null) return;
        var i = a.tag;
        if (i === 3 || i === 4) {
          var f = a.stateNode.containerInfo;
          if (f === u) break;
          if (i === 4) for (i = a.return; i !== null; ) {
            var d = i.tag;
            if ((d === 3 || d === 4) && i.stateNode.containerInfo === u) return;
            i = i.return;
          }
          for (; f !== null; ) {
            if (i = Fl(f), i === null) return;
            if (d = i.tag, d === 5 || d === 6 || d === 26 || d === 27) {
              a = n = i;
              continue t;
            }
            f = f.parentNode;
          }
        }
        a = a.return;
      }
      vo(function() {
        var z = n, M = Ri(l), U = [];
        t: {
          var T = Vo.get(t);
          if (T !== void 0) {
            var A = Fu, j = t;
            switch (t) {
              case "keypress":
                if (ku(l) === 0) break t;
              case "keydown":
              case "keyup":
                A = ym;
                break;
              case "focusin":
                j = "focus", A = xi;
                break;
              case "focusout":
                j = "blur", A = xi;
                break;
              case "beforeblur":
              case "afterblur":
                A = xi;
                break;
              case "click":
                if (l.button === 2) break t;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                A = So;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                A = am;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                A = pm;
                break;
              case Qo:
              case Go:
              case Xo:
                A = im;
                break;
              case Zo:
                A = bm;
                break;
              case "scroll":
              case "scrollend":
                A = em;
                break;
              case "wheel":
                A = zm;
                break;
              case "copy":
              case "cut":
              case "paste":
                A = fm;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                A = Eo;
                break;
              case "toggle":
              case "beforetoggle":
                A = Am;
            }
            var J = (e & 4) !== 0, yt = !J && (t === "scroll" || t === "scrollend"), p = J ? T !== null ? T + "Capture" : null : T;
            J = [];
            for (var m = z, E; m !== null; ) {
              var D = m;
              if (E = D.stateNode, D = D.tag, D !== 5 && D !== 26 && D !== 27 || E === null || p === null || (D = Va(m, p), D != null && J.push(Tu(m, D, E))), yt) break;
              m = m.return;
            }
            0 < J.length && (T = new A(T, j, null, l, M), U.push({
              event: T,
              listeners: J
            }));
          }
        }
        if ((e & 7) === 0) {
          t: {
            if (T = t === "mouseover" || t === "pointerover", A = t === "mouseout" || t === "pointerout", T && l !== _i && (j = l.relatedTarget || l.fromElement) && (Fl(j) || j[Wl])) break t;
            if ((A || T) && (T = M.window === M ? M : (T = M.ownerDocument) ? T.defaultView || T.parentWindow : window, A ? (j = l.relatedTarget || l.toElement, A = z, j = j ? Fl(j) : null, j !== null && (yt = y(j), J = j.tag, j !== yt || J !== 5 && J !== 27 && J !== 6) && (j = null)) : (A = null, j = z), A !== j)) {
              if (J = So, D = "onMouseLeave", p = "onMouseEnter", m = "mouse", (t === "pointerout" || t === "pointerover") && (J = Eo, D = "onPointerLeave", p = "onPointerEnter", m = "pointer"), yt = A == null ? T : Za(A), E = j == null ? T : Za(j), T = new J(D, m + "leave", A, l, M), T.target = yt, T.relatedTarget = E, D = null, Fl(M) === z && (J = new J(p, m + "enter", j, l, M), J.target = E, J.relatedTarget = yt, D = J), yt = D, A && j) e: {
                for (J = Ty, p = A, m = j, E = 0, D = p; D; D = J(D)) E++;
                D = 0;
                for (var V = m; V; V = J(V)) D++;
                for (; 0 < E - D; ) p = J(p), E--;
                for (; 0 < D - E; ) m = J(m), D--;
                for (; E--; ) {
                  if (p === m || m !== null && p === m.alternate) {
                    J = p;
                    break e;
                  }
                  p = J(p), m = J(m);
                }
                J = null;
              }
              else J = null;
              A !== null && dd(U, T, A, J, false), j !== null && yt !== null && dd(U, yt, j, J, true);
            }
          }
          t: {
            if (T = z ? Za(z) : window, A = T.nodeName && T.nodeName.toLowerCase(), A === "select" || A === "input" && T.type === "file") var it = Co;
            else if (Mo(T)) if (Do) it = Hm;
            else {
              it = xm;
              var Q = Um;
            }
            else A = T.nodeName, !A || A.toLowerCase() !== "input" || T.type !== "checkbox" && T.type !== "radio" ? z && Ai(z.elementType) && (it = Co) : it = Nm;
            if (it && (it = it(t, z))) {
              Oo(U, it, l, M);
              break t;
            }
            Q && Q(t, T, z), t === "focusout" && z && T.type === "number" && z.memoizedProps.value != null && Ti(T, "number", T.value);
          }
          switch (Q = z ? Za(z) : window, t) {
            case "focusin":
              (Mo(Q) || Q.contentEditable === "true") && (ia = Q, Li = z, Ia = null);
              break;
            case "focusout":
              Ia = Li = ia = null;
              break;
            case "mousedown":
              ji = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              ji = false, Lo(U, l, M);
              break;
            case "selectionchange":
              if (qm) break;
            case "keydown":
            case "keyup":
              Lo(U, l, M);
          }
          var W;
          if (Hi) t: {
            switch (t) {
              case "compositionstart":
                var ut = "onCompositionStart";
                break t;
              case "compositionend":
                ut = "onCompositionEnd";
                break t;
              case "compositionupdate":
                ut = "onCompositionUpdate";
                break t;
            }
            ut = void 0;
          }
          else na ? _o(t, l) && (ut = "onCompositionEnd") : t === "keydown" && l.keyCode === 229 && (ut = "onCompositionStart");
          ut && (zo && l.locale !== "ko" && (na || ut !== "onCompositionStart" ? ut === "onCompositionEnd" && na && (W = go()) : (nl = M, Ci = "value" in nl ? nl.value : nl.textContent, na = true)), Q = Xn(z, ut), 0 < Q.length && (ut = new bo(ut, t, null, l, M), U.push({
            event: ut,
            listeners: Q
          }), W ? ut.data = W : (W = Ro(l), W !== null && (ut.data = W)))), (W = Rm ? Mm(t, l) : Om(t, l)) && (ut = Xn(z, "onBeforeInput"), 0 < ut.length && (Q = new bo("onBeforeInput", "beforeinput", null, l, M), U.push({
            event: Q,
            listeners: ut
          }), Q.data = W)), Sy(U, t, z, l, M);
        }
        rd(U, e);
      });
    }
    function Tu(t, e, l) {
      return {
        instance: t,
        listener: e,
        currentTarget: l
      };
    }
    function Xn(t, e) {
      for (var l = e + "Capture", a = []; t !== null; ) {
        var u = t, n = u.stateNode;
        if (u = u.tag, u !== 5 && u !== 26 && u !== 27 || n === null || (u = Va(t, l), u != null && a.unshift(Tu(t, u, n)), u = Va(t, e), u != null && a.push(Tu(t, u, n))), t.tag === 3) return a;
        t = t.return;
      }
      return [];
    }
    function Ty(t) {
      if (t === null) return null;
      do
        t = t.return;
      while (t && t.tag !== 5 && t.tag !== 27);
      return t || null;
    }
    function dd(t, e, l, a, u) {
      for (var n = e._reactName, i = []; l !== null && l !== a; ) {
        var f = l, d = f.alternate, z = f.stateNode;
        if (f = f.tag, d !== null && d === a) break;
        f !== 5 && f !== 26 && f !== 27 || z === null || (d = z, u ? (z = Va(l, n), z != null && i.unshift(Tu(l, z, d))) : u || (z = Va(l, n), z != null && i.push(Tu(l, z, d)))), l = l.return;
      }
      i.length !== 0 && t.push({
        event: e,
        listeners: i
      });
    }
    var Ay = /\r\n?/g, _y = /\u0000|\uFFFD/g;
    function hd(t) {
      return (typeof t == "string" ? t : "" + t).replace(Ay, `
`).replace(_y, "");
    }
    function md(t, e) {
      return e = hd(e), hd(t) === e;
    }
    function mt(t, e, l, a, u, n) {
      switch (l) {
        case "children":
          typeof a == "string" ? e === "body" || e === "textarea" && a === "" || la(t, a) : (typeof a == "number" || typeof a == "bigint") && e !== "body" && la(t, "" + a);
          break;
        case "className":
          Ku(t, "class", a);
          break;
        case "tabIndex":
          Ku(t, "tabindex", a);
          break;
        case "dir":
        case "role":
        case "viewBox":
        case "width":
        case "height":
          Ku(t, l, a);
          break;
        case "style":
          mo(t, a, n);
          break;
        case "data":
          if (e !== "object") {
            Ku(t, "data", a);
            break;
          }
        case "src":
        case "href":
          if (a === "" && (e !== "a" || l !== "href")) {
            t.removeAttribute(l);
            break;
          }
          if (a == null || typeof a == "function" || typeof a == "symbol" || typeof a == "boolean") {
            t.removeAttribute(l);
            break;
          }
          a = wu("" + a), t.setAttribute(l, a);
          break;
        case "action":
        case "formAction":
          if (typeof a == "function") {
            t.setAttribute(l, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
            break;
          } else typeof n == "function" && (l === "formAction" ? (e !== "input" && mt(t, e, "name", u.name, u, null), mt(t, e, "formEncType", u.formEncType, u, null), mt(t, e, "formMethod", u.formMethod, u, null), mt(t, e, "formTarget", u.formTarget, u, null)) : (mt(t, e, "encType", u.encType, u, null), mt(t, e, "method", u.method, u, null), mt(t, e, "target", u.target, u, null)));
          if (a == null || typeof a == "symbol" || typeof a == "boolean") {
            t.removeAttribute(l);
            break;
          }
          a = wu("" + a), t.setAttribute(l, a);
          break;
        case "onClick":
          a != null && (t.onclick = qe);
          break;
        case "onScroll":
          a != null && et("scroll", t);
          break;
        case "onScrollEnd":
          a != null && et("scrollend", t);
          break;
        case "dangerouslySetInnerHTML":
          if (a != null) {
            if (typeof a != "object" || !("__html" in a)) throw Error(o(61));
            if (l = a.__html, l != null) {
              if (u.children != null) throw Error(o(60));
              t.innerHTML = l;
            }
          }
          break;
        case "multiple":
          t.multiple = a && typeof a != "function" && typeof a != "symbol";
          break;
        case "muted":
          t.muted = a && typeof a != "function" && typeof a != "symbol";
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "defaultValue":
        case "defaultChecked":
        case "innerHTML":
        case "ref":
          break;
        case "autoFocus":
          break;
        case "xlinkHref":
          if (a == null || typeof a == "function" || typeof a == "boolean" || typeof a == "symbol") {
            t.removeAttribute("xlink:href");
            break;
          }
          l = wu("" + a), t.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", l);
          break;
        case "contentEditable":
        case "spellCheck":
        case "draggable":
        case "value":
        case "autoReverse":
        case "externalResourcesRequired":
        case "focusable":
        case "preserveAlpha":
          a != null && typeof a != "function" && typeof a != "symbol" ? t.setAttribute(l, "" + a) : t.removeAttribute(l);
          break;
        case "inert":
        case "allowFullScreen":
        case "async":
        case "autoPlay":
        case "controls":
        case "default":
        case "defer":
        case "disabled":
        case "disablePictureInPicture":
        case "disableRemotePlayback":
        case "formNoValidate":
        case "hidden":
        case "loop":
        case "noModule":
        case "noValidate":
        case "open":
        case "playsInline":
        case "readOnly":
        case "required":
        case "reversed":
        case "scoped":
        case "seamless":
        case "itemScope":
          a && typeof a != "function" && typeof a != "symbol" ? t.setAttribute(l, "") : t.removeAttribute(l);
          break;
        case "capture":
        case "download":
          a === true ? t.setAttribute(l, "") : a !== false && a != null && typeof a != "function" && typeof a != "symbol" ? t.setAttribute(l, a) : t.removeAttribute(l);
          break;
        case "cols":
        case "rows":
        case "size":
        case "span":
          a != null && typeof a != "function" && typeof a != "symbol" && !isNaN(a) && 1 <= a ? t.setAttribute(l, a) : t.removeAttribute(l);
          break;
        case "rowSpan":
        case "start":
          a == null || typeof a == "function" || typeof a == "symbol" || isNaN(a) ? t.removeAttribute(l) : t.setAttribute(l, a);
          break;
        case "popover":
          et("beforetoggle", t), et("toggle", t), Vu(t, "popover", a);
          break;
        case "xlinkActuate":
          Be(t, "http://www.w3.org/1999/xlink", "xlink:actuate", a);
          break;
        case "xlinkArcrole":
          Be(t, "http://www.w3.org/1999/xlink", "xlink:arcrole", a);
          break;
        case "xlinkRole":
          Be(t, "http://www.w3.org/1999/xlink", "xlink:role", a);
          break;
        case "xlinkShow":
          Be(t, "http://www.w3.org/1999/xlink", "xlink:show", a);
          break;
        case "xlinkTitle":
          Be(t, "http://www.w3.org/1999/xlink", "xlink:title", a);
          break;
        case "xlinkType":
          Be(t, "http://www.w3.org/1999/xlink", "xlink:type", a);
          break;
        case "xmlBase":
          Be(t, "http://www.w3.org/XML/1998/namespace", "xml:base", a);
          break;
        case "xmlLang":
          Be(t, "http://www.w3.org/XML/1998/namespace", "xml:lang", a);
          break;
        case "xmlSpace":
          Be(t, "http://www.w3.org/XML/1998/namespace", "xml:space", a);
          break;
        case "is":
          Vu(t, "is", a);
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          (!(2 < l.length) || l[0] !== "o" && l[0] !== "O" || l[1] !== "n" && l[1] !== "N") && (l = Ph.get(l) || l, Vu(t, l, a));
      }
    }
    function sf(t, e, l, a, u, n) {
      switch (l) {
        case "style":
          mo(t, a, n);
          break;
        case "dangerouslySetInnerHTML":
          if (a != null) {
            if (typeof a != "object" || !("__html" in a)) throw Error(o(61));
            if (l = a.__html, l != null) {
              if (u.children != null) throw Error(o(60));
              t.innerHTML = l;
            }
          }
          break;
        case "children":
          typeof a == "string" ? la(t, a) : (typeof a == "number" || typeof a == "bigint") && la(t, "" + a);
          break;
        case "onScroll":
          a != null && et("scroll", t);
          break;
        case "onScrollEnd":
          a != null && et("scrollend", t);
          break;
        case "onClick":
          a != null && (t.onclick = qe);
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "innerHTML":
        case "ref":
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          if (!uo.hasOwnProperty(l)) t: {
            if (l[0] === "o" && l[1] === "n" && (u = l.endsWith("Capture"), e = l.slice(2, u ? l.length - 7 : void 0), n = t[Jt] || null, n = n != null ? n[l] : null, typeof n == "function" && t.removeEventListener(e, n, u), typeof a == "function")) {
              typeof n != "function" && n !== null && (l in t ? t[l] = null : t.hasAttribute(l) && t.removeAttribute(l)), t.addEventListener(e, a, u);
              break t;
            }
            l in t ? t[l] = a : a === true ? t.setAttribute(l, "") : Vu(t, l, a);
          }
      }
    }
    function Gt(t, e, l) {
      switch (e) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "img":
          et("error", t), et("load", t);
          var a = false, u = false, n;
          for (n in l) if (l.hasOwnProperty(n)) {
            var i = l[n];
            if (i != null) switch (n) {
              case "src":
                a = true;
                break;
              case "srcSet":
                u = true;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(o(137, e));
              default:
                mt(t, e, n, i, l, null);
            }
          }
          u && mt(t, e, "srcSet", l.srcSet, l, null), a && mt(t, e, "src", l.src, l, null);
          return;
        case "input":
          et("invalid", t);
          var f = n = i = u = null, d = null, z = null;
          for (a in l) if (l.hasOwnProperty(a)) {
            var M = l[a];
            if (M != null) switch (a) {
              case "name":
                u = M;
                break;
              case "type":
                i = M;
                break;
              case "checked":
                d = M;
                break;
              case "defaultChecked":
                z = M;
                break;
              case "value":
                n = M;
                break;
              case "defaultValue":
                f = M;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (M != null) throw Error(o(137, e));
                break;
              default:
                mt(t, e, a, M, l, null);
            }
          }
          oo(t, n, f, d, z, i, u, false);
          return;
        case "select":
          et("invalid", t), a = i = n = null;
          for (u in l) if (l.hasOwnProperty(u) && (f = l[u], f != null)) switch (u) {
            case "value":
              n = f;
              break;
            case "defaultValue":
              i = f;
              break;
            case "multiple":
              a = f;
            default:
              mt(t, e, u, f, l, null);
          }
          e = n, l = i, t.multiple = !!a, e != null ? ea(t, !!a, e, false) : l != null && ea(t, !!a, l, true);
          return;
        case "textarea":
          et("invalid", t), n = u = a = null;
          for (i in l) if (l.hasOwnProperty(i) && (f = l[i], f != null)) switch (i) {
            case "value":
              a = f;
              break;
            case "defaultValue":
              u = f;
              break;
            case "children":
              n = f;
              break;
            case "dangerouslySetInnerHTML":
              if (f != null) throw Error(o(91));
              break;
            default:
              mt(t, e, i, f, l, null);
          }
          so(t, a, u, n);
          return;
        case "option":
          for (d in l) l.hasOwnProperty(d) && (a = l[d], a != null) && (d === "selected" ? t.selected = a && typeof a != "function" && typeof a != "symbol" : mt(t, e, d, a, l, null));
          return;
        case "dialog":
          et("beforetoggle", t), et("toggle", t), et("cancel", t), et("close", t);
          break;
        case "iframe":
        case "object":
          et("load", t);
          break;
        case "video":
        case "audio":
          for (a = 0; a < zu.length; a++) et(zu[a], t);
          break;
        case "image":
          et("error", t), et("load", t);
          break;
        case "details":
          et("toggle", t);
          break;
        case "embed":
        case "source":
        case "link":
          et("error", t), et("load", t);
        case "area":
        case "base":
        case "br":
        case "col":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "track":
        case "wbr":
        case "menuitem":
          for (z in l) if (l.hasOwnProperty(z) && (a = l[z], a != null)) switch (z) {
            case "children":
            case "dangerouslySetInnerHTML":
              throw Error(o(137, e));
            default:
              mt(t, e, z, a, l, null);
          }
          return;
        default:
          if (Ai(e)) {
            for (M in l) l.hasOwnProperty(M) && (a = l[M], a !== void 0 && sf(t, e, M, a, l, void 0));
            return;
          }
      }
      for (f in l) l.hasOwnProperty(f) && (a = l[f], a != null && mt(t, e, f, a, l, null));
    }
    function Ry(t, e, l, a) {
      switch (e) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "input":
          var u = null, n = null, i = null, f = null, d = null, z = null, M = null;
          for (A in l) {
            var U = l[A];
            if (l.hasOwnProperty(A) && U != null) switch (A) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                d = U;
              default:
                a.hasOwnProperty(A) || mt(t, e, A, null, a, U);
            }
          }
          for (var T in a) {
            var A = a[T];
            if (U = l[T], a.hasOwnProperty(T) && (A != null || U != null)) switch (T) {
              case "type":
                n = A;
                break;
              case "name":
                u = A;
                break;
              case "checked":
                z = A;
                break;
              case "defaultChecked":
                M = A;
                break;
              case "value":
                i = A;
                break;
              case "defaultValue":
                f = A;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (A != null) throw Error(o(137, e));
                break;
              default:
                A !== U && mt(t, e, T, A, a, U);
            }
          }
          zi(t, i, f, d, z, M, n, u);
          return;
        case "select":
          A = i = f = T = null;
          for (n in l) if (d = l[n], l.hasOwnProperty(n) && d != null) switch (n) {
            case "value":
              break;
            case "multiple":
              A = d;
            default:
              a.hasOwnProperty(n) || mt(t, e, n, null, a, d);
          }
          for (u in a) if (n = a[u], d = l[u], a.hasOwnProperty(u) && (n != null || d != null)) switch (u) {
            case "value":
              T = n;
              break;
            case "defaultValue":
              f = n;
              break;
            case "multiple":
              i = n;
            default:
              n !== d && mt(t, e, u, n, a, d);
          }
          e = f, l = i, a = A, T != null ? ea(t, !!l, T, false) : !!a != !!l && (e != null ? ea(t, !!l, e, true) : ea(t, !!l, l ? [] : "", false));
          return;
        case "textarea":
          A = T = null;
          for (f in l) if (u = l[f], l.hasOwnProperty(f) && u != null && !a.hasOwnProperty(f)) switch (f) {
            case "value":
              break;
            case "children":
              break;
            default:
              mt(t, e, f, null, a, u);
          }
          for (i in a) if (u = a[i], n = l[i], a.hasOwnProperty(i) && (u != null || n != null)) switch (i) {
            case "value":
              T = u;
              break;
            case "defaultValue":
              A = u;
              break;
            case "children":
              break;
            case "dangerouslySetInnerHTML":
              if (u != null) throw Error(o(91));
              break;
            default:
              u !== n && mt(t, e, i, u, a, n);
          }
          ro(t, T, A);
          return;
        case "option":
          for (var j in l) T = l[j], l.hasOwnProperty(j) && T != null && !a.hasOwnProperty(j) && (j === "selected" ? t.selected = false : mt(t, e, j, null, a, T));
          for (d in a) T = a[d], A = l[d], a.hasOwnProperty(d) && T !== A && (T != null || A != null) && (d === "selected" ? t.selected = T && typeof T != "function" && typeof T != "symbol" : mt(t, e, d, T, a, A));
          return;
        case "img":
        case "link":
        case "area":
        case "base":
        case "br":
        case "col":
        case "embed":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "source":
        case "track":
        case "wbr":
        case "menuitem":
          for (var J in l) T = l[J], l.hasOwnProperty(J) && T != null && !a.hasOwnProperty(J) && mt(t, e, J, null, a, T);
          for (z in a) if (T = a[z], A = l[z], a.hasOwnProperty(z) && T !== A && (T != null || A != null)) switch (z) {
            case "children":
            case "dangerouslySetInnerHTML":
              if (T != null) throw Error(o(137, e));
              break;
            default:
              mt(t, e, z, T, a, A);
          }
          return;
        default:
          if (Ai(e)) {
            for (var yt in l) T = l[yt], l.hasOwnProperty(yt) && T !== void 0 && !a.hasOwnProperty(yt) && sf(t, e, yt, void 0, a, T);
            for (M in a) T = a[M], A = l[M], !a.hasOwnProperty(M) || T === A || T === void 0 && A === void 0 || sf(t, e, M, T, a, A);
            return;
          }
      }
      for (var p in l) T = l[p], l.hasOwnProperty(p) && T != null && !a.hasOwnProperty(p) && mt(t, e, p, null, a, T);
      for (U in a) T = a[U], A = l[U], !a.hasOwnProperty(U) || T === A || T == null && A == null || mt(t, e, U, T, a, A);
    }
    function yd(t) {
      switch (t) {
        case "css":
        case "script":
        case "font":
        case "img":
        case "image":
        case "input":
        case "link":
          return true;
        default:
          return false;
      }
    }
    function My() {
      if (typeof performance.getEntriesByType == "function") {
        for (var t = 0, e = 0, l = performance.getEntriesByType("resource"), a = 0; a < l.length; a++) {
          var u = l[a], n = u.transferSize, i = u.initiatorType, f = u.duration;
          if (n && f && yd(i)) {
            for (i = 0, f = u.responseEnd, a += 1; a < l.length; a++) {
              var d = l[a], z = d.startTime;
              if (z > f) break;
              var M = d.transferSize, U = d.initiatorType;
              M && yd(U) && (d = d.responseEnd, i += M * (d < f ? 1 : (f - z) / (d - z)));
            }
            if (--a, e += 8 * (n + i) / (u.duration / 1e3), t++, 10 < t) break;
          }
        }
        if (0 < t) return e / t / 1e6;
      }
      return navigator.connection && (t = navigator.connection.downlink, typeof t == "number") ? t : 5;
    }
    var df = null, hf = null;
    function Zn(t) {
      return t.nodeType === 9 ? t : t.ownerDocument;
    }
    function vd(t) {
      switch (t) {
        case "http://www.w3.org/2000/svg":
          return 1;
        case "http://www.w3.org/1998/Math/MathML":
          return 2;
        default:
          return 0;
      }
    }
    function gd(t, e) {
      if (t === 0) switch (e) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
      return t === 1 && e === "foreignObject" ? 0 : t;
    }
    function mf(t, e) {
      return t === "textarea" || t === "noscript" || typeof e.children == "string" || typeof e.children == "number" || typeof e.children == "bigint" || typeof e.dangerouslySetInnerHTML == "object" && e.dangerouslySetInnerHTML !== null && e.dangerouslySetInnerHTML.__html != null;
    }
    var yf = null;
    function Oy() {
      var t = window.event;
      return t && t.type === "popstate" ? t === yf ? false : (yf = t, true) : (yf = null, false);
    }
    var pd = typeof setTimeout == "function" ? setTimeout : void 0, Cy = typeof clearTimeout == "function" ? clearTimeout : void 0, Sd = typeof Promise == "function" ? Promise : void 0, Dy = typeof queueMicrotask == "function" ? queueMicrotask : typeof Sd < "u" ? function(t) {
      return Sd.resolve(null).then(t).catch(Uy);
    } : pd;
    function Uy(t) {
      setTimeout(function() {
        throw t;
      });
    }
    function zl(t) {
      return t === "head";
    }
    function bd(t, e) {
      var l = e, a = 0;
      do {
        var u = l.nextSibling;
        if (t.removeChild(l), u && u.nodeType === 8) if (l = u.data, l === "/$" || l === "/&") {
          if (a === 0) {
            t.removeChild(u), Na(e);
            return;
          }
          a--;
        } else if (l === "$" || l === "$?" || l === "$~" || l === "$!" || l === "&") a++;
        else if (l === "html") Au(t.ownerDocument.documentElement);
        else if (l === "head") {
          l = t.ownerDocument.head, Au(l);
          for (var n = l.firstChild; n; ) {
            var i = n.nextSibling, f = n.nodeName;
            n[Xa] || f === "SCRIPT" || f === "STYLE" || f === "LINK" && n.rel.toLowerCase() === "stylesheet" || l.removeChild(n), n = i;
          }
        } else l === "body" && Au(t.ownerDocument.body);
        l = u;
      } while (l);
      Na(e);
    }
    function Ed(t, e) {
      var l = t;
      t = 0;
      do {
        var a = l.nextSibling;
        if (l.nodeType === 1 ? e ? (l._stashedDisplay = l.style.display, l.style.display = "none") : (l.style.display = l._stashedDisplay || "", l.getAttribute("style") === "" && l.removeAttribute("style")) : l.nodeType === 3 && (e ? (l._stashedText = l.nodeValue, l.nodeValue = "") : l.nodeValue = l._stashedText || ""), a && a.nodeType === 8) if (l = a.data, l === "/$") {
          if (t === 0) break;
          t--;
        } else l !== "$" && l !== "$?" && l !== "$~" && l !== "$!" || t++;
        l = a;
      } while (l);
    }
    function vf(t) {
      var e = t.firstChild;
      for (e && e.nodeType === 10 && (e = e.nextSibling); e; ) {
        var l = e;
        switch (e = e.nextSibling, l.nodeName) {
          case "HTML":
          case "HEAD":
          case "BODY":
            vf(l), bi(l);
            continue;
          case "SCRIPT":
          case "STYLE":
            continue;
          case "LINK":
            if (l.rel.toLowerCase() === "stylesheet") continue;
        }
        t.removeChild(l);
      }
    }
    function xy(t, e, l, a) {
      for (; t.nodeType === 1; ) {
        var u = l;
        if (t.nodeName.toLowerCase() !== e.toLowerCase()) {
          if (!a && (t.nodeName !== "INPUT" || t.type !== "hidden")) break;
        } else if (a) {
          if (!t[Xa]) switch (e) {
            case "meta":
              if (!t.hasAttribute("itemprop")) break;
              return t;
            case "link":
              if (n = t.getAttribute("rel"), n === "stylesheet" && t.hasAttribute("data-precedence")) break;
              if (n !== u.rel || t.getAttribute("href") !== (u.href == null || u.href === "" ? null : u.href) || t.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin) || t.getAttribute("title") !== (u.title == null ? null : u.title)) break;
              return t;
            case "style":
              if (t.hasAttribute("data-precedence")) break;
              return t;
            case "script":
              if (n = t.getAttribute("src"), (n !== (u.src == null ? null : u.src) || t.getAttribute("type") !== (u.type == null ? null : u.type) || t.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin)) && n && t.hasAttribute("async") && !t.hasAttribute("itemprop")) break;
              return t;
            default:
              return t;
          }
        } else if (e === "input" && t.type === "hidden") {
          var n = u.name == null ? null : "" + u.name;
          if (u.type === "hidden" && t.getAttribute("name") === n) return t;
        } else return t;
        if (t = Se(t.nextSibling), t === null) break;
      }
      return null;
    }
    function Ny(t, e, l) {
      if (e === "") return null;
      for (; t.nodeType !== 3; ) if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !l || (t = Se(t.nextSibling), t === null)) return null;
      return t;
    }
    function zd(t, e) {
      for (; t.nodeType !== 8; ) if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !e || (t = Se(t.nextSibling), t === null)) return null;
      return t;
    }
    function gf(t) {
      return t.data === "$?" || t.data === "$~";
    }
    function pf(t) {
      return t.data === "$!" || t.data === "$?" && t.ownerDocument.readyState !== "loading";
    }
    function Hy(t, e) {
      var l = t.ownerDocument;
      if (t.data === "$~") t._reactRetry = e;
      else if (t.data !== "$?" || l.readyState !== "loading") e();
      else {
        var a = function() {
          e(), l.removeEventListener("DOMContentLoaded", a);
        };
        l.addEventListener("DOMContentLoaded", a), t._reactRetry = a;
      }
    }
    function Se(t) {
      for (; t != null; t = t.nextSibling) {
        var e = t.nodeType;
        if (e === 1 || e === 3) break;
        if (e === 8) {
          if (e = t.data, e === "$" || e === "$!" || e === "$?" || e === "$~" || e === "&" || e === "F!" || e === "F") break;
          if (e === "/$" || e === "/&") return null;
        }
      }
      return t;
    }
    var Sf = null;
    function Td(t) {
      t = t.nextSibling;
      for (var e = 0; t; ) {
        if (t.nodeType === 8) {
          var l = t.data;
          if (l === "/$" || l === "/&") {
            if (e === 0) return Se(t.nextSibling);
            e--;
          } else l !== "$" && l !== "$!" && l !== "$?" && l !== "$~" && l !== "&" || e++;
        }
        t = t.nextSibling;
      }
      return null;
    }
    function Ad(t) {
      t = t.previousSibling;
      for (var e = 0; t; ) {
        if (t.nodeType === 8) {
          var l = t.data;
          if (l === "$" || l === "$!" || l === "$?" || l === "$~" || l === "&") {
            if (e === 0) return t;
            e--;
          } else l !== "/$" && l !== "/&" || e++;
        }
        t = t.previousSibling;
      }
      return null;
    }
    function _d(t, e, l) {
      switch (e = Zn(l), t) {
        case "html":
          if (t = e.documentElement, !t) throw Error(o(452));
          return t;
        case "head":
          if (t = e.head, !t) throw Error(o(453));
          return t;
        case "body":
          if (t = e.body, !t) throw Error(o(454));
          return t;
        default:
          throw Error(o(451));
      }
    }
    function Au(t) {
      for (var e = t.attributes; e.length; ) t.removeAttributeNode(e[0]);
      bi(t);
    }
    var be = /* @__PURE__ */ new Map(), Rd = /* @__PURE__ */ new Set();
    function Vn(t) {
      return typeof t.getRootNode == "function" ? t.getRootNode() : t.nodeType === 9 ? t : t.ownerDocument;
    }
    var Ie = lt.d;
    lt.d = {
      f: By,
      r: qy,
      D: Yy,
      C: Ly,
      L: jy,
      m: Qy,
      X: Xy,
      S: Gy,
      M: Zy
    };
    function By() {
      var t = Ie.f(), e = Bn();
      return t || e;
    }
    function qy(t) {
      var e = Il(t);
      e !== null && e.tag === 5 && e.type === "form" ? Zr(e) : Ie.r(t);
    }
    var Da = typeof document > "u" ? null : document;
    function Md(t, e, l) {
      var a = Da;
      if (a && typeof e == "string" && e) {
        var u = de(e);
        u = 'link[rel="' + t + '"][href="' + u + '"]', typeof l == "string" && (u += '[crossorigin="' + l + '"]'), Rd.has(u) || (Rd.add(u), t = {
          rel: t,
          crossOrigin: l,
          href: e
        }, a.querySelector(u) === null && (e = a.createElement("link"), Gt(e, "link", t), Ht(e), a.head.appendChild(e)));
      }
    }
    function Yy(t) {
      Ie.D(t), Md("dns-prefetch", t, null);
    }
    function Ly(t, e) {
      Ie.C(t, e), Md("preconnect", t, e);
    }
    function jy(t, e, l) {
      Ie.L(t, e, l);
      var a = Da;
      if (a && t && e) {
        var u = 'link[rel="preload"][as="' + de(e) + '"]';
        e === "image" && l && l.imageSrcSet ? (u += '[imagesrcset="' + de(l.imageSrcSet) + '"]', typeof l.imageSizes == "string" && (u += '[imagesizes="' + de(l.imageSizes) + '"]')) : u += '[href="' + de(t) + '"]';
        var n = u;
        switch (e) {
          case "style":
            n = Ua(t);
            break;
          case "script":
            n = xa(t);
        }
        be.has(n) || (t = _({
          rel: "preload",
          href: e === "image" && l && l.imageSrcSet ? void 0 : t,
          as: e
        }, l), be.set(n, t), a.querySelector(u) !== null || e === "style" && a.querySelector(_u(n)) || e === "script" && a.querySelector(Ru(n)) || (e = a.createElement("link"), Gt(e, "link", t), Ht(e), a.head.appendChild(e)));
      }
    }
    function Qy(t, e) {
      Ie.m(t, e);
      var l = Da;
      if (l && t) {
        var a = e && typeof e.as == "string" ? e.as : "script", u = 'link[rel="modulepreload"][as="' + de(a) + '"][href="' + de(t) + '"]', n = u;
        switch (a) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            n = xa(t);
        }
        if (!be.has(n) && (t = _({
          rel: "modulepreload",
          href: t
        }, e), be.set(n, t), l.querySelector(u) === null)) {
          switch (a) {
            case "audioworklet":
            case "paintworklet":
            case "serviceworker":
            case "sharedworker":
            case "worker":
            case "script":
              if (l.querySelector(Ru(n))) return;
          }
          a = l.createElement("link"), Gt(a, "link", t), Ht(a), l.head.appendChild(a);
        }
      }
    }
    function Gy(t, e, l) {
      Ie.S(t, e, l);
      var a = Da;
      if (a && t) {
        var u = Pl(a).hoistableStyles, n = Ua(t);
        e = e || "default";
        var i = u.get(n);
        if (!i) {
          var f = {
            loading: 0,
            preload: null
          };
          if (i = a.querySelector(_u(n))) f.loading = 5;
          else {
            t = _({
              rel: "stylesheet",
              href: t,
              "data-precedence": e
            }, l), (l = be.get(n)) && bf(t, l);
            var d = i = a.createElement("link");
            Ht(d), Gt(d, "link", t), d._p = new Promise(function(z, M) {
              d.onload = z, d.onerror = M;
            }), d.addEventListener("load", function() {
              f.loading |= 1;
            }), d.addEventListener("error", function() {
              f.loading |= 2;
            }), f.loading |= 4, Kn(i, e, a);
          }
          i = {
            type: "stylesheet",
            instance: i,
            count: 1,
            state: f
          }, u.set(n, i);
        }
      }
    }
    function Xy(t, e) {
      Ie.X(t, e);
      var l = Da;
      if (l && t) {
        var a = Pl(l).hoistableScripts, u = xa(t), n = a.get(u);
        n || (n = l.querySelector(Ru(u)), n || (t = _({
          src: t,
          async: true
        }, e), (e = be.get(u)) && Ef(t, e), n = l.createElement("script"), Ht(n), Gt(n, "link", t), l.head.appendChild(n)), n = {
          type: "script",
          instance: n,
          count: 1,
          state: null
        }, a.set(u, n));
      }
    }
    function Zy(t, e) {
      Ie.M(t, e);
      var l = Da;
      if (l && t) {
        var a = Pl(l).hoistableScripts, u = xa(t), n = a.get(u);
        n || (n = l.querySelector(Ru(u)), n || (t = _({
          src: t,
          async: true,
          type: "module"
        }, e), (e = be.get(u)) && Ef(t, e), n = l.createElement("script"), Ht(n), Gt(n, "link", t), l.head.appendChild(n)), n = {
          type: "script",
          instance: n,
          count: 1,
          state: null
        }, a.set(u, n));
      }
    }
    function Od(t, e, l, a) {
      var u = (u = P.current) ? Vn(u) : null;
      if (!u) throw Error(o(446));
      switch (t) {
        case "meta":
        case "title":
          return null;
        case "style":
          return typeof l.precedence == "string" && typeof l.href == "string" ? (e = Ua(l.href), l = Pl(u).hoistableStyles, a = l.get(e), a || (a = {
            type: "style",
            instance: null,
            count: 0,
            state: null
          }, l.set(e, a)), a) : {
            type: "void",
            instance: null,
            count: 0,
            state: null
          };
        case "link":
          if (l.rel === "stylesheet" && typeof l.href == "string" && typeof l.precedence == "string") {
            t = Ua(l.href);
            var n = Pl(u).hoistableStyles, i = n.get(t);
            if (i || (u = u.ownerDocument || u, i = {
              type: "stylesheet",
              instance: null,
              count: 0,
              state: {
                loading: 0,
                preload: null
              }
            }, n.set(t, i), (n = u.querySelector(_u(t))) && !n._p && (i.instance = n, i.state.loading = 5), be.has(t) || (l = {
              rel: "preload",
              as: "style",
              href: l.href,
              crossOrigin: l.crossOrigin,
              integrity: l.integrity,
              media: l.media,
              hrefLang: l.hrefLang,
              referrerPolicy: l.referrerPolicy
            }, be.set(t, l), n || Vy(u, t, l, i.state))), e && a === null) throw Error(o(528, ""));
            return i;
          }
          if (e && a !== null) throw Error(o(529, ""));
          return null;
        case "script":
          return e = l.async, l = l.src, typeof l == "string" && e && typeof e != "function" && typeof e != "symbol" ? (e = xa(l), l = Pl(u).hoistableScripts, a = l.get(e), a || (a = {
            type: "script",
            instance: null,
            count: 0,
            state: null
          }, l.set(e, a)), a) : {
            type: "void",
            instance: null,
            count: 0,
            state: null
          };
        default:
          throw Error(o(444, t));
      }
    }
    function Ua(t) {
      return 'href="' + de(t) + '"';
    }
    function _u(t) {
      return 'link[rel="stylesheet"][' + t + "]";
    }
    function Cd(t) {
      return _({}, t, {
        "data-precedence": t.precedence,
        precedence: null
      });
    }
    function Vy(t, e, l, a) {
      t.querySelector('link[rel="preload"][as="style"][' + e + "]") ? a.loading = 1 : (e = t.createElement("link"), a.preload = e, e.addEventListener("load", function() {
        return a.loading |= 1;
      }), e.addEventListener("error", function() {
        return a.loading |= 2;
      }), Gt(e, "link", l), Ht(e), t.head.appendChild(e));
    }
    function xa(t) {
      return '[src="' + de(t) + '"]';
    }
    function Ru(t) {
      return "script[async]" + t;
    }
    function Dd(t, e, l) {
      if (e.count++, e.instance === null) switch (e.type) {
        case "style":
          var a = t.querySelector('style[data-href~="' + de(l.href) + '"]');
          if (a) return e.instance = a, Ht(a), a;
          var u = _({}, l, {
            "data-href": l.href,
            "data-precedence": l.precedence,
            href: null,
            precedence: null
          });
          return a = (t.ownerDocument || t).createElement("style"), Ht(a), Gt(a, "style", u), Kn(a, l.precedence, t), e.instance = a;
        case "stylesheet":
          u = Ua(l.href);
          var n = t.querySelector(_u(u));
          if (n) return e.state.loading |= 4, e.instance = n, Ht(n), n;
          a = Cd(l), (u = be.get(u)) && bf(a, u), n = (t.ownerDocument || t).createElement("link"), Ht(n);
          var i = n;
          return i._p = new Promise(function(f, d) {
            i.onload = f, i.onerror = d;
          }), Gt(n, "link", a), e.state.loading |= 4, Kn(n, l.precedence, t), e.instance = n;
        case "script":
          return n = xa(l.src), (u = t.querySelector(Ru(n))) ? (e.instance = u, Ht(u), u) : (a = l, (u = be.get(n)) && (a = _({}, l), Ef(a, u)), t = t.ownerDocument || t, u = t.createElement("script"), Ht(u), Gt(u, "link", a), t.head.appendChild(u), e.instance = u);
        case "void":
          return null;
        default:
          throw Error(o(443, e.type));
      }
      else e.type === "stylesheet" && (e.state.loading & 4) === 0 && (a = e.instance, e.state.loading |= 4, Kn(a, l.precedence, t));
      return e.instance;
    }
    function Kn(t, e, l) {
      for (var a = l.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), u = a.length ? a[a.length - 1] : null, n = u, i = 0; i < a.length; i++) {
        var f = a[i];
        if (f.dataset.precedence === e) n = f;
        else if (n !== u) break;
      }
      n ? n.parentNode.insertBefore(t, n.nextSibling) : (e = l.nodeType === 9 ? l.head : l, e.insertBefore(t, e.firstChild));
    }
    function bf(t, e) {
      t.crossOrigin == null && (t.crossOrigin = e.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = e.referrerPolicy), t.title == null && (t.title = e.title);
    }
    function Ef(t, e) {
      t.crossOrigin == null && (t.crossOrigin = e.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = e.referrerPolicy), t.integrity == null && (t.integrity = e.integrity);
    }
    var Jn = null;
    function Ud(t, e, l) {
      if (Jn === null) {
        var a = /* @__PURE__ */ new Map(), u = Jn = /* @__PURE__ */ new Map();
        u.set(l, a);
      } else u = Jn, a = u.get(l), a || (a = /* @__PURE__ */ new Map(), u.set(l, a));
      if (a.has(t)) return a;
      for (a.set(t, null), l = l.getElementsByTagName(t), u = 0; u < l.length; u++) {
        var n = l[u];
        if (!(n[Xa] || n[Yt] || t === "link" && n.getAttribute("rel") === "stylesheet") && n.namespaceURI !== "http://www.w3.org/2000/svg") {
          var i = n.getAttribute(e) || "";
          i = t + i;
          var f = a.get(i);
          f ? f.push(n) : a.set(i, [
            n
          ]);
        }
      }
      return a;
    }
    function xd(t, e, l) {
      t = t.ownerDocument || t, t.head.insertBefore(l, e === "title" ? t.querySelector("head > title") : null);
    }
    function Ky(t, e, l) {
      if (l === 1 || e.itemProp != null) return false;
      switch (t) {
        case "meta":
        case "title":
          return true;
        case "style":
          if (typeof e.precedence != "string" || typeof e.href != "string" || e.href === "") break;
          return true;
        case "link":
          if (typeof e.rel != "string" || typeof e.href != "string" || e.href === "" || e.onLoad || e.onError) break;
          return e.rel === "stylesheet" ? (t = e.disabled, typeof e.precedence == "string" && t == null) : true;
        case "script":
          if (e.async && typeof e.async != "function" && typeof e.async != "symbol" && !e.onLoad && !e.onError && e.src && typeof e.src == "string") return true;
      }
      return false;
    }
    function Nd(t) {
      return !(t.type === "stylesheet" && (t.state.loading & 3) === 0);
    }
    function Jy(t, e, l, a) {
      if (l.type === "stylesheet" && (typeof a.media != "string" || matchMedia(a.media).matches !== false) && (l.state.loading & 4) === 0) {
        if (l.instance === null) {
          var u = Ua(a.href), n = e.querySelector(_u(u));
          if (n) {
            e = n._p, e !== null && typeof e == "object" && typeof e.then == "function" && (t.count++, t = wn.bind(t), e.then(t, t)), l.state.loading |= 4, l.instance = n, Ht(n);
            return;
          }
          n = e.ownerDocument || e, a = Cd(a), (u = be.get(u)) && bf(a, u), n = n.createElement("link"), Ht(n);
          var i = n;
          i._p = new Promise(function(f, d) {
            i.onload = f, i.onerror = d;
          }), Gt(n, "link", a), l.instance = n;
        }
        t.stylesheets === null && (t.stylesheets = /* @__PURE__ */ new Map()), t.stylesheets.set(l, e), (e = l.state.preload) && (l.state.loading & 3) === 0 && (t.count++, l = wn.bind(t), e.addEventListener("load", l), e.addEventListener("error", l));
      }
    }
    var zf = 0;
    function wy(t, e) {
      return t.stylesheets && t.count === 0 && kn(t, t.stylesheets), 0 < t.count || 0 < t.imgCount ? function(l) {
        var a = setTimeout(function() {
          if (t.stylesheets && kn(t, t.stylesheets), t.unsuspend) {
            var n = t.unsuspend;
            t.unsuspend = null, n();
          }
        }, 6e4 + e);
        0 < t.imgBytes && zf === 0 && (zf = 62500 * My());
        var u = setTimeout(function() {
          if (t.waitingForImages = false, t.count === 0 && (t.stylesheets && kn(t, t.stylesheets), t.unsuspend)) {
            var n = t.unsuspend;
            t.unsuspend = null, n();
          }
        }, (t.imgBytes > zf ? 50 : 800) + e);
        return t.unsuspend = l, function() {
          t.unsuspend = null, clearTimeout(a), clearTimeout(u);
        };
      } : null;
    }
    function wn() {
      if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
        if (this.stylesheets) kn(this, this.stylesheets);
        else if (this.unsuspend) {
          var t = this.unsuspend;
          this.unsuspend = null, t();
        }
      }
    }
    var $n = null;
    function kn(t, e) {
      t.stylesheets = null, t.unsuspend !== null && (t.count++, $n = /* @__PURE__ */ new Map(), e.forEach($y, t), $n = null, wn.call(t));
    }
    function $y(t, e) {
      if (!(e.state.loading & 4)) {
        var l = $n.get(t);
        if (l) var a = l.get(null);
        else {
          l = /* @__PURE__ */ new Map(), $n.set(t, l);
          for (var u = t.querySelectorAll("link[data-precedence],style[data-precedence]"), n = 0; n < u.length; n++) {
            var i = u[n];
            (i.nodeName === "LINK" || i.getAttribute("media") !== "not all") && (l.set(i.dataset.precedence, i), a = i);
          }
          a && l.set(null, a);
        }
        u = e.instance, i = u.getAttribute("data-precedence"), n = l.get(i) || a, n === a && l.set(null, u), l.set(i, u), this.count++, a = wn.bind(this), u.addEventListener("load", a), u.addEventListener("error", a), n ? n.parentNode.insertBefore(u, n.nextSibling) : (t = t.nodeType === 9 ? t.head : t, t.insertBefore(u, t.firstChild)), e.state.loading |= 4;
      }
    }
    var Mu = {
      $$typeof: w,
      Provider: null,
      Consumer: null,
      _currentValue: He,
      _currentValue2: He,
      _threadCount: 0
    };
    function ky(t, e, l, a, u, n, i, f, d) {
      this.tag = 1, this.containerInfo = t, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = vi(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = vi(0), this.hiddenUpdates = vi(null), this.identifierPrefix = a, this.onUncaughtError = u, this.onCaughtError = n, this.onRecoverableError = i, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = d, this.incompleteTransitions = /* @__PURE__ */ new Map();
    }
    function Hd(t, e, l, a, u, n, i, f, d, z, M, U) {
      return t = new ky(t, e, l, i, d, z, M, U, f), e = 1, n === true && (e |= 24), n = ae(3, null, null, e), t.current = n, n.stateNode = t, e = tc(), e.refCount++, t.pooledCache = e, e.refCount++, n.memoizedState = {
        element: a,
        isDehydrated: l,
        cache: e
      }, uc(n), t;
    }
    function Bd(t) {
      return t ? (t = oa, t) : oa;
    }
    function qd(t, e, l, a, u, n) {
      u = Bd(u), a.context === null ? a.context = u : a.pendingContext = u, a = sl(e), a.payload = {
        element: l
      }, n = n === void 0 ? null : n, n !== null && (a.callback = n), l = dl(t, a, e), l !== null && (It(l, t, e), nu(l, t, e));
    }
    function Yd(t, e) {
      if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
        var l = t.retryLane;
        t.retryLane = l !== 0 && l < e ? l : e;
      }
    }
    function Tf(t, e) {
      Yd(t, e), (t = t.alternate) && Yd(t, e);
    }
    function Ld(t) {
      if (t.tag === 13 || t.tag === 31) {
        var e = Bl(t, 67108864);
        e !== null && It(e, t, 67108864), Tf(t, 67108864);
      }
    }
    function jd(t) {
      if (t.tag === 13 || t.tag === 31) {
        var e = fe();
        e = gi(e);
        var l = Bl(t, e);
        l !== null && It(l, t, e), Tf(t, e);
      }
    }
    var Wn = true;
    function Wy(t, e, l, a) {
      var u = X.T;
      X.T = null;
      var n = lt.p;
      try {
        lt.p = 2, Af(t, e, l, a);
      } finally {
        lt.p = n, X.T = u;
      }
    }
    function Fy(t, e, l, a) {
      var u = X.T;
      X.T = null;
      var n = lt.p;
      try {
        lt.p = 8, Af(t, e, l, a);
      } finally {
        lt.p = n, X.T = u;
      }
    }
    function Af(t, e, l, a) {
      if (Wn) {
        var u = _f(a);
        if (u === null) rf(t, e, a, Fn, l), Gd(t, a);
        else if (Py(u, t, e, l, a)) a.stopPropagation();
        else if (Gd(t, a), e & 4 && -1 < Iy.indexOf(t)) {
          for (; u !== null; ) {
            var n = Il(u);
            if (n !== null) switch (n.tag) {
              case 3:
                if (n = n.stateNode, n.current.memoizedState.isDehydrated) {
                  var i = Dl(n.pendingLanes);
                  if (i !== 0) {
                    var f = n;
                    for (f.pendingLanes |= 2, f.entangledLanes |= 2; i; ) {
                      var d = 1 << 31 - ee(i);
                      f.entanglements[1] |= d, i &= ~d;
                    }
                    xe(n), (ft & 6) === 0 && (Nn = Pt() + 500, Eu(0));
                  }
                }
                break;
              case 31:
              case 13:
                f = Bl(n, 2), f !== null && It(f, n, 2), Bn(), Tf(n, 2);
            }
            if (n = _f(a), n === null && rf(t, e, a, Fn, l), n === u) break;
            u = n;
          }
          u !== null && a.stopPropagation();
        } else rf(t, e, a, null, l);
      }
    }
    function _f(t) {
      return t = Ri(t), Rf(t);
    }
    var Fn = null;
    function Rf(t) {
      if (Fn = null, t = Fl(t), t !== null) {
        var e = y(t);
        if (e === null) t = null;
        else {
          var l = e.tag;
          if (l === 13) {
            if (t = S(e), t !== null) return t;
            t = null;
          } else if (l === 31) {
            if (t = R(e), t !== null) return t;
            t = null;
          } else if (l === 3) {
            if (e.stateNode.current.memoizedState.isDehydrated) return e.tag === 3 ? e.stateNode.containerInfo : null;
            t = null;
          } else e !== t && (t = null);
        }
      }
      return Fn = t, null;
    }
    function Qd(t) {
      switch (t) {
        case "beforetoggle":
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "toggle":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 2;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 8;
        case "message":
          switch (Yh()) {
            case wf:
              return 2;
            case $f:
              return 8;
            case ju:
            case Lh:
              return 32;
            case kf:
              return 268435456;
            default:
              return 32;
          }
        default:
          return 32;
      }
    }
    var Mf = false, Tl = null, Al = null, _l = null, Ou = /* @__PURE__ */ new Map(), Cu = /* @__PURE__ */ new Map(), Rl = [], Iy = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
    function Gd(t, e) {
      switch (t) {
        case "focusin":
        case "focusout":
          Tl = null;
          break;
        case "dragenter":
        case "dragleave":
          Al = null;
          break;
        case "mouseover":
        case "mouseout":
          _l = null;
          break;
        case "pointerover":
        case "pointerout":
          Ou.delete(e.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          Cu.delete(e.pointerId);
      }
    }
    function Du(t, e, l, a, u, n) {
      return t === null || t.nativeEvent !== n ? (t = {
        blockedOn: e,
        domEventName: l,
        eventSystemFlags: a,
        nativeEvent: n,
        targetContainers: [
          u
        ]
      }, e !== null && (e = Il(e), e !== null && Ld(e)), t) : (t.eventSystemFlags |= a, e = t.targetContainers, u !== null && e.indexOf(u) === -1 && e.push(u), t);
    }
    function Py(t, e, l, a, u) {
      switch (e) {
        case "focusin":
          return Tl = Du(Tl, t, e, l, a, u), true;
        case "dragenter":
          return Al = Du(Al, t, e, l, a, u), true;
        case "mouseover":
          return _l = Du(_l, t, e, l, a, u), true;
        case "pointerover":
          var n = u.pointerId;
          return Ou.set(n, Du(Ou.get(n) || null, t, e, l, a, u)), true;
        case "gotpointercapture":
          return n = u.pointerId, Cu.set(n, Du(Cu.get(n) || null, t, e, l, a, u)), true;
      }
      return false;
    }
    function Xd(t) {
      var e = Fl(t.target);
      if (e !== null) {
        var l = y(e);
        if (l !== null) {
          if (e = l.tag, e === 13) {
            if (e = S(l), e !== null) {
              t.blockedOn = e, eo(t.priority, function() {
                jd(l);
              });
              return;
            }
          } else if (e === 31) {
            if (e = R(l), e !== null) {
              t.blockedOn = e, eo(t.priority, function() {
                jd(l);
              });
              return;
            }
          } else if (e === 3 && l.stateNode.current.memoizedState.isDehydrated) {
            t.blockedOn = l.tag === 3 ? l.stateNode.containerInfo : null;
            return;
          }
        }
      }
      t.blockedOn = null;
    }
    function In(t) {
      if (t.blockedOn !== null) return false;
      for (var e = t.targetContainers; 0 < e.length; ) {
        var l = _f(t.nativeEvent);
        if (l === null) {
          l = t.nativeEvent;
          var a = new l.constructor(l.type, l);
          _i = a, l.target.dispatchEvent(a), _i = null;
        } else return e = Il(l), e !== null && Ld(e), t.blockedOn = l, false;
        e.shift();
      }
      return true;
    }
    function Zd(t, e, l) {
      In(t) && l.delete(e);
    }
    function t0() {
      Mf = false, Tl !== null && In(Tl) && (Tl = null), Al !== null && In(Al) && (Al = null), _l !== null && In(_l) && (_l = null), Ou.forEach(Zd), Cu.forEach(Zd);
    }
    function Pn(t, e) {
      t.blockedOn === e && (t.blockedOn = null, Mf || (Mf = true, c.unstable_scheduleCallback(c.unstable_NormalPriority, t0)));
    }
    var ti = null;
    function Vd(t) {
      ti !== t && (ti = t, c.unstable_scheduleCallback(c.unstable_NormalPriority, function() {
        ti === t && (ti = null);
        for (var e = 0; e < t.length; e += 3) {
          var l = t[e], a = t[e + 1], u = t[e + 2];
          if (typeof a != "function") {
            if (Rf(a || l) === null) continue;
            break;
          }
          var n = Il(l);
          n !== null && (t.splice(e, 3), e -= 3, Ac(n, {
            pending: true,
            data: u,
            method: l.method,
            action: a
          }, a, u));
        }
      }));
    }
    function Na(t) {
      function e(d) {
        return Pn(d, t);
      }
      Tl !== null && Pn(Tl, t), Al !== null && Pn(Al, t), _l !== null && Pn(_l, t), Ou.forEach(e), Cu.forEach(e);
      for (var l = 0; l < Rl.length; l++) {
        var a = Rl[l];
        a.blockedOn === t && (a.blockedOn = null);
      }
      for (; 0 < Rl.length && (l = Rl[0], l.blockedOn === null); ) Xd(l), l.blockedOn === null && Rl.shift();
      if (l = (t.ownerDocument || t).$$reactFormReplay, l != null) for (a = 0; a < l.length; a += 3) {
        var u = l[a], n = l[a + 1], i = u[Jt] || null;
        if (typeof n == "function") i || Vd(l);
        else if (i) {
          var f = null;
          if (n && n.hasAttribute("formAction")) {
            if (u = n, i = n[Jt] || null) f = i.formAction;
            else if (Rf(u) !== null) continue;
          } else f = i.action;
          typeof f == "function" ? l[a + 1] = f : (l.splice(a, 3), a -= 3), Vd(l);
        }
      }
    }
    function Kd() {
      function t(n) {
        n.canIntercept && n.info === "react-transition" && n.intercept({
          handler: function() {
            return new Promise(function(i) {
              return u = i;
            });
          },
          focusReset: "manual",
          scroll: "manual"
        });
      }
      function e() {
        u !== null && (u(), u = null), a || setTimeout(l, 20);
      }
      function l() {
        if (!a && !navigation.transition) {
          var n = navigation.currentEntry;
          n && n.url != null && navigation.navigate(n.url, {
            state: n.getState(),
            info: "react-transition",
            history: "replace"
          });
        }
      }
      if (typeof navigation == "object") {
        var a = false, u = null;
        return navigation.addEventListener("navigate", t), navigation.addEventListener("navigatesuccess", e), navigation.addEventListener("navigateerror", e), setTimeout(l, 100), function() {
          a = true, navigation.removeEventListener("navigate", t), navigation.removeEventListener("navigatesuccess", e), navigation.removeEventListener("navigateerror", e), u !== null && (u(), u = null);
        };
      }
    }
    function Of(t) {
      this._internalRoot = t;
    }
    ei.prototype.render = Of.prototype.render = function(t) {
      var e = this._internalRoot;
      if (e === null) throw Error(o(409));
      var l = e.current, a = fe();
      qd(l, a, t, e, null, null);
    }, ei.prototype.unmount = Of.prototype.unmount = function() {
      var t = this._internalRoot;
      if (t !== null) {
        this._internalRoot = null;
        var e = t.containerInfo;
        qd(t.current, 2, null, t, null, null), Bn(), e[Wl] = null;
      }
    };
    function ei(t) {
      this._internalRoot = t;
    }
    ei.prototype.unstable_scheduleHydration = function(t) {
      if (t) {
        var e = to();
        t = {
          blockedOn: null,
          target: t,
          priority: e
        };
        for (var l = 0; l < Rl.length && e !== 0 && e < Rl[l].priority; l++) ;
        Rl.splice(l, 0, t), l === 0 && Xd(t);
      }
    };
    var Jd = s.version;
    if (Jd !== "19.2.3") throw Error(o(527, Jd, "19.2.3"));
    lt.findDOMNode = function(t) {
      var e = t._reactInternals;
      if (e === void 0) throw typeof t.render == "function" ? Error(o(188)) : (t = Object.keys(t).join(","), Error(o(268, t)));
      return t = h(e), t = t !== null ? C(t) : null, t = t === null ? null : t.stateNode, t;
    };
    var e0 = {
      bundleType: 0,
      version: "19.2.3",
      rendererPackageName: "react-dom",
      currentDispatcherRef: X,
      reconcilerVersion: "19.2.3"
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
      var li = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!li.isDisabled && li.supportsFiber) try {
        ja = li.inject(e0), te = li;
      } catch {
      }
    }
    return xu.createRoot = function(t, e) {
      if (!v(t)) throw Error(o(299));
      var l = false, a = "", u = Pr, n = ts, i = es;
      return e != null && (e.unstable_strictMode === true && (l = true), e.identifierPrefix !== void 0 && (a = e.identifierPrefix), e.onUncaughtError !== void 0 && (u = e.onUncaughtError), e.onCaughtError !== void 0 && (n = e.onCaughtError), e.onRecoverableError !== void 0 && (i = e.onRecoverableError)), e = Hd(t, 1, false, null, null, l, a, null, u, n, i, Kd), t[Wl] = e.current, of(t), new Of(e);
    }, xu.hydrateRoot = function(t, e, l) {
      if (!v(t)) throw Error(o(299));
      var a = false, u = "", n = Pr, i = ts, f = es, d = null;
      return l != null && (l.unstable_strictMode === true && (a = true), l.identifierPrefix !== void 0 && (u = l.identifierPrefix), l.onUncaughtError !== void 0 && (n = l.onUncaughtError), l.onCaughtError !== void 0 && (i = l.onCaughtError), l.onRecoverableError !== void 0 && (f = l.onRecoverableError), l.formState !== void 0 && (d = l.formState)), e = Hd(t, 1, true, e, l ?? null, a, u, d, n, i, f, Kd), e.context = Bd(null), l = e.current, a = fe(), a = gi(a), u = sl(a), u.callback = null, dl(l, u, a), l = a, e.current.lanes = l, Ga(e, l), xe(e), t[Wl] = e.current, of(t), new ei(e);
    }, xu.version = "19.2.3", xu;
  }
  var th;
  function s0() {
    if (th) return Uf.exports;
    th = 1;
    function c() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(c);
      } catch (s) {
        console.error(s);
      }
    }
    return c(), Uf.exports = r0(), Uf.exports;
  }
  O1 = s0();
  var eh = "popstate";
  function d0(c = {}) {
    function s(v, y) {
      let { pathname: S = "/", search: R = "", hash: b = "" } = $l(v.location.hash.substring(1));
      return !S.startsWith("/") && !S.startsWith(".") && (S = "/" + S), qf("", {
        pathname: S,
        search: R,
        hash: b
      }, y.state && y.state.usr || null, y.state && y.state.key || "default");
    }
    function r(v, y) {
      let S = v.document.querySelector("base"), R = "";
      if (S && S.getAttribute("href")) {
        let b = v.location.href, h = b.indexOf("#");
        R = h === -1 ? b : b.slice(0, h);
      }
      return R + "#" + (typeof y == "string" ? y : Hu(y));
    }
    function o(v, y) {
      oe(v.pathname.charAt(0) === "/", `relative pathnames are not supported in hash history.push(${JSON.stringify(y)})`);
    }
    return m0(s, r, o, c);
  }
  function Et(c, s) {
    if (c === false || c === null || typeof c > "u") throw new Error(s);
  }
  function oe(c, s) {
    if (!c) {
      typeof console < "u" && console.warn(s);
      try {
        throw new Error(s);
      } catch {
      }
    }
  }
  function h0() {
    return Math.random().toString(36).substring(2, 10);
  }
  function lh(c, s) {
    return {
      usr: c.state,
      key: c.key,
      idx: s
    };
  }
  function qf(c, s, r = null, o) {
    return {
      pathname: typeof c == "string" ? c : c.pathname,
      search: "",
      hash: "",
      ...typeof s == "string" ? $l(s) : s,
      state: r,
      key: s && s.key || o || h0()
    };
  }
  function Hu({ pathname: c = "/", search: s = "", hash: r = "" }) {
    return s && s !== "?" && (c += s.charAt(0) === "?" ? s : "?" + s), r && r !== "#" && (c += r.charAt(0) === "#" ? r : "#" + r), c;
  }
  function $l(c) {
    let s = {};
    if (c) {
      let r = c.indexOf("#");
      r >= 0 && (s.hash = c.substring(r), c = c.substring(0, r));
      let o = c.indexOf("?");
      o >= 0 && (s.search = c.substring(o), c = c.substring(0, o)), c && (s.pathname = c);
    }
    return s;
  }
  function m0(c, s, r, o = {}) {
    let { window: v = document.defaultView, v5Compat: y = false } = o, S = v.history, R = "POP", b = null, h = C();
    h == null && (h = 0, S.replaceState({
      ...S.state,
      idx: h
    }, ""));
    function C() {
      return (S.state || {
        idx: null
      }).idx;
    }
    function _() {
      R = "POP";
      let L = C(), N = L == null ? null : L - h;
      h = L, b && b({
        action: R,
        location: Y.location,
        delta: N
      });
    }
    function q(L, N) {
      R = "PUSH";
      let H = qf(Y.location, L, N);
      r && r(H, L), h = C() + 1;
      let w = lh(H, h), zt = Y.createHref(H);
      try {
        S.pushState(w, "", zt);
      } catch (gt) {
        if (gt instanceof DOMException && gt.name === "DataCloneError") throw gt;
        v.location.assign(zt);
      }
      y && b && b({
        action: R,
        location: Y.location,
        delta: 1
      });
    }
    function Z(L, N) {
      R = "REPLACE";
      let H = qf(Y.location, L, N);
      r && r(H, L), h = C();
      let w = lh(H, h), zt = Y.createHref(H);
      S.replaceState(w, "", zt), y && b && b({
        action: R,
        location: Y.location,
        delta: 0
      });
    }
    function G(L) {
      return y0(L);
    }
    let Y = {
      get action() {
        return R;
      },
      get location() {
        return c(v, S);
      },
      listen(L) {
        if (b) throw new Error("A history only accepts one active listener");
        return v.addEventListener(eh, _), b = L, () => {
          v.removeEventListener(eh, _), b = null;
        };
      },
      createHref(L) {
        return s(v, L);
      },
      createURL: G,
      encodeLocation(L) {
        let N = G(L);
        return {
          pathname: N.pathname,
          search: N.search,
          hash: N.hash
        };
      },
      push: q,
      replace: Z,
      go(L) {
        return S.go(L);
      }
    };
    return Y;
  }
  function y0(c, s = false) {
    let r = "http://localhost";
    typeof window < "u" && (r = window.location.origin !== "null" ? window.location.origin : window.location.href), Et(r, "No window.location.(origin|href) available to create URL");
    let o = typeof c == "string" ? c : Hu(c);
    return o = o.replace(/ $/, "%20"), !s && o.startsWith("//") && (o = r + o), new URL(o, r);
  }
  function hh(c, s, r = "/") {
    return v0(c, s, r, false);
  }
  function v0(c, s, r, o) {
    let v = typeof s == "string" ? $l(s) : s, y = tl(v.pathname || "/", r);
    if (y == null) return null;
    let S = mh(c);
    g0(S);
    let R = null;
    for (let b = 0; R == null && b < S.length; ++b) {
      let h = O0(y);
      R = R0(S[b], h, o);
    }
    return R;
  }
  function mh(c, s = [], r = [], o = "", v = false) {
    let y = (S, R, b = v, h) => {
      let C = {
        relativePath: h === void 0 ? S.path || "" : h,
        caseSensitive: S.caseSensitive === true,
        childrenIndex: R,
        route: S
      };
      if (C.relativePath.startsWith("/")) {
        if (!C.relativePath.startsWith(o) && b) return;
        Et(C.relativePath.startsWith(o), `Absolute route path "${C.relativePath}" nested under path "${o}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`), C.relativePath = C.relativePath.slice(o.length);
      }
      let _ = Pe([
        o,
        C.relativePath
      ]), q = r.concat(C);
      S.children && S.children.length > 0 && (Et(S.index !== true, `Index routes must not have child routes. Please remove all child routes from route path "${_}".`), mh(S.children, s, q, _, b)), !(S.path == null && !S.index) && s.push({
        path: _,
        score: A0(_, S.index),
        routesMeta: q
      });
    };
    return c.forEach((S, R) => {
      var _a;
      if (S.path === "" || !((_a = S.path) == null ? void 0 : _a.includes("?"))) y(S, R);
      else for (let b of yh(S.path)) y(S, R, true, b);
    }), s;
  }
  function yh(c) {
    let s = c.split("/");
    if (s.length === 0) return [];
    let [r, ...o] = s, v = r.endsWith("?"), y = r.replace(/\?$/, "");
    if (o.length === 0) return v ? [
      y,
      ""
    ] : [
      y
    ];
    let S = yh(o.join("/")), R = [];
    return R.push(...S.map((b) => b === "" ? y : [
      y,
      b
    ].join("/"))), v && R.push(...S), R.map((b) => c.startsWith("/") && b === "" ? "/" : b);
  }
  function g0(c) {
    c.sort((s, r) => s.score !== r.score ? r.score - s.score : _0(s.routesMeta.map((o) => o.childrenIndex), r.routesMeta.map((o) => o.childrenIndex)));
  }
  var p0 = /^:[\w-]+$/, S0 = 3, b0 = 2, E0 = 1, z0 = 10, T0 = -2, ah = (c) => c === "*";
  function A0(c, s) {
    let r = c.split("/"), o = r.length;
    return r.some(ah) && (o += T0), s && (o += b0), r.filter((v) => !ah(v)).reduce((v, y) => v + (p0.test(y) ? S0 : y === "" ? E0 : z0), o);
  }
  function _0(c, s) {
    return c.length === s.length && c.slice(0, -1).every((o, v) => o === s[v]) ? c[c.length - 1] - s[s.length - 1] : 0;
  }
  function R0(c, s, r = false) {
    let { routesMeta: o } = c, v = {}, y = "/", S = [];
    for (let R = 0; R < o.length; ++R) {
      let b = o[R], h = R === o.length - 1, C = y === "/" ? s : s.slice(y.length) || "/", _ = ci({
        path: b.relativePath,
        caseSensitive: b.caseSensitive,
        end: h
      }, C), q = b.route;
      if (!_ && h && r && !o[o.length - 1].route.index && (_ = ci({
        path: b.relativePath,
        caseSensitive: b.caseSensitive,
        end: false
      }, C)), !_) return null;
      Object.assign(v, _.params), S.push({
        params: v,
        pathname: Pe([
          y,
          _.pathname
        ]),
        pathnameBase: x0(Pe([
          y,
          _.pathnameBase
        ])),
        route: q
      }), _.pathnameBase !== "/" && (y = Pe([
        y,
        _.pathnameBase
      ]));
    }
    return S;
  }
  function ci(c, s) {
    typeof c == "string" && (c = {
      path: c,
      caseSensitive: false,
      end: true
    });
    let [r, o] = M0(c.path, c.caseSensitive, c.end), v = s.match(r);
    if (!v) return null;
    let y = v[0], S = y.replace(/(.)\/+$/, "$1"), R = v.slice(1);
    return {
      params: o.reduce((h, { paramName: C, isOptional: _ }, q) => {
        if (C === "*") {
          let G = R[q] || "";
          S = y.slice(0, y.length - G.length).replace(/(.)\/+$/, "$1");
        }
        const Z = R[q];
        return _ && !Z ? h[C] = void 0 : h[C] = (Z || "").replace(/%2F/g, "/"), h;
      }, {}),
      pathname: y,
      pathnameBase: S,
      pattern: c
    };
  }
  function M0(c, s = false, r = true) {
    oe(c === "*" || !c.endsWith("*") || c.endsWith("/*"), `Route path "${c}" will be treated as if it were "${c.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${c.replace(/\*$/, "/*")}".`);
    let o = [], v = "^" + c.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (S, R, b) => (o.push({
      paramName: R,
      isOptional: b != null
    }), b ? "/?([^\\/]+)?" : "/([^\\/]+)")).replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
    return c.endsWith("*") ? (o.push({
      paramName: "*"
    }), v += c === "*" || c === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : r ? v += "\\/*$" : c !== "" && c !== "/" && (v += "(?:(?=\\/|$))"), [
      new RegExp(v, s ? void 0 : "i"),
      o
    ];
  }
  function O0(c) {
    try {
      return c.split("/").map((s) => decodeURIComponent(s).replace(/\//g, "%2F")).join("/");
    } catch (s) {
      return oe(false, `The URL path "${c}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${s}).`), c;
    }
  }
  function tl(c, s) {
    if (s === "/") return c;
    if (!c.toLowerCase().startsWith(s.toLowerCase())) return null;
    let r = s.endsWith("/") ? s.length - 1 : s.length, o = c.charAt(r);
    return o && o !== "/" ? null : c.slice(r) || "/";
  }
  var vh = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i, C0 = (c) => vh.test(c);
  function D0(c, s = "/") {
    let { pathname: r, search: o = "", hash: v = "" } = typeof c == "string" ? $l(c) : c, y;
    if (r) if (C0(r)) y = r;
    else {
      if (r.includes("//")) {
        let S = r;
        r = r.replace(/\/\/+/g, "/"), oe(false, `Pathnames cannot have embedded double slashes - normalizing ${S} -> ${r}`);
      }
      r.startsWith("/") ? y = uh(r.substring(1), "/") : y = uh(r, s);
    }
    else y = s;
    return {
      pathname: y,
      search: N0(o),
      hash: H0(v)
    };
  }
  function uh(c, s) {
    let r = s.replace(/\/+$/, "").split("/");
    return c.split("/").forEach((v) => {
      v === ".." ? r.length > 1 && r.pop() : v !== "." && r.push(v);
    }), r.length > 1 ? r.join("/") : "/";
  }
  function Nf(c, s, r, o) {
    return `Cannot include a '${c}' character in a manually specified \`to.${s}\` field [${JSON.stringify(o)}].  Please separate it out to the \`to.${r}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
  }
  function U0(c) {
    return c.filter((s, r) => r === 0 || s.route.path && s.route.path.length > 0);
  }
  function Lf(c) {
    let s = U0(c);
    return s.map((r, o) => o === s.length - 1 ? r.pathname : r.pathnameBase);
  }
  function jf(c, s, r, o = false) {
    let v;
    typeof c == "string" ? v = $l(c) : (v = {
      ...c
    }, Et(!v.pathname || !v.pathname.includes("?"), Nf("?", "pathname", "search", v)), Et(!v.pathname || !v.pathname.includes("#"), Nf("#", "pathname", "hash", v)), Et(!v.search || !v.search.includes("#"), Nf("#", "search", "hash", v)));
    let y = c === "" || v.pathname === "", S = y ? "/" : v.pathname, R;
    if (S == null) R = r;
    else {
      let _ = s.length - 1;
      if (!o && S.startsWith("..")) {
        let q = S.split("/");
        for (; q[0] === ".."; ) q.shift(), _ -= 1;
        v.pathname = q.join("/");
      }
      R = _ >= 0 ? s[_] : "/";
    }
    let b = D0(v, R), h = S && S !== "/" && S.endsWith("/"), C = (y || S === ".") && r.endsWith("/");
    return !b.pathname.endsWith("/") && (h || C) && (b.pathname += "/"), b;
  }
  var Pe = (c) => c.join("/").replace(/\/\/+/g, "/"), x0 = (c) => c.replace(/\/+$/, "").replace(/^\/*/, "/"), N0 = (c) => !c || c === "?" ? "" : c.startsWith("?") ? c : "?" + c, H0 = (c) => !c || c === "#" ? "" : c.startsWith("#") ? c : "#" + c, B0 = class {
    constructor(c, s, r, o = false) {
      this.status = c, this.statusText = s || "", this.internal = o, r instanceof Error ? (this.data = r.toString(), this.error = r) : this.data = r;
    }
  };
  function q0(c) {
    return c != null && typeof c.status == "number" && typeof c.statusText == "string" && typeof c.internal == "boolean" && "data" in c;
  }
  function Y0(c) {
    return c.map((s) => s.route.path).filter(Boolean).join("/").replace(/\/\/*/g, "/") || "/";
  }
  var gh = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u";
  function ph(c, s) {
    let r = c;
    if (typeof r != "string" || !vh.test(r)) return {
      absoluteURL: void 0,
      isExternal: false,
      to: r
    };
    let o = r, v = false;
    if (gh) try {
      let y = new URL(window.location.href), S = r.startsWith("//") ? new URL(y.protocol + r) : new URL(r), R = tl(S.pathname, s);
      S.origin === y.origin && R != null ? r = R + S.search + S.hash : v = true;
    } catch {
      oe(false, `<Link to="${r}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`);
    }
    return {
      absoluteURL: o,
      isExternal: v,
      to: r
    };
  }
  Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
  var Sh = [
    "POST",
    "PUT",
    "PATCH",
    "DELETE"
  ];
  new Set(Sh);
  var L0 = [
    "GET",
    ...Sh
  ];
  new Set(L0);
  var qa = O.createContext(null);
  qa.displayName = "DataRouter";
  var fi = O.createContext(null);
  fi.displayName = "DataRouterState";
  var j0 = O.createContext(false), bh = O.createContext({
    isTransitioning: false
  });
  bh.displayName = "ViewTransition";
  var Q0 = O.createContext(/* @__PURE__ */ new Map());
  Q0.displayName = "Fetchers";
  var G0 = O.createContext(null);
  G0.displayName = "Await";
  var re = O.createContext(null);
  re.displayName = "Navigation";
  var qu = O.createContext(null);
  qu.displayName = "Location";
  var Ne = O.createContext({
    outlet: null,
    matches: [],
    isDataRoute: false
  });
  Ne.displayName = "Route";
  var Qf = O.createContext(null);
  Qf.displayName = "RouteError";
  var Eh = "REACT_ROUTER_ERROR", X0 = "REDIRECT", Z0 = "ROUTE_ERROR_RESPONSE";
  function V0(c) {
    if (c.startsWith(`${Eh}:${X0}:{`)) try {
      let s = JSON.parse(c.slice(28));
      if (typeof s == "object" && s && typeof s.status == "number" && typeof s.statusText == "string" && typeof s.location == "string" && typeof s.reloadDocument == "boolean" && typeof s.replace == "boolean") return s;
    } catch {
    }
  }
  function K0(c) {
    if (c.startsWith(`${Eh}:${Z0}:{`)) try {
      let s = JSON.parse(c.slice(40));
      if (typeof s == "object" && s && typeof s.status == "number" && typeof s.statusText == "string") return new B0(s.status, s.statusText, s.data);
    } catch {
    }
  }
  function J0(c, { relative: s } = {}) {
    Et(Ya(), "useHref() may be used only in the context of a <Router> component.");
    let { basename: r, navigator: o } = O.useContext(re), { hash: v, pathname: y, search: S } = Yu(c, {
      relative: s
    }), R = y;
    return r !== "/" && (R = y === "/" ? r : Pe([
      r,
      y
    ])), o.createHref({
      pathname: R,
      search: S,
      hash: v
    });
  }
  function Ya() {
    return O.useContext(qu) != null;
  }
  Ol = function() {
    return Et(Ya(), "useLocation() may be used only in the context of a <Router> component."), O.useContext(qu).location;
  };
  var zh = "You should call navigate() in a React.useEffect(), not when your component is first rendered.";
  function Th(c) {
    O.useContext(re).static || O.useLayoutEffect(c);
  }
  Ah = function() {
    let { isDataRoute: c } = O.useContext(Ne);
    return c ? nv() : w0();
  };
  function w0() {
    Et(Ya(), "useNavigate() may be used only in the context of a <Router> component.");
    let c = O.useContext(qa), { basename: s, navigator: r } = O.useContext(re), { matches: o } = O.useContext(Ne), { pathname: v } = Ol(), y = JSON.stringify(Lf(o)), S = O.useRef(false);
    return Th(() => {
      S.current = true;
    }), O.useCallback((b, h = {}) => {
      if (oe(S.current, zh), !S.current) return;
      if (typeof b == "number") {
        r.go(b);
        return;
      }
      let C = jf(b, JSON.parse(y), v, h.relative === "path");
      c == null && s !== "/" && (C.pathname = C.pathname === "/" ? s : Pe([
        s,
        C.pathname
      ])), (h.replace ? r.replace : r.push)(C, h.state, h);
    }, [
      s,
      r,
      y,
      v,
      c
    ]);
  }
  O.createContext(null);
  function Yu(c, { relative: s } = {}) {
    let { matches: r } = O.useContext(Ne), { pathname: o } = Ol(), v = JSON.stringify(Lf(r));
    return O.useMemo(() => jf(c, JSON.parse(v), o, s === "path"), [
      c,
      v,
      o,
      s
    ]);
  }
  function $0(c, s) {
    return _h(c, s);
  }
  function _h(c, s, r, o, v) {
    var _a;
    Et(Ya(), "useRoutes() may be used only in the context of a <Router> component.");
    let { navigator: y } = O.useContext(re), { matches: S } = O.useContext(Ne), R = S[S.length - 1], b = R ? R.params : {}, h = R ? R.pathname : "/", C = R ? R.pathnameBase : "/", _ = R && R.route;
    {
      let H = _ && _.path || "";
      Mh(h, !_ || H.endsWith("*") || H.endsWith("*?"), `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${h}" (under <Route path="${H}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${H}"> to <Route path="${H === "/" ? "*" : `${H}/*`}">.`);
    }
    let q = Ol(), Z;
    if (s) {
      let H = typeof s == "string" ? $l(s) : s;
      Et(C === "/" || ((_a = H.pathname) == null ? void 0 : _a.startsWith(C)), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${C}" but pathname "${H.pathname}" was given in the \`location\` prop.`), Z = H;
    } else Z = q;
    let G = Z.pathname || "/", Y = G;
    if (C !== "/") {
      let H = C.replace(/^\//, "").split("/");
      Y = "/" + G.replace(/^\//, "").split("/").slice(H.length).join("/");
    }
    let L = hh(c, {
      pathname: Y
    });
    oe(_ || L != null, `No routes matched location "${Z.pathname}${Z.search}${Z.hash}" `), oe(L == null || L[L.length - 1].route.element !== void 0 || L[L.length - 1].route.Component !== void 0 || L[L.length - 1].route.lazy !== void 0, `Matched leaf route at location "${Z.pathname}${Z.search}${Z.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);
    let N = P0(L && L.map((H) => Object.assign({}, H, {
      params: Object.assign({}, b, H.params),
      pathname: Pe([
        C,
        y.encodeLocation ? y.encodeLocation(H.pathname.replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : H.pathname
      ]),
      pathnameBase: H.pathnameBase === "/" ? C : Pe([
        C,
        y.encodeLocation ? y.encodeLocation(H.pathnameBase.replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : H.pathnameBase
      ])
    })), S, r, o, v);
    return s && N ? O.createElement(qu.Provider, {
      value: {
        location: {
          pathname: "/",
          search: "",
          hash: "",
          state: null,
          key: "default",
          ...Z
        },
        navigationType: "POP"
      }
    }, N) : N;
  }
  function k0() {
    let c = uv(), s = q0(c) ? `${c.status} ${c.statusText}` : c instanceof Error ? c.message : JSON.stringify(c), r = c instanceof Error ? c.stack : null, o = "rgba(200,200,200, 0.5)", v = {
      padding: "0.5rem",
      backgroundColor: o
    }, y = {
      padding: "2px 4px",
      backgroundColor: o
    }, S = null;
    return console.error("Error handled by React Router default ErrorBoundary:", c), S = O.createElement(O.Fragment, null, O.createElement("p", null, "\u{1F4BF} Hey developer \u{1F44B}"), O.createElement("p", null, "You can provide a way better UX than this when your app throws errors by providing your own ", O.createElement("code", {
      style: y
    }, "ErrorBoundary"), " or", " ", O.createElement("code", {
      style: y
    }, "errorElement"), " prop on your route.")), O.createElement(O.Fragment, null, O.createElement("h2", null, "Unexpected Application Error!"), O.createElement("h3", {
      style: {
        fontStyle: "italic"
      }
    }, s), r ? O.createElement("pre", {
      style: v
    }, r) : null, S);
  }
  var W0 = O.createElement(k0, null), Rh = class extends O.Component {
    constructor(c) {
      super(c), this.state = {
        location: c.location,
        revalidation: c.revalidation,
        error: c.error
      };
    }
    static getDerivedStateFromError(c) {
      return {
        error: c
      };
    }
    static getDerivedStateFromProps(c, s) {
      return s.location !== c.location || s.revalidation !== "idle" && c.revalidation === "idle" ? {
        error: c.error,
        location: c.location,
        revalidation: c.revalidation
      } : {
        error: c.error !== void 0 ? c.error : s.error,
        location: s.location,
        revalidation: c.revalidation || s.revalidation
      };
    }
    componentDidCatch(c, s) {
      this.props.onError ? this.props.onError(c, s) : console.error("React Router caught the following error during render", c);
    }
    render() {
      let c = this.state.error;
      if (this.context && typeof c == "object" && c && "digest" in c && typeof c.digest == "string") {
        const r = K0(c.digest);
        r && (c = r);
      }
      let s = c !== void 0 ? O.createElement(Ne.Provider, {
        value: this.props.routeContext
      }, O.createElement(Qf.Provider, {
        value: c,
        children: this.props.component
      })) : this.props.children;
      return this.context ? O.createElement(F0, {
        error: c
      }, s) : s;
    }
  };
  Rh.contextType = j0;
  var Hf = /* @__PURE__ */ new WeakMap();
  function F0({ children: c, error: s }) {
    let { basename: r } = O.useContext(re);
    if (typeof s == "object" && s && "digest" in s && typeof s.digest == "string") {
      let o = V0(s.digest);
      if (o) {
        let v = Hf.get(s);
        if (v) throw v;
        let y = ph(o.location, r);
        if (gh && !Hf.get(s)) if (y.isExternal || o.reloadDocument) window.location.href = y.absoluteURL || y.to;
        else {
          const S = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(y.to, {
            replace: o.replace
          }));
          throw Hf.set(s, S), S;
        }
        return O.createElement("meta", {
          httpEquiv: "refresh",
          content: `0;url=${y.absoluteURL || y.to}`
        });
      }
    }
    return c;
  }
  function I0({ routeContext: c, match: s, children: r }) {
    let o = O.useContext(qa);
    return o && o.static && o.staticContext && (s.route.errorElement || s.route.ErrorBoundary) && (o.staticContext._deepestRenderedBoundaryId = s.route.id), O.createElement(Ne.Provider, {
      value: c
    }, r);
  }
  function P0(c, s = [], r = null, o = null, v = null) {
    if (c == null) {
      if (!r) return null;
      if (r.errors) c = r.matches;
      else if (s.length === 0 && !r.initialized && r.matches.length > 0) c = r.matches;
      else return null;
    }
    let y = c, S = r == null ? void 0 : r.errors;
    if (S != null) {
      let C = y.findIndex((_) => _.route.id && (S == null ? void 0 : S[_.route.id]) !== void 0);
      Et(C >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(S).join(",")}`), y = y.slice(0, Math.min(y.length, C + 1));
    }
    let R = false, b = -1;
    if (r) for (let C = 0; C < y.length; C++) {
      let _ = y[C];
      if ((_.route.HydrateFallback || _.route.hydrateFallbackElement) && (b = C), _.route.id) {
        let { loaderData: q, errors: Z } = r, G = _.route.loader && !q.hasOwnProperty(_.route.id) && (!Z || Z[_.route.id] === void 0);
        if (_.route.lazy || G) {
          R = true, b >= 0 ? y = y.slice(0, b + 1) : y = [
            y[0]
          ];
          break;
        }
      }
    }
    let h = r && o ? (C, _) => {
      var _a, _b;
      o(C, {
        location: r.location,
        params: ((_b = (_a = r.matches) == null ? void 0 : _a[0]) == null ? void 0 : _b.params) ?? {},
        unstable_pattern: Y0(r.matches),
        errorInfo: _
      });
    } : void 0;
    return y.reduceRight((C, _, q) => {
      let Z, G = false, Y = null, L = null;
      r && (Z = S && _.route.id ? S[_.route.id] : void 0, Y = _.route.errorElement || W0, R && (b < 0 && q === 0 ? (Mh("route-fallback", false, "No `HydrateFallback` element provided to render during initial hydration"), G = true, L = null) : b === q && (G = true, L = _.route.hydrateFallbackElement || null)));
      let N = s.concat(y.slice(0, q + 1)), H = () => {
        let w;
        return Z ? w = Y : G ? w = L : _.route.Component ? w = O.createElement(_.route.Component, null) : _.route.element ? w = _.route.element : w = C, O.createElement(I0, {
          match: _,
          routeContext: {
            outlet: C,
            matches: N,
            isDataRoute: r != null
          },
          children: w
        });
      };
      return r && (_.route.ErrorBoundary || _.route.errorElement || q === 0) ? O.createElement(Rh, {
        location: r.location,
        revalidation: r.revalidation,
        component: Y,
        error: Z,
        children: H(),
        routeContext: {
          outlet: null,
          matches: N,
          isDataRoute: true
        },
        onError: h
      }) : H();
    }, null);
  }
  function Gf(c) {
    return `${c} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
  }
  function tv(c) {
    let s = O.useContext(qa);
    return Et(s, Gf(c)), s;
  }
  function ev(c) {
    let s = O.useContext(fi);
    return Et(s, Gf(c)), s;
  }
  function lv(c) {
    let s = O.useContext(Ne);
    return Et(s, Gf(c)), s;
  }
  function Xf(c) {
    let s = lv(c), r = s.matches[s.matches.length - 1];
    return Et(r.route.id, `${c} can only be used on routes that contain a unique "id"`), r.route.id;
  }
  function av() {
    return Xf("useRouteId");
  }
  function uv() {
    var _a;
    let c = O.useContext(Qf), s = ev("useRouteError"), r = Xf("useRouteError");
    return c !== void 0 ? c : (_a = s.errors) == null ? void 0 : _a[r];
  }
  function nv() {
    let { router: c } = tv("useNavigate"), s = Xf("useNavigate"), r = O.useRef(false);
    return Th(() => {
      r.current = true;
    }), O.useCallback(async (v, y = {}) => {
      oe(r.current, zh), r.current && (typeof v == "number" ? await c.navigate(v) : await c.navigate(v, {
        fromRouteId: s,
        ...y
      }));
    }, [
      c,
      s
    ]);
  }
  var nh = {};
  function Mh(c, s, r) {
    !s && !nh[c] && (nh[c] = true, oe(false, r));
  }
  O.memo(iv);
  function iv({ routes: c, future: s, state: r, onError: o }) {
    return _h(c, void 0, r, o, s);
  }
  C1 = function({ to: c, replace: s, state: r, relative: o }) {
    Et(Ya(), "<Navigate> may be used only in the context of a <Router> component.");
    let { static: v } = O.useContext(re);
    oe(!v, "<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");
    let { matches: y } = O.useContext(Ne), { pathname: S } = Ol(), R = Ah(), b = jf(c, Lf(y), S, o === "path"), h = JSON.stringify(b);
    return O.useEffect(() => {
      R(JSON.parse(h), {
        replace: s,
        state: r,
        relative: o
      });
    }, [
      R,
      h,
      o,
      s,
      r
    ]), null;
  };
  cv = function(c) {
    Et(false, "A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.");
  };
  function fv({ basename: c = "/", children: s = null, location: r, navigationType: o = "POP", navigator: v, static: y = false, unstable_useTransitions: S }) {
    Et(!Ya(), "You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");
    let R = c.replace(/^\/*/, "/"), b = O.useMemo(() => ({
      basename: R,
      navigator: v,
      static: y,
      unstable_useTransitions: S,
      future: {}
    }), [
      R,
      v,
      y,
      S
    ]);
    typeof r == "string" && (r = $l(r));
    let { pathname: h = "/", search: C = "", hash: _ = "", state: q = null, key: Z = "default" } = r, G = O.useMemo(() => {
      let Y = tl(h, R);
      return Y == null ? null : {
        location: {
          pathname: Y,
          search: C,
          hash: _,
          state: q,
          key: Z
        },
        navigationType: o
      };
    }, [
      R,
      h,
      C,
      _,
      q,
      Z,
      o
    ]);
    return oe(G != null, `<Router basename="${R}"> is not able to match the URL "${h}${C}${_}" because it does not start with the basename, so the <Router> won't render anything.`), G == null ? null : O.createElement(re.Provider, {
      value: b
    }, O.createElement(qu.Provider, {
      children: s,
      value: G
    }));
  }
  D1 = function({ children: c, location: s }) {
    return $0(Yf(c), s);
  };
  function Yf(c, s = []) {
    let r = [];
    return O.Children.forEach(c, (o, v) => {
      if (!O.isValidElement(o)) return;
      let y = [
        ...s,
        v
      ];
      if (o.type === O.Fragment) {
        r.push.apply(r, Yf(o.props.children, y));
        return;
      }
      Et(o.type === cv, `[${typeof o.type == "string" ? o.type : o.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`), Et(!o.props.index || !o.props.children, "An index route cannot have child routes.");
      let S = {
        id: o.props.id || y.join("-"),
        caseSensitive: o.props.caseSensitive,
        element: o.props.element,
        Component: o.props.Component,
        index: o.props.index,
        path: o.props.path,
        middleware: o.props.middleware,
        loader: o.props.loader,
        action: o.props.action,
        hydrateFallbackElement: o.props.hydrateFallbackElement,
        HydrateFallback: o.props.HydrateFallback,
        errorElement: o.props.errorElement,
        ErrorBoundary: o.props.ErrorBoundary,
        hasErrorBoundary: o.props.hasErrorBoundary === true || o.props.ErrorBoundary != null || o.props.errorElement != null,
        shouldRevalidate: o.props.shouldRevalidate,
        handle: o.props.handle,
        lazy: o.props.lazy
      };
      o.props.children && (S.children = Yf(o.props.children, y)), r.push(S);
    }), r;
  }
  var ni = "get", ii = "application/x-www-form-urlencoded";
  function oi(c) {
    return typeof HTMLElement < "u" && c instanceof HTMLElement;
  }
  function ov(c) {
    return oi(c) && c.tagName.toLowerCase() === "button";
  }
  function rv(c) {
    return oi(c) && c.tagName.toLowerCase() === "form";
  }
  function sv(c) {
    return oi(c) && c.tagName.toLowerCase() === "input";
  }
  function dv(c) {
    return !!(c.metaKey || c.altKey || c.ctrlKey || c.shiftKey);
  }
  function hv(c, s) {
    return c.button === 0 && (!s || s === "_self") && !dv(c);
  }
  var ai = null;
  function mv() {
    if (ai === null) try {
      new FormData(document.createElement("form"), 0), ai = false;
    } catch {
      ai = true;
    }
    return ai;
  }
  var yv = /* @__PURE__ */ new Set([
    "application/x-www-form-urlencoded",
    "multipart/form-data",
    "text/plain"
  ]);
  function Bf(c) {
    return c != null && !yv.has(c) ? (oe(false, `"${c}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${ii}"`), null) : c;
  }
  function vv(c, s) {
    let r, o, v, y, S;
    if (rv(c)) {
      let R = c.getAttribute("action");
      o = R ? tl(R, s) : null, r = c.getAttribute("method") || ni, v = Bf(c.getAttribute("enctype")) || ii, y = new FormData(c);
    } else if (ov(c) || sv(c) && (c.type === "submit" || c.type === "image")) {
      let R = c.form;
      if (R == null) throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');
      let b = c.getAttribute("formaction") || R.getAttribute("action");
      if (o = b ? tl(b, s) : null, r = c.getAttribute("formmethod") || R.getAttribute("method") || ni, v = Bf(c.getAttribute("formenctype")) || Bf(R.getAttribute("enctype")) || ii, y = new FormData(R, c), !mv()) {
        let { name: h, type: C, value: _ } = c;
        if (C === "image") {
          let q = h ? `${h}.` : "";
          y.append(`${q}x`, "0"), y.append(`${q}y`, "0");
        } else h && y.append(h, _);
      }
    } else {
      if (oi(c)) throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');
      r = ni, o = null, v = ii, S = c;
    }
    return y && v === "text/plain" && (S = y, y = void 0), {
      action: o,
      method: r.toLowerCase(),
      encType: v,
      formData: y,
      body: S
    };
  }
  Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
  function Zf(c, s) {
    if (c === false || c === null || typeof c > "u") throw new Error(s);
  }
  function gv(c, s, r) {
    let o = typeof c == "string" ? new URL(c, typeof window > "u" ? "server://singlefetch/" : window.location.origin) : c;
    return o.pathname === "/" ? o.pathname = `_root.${r}` : s && tl(o.pathname, s) === "/" ? o.pathname = `${s.replace(/\/$/, "")}/_root.${r}` : o.pathname = `${o.pathname.replace(/\/$/, "")}.${r}`, o;
  }
  async function pv(c, s) {
    if (c.id in s) return s[c.id];
    try {
      let r = await import(c.module).then(async (m) => {
        await m.__tla;
        return m;
      });
      return s[c.id] = r, r;
    } catch (r) {
      return console.error(`Error loading route module \`${c.module}\`, reloading page...`), console.error(r), window.__reactRouterContext && window.__reactRouterContext.isSpaMode, window.location.reload(), new Promise(() => {
      });
    }
  }
  function Sv(c) {
    return c == null ? false : c.href == null ? c.rel === "preload" && typeof c.imageSrcSet == "string" && typeof c.imageSizes == "string" : typeof c.rel == "string" && typeof c.href == "string";
  }
  async function bv(c, s, r) {
    let o = await Promise.all(c.map(async (v) => {
      let y = s.routes[v.route.id];
      if (y) {
        let S = await pv(y, r);
        return S.links ? S.links() : [];
      }
      return [];
    }));
    return Av(o.flat(1).filter(Sv).filter((v) => v.rel === "stylesheet" || v.rel === "preload").map((v) => v.rel === "stylesheet" ? {
      ...v,
      rel: "prefetch",
      as: "style"
    } : {
      ...v,
      rel: "prefetch"
    }));
  }
  function ih(c, s, r, o, v, y) {
    let S = (b, h) => r[h] ? b.route.id !== r[h].route.id : true, R = (b, h) => {
      var _a;
      return r[h].pathname !== b.pathname || ((_a = r[h].route.path) == null ? void 0 : _a.endsWith("*")) && r[h].params["*"] !== b.params["*"];
    };
    return y === "assets" ? s.filter((b, h) => S(b, h) || R(b, h)) : y === "data" ? s.filter((b, h) => {
      var _a;
      let C = o.routes[b.route.id];
      if (!C || !C.hasLoader) return false;
      if (S(b, h) || R(b, h)) return true;
      if (b.route.shouldRevalidate) {
        let _ = b.route.shouldRevalidate({
          currentUrl: new URL(v.pathname + v.search + v.hash, window.origin),
          currentParams: ((_a = r[0]) == null ? void 0 : _a.params) || {},
          nextUrl: new URL(c, window.origin),
          nextParams: b.params,
          defaultShouldRevalidate: true
        });
        if (typeof _ == "boolean") return _;
      }
      return true;
    }) : [];
  }
  function Ev(c, s, { includeHydrateFallback: r } = {}) {
    return zv(c.map((o) => {
      let v = s.routes[o.route.id];
      if (!v) return [];
      let y = [
        v.module
      ];
      return v.clientActionModule && (y = y.concat(v.clientActionModule)), v.clientLoaderModule && (y = y.concat(v.clientLoaderModule)), r && v.hydrateFallbackModule && (y = y.concat(v.hydrateFallbackModule)), v.imports && (y = y.concat(v.imports)), y;
    }).flat(1));
  }
  function zv(c) {
    return [
      ...new Set(c)
    ];
  }
  function Tv(c) {
    let s = {}, r = Object.keys(c).sort();
    for (let o of r) s[o] = c[o];
    return s;
  }
  function Av(c, s) {
    let r = /* @__PURE__ */ new Set();
    return new Set(s), c.reduce((o, v) => {
      let y = JSON.stringify(Tv(v));
      return r.has(y) || (r.add(y), o.push({
        key: y,
        link: v
      })), o;
    }, []);
  }
  function Oh() {
    let c = O.useContext(qa);
    return Zf(c, "You must render this element inside a <DataRouterContext.Provider> element"), c;
  }
  function _v() {
    let c = O.useContext(fi);
    return Zf(c, "You must render this element inside a <DataRouterStateContext.Provider> element"), c;
  }
  var Vf = O.createContext(void 0);
  Vf.displayName = "FrameworkContext";
  function Ch() {
    let c = O.useContext(Vf);
    return Zf(c, "You must render this element inside a <HydratedRouter> element"), c;
  }
  function Rv(c, s) {
    let r = O.useContext(Vf), [o, v] = O.useState(false), [y, S] = O.useState(false), { onFocus: R, onBlur: b, onMouseEnter: h, onMouseLeave: C, onTouchStart: _ } = s, q = O.useRef(null);
    O.useEffect(() => {
      if (c === "render" && S(true), c === "viewport") {
        let Y = (N) => {
          N.forEach((H) => {
            S(H.isIntersecting);
          });
        }, L = new IntersectionObserver(Y, {
          threshold: 0.5
        });
        return q.current && L.observe(q.current), () => {
          L.disconnect();
        };
      }
    }, [
      c
    ]), O.useEffect(() => {
      if (o) {
        let Y = setTimeout(() => {
          S(true);
        }, 100);
        return () => {
          clearTimeout(Y);
        };
      }
    }, [
      o
    ]);
    let Z = () => {
      v(true);
    }, G = () => {
      v(false), S(false);
    };
    return r ? c !== "intent" ? [
      y,
      q,
      {}
    ] : [
      y,
      q,
      {
        onFocus: Nu(R, Z),
        onBlur: Nu(b, G),
        onMouseEnter: Nu(h, Z),
        onMouseLeave: Nu(C, G),
        onTouchStart: Nu(_, Z)
      }
    ] : [
      false,
      q,
      {}
    ];
  }
  function Nu(c, s) {
    return (r) => {
      c && c(r), r.defaultPrevented || s(r);
    };
  }
  function Mv({ page: c, ...s }) {
    let { router: r } = Oh(), o = O.useMemo(() => hh(r.routes, c, r.basename), [
      r.routes,
      c,
      r.basename
    ]);
    return o ? O.createElement(Cv, {
      page: c,
      matches: o,
      ...s
    }) : null;
  }
  function Ov(c) {
    let { manifest: s, routeModules: r } = Ch(), [o, v] = O.useState([]);
    return O.useEffect(() => {
      let y = false;
      return bv(c, s, r).then((S) => {
        y || v(S);
      }), () => {
        y = true;
      };
    }, [
      c,
      s,
      r
    ]), o;
  }
  function Cv({ page: c, matches: s, ...r }) {
    let o = Ol(), { manifest: v, routeModules: y } = Ch(), { basename: S } = Oh(), { loaderData: R, matches: b } = _v(), h = O.useMemo(() => ih(c, s, b, v, o, "data"), [
      c,
      s,
      b,
      v,
      o
    ]), C = O.useMemo(() => ih(c, s, b, v, o, "assets"), [
      c,
      s,
      b,
      v,
      o
    ]), _ = O.useMemo(() => {
      if (c === o.pathname + o.search + o.hash) return [];
      let G = /* @__PURE__ */ new Set(), Y = false;
      if (s.forEach((N) => {
        var _a;
        let H = v.routes[N.route.id];
        !H || !H.hasLoader || (!h.some((w) => w.route.id === N.route.id) && N.route.id in R && ((_a = y[N.route.id]) == null ? void 0 : _a.shouldRevalidate) || H.hasClientLoader ? Y = true : G.add(N.route.id));
      }), G.size === 0) return [];
      let L = gv(c, S, "data");
      return Y && G.size > 0 && L.searchParams.set("_routes", s.filter((N) => G.has(N.route.id)).map((N) => N.route.id).join(",")), [
        L.pathname + L.search
      ];
    }, [
      S,
      R,
      o,
      v,
      h,
      s,
      c,
      y
    ]), q = O.useMemo(() => Ev(C, v), [
      C,
      v
    ]), Z = Ov(C);
    return O.createElement(O.Fragment, null, _.map((G) => O.createElement("link", {
      key: G,
      rel: "prefetch",
      as: "fetch",
      href: G,
      ...r
    })), q.map((G) => O.createElement("link", {
      key: G,
      rel: "modulepreload",
      href: G,
      ...r
    })), Z.map(({ key: G, link: Y }) => O.createElement("link", {
      key: G,
      nonce: r.nonce,
      ...Y
    })));
  }
  function Dv(...c) {
    return (s) => {
      c.forEach((r) => {
        typeof r == "function" ? r(s) : r != null && (r.current = s);
      });
    };
  }
  var Uv = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u";
  try {
    Uv && (window.__reactRouterVersion = "7.11.0");
  } catch {
  }
  U1 = function({ basename: c, children: s, unstable_useTransitions: r, window: o }) {
    let v = O.useRef();
    v.current == null && (v.current = d0({
      window: o,
      v5Compat: true
    }));
    let y = v.current, [S, R] = O.useState({
      action: y.action,
      location: y.location
    }), b = O.useCallback((h) => {
      r === false ? R(h) : O.startTransition(() => R(h));
    }, [
      r
    ]);
    return O.useLayoutEffect(() => y.listen(b), [
      y,
      b
    ]), O.createElement(fv, {
      basename: c,
      children: s,
      location: S.location,
      navigationType: S.action,
      navigator: y,
      unstable_useTransitions: r
    });
  };
  var Dh = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i, Uh = O.forwardRef(function({ onClick: s, discover: r = "render", prefetch: o = "none", relative: v, reloadDocument: y, replace: S, state: R, target: b, to: h, preventScrollReset: C, viewTransition: _, unstable_defaultShouldRevalidate: q, ...Z }, G) {
    let { basename: Y, unstable_useTransitions: L } = O.useContext(re), N = typeof h == "string" && Dh.test(h), H = ph(h, Y);
    h = H.to;
    let w = J0(h, {
      relative: v
    }), [zt, gt, qt] = Rv(o, Z), F = Bv(h, {
      replace: S,
      state: R,
      target: b,
      preventScrollReset: C,
      relative: v,
      viewTransition: _,
      unstable_defaultShouldRevalidate: q,
      unstable_useTransitions: L
    });
    function Ot(Ee) {
      s && s(Ee), Ee.defaultPrevented || F(Ee);
    }
    let Xt = O.createElement("a", {
      ...Z,
      ...qt,
      href: H.absoluteURL || w,
      onClick: H.isExternal || y ? s : Ot,
      ref: Dv(G, gt),
      target: b,
      "data-discover": !N && r === "render" ? "true" : void 0
    });
    return zt && !N ? O.createElement(O.Fragment, null, Xt, O.createElement(Mv, {
      page: w
    })) : Xt;
  });
  Uh.displayName = "Link";
  var xv = O.forwardRef(function({ "aria-current": s = "page", caseSensitive: r = false, className: o = "", end: v = false, style: y, to: S, viewTransition: R, children: b, ...h }, C) {
    let _ = Yu(S, {
      relative: h.relative
    }), q = Ol(), Z = O.useContext(fi), { navigator: G, basename: Y } = O.useContext(re), L = Z != null && Qv(_) && R === true, N = G.encodeLocation ? G.encodeLocation(_).pathname : _.pathname, H = q.pathname, w = Z && Z.navigation && Z.navigation.location ? Z.navigation.location.pathname : null;
    r || (H = H.toLowerCase(), w = w ? w.toLowerCase() : null, N = N.toLowerCase()), w && Y && (w = tl(w, Y) || w);
    const zt = N !== "/" && N.endsWith("/") ? N.length - 1 : N.length;
    let gt = H === N || !v && H.startsWith(N) && H.charAt(zt) === "/", qt = w != null && (w === N || !v && w.startsWith(N) && w.charAt(N.length) === "/"), F = {
      isActive: gt,
      isPending: qt,
      isTransitioning: L
    }, Ot = gt ? s : void 0, Xt;
    typeof o == "function" ? Xt = o(F) : Xt = [
      o,
      gt ? "active" : null,
      qt ? "pending" : null,
      L ? "transitioning" : null
    ].filter(Boolean).join(" ");
    let Ee = typeof y == "function" ? y(F) : y;
    return O.createElement(Uh, {
      ...h,
      "aria-current": Ot,
      className: Xt,
      ref: C,
      style: Ee,
      to: S,
      viewTransition: R
    }, typeof b == "function" ? b(F) : b);
  });
  xv.displayName = "NavLink";
  var Nv = O.forwardRef(({ discover: c = "render", fetcherKey: s, navigate: r, reloadDocument: o, replace: v, state: y, method: S = ni, action: R, onSubmit: b, relative: h, preventScrollReset: C, viewTransition: _, unstable_defaultShouldRevalidate: q, ...Z }, G) => {
    let { unstable_useTransitions: Y } = O.useContext(re), L = Lv(), N = jv(R, {
      relative: h
    }), H = S.toLowerCase() === "get" ? "get" : "post", w = typeof R == "string" && Dh.test(R), zt = (gt) => {
      if (b && b(gt), gt.defaultPrevented) return;
      gt.preventDefault();
      let qt = gt.nativeEvent.submitter, F = (qt == null ? void 0 : qt.getAttribute("formmethod")) || S, Ot = () => L(qt || gt.currentTarget, {
        fetcherKey: s,
        method: F,
        navigate: r,
        replace: v,
        state: y,
        relative: h,
        preventScrollReset: C,
        viewTransition: _,
        unstable_defaultShouldRevalidate: q
      });
      Y && r !== false ? O.startTransition(() => Ot()) : Ot();
    };
    return O.createElement("form", {
      ref: G,
      method: H,
      action: N,
      onSubmit: o ? b : zt,
      ...Z,
      "data-discover": !w && c === "render" ? "true" : void 0
    });
  });
  Nv.displayName = "Form";
  function Hv(c) {
    return `${c} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
  }
  function xh(c) {
    let s = O.useContext(qa);
    return Et(s, Hv(c)), s;
  }
  function Bv(c, { target: s, replace: r, state: o, preventScrollReset: v, relative: y, viewTransition: S, unstable_defaultShouldRevalidate: R, unstable_useTransitions: b } = {}) {
    let h = Ah(), C = Ol(), _ = Yu(c, {
      relative: y
    });
    return O.useCallback((q) => {
      if (hv(q, s)) {
        q.preventDefault();
        let Z = r !== void 0 ? r : Hu(C) === Hu(_), G = () => h(c, {
          replace: Z,
          state: o,
          preventScrollReset: v,
          relative: y,
          viewTransition: S,
          unstable_defaultShouldRevalidate: R
        });
        b ? O.startTransition(() => G()) : G();
      }
    }, [
      C,
      h,
      _,
      r,
      o,
      s,
      c,
      v,
      y,
      S,
      R,
      b
    ]);
  }
  var qv = 0, Yv = () => `__${String(++qv)}__`;
  function Lv() {
    let { router: c } = xh("useSubmit"), { basename: s } = O.useContext(re), r = av(), o = c.fetch, v = c.navigate;
    return O.useCallback(async (y, S = {}) => {
      let { action: R, method: b, encType: h, formData: C, body: _ } = vv(y, s);
      if (S.navigate === false) {
        let q = S.fetcherKey || Yv();
        await o(q, r, S.action || R, {
          unstable_defaultShouldRevalidate: S.unstable_defaultShouldRevalidate,
          preventScrollReset: S.preventScrollReset,
          formData: C,
          body: _,
          formMethod: S.method || b,
          formEncType: S.encType || h,
          flushSync: S.flushSync
        });
      } else await v(S.action || R, {
        unstable_defaultShouldRevalidate: S.unstable_defaultShouldRevalidate,
        preventScrollReset: S.preventScrollReset,
        formData: C,
        body: _,
        formMethod: S.method || b,
        formEncType: S.encType || h,
        replace: S.replace,
        state: S.state,
        fromRouteId: r,
        flushSync: S.flushSync,
        viewTransition: S.viewTransition
      });
    }, [
      o,
      v,
      s,
      r
    ]);
  }
  function jv(c, { relative: s } = {}) {
    let { basename: r } = O.useContext(re), o = O.useContext(Ne);
    Et(o, "useFormAction must be used inside a RouteContext");
    let [v] = o.matches.slice(-1), y = {
      ...Yu(c || ".", {
        relative: s
      })
    }, S = Ol();
    if (c == null) {
      y.search = S.search;
      let R = new URLSearchParams(y.search), b = R.getAll("index");
      if (b.some((C) => C === "")) {
        R.delete("index"), b.filter((_) => _).forEach((_) => R.append("index", _));
        let C = R.toString();
        y.search = C ? `?${C}` : "";
      }
    }
    return (!c || c === ".") && v.route.index && (y.search = y.search ? y.search.replace(/^\?/, "?index&") : "?index"), r !== "/" && (y.pathname = y.pathname === "/" ? r : Pe([
      r,
      y.pathname
    ])), Hu(y);
  }
  function Qv(c, { relative: s } = {}) {
    let r = O.useContext(bh);
    Et(r != null, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
    let { basename: o } = xh("useViewTransitionState"), v = Yu(c, {
      relative: s
    });
    if (!r.isTransitioning) return false;
    let y = tl(r.currentLocation.pathname, o) || r.currentLocation.pathname, S = tl(r.nextLocation.pathname, o) || r.nextLocation.pathname;
    return ci(v.pathname, S) != null || ci(v.pathname, y) != null;
  }
  x1 = dh();
  const Gv = (c) => c.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), Xv = (c) => c.replace(/^([A-Z])|[\s-_]+(\w)/g, (s, r, o) => o ? o.toUpperCase() : r.toLowerCase()), ch = (c) => {
    const s = Xv(c);
    return s.charAt(0).toUpperCase() + s.slice(1);
  }, Nh = (...c) => c.filter((s, r, o) => !!s && s.trim() !== "" && o.indexOf(s) === r).join(" ").trim(), Zv = (c) => {
    for (const s in c) if (s.startsWith("aria-") || s === "role" || s === "title") return true;
  };
  var Vv = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  };
  const Kv = O.forwardRef(({ color: c = "currentColor", size: s = 24, strokeWidth: r = 2, absoluteStrokeWidth: o, className: v = "", children: y, iconNode: S, ...R }, b) => O.createElement("svg", {
    ref: b,
    ...Vv,
    width: s,
    height: s,
    stroke: c,
    strokeWidth: o ? Number(r) * 24 / Number(s) : r,
    className: Nh("lucide", v),
    ...!y && !Zv(R) && {
      "aria-hidden": "true"
    },
    ...R
  }, [
    ...S.map(([h, C]) => O.createElement(h, C)),
    ...Array.isArray(y) ? y : [
      y
    ]
  ]));
  const rt = (c, s) => {
    const r = O.forwardRef(({ className: o, ...v }, y) => O.createElement(Kv, {
      ref: y,
      iconNode: s,
      className: Nh(`lucide-${Gv(ch(c))}`, `lucide-${c}`, o),
      ...v
    }));
    return r.displayName = ch(c), r;
  };
  let Jv;
  Jv = [
    [
      "path",
      {
        d: "M17 7 7 17",
        key: "15tmo1"
      }
    ],
    [
      "path",
      {
        d: "M17 17H7V7",
        key: "1org7z"
      }
    ]
  ];
  N1 = rt("arrow-down-left", Jv);
  let wv;
  wv = [
    [
      "path",
      {
        d: "m12 19-7-7 7-7",
        key: "1l729n"
      }
    ],
    [
      "path",
      {
        d: "M19 12H5",
        key: "x3x0zl"
      }
    ]
  ];
  H1 = rt("arrow-left", wv);
  let $v;
  $v = [
    [
      "path",
      {
        d: "M7 7h10v10",
        key: "1tivn9"
      }
    ],
    [
      "path",
      {
        d: "M7 17 17 7",
        key: "1vkiza"
      }
    ]
  ];
  B1 = rt("arrow-up-right", $v);
  let kv;
  kv = [
    [
      "path",
      {
        d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
        key: "1yiouv"
      }
    ],
    [
      "circle",
      {
        cx: "12",
        cy: "8",
        r: "6",
        key: "1vp47v"
      }
    ]
  ];
  q1 = rt("award", kv);
  let Wv;
  Wv = [
    [
      "path",
      {
        d: "M15 13a3 3 0 1 0-6 0",
        key: "10j68g"
      }
    ],
    [
      "path",
      {
        d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
        key: "k3hazp"
      }
    ],
    [
      "circle",
      {
        cx: "12",
        cy: "8",
        r: "2",
        key: "1822b1"
      }
    ]
  ];
  Y1 = rt("book-user", Wv);
  let Fv;
  Fv = [
    [
      "path",
      {
        d: "M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",
        key: "pzmjnu"
      }
    ],
    [
      "path",
      {
        d: "M21.21 15.89A10 10 0 1 1 8 2.83",
        key: "k2fpak"
      }
    ]
  ];
  L1 = rt("chart-pie", Fv);
  let Iv;
  Iv = [
    [
      "path",
      {
        d: "M20 6 9 17l-5-5",
        key: "1gmf2c"
      }
    ]
  ];
  j1 = rt("check", Iv);
  let Pv;
  Pv = [
    [
      "path",
      {
        d: "m9 18 6-6-6-6",
        key: "mthhwq"
      }
    ]
  ];
  Q1 = rt("chevron-right", Pv);
  let t1;
  t1 = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "line",
      {
        x1: "12",
        x2: "12",
        y1: "8",
        y2: "12",
        key: "1pkeuh"
      }
    ],
    [
      "line",
      {
        x1: "12",
        x2: "12.01",
        y1: "16",
        y2: "16",
        key: "4dfq90"
      }
    ]
  ];
  G1 = rt("circle-alert", t1);
  let e1;
  e1 = [
    [
      "path",
      {
        d: "M21.801 10A10 10 0 1 1 17 3.335",
        key: "yps3ct"
      }
    ],
    [
      "path",
      {
        d: "m9 11 3 3L22 4",
        key: "1pflzl"
      }
    ]
  ];
  X1 = rt("circle-check-big", e1);
  let l1;
  l1 = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "path",
      {
        d: "m9 12 2 2 4-4",
        key: "dzmm74"
      }
    ]
  ];
  Z1 = rt("circle-check", l1);
  let a1;
  a1 = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "path",
      {
        d: "M8 12h8",
        key: "1wcyev"
      }
    ]
  ];
  V1 = rt("circle-minus", a1);
  let u1;
  u1 = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "path",
      {
        d: "m15 9-6 6",
        key: "1uzhvr"
      }
    ],
    [
      "path",
      {
        d: "m9 9 6 6",
        key: "z0biqf"
      }
    ]
  ];
  K1 = rt("circle-x", u1);
  let n1;
  n1 = [
    [
      "path",
      {
        d: "M12 6v6l4 2",
        key: "mmk7yg"
      }
    ],
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ]
  ];
  J1 = rt("clock", n1);
  let i1;
  i1 = [
    [
      "circle",
      {
        cx: "8",
        cy: "8",
        r: "6",
        key: "3yglwk"
      }
    ],
    [
      "path",
      {
        d: "M18.09 10.37A6 6 0 1 1 10.34 18",
        key: "t5s6rm"
      }
    ],
    [
      "path",
      {
        d: "M7 6h1v4",
        key: "1obek4"
      }
    ],
    [
      "path",
      {
        d: "m16.71 13.88.7.71-2.82 2.82",
        key: "1rbuyh"
      }
    ]
  ];
  w1 = rt("coins", i1);
  let c1;
  c1 = [
    [
      "rect",
      {
        width: "14",
        height: "14",
        x: "8",
        y: "8",
        rx: "2",
        ry: "2",
        key: "17jyea"
      }
    ],
    [
      "path",
      {
        d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
        key: "zix9uf"
      }
    ]
  ];
  $1 = rt("copy", c1);
  let f1;
  f1 = [
    [
      "path",
      {
        d: "M15 3h6v6",
        key: "1q9fwt"
      }
    ],
    [
      "path",
      {
        d: "M10 14 21 3",
        key: "gplh6r"
      }
    ],
    [
      "path",
      {
        d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
        key: "a6xqqp"
      }
    ]
  ];
  k1 = rt("external-link", f1);
  let o1;
  o1 = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "path",
      {
        d: "M12 16v-4",
        key: "1dtifu"
      }
    ],
    [
      "path",
      {
        d: "M12 8h.01",
        key: "e9boi3"
      }
    ]
  ];
  W1 = rt("info", o1);
  let r1;
  r1 = [
    [
      "path",
      {
        d: "M5 12h14",
        key: "1ays0h"
      }
    ],
    [
      "path",
      {
        d: "M12 5v14",
        key: "s699le"
      }
    ]
  ];
  F1 = rt("plus", r1);
  let s1;
  s1 = [
    [
      "rect",
      {
        width: "5",
        height: "5",
        x: "3",
        y: "3",
        rx: "1",
        key: "1tu5fj"
      }
    ],
    [
      "rect",
      {
        width: "5",
        height: "5",
        x: "16",
        y: "3",
        rx: "1",
        key: "1v8r4q"
      }
    ],
    [
      "rect",
      {
        width: "5",
        height: "5",
        x: "3",
        y: "16",
        rx: "1",
        key: "1x03jg"
      }
    ],
    [
      "path",
      {
        d: "M21 16h-3a2 2 0 0 0-2 2v3",
        key: "177gqh"
      }
    ],
    [
      "path",
      {
        d: "M21 21v.01",
        key: "ents32"
      }
    ],
    [
      "path",
      {
        d: "M12 7v3a2 2 0 0 1-2 2H7",
        key: "8crl2c"
      }
    ],
    [
      "path",
      {
        d: "M3 12h.01",
        key: "nlz23k"
      }
    ],
    [
      "path",
      {
        d: "M12 3h.01",
        key: "n36tog"
      }
    ],
    [
      "path",
      {
        d: "M12 16v.01",
        key: "133mhm"
      }
    ],
    [
      "path",
      {
        d: "M16 12h1",
        key: "1slzba"
      }
    ],
    [
      "path",
      {
        d: "M21 12v.01",
        key: "1lwtk9"
      }
    ],
    [
      "path",
      {
        d: "M12 21v-1",
        key: "1880an"
      }
    ]
  ];
  I1 = rt("qr-code", s1);
  let d1;
  d1 = [
    [
      "path",
      {
        d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
        key: "v9h5vc"
      }
    ],
    [
      "path",
      {
        d: "M21 3v5h-5",
        key: "1q7to0"
      }
    ],
    [
      "path",
      {
        d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
        key: "3uifl3"
      }
    ],
    [
      "path",
      {
        d: "M8 16H3v5",
        key: "1cv678"
      }
    ]
  ];
  P1 = rt("refresh-cw", d1);
  let h1;
  h1 = [
    [
      "path",
      {
        d: "m21 21-4.34-4.34",
        key: "14j7rj"
      }
    ],
    [
      "circle",
      {
        cx: "11",
        cy: "11",
        r: "8",
        key: "4ej97u"
      }
    ]
  ];
  tg = rt("search", h1);
  let m1;
  m1 = [
    [
      "path",
      {
        d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
        key: "1ffxy3"
      }
    ],
    [
      "path",
      {
        d: "m21.854 2.147-10.94 10.939",
        key: "12cjpa"
      }
    ]
  ];
  eg = rt("send", m1);
  let y1;
  y1 = [
    [
      "path",
      {
        d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
        key: "oel41y"
      }
    ],
    [
      "path",
      {
        d: "m9 12 2 2 4-4",
        key: "dzmm74"
      }
    ]
  ];
  lg = rt("shield-check", y1);
  let v1;
  v1 = [
    [
      "path",
      {
        d: "M10 11v6",
        key: "nco0om"
      }
    ],
    [
      "path",
      {
        d: "M14 11v6",
        key: "outv1u"
      }
    ],
    [
      "path",
      {
        d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
        key: "miytrc"
      }
    ],
    [
      "path",
      {
        d: "M3 6h18",
        key: "d0wm0j"
      }
    ],
    [
      "path",
      {
        d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
        key: "e791ji"
      }
    ]
  ];
  ag = rt("trash-2", v1);
  let g1;
  g1 = [
    [
      "path",
      {
        d: "M16 7h6v6",
        key: "box55l"
      }
    ],
    [
      "path",
      {
        d: "m22 7-8.5 8.5-5-5L2 17",
        key: "1t1m79"
      }
    ]
  ];
  ug = rt("trending-up", g1);
  let p1;
  p1 = [
    [
      "path",
      {
        d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
        key: "975kel"
      }
    ],
    [
      "circle",
      {
        cx: "12",
        cy: "7",
        r: "4",
        key: "17ys0d"
      }
    ]
  ];
  ng = rt("user", p1);
  let S1;
  S1 = [
    [
      "path",
      {
        d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
        key: "1yyitq"
      }
    ],
    [
      "path",
      {
        d: "M16 3.128a4 4 0 0 1 0 7.744",
        key: "16gr8j"
      }
    ],
    [
      "path",
      {
        d: "M22 21v-2a4 4 0 0 0-3-3.87",
        key: "kshegd"
      }
    ],
    [
      "circle",
      {
        cx: "9",
        cy: "7",
        r: "4",
        key: "nufk8"
      }
    ]
  ];
  ig = rt("users", S1);
  let b1;
  b1 = [
    [
      "path",
      {
        d: "m9 12 2 2 4-4",
        key: "dzmm74"
      }
    ],
    [
      "path",
      {
        d: "M5 7c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v12H5V7Z",
        key: "1ezoue"
      }
    ],
    [
      "path",
      {
        d: "M22 19H2",
        key: "nuriw5"
      }
    ]
  ];
  cg = rt("vote", b1);
  let E1;
  E1 = [
    [
      "path",
      {
        d: "M18 6 6 18",
        key: "1bl5f8"
      }
    ],
    [
      "path",
      {
        d: "m6 6 12 12",
        key: "d8bk6v"
      }
    ]
  ];
  fg = rt("x", E1);
  var Ha = {}, ui = {}, fh;
  function z1() {
    if (fh) return ui;
    fh = 1, Object.defineProperty(ui, "__esModule", {
      value: true
    });
    var c = Object.assign || function(h) {
      for (var C = 1; C < arguments.length; C++) {
        var _ = arguments[C];
        for (var q in _) Object.prototype.hasOwnProperty.call(_, q) && (h[q] = _[q]);
      }
      return h;
    }, s = sh(), r = y(s), o = Bu(), v = y(o);
    function y(h) {
      return h && h.__esModule ? h : {
        default: h
      };
    }
    function S(h, C) {
      var _ = {};
      for (var q in h) C.indexOf(q) >= 0 || Object.prototype.hasOwnProperty.call(h, q) && (_[q] = h[q]);
      return _;
    }
    var R = {
      bgColor: r.default.oneOfType([
        r.default.object,
        r.default.string
      ]).isRequired,
      bgD: r.default.string.isRequired,
      fgColor: r.default.oneOfType([
        r.default.object,
        r.default.string
      ]).isRequired,
      fgD: r.default.string.isRequired,
      size: r.default.number.isRequired,
      title: r.default.string,
      viewBoxSize: r.default.number.isRequired,
      xmlns: r.default.string
    }, b = (0, o.forwardRef)(function(h, C) {
      var _ = h.bgColor, q = h.bgD, Z = h.fgD, G = h.fgColor, Y = h.size, L = h.title, N = h.viewBoxSize, H = h.xmlns, w = H === void 0 ? "http://www.w3.org/2000/svg" : H, zt = S(h, [
        "bgColor",
        "bgD",
        "fgD",
        "fgColor",
        "size",
        "title",
        "viewBoxSize",
        "xmlns"
      ]);
      return v.default.createElement("svg", c({}, zt, {
        height: Y,
        ref: C,
        viewBox: "0 0 " + N + " " + N,
        width: Y,
        xmlns: w
      }), L ? v.default.createElement("title", null, L) : null, v.default.createElement("path", {
        d: q,
        fill: _
      }), v.default.createElement("path", {
        d: Z,
        fill: G
      }));
    });
    return b.displayName = "QRCodeSvg", b.propTypes = R, ui.default = b, ui;
  }
  var oh;
  function T1() {
    if (oh) return Ha;
    oh = 1, Object.defineProperty(Ha, "__esModule", {
      value: true
    }), Ha.QRCode = void 0;
    var c = Object.assign || function(Y) {
      for (var L = 1; L < arguments.length; L++) {
        var N = arguments[L];
        for (var H in N) Object.prototype.hasOwnProperty.call(N, H) && (Y[H] = N[H]);
      }
      return Y;
    }, s = sh(), r = _(s), o = n0(), v = _(o), y = u0(), S = _(y), R = Bu(), b = _(R), h = z1(), C = _(h);
    function _(Y) {
      return Y && Y.__esModule ? Y : {
        default: Y
      };
    }
    function q(Y, L) {
      var N = {};
      for (var H in Y) L.indexOf(H) >= 0 || Object.prototype.hasOwnProperty.call(Y, H) && (N[H] = Y[H]);
      return N;
    }
    var Z = {
      bgColor: r.default.oneOfType([
        r.default.object,
        r.default.string
      ]),
      fgColor: r.default.oneOfType([
        r.default.object,
        r.default.string
      ]),
      level: r.default.string,
      size: r.default.number,
      value: r.default.string.isRequired
    }, G = (0, R.forwardRef)(function(Y, L) {
      var N = Y.bgColor, H = N === void 0 ? "#FFFFFF" : N, w = Y.fgColor, zt = w === void 0 ? "#000000" : w, gt = Y.level, qt = gt === void 0 ? "L" : gt, F = Y.size, Ot = F === void 0 ? 256 : F, Xt = Y.value, Ee = q(Y, [
        "bgColor",
        "fgColor",
        "level",
        "size",
        "value"
      ]), Oe = new S.default(-1, v.default[qt]);
      Oe.addData(Xt), Oe.make();
      var ze = Oe.modules;
      return b.default.createElement(C.default, c({}, Ee, {
        bgColor: H,
        bgD: ze.map(function(el, Te) {
          return el.map(function(Ae, X) {
            return Ae ? "" : "M " + X + " " + Te + " l 1 0 0 1 -1 0 Z";
          }).join(" ");
        }).join(" "),
        fgColor: zt,
        fgD: ze.map(function(el, Te) {
          return el.map(function(Ae, X) {
            return Ae ? "M " + X + " " + Te + " l 1 0 0 1 -1 0 Z" : "";
          }).join(" ");
        }).join(" "),
        ref: L,
        size: Ot,
        viewBoxSize: ze.length
      }));
    });
    return Ha.QRCode = G, G.displayName = "QRCode", G.propTypes = Z, Ha.default = G, Ha;
  }
  var A1 = T1();
  og = rh(A1);
})();
export {
  B1 as A,
  Y1 as B,
  w1 as C,
  O1 as D,
  k1 as E,
  U1 as H,
  W1 as I,
  C1 as N,
  F1 as P,
  I1 as Q,
  M1 as R,
  eg as S,
  ug as T,
  ig as U,
  cg as V,
  fg as X,
  __tla,
  J1 as a,
  x1 as b,
  og as c,
  j1 as d,
  $1 as e,
  N1 as f,
  K1 as g,
  G1 as h,
  X1 as i,
  R1 as j,
  H1 as k,
  P1 as l,
  q1 as m,
  tg as n,
  lg as o,
  Q1 as p,
  Z1 as q,
  O as r,
  L1 as s,
  V1 as t,
  Ah as u,
  ng as v,
  ag as w,
  Ol as x,
  D1 as y,
  cv as z
};
