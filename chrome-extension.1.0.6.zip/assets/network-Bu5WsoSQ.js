var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { S as O, T as N } from "./vendor-Ds0KLgep.js";
const w = "lumen_vault_v1", S = "lumen_session_v1", E = "lumen_settings_v1", C = "lumen_wallet_keys", h = "session_keys", B = "vault_key", U = 300 * 1e3, _ = 31e4, V = "SHA-256", L = 12, M = 16, R = () => {
  var _a;
  return typeof chrome < "u" && !!((_a = chrome.storage) == null ? void 0 : _a.local);
}, T = () => {
  var _a;
  return typeof chrome < "u" && !!((_a = chrome.storage) == null ? void 0 : _a.session);
}, I = () => typeof indexedDB < "u", d = { get: async (r) => {
  if (R()) {
    const e = await chrome.storage.local.get(r);
    return e[r] ? JSON.parse(e[r]) : null;
  }
  const t = localStorage.getItem(r);
  return t ? JSON.parse(t) : null;
}, set: async (r, t) => {
  const e = JSON.stringify(t);
  R() ? await chrome.storage.local.set({ [r]: e }) : localStorage.setItem(r, e);
}, remove: async (r) => {
  R() ? await chrome.storage.local.remove(r) : localStorage.removeItem(r);
} }, k = () => new Promise((r, t) => {
  const e = indexedDB.open(C, 1);
  e.onupgradeneeded = () => {
    const s = e.result;
    s.objectStoreNames.contains(h) || s.createObjectStore(h);
  }, e.onsuccess = () => r(e.result), e.onerror = () => t(e.error);
}), G = async (r) => {
  const t = await k();
  await new Promise((e, s) => {
    const a = t.transaction(h, "readwrite");
    a.objectStore(h).put(r, B), a.oncomplete = () => {
      t.close(), e();
    }, a.onerror = () => {
      t.close(), s(a.error);
    };
  });
}, F = async () => {
  const r = await k();
  return new Promise((t, e) => {
    const a = r.transaction(h, "readonly").objectStore(h).get(B);
    a.onsuccess = () => {
      r.close(), t(a.result || null);
    }, a.onerror = () => {
      r.close(), e(a.error);
    };
  });
}, J = async () => {
  const r = await k();
  await new Promise((t, e) => {
    const s = r.transaction(h, "readwrite");
    s.objectStore(h).delete(B), s.oncomplete = () => {
      r.close(), t();
    }, s.onerror = () => {
      r.close(), e(s.error);
    };
  });
}, p = { get: async (r) => {
  if (T()) {
    const e = await chrome.storage.session.get(r);
    return e[r] ? JSON.parse(e[r]) : null;
  }
  const t = sessionStorage.getItem(r);
  return t ? JSON.parse(t) : null;
}, set: async (r, t) => {
  const e = JSON.stringify(t);
  T() ? await chrome.storage.session.set({ [r]: e }) : sessionStorage.setItem(r, e);
}, remove: async (r) => {
  T() ? await chrome.storage.session.remove(r) : sessionStorage.removeItem(r);
} }, D = (r) => {
  let t = "";
  for (let e = 0; e < r.length; e++) t += String.fromCharCode(r[e]);
  return btoa(t);
}, m = (r) => {
  const t = atob(r), e = new Uint8Array(t.length);
  for (let s = 0; s < t.length; s++) e[s] = t.charCodeAt(s);
  return e;
}, b = () => {
  if (typeof crypto > "u" || !crypto.subtle) throw new Error("WebCrypto is not available in this environment.");
  return crypto;
}, x = async (r, t, e) => {
  const s = b(), a = new TextEncoder(), n = new Uint8Array(t), o = await s.subtle.importKey("raw", a.encode(r), { name: "PBKDF2" }, false, ["deriveKey"]);
  return await s.subtle.deriveKey({ name: "PBKDF2", salt: n, iterations: e, hash: V }, o, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
};
let c = null;
const W = "lumen_session_key_jwk";
class H {
  static async persistSessionKey(t) {
    if (I()) try {
      await G(t);
    } catch (e) {
      console.error("Failed to persist session key:", e);
    }
  }
  static async restoreSessionKey() {
    if (!I()) return null;
    try {
      return await F();
    } catch (t) {
      return console.error("Failed to restore session key:", t), null;
    }
  }
  static async lock(t, e) {
    if (!c && !e && (c = await this.restoreSessionKey(), !c)) throw new Error("Wallet is locked.");
    const s = b(), a = new Uint8Array(s.getRandomValues(new Uint8Array(L)));
    let n, o, i;
    if (c) {
      const l = await d.get(w);
      if (!l || l.v !== 2) throw new Error("Vault metadata missing or unsupported.");
      n = new Uint8Array(m(l.saltB64)), o = l.iterations || _, i = c;
    } else n = new Uint8Array(s.getRandomValues(new Uint8Array(M))), o = _, i = await x(e, n, o), c = i, await this.persistSessionKey(i);
    const u = new TextEncoder().encode(JSON.stringify(t)), f = new Uint8Array(await s.subtle.encrypt({ name: "AES-GCM", iv: new Uint8Array(a) }, i, u)), g = { v: 2, kdf: "PBKDF2", hash: "SHA-256", iterations: o, saltB64: D(n), ivB64: D(a), ciphertextB64: D(f) };
    await d.set(w, g), await this.touchSession();
  }
  static async unlock(t) {
    const e = await d.get(w);
    if (!e) throw new Error("No wallet found.");
    if (e.v !== 2 && typeof e.data == "string") try {
      const n = O.decrypt(e.data, t).toString(N);
      if (!n) throw new Error("Decryption failed. Invalid password.");
      const o = JSON.parse(n), i = Array.isArray(o) ? o : [o];
      return await this.lock(i, t), i;
    } catch {
      throw new Error("Incorrect Password.");
    }
    const s = e;
    if (s.v !== 2) throw new Error("Unsupported vault format.");
    try {
      const a = b(), n = new Uint8Array(m(s.saltB64)), o = new Uint8Array(m(s.ivB64)), i = new Uint8Array(m(s.ciphertextB64)), u = await x(t, n, s.iterations || _), f = await a.subtle.decrypt({ name: "AES-GCM", iv: new Uint8Array(o) }, u, i), g = new TextDecoder().decode(new Uint8Array(f)), l = JSON.parse(g), A = Array.isArray(l) ? l : [l];
      return c = u, await this.persistSessionKey(u), await this.touchSession(), A;
    } catch {
      throw new Error("Incorrect Password.");
    }
  }
  static async getWallets() {
    if (c || (c = await this.restoreSessionKey()), !c) throw new Error("Session expired.");
    const t = await d.get(w);
    if (!t) throw new Error("No wallet found.");
    if (t.v !== 2) throw new Error("Unsupported vault format.");
    const e = b(), s = new Uint8Array(m(t.ivB64)), a = new Uint8Array(m(t.ciphertextB64)), n = await e.subtle.decrypt({ name: "AES-GCM", iv: new Uint8Array(s) }, c, a), o = new TextDecoder().decode(new Uint8Array(n)), i = JSON.parse(o);
    return Array.isArray(i) ? i : [i];
  }
  static async saveWallets(t) {
    await this.lock(t);
  }
  static async setLockTimeout(t, e) {
    let s = U;
    t === "minute" && (s = e * 60 * 1e3), t === "hour" && (s = e * 60 * 60 * 1e3), t === "day" && (s = e * 24 * 60 * 60 * 1e3);
    const a = { lockTimeoutMsg: s, lockType: t, lockValue: e };
    await d.set(E, a);
  }
  static async getLockSettings() {
    const t = await d.get(E);
    return t ? { type: t.lockType || "minute", value: t.lockValue || 5 } : { type: "minute", value: 5 };
  }
  static async getLockTimeout() {
    var _a;
    return ((_a = await d.get(E)) == null ? void 0 : _a.lockTimeoutMsg) || U;
  }
  static async hasWallet() {
    return !!await d.get(w);
  }
  static async clear() {
    await d.remove(w), await this.clearSession(), await d.remove(E);
  }
  static async isSessionExpired() {
    const t = await p.get(S);
    if (!t) return true;
    const e = await this.getLockTimeout();
    return Date.now() - t.lastActiveAt > e;
  }
  static async touchSession() {
    const t = await p.get(S);
    t ? (t.lastActiveAt = Date.now(), await p.set(S, t)) : await p.set(S, { lastActiveAt: Date.now() });
  }
  static async clearSession() {
    if (c = null, await p.remove(S), await p.remove(W), I()) try {
      await J();
    } catch (t) {
      console.error("Failed to clear session key:", t);
    }
  }
  static async removeWallet(t) {
    const s = (await this.getWallets()).filter((a) => a.address !== t);
    return s.length === 0 ? (await this.clear(), []) : (await this.saveWallets(s), s);
  }
}
const P = [{ address: "https://rpc.cosmos.directory/lumen", provider: "CosmosDirectory" }, { address: "https://rpc.lumen.chaintools.tech", provider: "ChainTools" }, { address: "https://lumen.blocksync.me/rpc", provider: "BlockSync" }, { address: "https://lumen-mainnet-rpc.mekonglabs.com", provider: "MekongLabs" }, { address: "https://rpc-lumen.onenov.xyz", provider: "OneNov" }], y = [{ address: "https://rest.cosmos.directory/lumen", provider: "CosmosDirectory" }, { address: "https://lumen-api.node9x.com", provider: "node9x" }, { address: "https://api.lumen.chaintools.tech", provider: "ChainTools" }, { address: "https://lumen-mainnet-api.mekonglabs.com", provider: "MekongLabs" }], K = "lumen";
const _v = class _v {
  constructor() {
    __publicField(this, "currentRpc", P[0].address);
    __publicField(this, "currentRest", y[0].address);
    __publicField(this, "isAuto", true);
    __publicField(this, "manualProvider", null);
    __publicField(this, "lastUpdate", 0);
    __publicField(this, "UPDATE_INTERVAL", 300 * 1e3);
    this.loadSettings();
  }
  static getInstance() {
    return _v.instance || (_v.instance = new _v()), _v.instance;
  }
  async loadSettings() {
    if (typeof chrome < "u" && chrome.storage) {
      const e = (await chrome.storage.local.get(["rpc_settings"])).rpc_settings;
      if (e && (this.isAuto = e.isAuto ?? true, this.manualProvider = e.manualProvider ?? null, !this.isAuto && this.manualProvider)) {
        const s = P.find((n) => n.provider === this.manualProvider), a = y.find((n) => n.provider === this.manualProvider);
        if (!s && !a) {
          this.isAuto = true, this.manualProvider = null;
          return;
        }
        s && (this.currentRpc = s.address), a && (this.currentRest = a.address);
      }
    }
  }
  async saveSettings() {
    typeof chrome < "u" && chrome.storage && await chrome.storage.local.set({ rpc_settings: { isAuto: this.isAuto, manualProvider: this.manualProvider } });
  }
  async getRpcEndpoint() {
    var _a;
    this.isAuto && await this.refreshIfNecessary();
    const t = (_a = y.find((s) => s.address === this.currentRest)) == null ? void 0 : _a.provider, e = P.find((s) => s.provider === t);
    return e ? e.address : this.currentRpc;
  }
  async getRestEndpoint(t = false) {
    return this.isAuto && await this.refreshIfNecessary(t), this.currentRest;
  }
  getQuickRestEndpoint() {
    return y[0].address;
  }
  async sync() {
    this.isAuto && await this.refreshBestRpc(true);
  }
  setAuto(t) {
    if (this.isAuto = t, t) this.refreshBestRpc(true);
    else if (this.manualProvider) {
      const e = y.find((s) => s.provider === this.manualProvider);
      e && (this.currentRest = e.address);
    }
    this.saveSettings();
  }
  setManualProvider(t) {
    this.isAuto = false, this.manualProvider = t;
    const e = y.find((s) => s.provider === t);
    e && (this.currentRest = e.address), this.saveSettings();
  }
  isAutoMode() {
    return this.isAuto;
  }
  getSelectedProvider() {
    return this.isAuto ? "Auto" : this.manualProvider;
  }
  async refreshIfNecessary(t = false) {
    const e = Date.now();
    (t || e - this.lastUpdate > this.UPDATE_INTERVAL) && await this.refreshBestRpc(t);
  }
  async refreshBestRpc(t = false) {
    if (!this.isAuto && !t) return;
    const s = (await Promise.allSettled(y.map(async (n) => {
      var _a, _b, _c, _d;
      const o = Date.now(), i = await fetch(`${n.address.replace(/\/$/, "")}/cosmos/base/tendermint/v1beta1/blocks/latest`, { signal: AbortSignal.timeout(3e3) });
      if (!i.ok) throw new Error("Block fetch failed");
      const u = await i.json(), f = parseInt(((_b = (_a = u.block) == null ? void 0 : _a.header) == null ? void 0 : _b.height) || "0"), g = (_d = (_c = u.block) == null ? void 0 : _c.header) == null ? void 0 : _d.chain_id, l = await fetch(`${n.address.replace(/\/$/, "")}/cosmos/base/tendermint/v1beta1/syncing`, { signal: AbortSignal.timeout(2e3) });
      let A = false;
      return l.ok && (A = (await l.json()).syncing === true), { provider: n.provider, address: n.address, height: f, latency: Date.now() - o, isSyncing: A, chainId: g };
    }))).filter((n) => n.status === "fulfilled").map((n) => n.value).filter((n) => {
      const o = String(n.chainId || "").toLowerCase();
      return (o === K || o.startsWith(`${K}-`)) && n.height > 0 && !n.isSyncing;
    });
    if (s.length === 0) return;
    const a = s.sort((n, o) => o.height - n.height || n.latency - o.latency);
    if (s.length >= 3 || t && s.length > 0) {
      const n = a[0];
      this.currentRest = n.address, this.lastUpdate = Date.now();
    } else if (t) {
      const n = a[0];
      this.currentRest = n.address, this.lastUpdate = Date.now();
    }
  }
};
__publicField(_v, "instance");
let v = _v;
export {
  v as N,
  y as R,
  H as V,
  P as a
};
